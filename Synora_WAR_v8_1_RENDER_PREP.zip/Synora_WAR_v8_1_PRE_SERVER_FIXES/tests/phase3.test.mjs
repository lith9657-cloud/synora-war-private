/**
 * Synora WAR v5 — PHASE 3: the test suite.
 *
 * The tests check the PROPERTIES the Phase-3 conclusions depend on:
 *   - the answer key is unreachable from the solver,
 *   - the memory file survives a process boundary and carries no answers,
 *   - the memory can be removed / replaced by noise (the falsification controls),
 *   - the held-out group C is not referenced anywhere in the solver's code,
 *   - the budget is respected and the search is deterministic.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { Ledger } from '../synora-v5/ledger.mjs';
import { Grader } from '../synora-v5/phase3/grader.mjs';
import { PstEngine } from '../synora-v5/phase3/engine.mjs';
import { TASKS, byId, byGroup, taskInput } from '../synora-v5/phase3/tasks.mjs';
import { PLANS } from '../synora-v5/phase3/secrets.mjs';
import { saveMemory, loadMemory, scanMemoryForAnswers } from '../synora-v5/phase3/memory.mjs';
import { defectFamilies, similarity, similarityReport, median } from '../synora-v5/phase3/analysis.mjs';
import { insertCall, insertCallArg } from '../synora-v5/phase3/operators.mjs';
import { TOOLS, WORKSPACE, VALUE_POOL } from '../synora-v5/pst/environment.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(HERE, '..');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'p3-test-'));

let passed = 0, failed = 0;
const failures = [];

async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  ok  ${name}`);
  } catch (err) {
    failed++;
    failures.push({ name, err });
    console.log(`  FAIL ${name}: ${err.message}`);
  }
}

function buildFromPlan(plan) {
  let expr = 'input';
  for (const call of plan.calls) {
    const [name, ...args] = call;
    const contract = TOOLS[name].args;
    const parts = args.map(a => JSON.stringify(a));
    if (contract[0] === 'entries' || contract[0] === 'text') parts.unshift(expr);
    expr = `${name}(${parts.join(', ')})`;
  }
  if (plan.field === 'length') expr += '.length';
  else if (plan.field) expr += `.${plan.field}`;
  return `function solution(input){return ${expr}}`;
}

const grader = new Grader({ size: 2, timeoutMs: 700 });
await grader.init();

/**
 * Tokens that are PUBLIC by construction: the workspace file names, the public value pool and
 * the tool names. An "answer" that consists of public tokens cannot be a leak — the solver
 * could compose it from public information. Only answers that are NOT public tokens matter.
 */
const PUBLIC_TOKENS = new Set([
  ...WORKSPACE.map(w => w.name),
  ...VALUE_POOL.map(v => String(v)),
  ...Object.keys(TOOLS),
]);
const isPublicAnswer = v => typeof v === 'string' && PUBLIC_TOKENS.has(v);

/* ------------------------------------------------------------------ structure */

await test('tasks: 19 tasks in three groups (7 acquisition / 6 generalisation / 6 held out)', () => {
  assert.equal(TASKS.length, 19);
  assert.equal(byGroup('A').length, 7);
  assert.equal(byGroup('B').length, 6);
  assert.equal(byGroup('C').length, 6);
});

await test('grader: every reference program is perfect and every seed is wrong', async () => {
  for (const task of TASKS) {
    const ref = await grader.grade(buildFromPlan(PLANS[task.id]), task, null);
    assert.ok(ref.private.full, `${task.id} reference must be perfect`);
    const seed = await grader.grade(task.seed, task, null);
    assert.ok(!seed.private.full, `${task.id} seed must not be perfect`);
  }
});

await test('no-leak: the solver-side modules never import the answer key', () => {
  // the SOLVER side (engine, operators, tasks, memory) must never see the answer key.
  // analysis.mjs is deliberately allowed to read it: it is an offline measuring instrument,
  // and it must not be reachable from the solver either.
  for (const file of ['engine.mjs', 'operators.mjs', 'tasks.mjs', 'memory.mjs']) {
    const source = fs.readFileSync(path.join(ROOT, 'synora-v5', 'phase3', file), 'utf8');
    assert.ok(!/from '\.\/secrets\.mjs'/.test(source), `${file} imports secrets.mjs`);
    assert.ok(!/analysis\.mjs/.test(source), `${file} imports the analysis module`);
  }
  const graderSource = fs.readFileSync(path.join(ROOT, 'synora-v5', 'phase3', 'grader.mjs'), 'utf8');
  assert.ok(/from '\.\/secrets\.mjs'/.test(graderSource));
});

await test('no-leak: the grader never returns the expected value to the solver', async () => {
  for (const task of TASKS) {
    const result = await grader.grade(task.seed, task, taskInput(task));
    const serialised = JSON.stringify(result.public);
    assert.ok(!serialised.includes('expected'), `${task.id} leaks the field name`);
    const expected = result.private.expected;
    // the candidate's OWN output is legitimately visible; the ANSWER must not be
    const withoutOutput = JSON.stringify({ ...result.public, output: undefined });
    if (typeof expected === 'string' && !isPublicAnswer(expected)) {
      assert.ok(!withoutOutput.includes(expected), `${task.id} leaks the answer`);
    }
    if (expected && typeof expected === 'object') {
      for (const v of Object.values(expected)) {
        if (typeof v === 'string') assert.ok(!serialised.includes(v), `${task.id} leaks ${v}`);
      }
    }
  }
});

await test('no-leak: a saved memory file contains no expected value of ANY group', async () => {
  const ledger = new Ledger();
  const engine = new PstEngine({ grader, ledger, mode: 'cri', seed: 2, budget: 120, generations: 40 });
  await engine.runTask(byId('A1_names3_txt'));
  const file = path.join(TMP, 'memory.json');
  saveMemory(ledger, file, { seed: 2 });
  const expected = TASKS.map(t => Grader.expectedValue(t, taskInput(t))).filter(v => v !== undefined && v !== null);
  const hits = scanMemoryForAnswers(file, expected.filter(v => !isPublicAnswer(v)));
  assert.deepEqual(hits, [], `the memory leaked: ${JSON.stringify(hits)}`);
});

await test('no-leak: the held-out group C never appears in the solver-side code', () => {
  for (const file of ['engine.mjs', 'operators.mjs', 'memory.mjs']) {
    const source = fs.readFileSync(path.join(ROOT, 'synora-v5', 'phase3', file), 'utf8');
    for (const id of byGroup('C').map(t => t.id)) {
      assert.ok(!source.includes(id), `${file} mentions the held-out task ${id}`);
    }
  }
});

/* ------------------------------------------------------------------ persistence */

await test('persistence: save → load round-trips the ledger exactly', async () => {
  const ledger = new Ledger();
  const engine = new PstEngine({ grader, ledger, mode: 'cri', seed: 4, budget: 120, generations: 40 });
  await engine.runTask(byId('A2_ext_sum_csv'));
  const file = path.join(TMP, 'roundtrip.json');
  const saved = saveMemory(ledger, file, { seed: 4 });
  const loaded = loadMemory(file);
  assert.equal(loaded.skills, saved.skills);
  assert.equal(loaded.ledger.skills.size, ledger.skills.size);
  const a = [...ledger.skills.values()].map(s => `${s.signature}::${s.transformId}::${s.credit}`).sort();
  const b = [...loaded.ledger.skills.values()].map(s => `${s.signature}::${s.transformId}::${s.credit}`).sort();
  assert.deepEqual(a, b, 'the restored skills differ from the saved ones');
});

await test('persistence: the memory file is written by one process and read by another', () => {
  const file = path.join(TMP, 'cross-process.json');
  const write = execFileSync(process.execPath, [
    path.join(ROOT, 'synora-v5', 'phase3', 'acquire.mjs'),
    '--seed=3', '--budget=60', '--generations=30', `--out=${file}`,
  ], { cwd: ROOT, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
  const receipt = JSON.parse(write);
  assert.ok(receipt.memory.sha256, 'no integrity hash in the receipt');
  const loaded = loadMemory(file);
  assert.ok(loaded.skills > 0, 'the restored memory has no skills');
  assert.notEqual(receipt.pid, process.pid, 'the acquisition ran in this process — that defeats the test');
});

await test('persistence: a corrupted memory file is rejected, not silently loaded', async () => {
  const ledger = new Ledger();
  ledger.noteSuccess({ taskId: 'x', signature: 's', transformId: 't', gen: 1 });
  const file = path.join(TMP, 'corrupt.json');
  saveMemory(ledger, file, { seed: 1 });
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  raw.ledger.skills[0].credit = 999;                   // tamper
  fs.writeFileSync(file, JSON.stringify(raw));
  assert.throws(() => loadMemory(file), /integrity/);
});

await test('persistence: the restored memory changes what the engine does', async () => {
  const ledger = new Ledger();
  const engine = new PstEngine({ grader, ledger, mode: 'cri', seed: 5, budget: 150, generations: 40 });
  await engine.runTask(byId('A1_names3_txt'));
  const file = path.join(TMP, 'usable.json');
  saveMemory(ledger, file, { seed: 5 });
  const restored = loadMemory(file).ledger;
  const cold = new PstEngine({ grader, ledger: new Ledger(), mode: 'cri', seed: 5, budget: 150, generations: 40 });
  const warm = new PstEngine({ grader, ledger: restored, mode: 'cri', seed: 5, budget: 150, generations: 40 });
  const coldResult = await cold.runTask(byId('C1_two_filter_one'));
  const warmResult = await warm.runTask(byId('C1_two_filter_one'));
  assert.ok(warmResult.success, 'the warm engine should solve the held-out task');
  assert.ok(warmResult.evaluations < coldResult.evaluations,
    `the warm engine was not faster (${warmResult.evaluations} vs ${coldResult.evaluations})`);
});

/* ------------------------------------------------------------------ falsification */

await test('falsification: removing the memory returns the engine to the cold behaviour', async () => {
  const task = byId('C6_txt_two_names');
  const ledger = new Ledger();
  const learner = new PstEngine({ grader, ledger, mode: 'cri', seed: 6, budget: 150, generations: 40 });
  await learner.runTask(byId('A1_names3_txt'));
  // the same seed, but the memory is emptied before the task: the two must agree exactly
  const cold = new PstEngine({ grader, ledger: new Ledger(), mode: 'cri', seed: 6, budget: 150, generations: 40 });
  const rCold = await cold.runTask(task);
  const emptyButSame = new PstEngine({ grader, ledger: new Ledger(), mode: 'cri', seed: 6, budget: 150, generations: 40 });
  const rEmpty = await emptyButSame.runTask(task);
  assert.equal(rEmpty.evaluations, rCold.evaluations, 'without memory the engines must agree');
  // with the populated memory the same task must be cheaper
  const warm = new PstEngine({ grader, ledger, mode: 'cri', seed: 6, budget: 150, generations: 40 });
  const rWarm = await warm.runTask(task);
  assert.ok(rWarm.evaluations < rCold.evaluations,
    `the warm engine should need fewer evaluations (${rWarm.evaluations} vs ${rCold.evaluations})`);
});

await test('falsification: a noise memory is NOT better than no memory', async () => {
  const task = byId('C4_sort_size_desc_names');
  const ledger = new Ledger();
  const learn = new PstEngine({ grader, ledger, mode: 'cri', seed: 7, budget: 150, generations: 40 });
  await learn.runTask(byId('A6_sort_by_name'));
  const noise = new PstEngine({ grader, ledger, mode: 'noise', seed: 7, budget: 150, generations: 40 });
  const real = new PstEngine({ grader, ledger, mode: 'cri', seed: 7, budget: 150, generations: 40 });
  const rNoise = await noise.runTask(task);
  const rReal = await real.runTask(task);
  assert.ok(rReal.evaluations < rNoise.evaluations,
    `the real memory should beat the noise memory (${rReal.evaluations} vs ${rNoise.evaluations})`);
});

await test('falsification: the same budget is used by every arm', async () => {
  const budget = 40;
  for (const mode of ['base', 'cri', 'noise']) {
    const engine = new PstEngine({ grader, ledger: new Ledger(), mode, seed: 8, budget, generations: 30 });
    const result = await engine.runTask(byId('B1_two_filter_names'));
    assert.ok(result.evaluations <= budget + 1, `${mode} exceeded the budget: ${result.evaluations}`);
  }
});

await test('determinism: the same seed gives the same result', async () => {
  const run = async () => {
    const engine = new PstEngine({ grader, ledger: new Ledger(), mode: 'cri', seed: 11, budget: 80, generations: 30 });
    const r = await engine.runTask(byId('B6_md_largest_one'));
    return `${r.success}|${r.evaluations}|${r.champion.code}`;
  };
  assert.equal(await run(), await run());
});

/* ------------------------------------------------------------------ diversity */

await test('diversity: the analytic defect families are computed for every task', () => {
  for (const task of TASKS) {
    const families = defectFamilies(task.id);
    assert.ok(families.length > 0, `${task.id} has no detected defect`);
  }
});

await test('diversity: most B and C tasks are NOT clones of an A task', () => {
  const report = similarityReport();
  const novel = Object.entries(report.classes).filter(([, v]) => v.group !== 'A' && v.class === 'cross_structure');
  assert.ok(novel.length >= 8, `only ${novel.length} cross-structure tasks — not enough diversity`);
  for (const [id, v] of Object.entries(report.classes)) {
    if (v.group === 'A') continue;
    assert.ok(v.maxSimInA < 0.95, `${id} is a clone of an A task`);
  }
});

await test('diversity: the similarity metric separates different structures', () => {
  assert.ok(similarity('A1_names3_txt', 'B1_two_filter_names') < 0.9);
  assert.ok(similarity('A2_ext_sum_csv', 'B6_md_largest_one') < 0.9);
  assert.equal(similarity('A1_names3_txt', 'A1_names3_txt'), 1);
});

/* ------------------------------------------------------------------ operators */

await test('operators: the insertion happens at the right point of the pipeline', () => {
  const filePipeline = "function solution(input){return joinNames(sortBy(listDir(),'size','desc'),'-')}";
  assert.equal(insertCall(filePipeline, 'filterByExt'),
    "function solution(input){return joinNames(sortBy(filterByExt(listDir()),'size','desc'),'-')}");
  const textPipeline = 'function solution(input){return toArabicDigits(input)}';
  assert.equal(insertCall(textPipeline, 'normalizeSpaces'),
    'function solution(input){return toArabicDigits(normalizeSpaces(input))}');
});

await test('operators: the inserted call can carry a value', () => {
  const seed = "function solution(input){return sumSize(listDir())}";
  const code = insertCallArg(seed, 'filterByExt', 'ext', 'md');
  assert.equal(code, "function solution(input){return sumSize(filterByExt(listDir(),'md'))}");
});

await test('the Phase-2 package is untouched by Phase 3', () => {
  const pstOperators = fs.readFileSync(path.join(ROOT, 'synora-v5', 'pst', 'operators.mjs'), 'utf8');
  assert.ok(!/insertCallArg/.test(pstOperators), 'Phase 2 operators were modified');
  assert.ok(!/phase3/.test(pstOperators), 'Phase 2 operators mention phase3');
  const pstEngine = fs.readFileSync(path.join(ROOT, 'synora-v5', 'pst', 'engine.mjs'), 'utf8');
  assert.ok(!/noise/.test(pstEngine), 'Phase 2 engine was modified');
});

await grader.close();
fs.rmSync(TMP, { recursive: true, force: true });

console.log(`\n${passed} passed, ${failed} failed`);
if (failed) {
  for (const f of failures) console.log(`\n--- ${f.name}\n${f.err.stack}`);
  process.exit(1);
}
