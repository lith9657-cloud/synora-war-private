import { AdaptivePstEngine } from '../synora-v5/phase4/adaptive-engine.mjs';
import { Ledger } from '../synora-v5/ledger.mjs';

let passed = 0, failed = 0;
function check(name, fn) { try { fn(); passed++; console.log(`ok ${name}`); } catch (e) { failed++; console.error(`FAIL ${name}: ${e.message}`); } }
function engine({budget=40, hint='asc'}={}) {
  const ledger = new Ledger();
  ledger.skills.set('fixture-skill', { verified: true, hint: { key: 'SET_ARG:sortBy:dir', value: hint } });
  return new AdaptivePstEngine({ ledger, mode:'adaptive', budget, generations:1, grader:null });
}
const key = 'SET_ARG:sortBy:dir';
check('uses a unique verified hint at low budget before evidence', () => { if (engine().hintFor(key) !== 'asc') throw Error('expected asc'); });
check('abstains from inherited value hints at budget 80', () => { if (engine({budget:80}).hintFor(key) !== null) throw Error('expected abstention'); });
check('abstains after two misses for this exact hint when misses exceed hits', () => { const e=engine(); e.recordHintOutcome({key,value:'asc',context:'sort',success:false}); e.recordHintOutcome({key,value:'asc',context:'sort',success:false}); if(e.hintFor(key)!==null) throw Error('expected abstention'); });
check('does not abstain when successes tie misses for this hint', () => { const e=engine(); for(const success of [false,false,true,true]) e.recordHintOutcome({key,value:'asc',context:'sort',success}); if(e.hintFor(key)!=='asc') throw Error('unexpected abstention'); });
check('does not disable a hint after one transient miss', () => { const e=engine(); e.recordHintOutcome({key,value:'asc',context:'sort',success:false}); if(e.hintFor(key)!=='asc') throw Error('single miss should not disable hint'); });
check('ignores unverified skills', () => { const e=engine(); e.ledger.skills.set('fixture-skill',{verified:false,hint:{key,value:'asc'}}); if(e.hintFor(key)!==null) throw Error('unverified hint used'); });
check('bad evidence for one value does not poison a different value', () => { const e=engine(); e.recordHintOutcome({key,value:'desc',context:'sort',success:false}); e.recordHintOutcome({key,value:'desc',context:'sort',success:false}); if(e.hintFor(key)!=='asc') throw Error('evidence leaked across values'); });
check('tracks outcomes by context as well as hint identity', () => { const e=engine(); e.recordHintOutcome({key,value:'asc',context:'sort',success:true}); e.recordHintOutcome({key,value:'asc',context:'filter',success:false}); const ev=e.hintEvidence.get(e._hintId(key,'asc')); if(ev.contexts.get('sort').hits!==1 || ev.contexts.get('filter').misses!==1) throw Error('context evidence missing'); });
check('failures in separate contexts do not poison a different active context', () => { const e=engine(); e.recordHintOutcome({key,value:'asc',context:'sort',success:false}); e.recordHintOutcome({key,value:'asc',context:'filter',success:false}); if(e.hintFor(key,'sort')!=='asc') throw Error('two cross-context misses must not suppress sort hint'); });
check('repeated failures in the active context trigger abstention', () => { const e=engine(); e.recordHintOutcome({key,value:'asc',context:'sort',success:false}); e.recordHintOutcome({key,value:'asc',context:'sort',success:false}); if(e.hintFor(key,'sort')!==null) throw Error('expected context-local abstention'); });
check('a useful context remains usable when another context has repeated misses', () => { const e=engine(); e.recordHintOutcome({key,value:'asc',context:'sort',success:true}); for(let i=0;i<3;i++) e.recordHintOutcome({key,value:'asc',context:'filter',success:false}); if(e.hintFor(key,'sort')!=='asc') throw Error('useful context poisoned'); if(e.hintFor(key,'filter')!==null) throw Error('bad context should abstain'); });
check('unknown context with no evidence does not inherit negative evidence', () => { const e=engine(); for(let i=0;i<3;i++) e.recordHintOutcome({key,value:'asc',context:'sort',success:false}); if(e.hintFor(key,'other-context')!=='asc') throw Error('unknown context should not inherit misses'); });
check('conflicting evidence inside one context abstains only when misses dominate', () => { const e=engine(); for(const success of [true,false,false]) e.recordHintOutcome({key,value:'asc',context:'sort',success}); if(e.hintFor(key,'sort')!==null) throw Error('expected conservative abstention'); });
check('duplicate event IDs are counted once', () => { const e=engine(); e.recordHintOutcome({key,value:'asc',context:'sort',success:false,eventId:'evt-1'}); e.recordHintOutcome({key,value:'asc',context:'sort',success:false,eventId:'evt-1'}); const ev=e.hintEvidence.get(e._hintId(key,'asc')); if(ev.misses!==1 || ev.contexts.get('sort').misses!==1) throw Error('duplicate counted twice'); });
check('empty and malformed evidence is ignored safely', () => { const e=engine(); e.recordHintOutcome({key:null,value:'asc',context:'sort',success:false}); e.recordHintOutcome({key,value:undefined,context:'sort',success:false}); e.recordHintOutcome({key,value:'asc',context:'sort',success:'false'}); if(e.hintEvidence.size!==0) throw Error('malformed evidence recorded'); });
check('does not apply adaptive abstention in CRI mode', () => { const e=engine(); e.mode='cri'; e.recordHintOutcome({key,value:'asc',context:'sort',success:false}); e.recordHintOutcome({key,value:'asc',context:'sort',success:false}); if(e.hintFor(key)!=='asc') throw Error('adaptive policy leaked into cri mode'); });
console.log(`\n${passed} passed, ${failed} failed`);
if (failed) process.exit(1);
