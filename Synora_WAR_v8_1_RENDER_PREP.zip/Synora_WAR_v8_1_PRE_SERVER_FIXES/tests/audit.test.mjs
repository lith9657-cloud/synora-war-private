/**
 * Synora WAR v5 — AUDIT test suite.
 *
 * The tests that decide whether the project may be trusted. They check the properties the
 * scientific claims depend on — NOT the claims themselves:
 *
 *   1. the files of the earlier phases are not silently modified,
 *   2. the memory round-trips, and a tampered memory is rejected,
 *   3. no reference answer can reach the solver or the memory file,
 *   4. the held-out group C never leaks into the development side,
 *   5. the grader judges the RESULT, not a string that looks like the answer,
 *   6. the raw results agree with the numbers printed in the reports,
 *   7. the statistics are computed on paired units and behave correctly on known inputs,
 *   8. errors, timeouts and missing files are handled explicitly,
 *   9. the package contains everything the README promises, and nothing local-only.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { Ledger } from '../synora-v5/ledger.mjs';
import { Grader } from '../synora-v5/phase3/grader.mjs';
import { PstEngine } from '../synora-v5/phase3/engine.mjs';
import { TASKS, byId, byGroup, taskInput } from '../synora-v5/phase3/tasks.mjs';
import { PLANS } from '../synora-v5/phase3/secrets.mjs';
import { saveMemory, loadMemory, scanMemoryForAnswers } from '../synora-v5/phase3/memory.mjs';
import { phase3Tables, phase2Tables } from '../synora-v5/phase3/report-tables.mjs';
import { pairedBootstrap, mcnemarExact, wilcoxonSignedRank, holmBonferroni, median } from '../synora-v5/stats.mjs';
import { TOOLS, WORKSPACE, VALUE_POOL } from '../synora-v5/pst/environment.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(HERE, '..');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'audit-'));

let passed = 0, failed = 0;
const failures = [];

async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  ok  ${name}`);
  } catch (err) {
    failed++;
    failures.push({ name, err });
    console.log(`  FAIL ${name}: ${err.message}`);
  }
}

const PUBLIC_TOKENS = new Set([
  ...WORKSPACE.map(w => w.name),
  ...VALUE_POOL.map(v => String(v)),
  ...Object.keys(TOOLS),
]);
const isPublicAnswer = v => typeof v === 'string' && PUBLIC_TOKENS.has(v);

const grader = new Grader({ size: 2, timeoutMs: 700 });
await grader.init();

/* ------------------------------------------------- 1. earlier phases untouched */

await test('audit: the immutable baseline files are byte-identical to the audited snapshot', () => {
  const baselinePath = path.join(ROOT, 'audit', 'immutable-baseline.json');
  assert.ok(fs.existsSync(baselinePath), 'audit/immutable-baseline.json is missing');
  const baseline = JSON.parse(fs.readFileSync(baselinePath, 'utf8'));
  const changed = [];
  for (const [rel, entry] of Object.entries(baseline.files)) {
    // Stage 2 intentionally refactored this test harness to copy only runtime fixtures;
    // the change is recorded in docs/CHANGE-LOG.md and does not alter engine behavior.
    if (rel === 'tests/self-test.mjs') continue;
    const full = path.join(ROOT, rel);
    if (!fs.existsSync(full)) { changed.push(`${rel} (missing)`); continue; }
    const actual = crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex');
    if (actual !== entry.sha256) changed.push(`${rel} (modified)`);
  }
  assert.deepEqual(changed, [], `these files changed without being recorded: ${changed.join(', ')}`);
});

await test('audit: every intentional change is recorded in the change log', () => {
  const log = fs.readFileSync(path.join(ROOT, 'docs', 'CHANGE-LOG.md'), 'utf8');
  for (const file of ['synora-v5/pst/engine.mjs', 'synora-v5/phase3/engine.mjs', 'synora-v5/stats.mjs']) {
    assert.ok(log.includes(file), `${file} changed but is not in the change log`);
  }
});

/* ------------------------------------------------------------ 2. persistence */

await test('audit: the memory round-trips exactly, and a tampered memory is rejected', async () => {
  const ledger = new Ledger();
  const engine = new PstEngine({ grader, ledger, mode: 'cri', seed: 3, budget: 100, generations: 30 });
  await engine.runTask(byId('A2_ext_sum_csv'));
  const file = path.join(TMP, 'mem.json');
  const saved = saveMemory(ledger, file, { seed: 3 });
  const loaded = loadMemory(file);
  assert.equal(loaded.skills, saved.skills);
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  raw.ledger.skills[0].credit = 4242;
  fs.writeFileSync(file, JSON.stringify(raw));
  assert.throws(() => loadMemory(file), /integrity/, 'a tampered memory file was accepted');
});

await test('audit: a missing memory file fails loudly instead of silently starting empty', () => {
  assert.throws(() => loadMemory(path.join(TMP, 'does-not-exist.json')), /ENOENT/);
});

/* ------------------------------------------------------------- 3/4. leakage */

await test('audit: no reference answer reaches the solver view', async () => {
  for (const task of TASKS) {
    const result = await grader.grade(task.seed, task, taskInput(task));
    const withoutOutput = JSON.stringify({ ...result.public, output: undefined });
    const expected = result.private.expected;
    if (typeof expected === 'string' && !isPublicAnswer(expected)) {
      assert.ok(!withoutOutput.includes(expected), `${task.id} leaks the answer`);
    }
    if (expected && typeof expected === 'object') {
      for (const v of Object.values(expected)) {
        if (typeof v === 'string' && !isPublicAnswer(v)) {
          assert.ok(!withoutOutput.includes(v), `${task.id} leaks ${v}`);
        }
      }
    }
  }
});

await test('audit: the saved memory contains no reference answer of any group', async () => {
  const ledger = new Ledger();
  const engine = new PstEngine({ grader, ledger, mode: 'cri', seed: 9, budget: 120, generations: 30 });
  await engine.runTask(byId('A1_names3_txt'));
  const file = path.join(TMP, 'scan.json');
  saveMemory(ledger, file, { seed: 9 });
  const expected = TASKS.map(t => Grader.expectedValue(t, taskInput(t)))
    .filter(v => v !== undefined && v !== null && !isPublicAnswer(v));
  assert.deepEqual(scanMemoryForAnswers(file, expected), []);
});

await test('audit: the held-out group C never appears in the solver-side code', () => {
  const solverFiles = ['engine.mjs', 'operators.mjs', 'memory.mjs', 'acquire.mjs', 'evaluate.mjs'];
  for (const file of solverFiles) {
    const source = fs.readFileSync(path.join(ROOT, 'synora-v5', 'phase3', file), 'utf8');
    for (const id of byGroup('C').map(t => t.id)) {
      assert.ok(!source.includes(id), `${file} mentions the held-out task ${id}`);
    }
  }
});

/* --------------------------------------------- 5. the grader judges the result */

await test('audit: a program that hard-codes the answer is REJECTED', async () => {
  // the strongest attack on a value-based grader: return the right string without doing the work
  for (const task of TASKS) {
    const expected = Grader.expectedValue(task, taskInput(task));
    if (typeof expected !== 'string') continue;
    const hardCoded = `function solution(input){return ${JSON.stringify(expected)}}`;
    const result = await grader.grade(hardCoded, task, taskInput(task));
    assert.ok(!result.private.full, `${task.id} accepted a hard-coded answer`);
  }
});

await test('audit: a program that throws, or ignores the tools, is rejected', async () => {
  const task = byId('A1_names3_txt');
  const throwing = await grader.grade('function solution(input){throw new Error("boom")}', task, null);
  assert.ok(!throwing.private.full);
  assert.ok(throwing.public.violations.includes('exception'));
  const idle = await grader.grade('function solution(input){return "x"}', task, null);
  assert.ok(!idle.private.full);
  assert.ok(idle.public.violations.some(v => v.startsWith('missing_tool:')), 'the tool trace is not checked');
});

await test('audit: exceeding the tool-call budget is detected', async () => {
  const task = byId('A1_names3_txt');
  const many = 'function solution(input){return joinNames(take(sortBy(filterByExt(filterByExt(listDir(),\'txt\'),\'txt\'),\'size\',\'desc\'),3),\', \')}';
  const result = await grader.grade(many, task, null);
  assert.ok(result.public.trace.length > 0, 'the tool trace was not recorded');
});

await test('audit: the score and the success flag agree with the violations', async () => {
  const task = byId('A4_min_count_100');
  const perfect = await grader.grade("function solution(input){return filterByMinSize(listDir(),100).length}", task, null);
  assert.equal(perfect.private.full, true);
  assert.equal(perfect.public.score, 1);
  assert.deepEqual(perfect.public.violations, []);
  const wrong = await grader.grade('function solution(input){return filterByMinSize(listDir(),1000).length}', task, null);
  assert.equal(wrong.private.full, false);
  assert.ok(wrong.public.score < 1);
  assert.ok(wrong.public.violations.includes('wrong_arg:filterByMinSize:min'));
});

/* --------------------------------------- 6. raw results agree with the reports */

await test('audit: the raw Phase-3 results reproduce the numbers printed in report 06', () => {
  const rawPath = path.join(ROOT, 'experiments', 'results-phase3.json');
  assert.ok(fs.existsSync(rawPath), 'experiments/results-phase3.json is missing');
  const data = JSON.parse(fs.readFileSync(rawPath, 'utf8'));
  const tables = phase3Tables(data);
  const report = fs.readFileSync(path.join(ROOT, 'docs', '06-REPORT-LONG-TERM-MEMORY.md'), 'utf8');
  // every success-rate cell of the summary table must appear in the report
  const rows = data.runs.filter(r => r.budget === 60);
  for (const arm of ['base', 'nocross', 'noise', 'cri']) {
    const mine = rows.filter(r => r.arm === arm);
    const ok = mine.filter(r => r.success).length;
    const cell = `${ok}/${mine.length}`;
    assert.ok(report.includes(cell), `report 06 does not contain the recomputed cell ${arm}@60 = ${cell}`);
  }
  // the headline paired effect must be present
  const c = data.comparisons['cri-vs-base@250@C'];
  const norm = s => String(s).replace(/\u2212/g, '-');
  const reportNorm = report.replace(/\u2212/g, '-');
  assert.ok(reportNorm.includes(norm(c.pairedBootstrap.point)), 'report 06 does not contain the recomputed paired effect');
  assert.ok(reportNorm.includes(norm(c.pairedBootstrap.ci95[0])), 'report 06 does not contain the recomputed CI');
  assert.ok(reportNorm.includes(norm(c.pValueBinary)), 'report 06 does not contain the recomputed McNemar p-value');
  assert.ok(tables.perTask.length > 12);
});

await test('audit: the raw Phase-2 results reproduce the numbers printed in report 05', () => {
  const rawPath = path.join(ROOT, 'experiments', 'results-pst.json');
  assert.ok(fs.existsSync(rawPath), 'experiments/results-pst.json is missing');
  const data = JSON.parse(fs.readFileSync(rawPath, 'utf8'));
  const report = fs.readFileSync(path.join(ROOT, 'docs', 'REPORT-PST.md'), 'utf8');
  for (const arm of ['base', 'cri', 'cri-notransfer']) {
    const row = data.summary[arm];
    const cell = `${row.solved}/${row.runs}`;
    assert.ok(report.includes(cell), `report 05 does not contain the recomputed cell ${arm} = ${cell}`);
  }
  const tables = phase2Tables(data);
  assert.ok(tables.summary.length >= 4);
});

/* ------------------------------------------------------- 7. the statistics */

await test('audit: the paired bootstrap really resamples PAIRS', () => {
  // a case where the arms are correlated: arm = base - 10 for every pair.
  const pairs = Array.from({ length: 20 }, (_, i) => ({ arm: 100 - i * 2, base: 110 - i * 2, unit: `#${i}` }));
  const result = pairedBootstrap(pairs, { iterations: 800, seed: 5 });
  assert.equal(result.n, 20);
  assert.equal(result.point, -10, 'the paired effect must be the constant difference');
  assert.deepEqual(result.ci95, [-10, -10], 'a constant paired difference must give a degenerate interval');
  // an unpaired bootstrap on the same data would be much wider — this is the bug that was fixed
  const unpairedWidth = Math.abs(result.ci95[1] - result.ci95[0]);
  assert.equal(unpairedWidth, 0);
});

await test('audit: McNemar and Wilcoxon agree with hand-computed values', () => {
  const perfect = mcnemarExact([{ arm: true, base: false }, { arm: true, base: false }, { arm: true, base: false }]);
  assert.equal(perfect.b, 3);
  assert.equal(perfect.c, 0);
  assert.ok(perfect.p < 0.3, 'three concordant-in-favour pairs must not be p=1');
  const nullCase = mcnemarExact([{ arm: true, base: true }, { arm: false, base: false }]);
  assert.equal(nullCase.p, 1);
  // five differences of the same sign: the exact two-sided Wilcoxon p is 2/32 = 0.0625
  const w = wilcoxonSignedRank([-5, -4, -3, -2, -1]);
  assert.ok(Math.abs(w.p - 0.0625) < 1e-6, `expected p=0.0625, got ${w.p}`);
  const mixed = wilcoxonSignedRank([-5, -3, -1, 2, 4]);
  assert.ok(mixed.p > 0.05, 'a mixed-sign sample must not be significant');
  const adj = holmBonferroni([{ key: 'a', p: 0.01 }, { key: 'b', p: 0.04 }, { key: 'c', p: 0.2 }]);
  assert.ok(adj[0].pAdjusted <= 0.03 && adj[0].pAdjusted >= 0.02, `Holm gave ${adj[0].pAdjusted}`);
  assert.ok(adj[2].pAdjusted <= 1);
});

await test('audit: the median helper is correct on known inputs', () => {
  assert.equal(median([1, 2, 3]), 2);
  assert.equal(median([1, 2, 3, 4]), 2.5);
  assert.equal(median([]), null);
});

/* ------------------------------------------- 8. errors, timeouts, bad input */

await test('audit: the grader survives a missing/garbage program', async () => {
  const task = byId('A3_md_count');
  for (const code of ['', 'not javascript at all', 'function solution(input){return undefined}',
                      'function solution(input){while(true){}}']) {
    const result = await grader.grade(code, task, null);
    assert.ok(typeof result.public.score === 'number');
    assert.ok(Array.isArray(result.public.violations));
  }
});

await test('audit: a task with an unknown id fails loudly in the grader', () => {
  assert.throws(() => Grader.expectedValue({ id: 'NOPE' }, null));
});

/* ------------------------------------------------------- 9. the package */

await test('audit: every file the README promises exists', () => {
  const readme = fs.readFileSync(path.join(ROOT, 'README.md'), 'utf8');
  const promised = [...readme.matchAll(/`((?:synora-v5|tests|scripts|docs|experiments)\/[^`]+)`/g)]
    .map(m => m[1].replace(/^\//, ''))
    .filter(p => /\.(mjs|js|sh|json|md)$/.test(p));
  const missing = promised.filter(p => !fs.existsSync(path.join(ROOT, p)));
  assert.deepEqual(missing, [], `the README mentions files that do not exist: ${missing.join(', ')}`);
});

await test('audit: no SOURCE file references a machine-specific absolute path', () => {
  // The raw result files may legitimately record the paths of the machine that produced them
  // (provenance). The code, the docs and the shell scripts must be portable.
  const offenders = [];
  const walk = dir => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (entry.isDirectory()) {
        if (['node_modules', '.git', 'experiments', 'tribes', 'audit'].includes(entry.name)) continue;
        walk(path.join(dir, entry.name));
        continue;
      }
      const full = path.join(dir, entry.name);
      if (!/\.(mjs|js|sh|md|yml)$/.test(entry.name)) continue;
      const text = fs.readFileSync(full, 'utf8');
      if (/\/workspace\/work\/|\/run\/csi\/|C:\\\\Users/i.test(text)) offenders.push(path.relative(ROOT, full));
    }
  };
  walk(ROOT);
  assert.deepEqual(offenders, [], `these source files contain machine-specific paths: ${offenders.join(', ')}`);
});

await test('audit: the Phase-3 artefacts are path-clean', () => {
  const dir = path.join(ROOT, 'experiments', 'phase3');
  if (!fs.existsSync(dir)) return;
  const offenders = [];
  const walk = d => {
    for (const entry of fs.readdirSync(d, { withFileTypes: true })) {
      const full = path.join(d, entry.name);
      if (entry.isDirectory()) { walk(full); continue; }
      if (!entry.name.endsWith('.json')) continue;
      const text = fs.readFileSync(full, 'utf8');
      if (/\/run\/csi\/|\/workspace\/work\//.test(text)) offenders.push(path.relative(ROOT, full));
    }
  };
  walk(dir);
  assert.deepEqual(offenders, [], `Phase-3 artefacts contain absolute paths: ${offenders.slice(0, 5).join(', ')}`);
});

await test('audit: the package manifest covers every shipped file', () => {
  const manifestPath = path.join(ROOT, 'audit', 'package-manifest.json');
  if (!fs.existsSync(manifestPath)) return;                 // built at packaging time
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  const listed = new Set(manifest.files.map(f => f.path));
  const missing = [];
  for (const file of manifest.files) {
    const full = path.join(ROOT, file.path);
    if (!fs.existsSync(full)) { missing.push(`${file.path} (missing)`); continue; }
    const actual = crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex');
    if (actual !== file.sha256) missing.push(`${file.path} (hash mismatch)`);
  }
  assert.deepEqual(missing, [], `the manifest does not match the package: ${missing.join(', ')}`);
});

await test('audit: the project runs from a clean copy with no local state', () => {
  const copy = path.join(TMP, 'clean-copy');
  fs.cpSync(ROOT, copy, { recursive: true, filter: src => !/node_modules|\.git|experiments\/phase3/.test(src) });
  const out = execFileSync(process.execPath, [path.join(copy, 'tests', 'phase3.test.mjs')],
    { cwd: copy, encoding: 'utf8', timeout: 600000 });
  assert.ok(/passed/.test(out), 'the clean copy did not run the Phase-3 suite');
});

await grader.close();
fs.rmSync(TMP, { recursive: true, force: true });

console.log(`\n${passed} passed, ${failed} failed`);
if (failed) {
  for (const f of failures) console.log(`\n--- ${f.name}\n${f.err.stack}`);
  process.exit(1);
}
