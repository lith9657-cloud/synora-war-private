import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { DigitalObjectCore, SCHEMA_VERSION } from '../synora-v5/digital-object-core/index.mjs';
import { DigitalObjectSynoraAdapter } from '../synora-v5/digital-object-core/synora-adapter.mjs';

const tmpdir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'synora-docore-'));
const stableForHash = value => { if (Array.isArray(value)) return `[${value.map(stableForHash).join(',')}]`; if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${stableForHash(value[k])}`).join(',')}}`; return JSON.stringify(value); };
const shaForPayload = payload => crypto.createHash('sha256').update(stableForHash(payload)).digest('hex');

test('objects have stable identity, typed properties, guarded state transitions, and validated relations', () => {
  const c = new DigitalObjectCore(); c.createObject({ id: 'A', type: 'person', properties: { name: 'Socrates', age: 70 } }); c.createObject({ id: 'B', type: 'class' });
  assert.equal(c.getObject('A').properties.name, 'Socrates'); assert.throws(() => c.createObject({ id: 'A' }), /already exists/);
  assert.throws(() => c.createObject({ id: 'bad', properties: { list: [] } }), /properties/);
  assert.throws(() => c.addRelation({ id: 'r', from: 'A', to: 'missing', type: 'related' }), /unknown object/);
  c.addRelation({ id: 'r', from: 'A', to: 'B', type: 'member-of' });
  assert.throws(() => c.transition('A', 'dead', { allowedFrom: ['inactive'] }), /transition rejected/);
  c.transition('A', 'inactive', { allowedFrom: ['active'] }); assert.equal(c.getObject('A').state, 'inactive');
});

test('same event is idempotent for create, transition, relation, fact, rule, enablement and outcomes; reused ID with changed payload conflicts', () => {
  const c = new DigitalObjectCore();
  c.createObject({ id: 'A' }, 'obj-1'); const beforeCreateEvents = c.events.size;
  assert.equal(c.createObject({ id: 'A' }, 'obj-1').duplicate, true); assert.equal(c.events.size, beforeCreateEvents); assert.equal(c.objects.size, 1);
  assert.throws(() => c.createObject({ id: 'A', state: 'inactive' }, 'obj-1'), /event id conflict/);
  c.createObject({ id: 'B' }); c.transition('A', 'inactive', { eventId: 'transition-1' });
  assert.equal(c.transition('A', 'inactive', { eventId: 'transition-1' }).duplicate, true); assert.equal(c.events.size, 3);
  c.addRelation({ id: 'r1', from: 'A', to: 'B', type: 'knows' }, 'rel-1');
  assert.equal(c.addRelation({ id: 'r1', from: 'A', to: 'B', type: 'knows' }, 'rel-1').duplicate, true); assert.equal(c.relations.size, 1);
  c.addFact({ subject: 'A', predicate: 'p', object: true }, 'fact-1');
  assert.equal(c.addFact({ subject: 'A', predicate: 'p', object: true }, 'fact-1').duplicate, true); assert.equal(c.facts.size, 1);
  assert.equal(c.removeFact({ subject: 'A', predicate: 'p', object: true }, 'remove-fact-1').duplicate, false);
  assert.equal(c.removeFact({ subject: 'A', predicate: 'p', object: true }, 'remove-fact-1').duplicate, true); assert.equal(c.facts.size, 0);
  c.addFact({ subject: 'A', predicate: 'p', object: true }, 'fact-1-recreated');
  c.addRule({ id: 'rule-1', premise: { predicate: 'p' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'q', objectValue: true } }, 'rule-1-event');
  assert.equal(c.addRule({ id: 'rule-1', premise: { predicate: 'p' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'q', objectValue: true } }, 'rule-1-event').duplicate, true);
  c.setRuleEnabled('rule-1', false, 'enable-1'); assert.equal(c.setRuleEnabled('rule-1', false, 'enable-1').duplicate, true);
  c.recordOutcome({ ruleId: 'rule-1', eventId: 'outcome-1', success: true });
  assert.equal(c.recordOutcome({ ruleId: 'rule-1', eventId: 'outcome-1', success: true }).duplicate, true);
  assert.equal(c.rules.get('rule-1').successes, 1); assert.equal(c.rules.get('rule-1').failures, 0);
  assert.throws(() => c.recordOutcome({ ruleId: 'rule-1', eventId: 'outcome-1', success: false }), /event id conflict/);
});

test('fact-removal event identity distinguishes wildcard selectors from explicit null values', () => {
  const c = new DigitalObjectCore(); c.addFact({ subject: 'S', predicate: 'p', object: null, source: 'user' }, 'null-fact');
  c.removeFact({ subject: 'S', predicate: 'p' }, 'remove-selector');
  c.addFact({ subject: 'S', predicate: 'p', object: null, source: 'user' }, 'null-fact-2');
  assert.throws(() => c.removeFact({ subject: 'S', predicate: 'p', object: null }, 'remove-selector'), /event id conflict/);
  assert.equal(c.facts.size, 1);
});

test('failed operations do not mutate state or append success-looking events', () => {
  const c = new DigitalObjectCore(); c.createObject({ id: 'A' });
  const count = c.events.size; assert.throws(() => c.addRelation({ id: 'bad-r', from: 'A', to: 'missing', type: 'knows' }, 'failed-rel'), /unknown object/);
  assert.equal(c.events.size, count); assert.equal(c.relations.size, 0);
  assert.throws(() => c.transition('A', 'dead', { allowedFrom: ['sleeping'], eventId: 'failed-transition' }), /transition rejected/);
  assert.equal(c.events.has('failed-transition'), false); assert.equal(c.getObject('A').state, 'active');
  assert.throws(() => c.recordOutcome({ ruleId: 'missing', eventId: 'failed-outcome', success: true }), /unknown rule/);
  assert.equal(c.events.has('failed-outcome'), false);
});

test('Socrates inference has proof lineage, chained rules work, and retraction rebuilds without stale conclusions', () => {
  const c = new DigitalObjectCore();
  c.addFact({ subject: 'Socrates', predicate: 'is-a', object: 'human', source: 'premise-A', evidence: ['premise citation'] });
  c.addRule({ id: 'human-mortal', premise: { predicate: 'is-a', object: 'human' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'is-a', objectValue: 'mortal' } });
  c.addRule({ id: 'mortal-dies', premise: { predicate: 'is-a', object: 'mortal' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'eventually', objectValue: 'dies' } });
  let result = c.infer();
  const mortal = result.facts.find(f => f.subject === 'Socrates' && f.object === 'mortal');
  const dies = result.facts.find(f => f.subject === 'Socrates' && f.object === 'dies');
  assert.ok(mortal?.derived && dies?.derived); assert.equal(mortal.ruleId, 'human-mortal'); assert.ok(dies.premiseFactIds.includes(mortal.id));
  assert.ok(result.derived.some(x => x.ruleId === 'human-mortal' && x.premiseFactId.startsWith('fact:')));
  c.removeFact({ subject: 'Socrates', predicate: 'is-a', object: 'human', source: 'premise-A' }, 'retract-premise');
  result = c.infer(); assert.equal(result.facts.some(f => f.subject === 'Socrates' && (f.object === 'mortal' || f.object === 'dies')), false);
});

test('non-accepted evidence from any source blocks inference for that proposition; conflicts are explicit', () => {
  const c = new DigitalObjectCore(); c.addFact({ subject: 'x', predicate: 'color', object: 'red', source: 'source-1' });
  c.addFact({ subject: 'x', predicate: 'color', object: 'red', source: 'source-2', status: 'rejected' });
  c.addFact({ subject: 'x', predicate: 'color', object: 'blue', source: 'source-3' });
  c.addRule({ id: 'red-rule', premise: { predicate: 'color', object: 'red' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'safe', objectValue: true } });
  const r = c.infer(); assert.equal(r.facts.some(f => f.predicate === 'safe'), false);
  assert.ok(r.conflicts.some(x => x.subject === 'x' && x.predicate === 'color'));
});

test('cycles terminate, duplicate derivations are not emitted, and inference limits are explicit', () => {
  const c = new DigitalObjectCore({ maxInferenceRounds: 8, maxDerivedFacts: 10 });
  c.addFact({ subject: 'loop', predicate: 'p', object: 'a' });
  c.addRule({ id: 'a-b', premise: { predicate: 'p', object: 'a' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'p', objectValue: 'b' } });
  c.addRule({ id: 'b-a', premise: { predicate: 'p', object: 'b' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'p', objectValue: 'a' } });
  const r = c.infer(); assert.equal(r.exhausted, false); assert.equal(r.derived.length, 1);
  const limited = new DigitalObjectCore({ maxInferenceRounds: 1 }); limited.addFact({ subject: 's', predicate: 'p', object: 0 });
  limited.addRule({ id: 'r1', premise: { predicate: 'p', object: 0 }, conclusion: { subjectFrom: 'premise.subject', predicate: 'p', objectValue: 1 } });
  limited.addRule({ id: 'r2', premise: { predicate: 'p', object: 1 }, conclusion: { subjectFrom: 'premise.subject', predicate: 'p', objectValue: 2 } });
  assert.equal(limited.infer().exhausted, true);
  assert.throws(() => limited.infer({ maxRounds: 2 }), /round limit/);
});

test('identical fact requests are idempotent; source/status updates are recorded and change inference', () => {
  const c = new DigitalObjectCore();
  c.addFact({ subject: 'S', predicate: 'p', object: 'yes', source: 'src' }, 'f1');
  const events = c.events.size; assert.equal(c.addFact({ subject: 'S', predicate: 'p', object: 'yes', source: 'src' }, 'f2').duplicate, true); assert.equal(c.events.size, events + 1); assert.throws(() => c.addFact({ subject: 'S', predicate: 'p', object: 'no', source: 'src' }, 'f2'), /event id conflict/);
  c.addRule({ id: 'r', premise: { predicate: 'p', object: 'yes' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'q', objectValue: true } });
  assert.ok(c.infer().facts.some(f => f.predicate === 'q'));
  c.addFact({ subject: 'S', predicate: 'p', object: 'yes', source: 'src', status: 'rejected' }, 'f3');
  assert.ok(!c.infer().facts.some(f => f.predicate === 'q'));
});

test('accepted contradictory values block inference until the proposition is reconciled', () => {
  const c = new DigitalObjectCore({ functionalPredicates: ['color'] });
  c.addFact({ subject: 'x', predicate: 'color', object: 'red', source: 's1' });
  c.addFact({ subject: 'x', predicate: 'color', object: 'blue', source: 's2' });
  c.addRule({ id: 'red-is-safe', premise: { predicate: 'color', object: 'red' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'safe', objectValue: true } });
  const result = c.infer();
  assert.equal(result.facts.some(f => f.predicate === 'safe'), false);
  assert.ok(result.conflicts.some(x => x.subject === 'x' && x.predicate === 'color'));
});

test('derived conflicts on functional predicates retract conflicting conclusions and their descendants', () => {
  const c = new DigitalObjectCore({ functionalPredicates: ['color'] });
  c.addFact({ subject: 'x', predicate: 'p', object: true });
  c.addRule({ id: 'derive-red', premise: { predicate: 'p' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'color', objectValue: 'red' } });
  c.addRule({ id: 'derive-safe', premise: { predicate: 'color', object: 'red' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'safe', objectValue: true } });
  c.addRule({ id: 'derive-blue', premise: { predicate: 'p' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'color', objectValue: 'blue' } });
  const result = c.infer();
  assert.equal(result.facts.some(f => f.predicate === 'color' || f.predicate === 'safe'), false);
  assert.ok(result.conflicts.some(x => x.policy === 'functional predicate conflict blocks all derived alternatives'));
});

test('hypotheses remain separate from accepted/retrieved facts, and retrieved facts can support inference', () => {
  const c = new DigitalObjectCore();
  c.addFact({ subject: 'S', predicate: 'status', object: 'possible', source: 'guess', kind: 'hypothesis' });
  c.addFact({ subject: 'S', predicate: 'status', object: 'verified', source: 'archive', kind: 'retrieved' });
  c.addRule({ id: 'verified-rule', premise: { predicate: 'status', object: 'verified' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'eligible', objectValue: true } });
  const result = c.infer();
  assert.equal(result.hypotheses.length, 1); assert.equal(result.hypotheses[0].kind, 'hypothesis');
  assert.ok(result.facts.some(f => f.predicate === 'eligible' && f.derived));
  assert.ok(result.facts.some(f => f.kind === 'retrieved' && f.object === 'verified'));
});

test('schema v2 snapshots migrate deterministically while preserving facts and event history', () => {
  const dir = tmpdir(), file = path.join(dir, 'v2.json'); const c = new DigitalObjectCore();
  c.addFact({ subject: 'A', predicate: 'p', object: 'v', source: 'legacy-source' }, 'legacy-fact-event');
  const payload = c.snapshot(); payload.schemaVersion = 2; delete payload.config.functionalPredicates;
  payload.facts = payload.facts.map(({ kind, ...fact }) => fact);
  fs.writeFileSync(file, JSON.stringify({ payload, sha256: shaForPayload(payload) }));
  const restored = DigitalObjectCore.load(file);
  assert.equal(restored.snapshot().schemaVersion, SCHEMA_VERSION);
  assert.equal([...restored.facts.values()][0].kind, 'direct');
  assert.equal(restored.events.size, c.events.size);
  assert.equal(restored.addFact({ subject: 'A', predicate: 'p', object: 'v', source: 'legacy-source' }, 'legacy-fact-event').duplicate, true);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('conjunctive rules require every premise and retain all premise lineage', () => {
  const c = new DigitalObjectCore();
  c.addFact({ subject: 'Socrates', predicate: 'is-a', object: 'human', source: 'premise-human' });
  c.addFact({ subject: 'Socrates', predicate: 'has', object: 'reason', source: 'premise-reason' });
  c.addRule({ id: 'rational-human', premise: [{ predicate: 'is-a', object: 'human' }, { predicate: 'has', object: 'reason' }], conclusion: { subjectFrom: 'premise.subject', predicate: 'is', objectValue: 'rational' } });
  let result = c.infer();
  const derived = result.facts.find(f => f.predicate === 'is' && f.object === 'rational');
  assert.ok(derived?.derived); assert.equal(derived.premiseFactIds.length, 2);
  c.removeFact({ subject: 'Socrates', predicate: 'has', object: 'reason', source: 'premise-reason' }, 'remove-reason');
  result = c.infer(); assert.equal(result.facts.some(f => f.predicate === 'is' && f.object === 'rational'), false);
});

test('persistence validates schema, truncation, tampering and preserves an existing target when replacement fails', () => {
  const dir = tmpdir(), file = path.join(dir, 'core.json'); const c = new DigitalObjectCore(); c.createObject({ id: 'A' }); c.save(file);
  const good = fs.readFileSync(file, 'utf8');
  fs.writeFileSync(file, good.slice(0, Math.floor(good.length / 2))); assert.throws(() => DigitalObjectCore.load(file), /read\/parse failed/);
  fs.writeFileSync(file, good); const raw = JSON.parse(good); raw.payload.schemaVersion = SCHEMA_VERSION + 1; fs.writeFileSync(file, JSON.stringify(raw)); assert.throws(() => DigitalObjectCore.load(file), /schema\/version invalid/);
  fs.writeFileSync(file, good); const changed = JSON.parse(good); changed.payload.objects[0].state = 'tampered'; fs.writeFileSync(file, JSON.stringify(changed)); assert.throws(() => DigitalObjectCore.load(file), /integrity check/);
  const targetDir = path.join(dir, 'blocked-target'); fs.mkdirSync(targetDir); fs.writeFileSync(path.join(targetDir, 'sentinel'), 'preserve');
  assert.throws(() => c.save(targetDir), /persistence write failed/); assert.equal(fs.readFileSync(path.join(targetDir, 'sentinel'), 'utf8'), 'preserve');
  assert.equal(fs.readdirSync(dir).some(n => n.includes('.tmp-')), false); fs.rmSync(dir, { recursive: true, force: true });
});

test('persistence keeps a verified backup and refuses to overwrite a corrupted current snapshot', () => {
  const dir = tmpdir(), file = path.join(dir, 'core.json');
  const c = new DigitalObjectCore(); c.createObject({ id: 'A' }); c.save(file);
  c.createObject({ id: 'B' }); c.save(file);
  assert.ok(fs.existsSync(`${file}.bak`));
  const backup = DigitalObjectCore.load(`${file}.bak`); assert.ok(backup.getObject('A')); assert.equal(backup.getObject('B'), null);
  const currentBytes = fs.readFileSync(file, 'utf8');
  fs.writeFileSync(`${file}.lock`, JSON.stringify({ pid: process.pid, startedAt: new Date().toISOString() }));
  assert.throws(() => c.save(file), /writer lock is already held/);
  assert.equal(fs.readFileSync(file, 'utf8'), currentBytes); fs.unlinkSync(`${file}.lock`);
  fs.writeFileSync(file, '{truncated');
  assert.throws(() => c.save(file), /existing target is invalid; refusing to replace it/);
  assert.equal(fs.readFileSync(file, 'utf8'), '{truncated');
  assert.ok(DigitalObjectCore.load(`${file}.bak`).getObject('A'));
  fs.rmSync(dir, { recursive: true, force: true });
});

test('fresh Node process restores object graph, facts, rules, evidence, event history and deduplication', () => {
  const dir = tmpdir(), file = path.join(dir, 'state.json');
  const moduleUrl = new URL('../synora-v5/digital-object-core/index.mjs', import.meta.url).href;
  const setup = `import {DigitalObjectCore} from ${JSON.stringify(moduleUrl)}; const c=new DigitalObjectCore(); c.createObject({id:'Socrates',type:'person'},'obj-s'); c.createObject({id:'Human',type:'class'},'obj-h'); c.addRelation({id:'r1',from:'Socrates',to:'Human',type:'instance-of'},'rel-1'); c.addFact({subject:'Socrates',predicate:'is-a',object:'human',source:'premise',evidence:['citation']},'fact-1'); c.addRule({id:'mortal',premise:{predicate:'is-a',object:'human'},conclusion:{subjectFrom:'premise.subject',predicate:'is-a',objectValue:'mortal'}},'rule-1'); c.recordOutcome({ruleId:'mortal',eventId:'outcome-1',success:true}); c.save(${JSON.stringify(file)});`;
  const a = spawnSync(process.execPath, ['--input-type=module', '-e', setup], { encoding: 'utf8' }); assert.equal(a.status, 0, a.stderr);
  const restore = `import {DigitalObjectCore} from ${JSON.stringify(moduleUrl)}; const c=DigitalObjectCore.load(${JSON.stringify(file)}); const before=c.events.size; const d=c.createObject({id:'Socrates',type:'person'},'obj-s'); const r=c.infer(); if(!d.duplicate||c.events.size!==before||!c.relations.has('r1')||!c.evidence.size||!r.facts.some(f=>f.subject==='Socrates'&&f.object==='mortal'&&f.derived)||c.rules.get('mortal').successes!==1) process.exit(9); console.log('RESTORED_OK');`;
  const b = spawnSync(process.execPath, ['--input-type=module', '-e', restore], { encoding: 'utf8' }); assert.equal(b.status, 0, b.stderr); assert.match(b.stdout, /RESTORED_OK/);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('event deduplication survives restart and conflicting replay fails without partial mutation', () => {
  const dir = tmpdir(), file = path.join(dir, 'state.json'); const c = new DigitalObjectCore(); c.addRule({ id: 'r', premise: { predicate: 'p' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'q', objectValue: true } });
  c.recordOutcome({ ruleId: 'r', eventId: 'same-outcome', success: true }); c.save(file);
  const d = DigitalObjectCore.load(file), before = d.events.size; assert.equal(d.recordOutcome({ ruleId: 'r', eventId: 'same-outcome', success: true }).duplicate, true); assert.equal(d.events.size, before);
  assert.throws(() => d.recordOutcome({ ruleId: 'r', eventId: 'same-outcome', success: false }), /event id conflict/); assert.equal(d.rules.get('r').successes, 1); assert.equal(d.rules.get('r').failures, 0);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('integration adapter records real CRI-compatible engine results idempotently without changing engine search code', async () => {
  const { PstEngine } = await import('../synora-v5/phase4/engine.mjs');
  const { Grader } = await import('../synora-v5/phase4/grader.mjs');
  const { TASKS } = await import('../synora-v5/phase4/tasks.mjs');
  const core = new DigitalObjectCore(); const grader = new Grader({ size: 1 }); await grader.init();
  try {
    const engine = new PstEngine({ grader, mode: 'cri', seed: 17, budget: 2, generations: 1 });
    const adapter = new DigitalObjectSynoraAdapter(core, { runId: 'acceptance-run', mode: 'cri', seed: 17, budget: 2 }); adapter.attach(engine);
    const result = await engine.runTask(TASKS[0]);
    assert.ok(result.digitalObjectRecording?.factId); assert.equal(core.facts.size, 1);
    const recorded = adapter.recordTaskResult(result); assert.equal(recorded.duplicate, true); assert.equal(core.facts.size, 1);
    assert.equal(adapter.detach(), true); assert.equal(adapter.detach(), false);
    const adaptive = new (await import('../synora-v5/phase4/adaptive-engine.mjs')).AdaptivePstEngine({ grader, mode: 'adaptive', seed: 18, budget: 2, generations: 1 });
    const adaptiveAdapter = new DigitalObjectSynoraAdapter(core, { runId: 'adaptive-run', mode: 'adaptive', seed: 18, budget: 2 }); adaptiveAdapter.attach(adaptive);
    const adaptiveResult = await adaptive.runTask(TASKS[0]); assert.ok(adaptiveResult.digitalObjectRecording?.factId); assert.equal(core.facts.size, 2);

    const failingEngine = new PstEngine({ grader, mode: 'cri', seed: 19, budget: 2, generations: 1 });
    const failingAdapter = new DigitalObjectSynoraAdapter(core, { runId: 'retry-run', mode: 'cri', seed: 19, budget: 2 }); failingAdapter.attach(failingEngine);
    const originalAddFact = core.addFact.bind(core); let failOnce = true;
    core.addFact = (...args) => { if (failOnce) { failOnce = false; throw new Error('simulated recording failure'); } return originalAddFact(...args); };
    const preserved = await failingEngine.runTask(TASKS[0]);
    assert.equal(typeof preserved.success, 'boolean'); assert.equal(preserved.digitalObjectRecording.ok, false);
    core.addFact = originalAddFact;
    const retried = failingAdapter.recordTaskResult(preserved); assert.equal(retried.duplicate, false); assert.ok(core.facts.size >= 3);
    failingAdapter.detach();
  } finally { await grader.close(); }
});
