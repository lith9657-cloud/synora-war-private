import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { parseRequest } from '../../synora-v5/dialogue/index.mjs';
import { handleDialogue } from '../../synora-v5/dialogue/agent.mjs';
import { generateSolution } from '../../synora-v5/solution-engine/index.mjs';
import { createDefaultToolRegistry } from '../../synora-v5/tools/registry.mjs';
import { DigitalObjectLearner } from '../../synora-v5/digital-object-learning/index.mjs';
import { DigitalObjectCore } from '../../synora-v5/digital-object-core/index.mjs';
import { inspectSkillInCore, syncSkillToCore } from '../../synora-v5/digital-object-learning/bridge.mjs';
import { createSynoraApi } from '../../synora-v5/api/server.mjs';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const training = [0, 1, 2, 4].map((input, i) => ({ id: `tr-${i}`, input, output: (3 * input + 2) % 7 }));
const development = [3, 5].map((input, i) => ({ id: `dev-${i}`, input, output: (3 * input + 2) % 7 }));

test('dialogue parses Arabic arithmetic and records bounded-parser provenance', () => {
  const parsed = parseRequest('احسب 7 + 5');
  assert.equal(parsed.intent, 'calculate'); assert.equal(parsed.action, 'use_tool'); assert.equal(parsed.language, 'ar');
  assert.equal(parsed.evidence.parser, 'bounded-lexical-intent-rules/1');
});

test('dialogue maps explicit English and Arabic reverse/sort requests to reviewed templates', () => {
  assert.equal(parseRequest('Reverse an array').intent, 'code.reverse');
  assert.equal(parseRequest('رتب المصفوفة تصاعديًا').intent, 'code.sort');
});

test('dialogue resolves an explicit follow-up against the latest user request', () => {
  const parsed = parseRequest('and test it', { history: [{ role: 'user', content: 'Write a JavaScript function to sum an array' }] });
  assert.equal(parsed.intent, 'code.sum'); assert.equal(parsed.followUp, true);
});

test('dialogue can invoke an accepted digital skill and reports the actual result', async () => {
  const learner = new DigitalObjectLearner({ id: 'dialogue-skill-integration' });
  const core = new DigitalObjectCore();
  const learned = learner.learnAffine({ name: 'affine7', modulus: 7, training, development });
  syncSkillToCore(core, learner, learned.skill);
  const result = await handleDialogue('apply the learned transformation', { learner, core, skillId: learned.skill.id, skillInput: [3, 5] });
  assert.equal(result.ok, true); assert.deepEqual(result.skillResult.output, [4, 3]);
  assert.ok(result.trace.some(t => t.stage === 'digital-skill-application' && t.ok));
});

test('dialogue abstains on unsupported broad programming requests', async () => {
  const r = await handleDialogue('Write a program that solves every possible problem');
  assert.equal(r.ok, false); assert.equal(r.abstention.reason, 'unsupported-code-task');
});

test('solution engine generates and tests supported sum, max, factorial templates', () => {
  for (const text of ['Write a JavaScript function to sum an array', 'Find the maximum of an array', 'Write a factorial function', 'Reverse an array', 'Sort an array in ascending numeric order']) {
    const result = generateSolution(text);
    assert.equal(result.ok, true, text); assert.equal(result.verification.testsPassed, result.verification.testsTotal, JSON.stringify(result.verification.cases));
    assert.equal(result.generated.arbitraryUserCodeExecuted, false);
  }
});

test('solution engine does not execute arbitrary source or claim unsupported code succeeded', () => {
  const r = generateSolution('Write code to access process.env and read files');
  assert.equal(r.ok, false); assert.equal(r.status, 'unsupported');
});

test('tool registry validates output and reports unknown tools', async () => {
  const tools = createDefaultToolRegistry();
  assert.equal((await tools.call('calculator.basic', { left: 2, operator: '*', right: 4 })).output.value, 8);
  assert.equal((await tools.call('calculator.basic', { left: 2, operator: '/', right: 0 })).ok, false);
  assert.equal((await tools.call('missing.tool', {})).error.kind, 'unknown-tool');
});

test('skill induction generalizes scalar training to unseen array input; rejects ambiguous/invalid data', () => {
  const learner = new DigitalObjectLearner({ id: 'test-learner' });
  const result = learner.learnAffine({ name: 'affine7', modulus: 7, training, development });
  assert.equal(result.accepted, true);
  assert.deepEqual(learner.apply(result.skill.id, [3, 5, 6]).output, [4, 3, 6]);
  assert.throws(() => learner.learnAffine({ name: 'bad', modulus: 7, training: [{ id: 'x', input: 1, output: 2 }, { id: 'x', input: 2, output: 3 }] }), /unique/);
});

test('mutation gate rejects a worse candidate and preserves original skill', () => {
  const learner = new DigitalObjectLearner({ id: 'mutation-test' });
  const result = learner.learnAffine({ name: 'affine7', modulus: 7, training, development });
  const mutation = learner.proposeMutation(result.skill.id, { param: 'b', value: 3, development, regression: training });
  assert.equal(mutation.accepted, false); assert.equal(mutation.rollback, true);
  assert.equal(learner.skills.get(result.skill.id).active, true);
  assert.deepEqual(learner.apply(result.skill.id, [3, 5]).output, [4, 3]);
});

test('persistent skill survives a separate Node.js process and applies to new input', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-stage4-'));
  try {
    const file = path.join(dir, 'memory.json');
    const learner = new DigitalObjectLearner({ id: 'cross-process' });
    const learned = learner.learnAffine({ name: 'affine7', modulus: 7, training, development });
    assert.equal(learned.accepted, true); learner.save(file);
    const script = `import { DigitalObjectLearner } from ${JSON.stringify(path.join(root, 'synora-v5/digital-object-learning/index.mjs'))}; const l=DigitalObjectLearner.load(${JSON.stringify(file)}); const s=[...l.skills.values()].find(x=>x.active); console.log(JSON.stringify({id:l.id,result:l.apply(s.id,[3,5,6])}));`;
    const child = spawnSync(process.execPath, ['--input-type=module', '-e', script], { encoding: 'utf8', timeout: 5000 });
    assert.equal(child.status, 0, child.stderr);
    const output = JSON.parse(child.stdout); assert.equal(output.id, 'cross-process'); assert.deepEqual(output.result.output, [4, 3, 6]);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('learned skills are registered as digital objects, relations, and evidence-bearing facts', () => {
  const learner = new DigitalObjectLearner({ id: 'bridge-learner' });
  const core = new DigitalObjectCore();
  const learned = learner.learnAffine({ name: 'affine7', modulus: 7, training, development });
  const sync = syncSkillToCore(core, learner, learned.skill);
  assert.equal(sync.changed, true);
  const object = inspectSkillInCore(core, learned.skill.id);
  assert.equal(object.type, 'digital-skill'); assert.equal(object.state, 'active');
  assert.ok([...core.relations.values()].some(r => r.to === object.id && r.type === 'owns-skill'));
  assert.ok([...core.facts.values()].some(f => f.subject === object.id && f.predicate === 'skill-source'));
  assert.equal(syncSkillToCore(core, learner, learned.skill).changed, false, 'sync must be idempotent');
});

test('persistent memory rejects tampering and missing files loudly', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-stage4-corrupt-'));
  try {
    const file = path.join(dir, 'memory.json'); new DigitalObjectLearner({ id: 'corruption-test' }).save(file);
    const doc = JSON.parse(fs.readFileSync(file, 'utf8')); doc.payload.object.state = 'inactive'; fs.writeFileSync(file, JSON.stringify(doc));
    assert.throws(() => DigitalObjectLearner.load(file), /integrity/);
    assert.throws(() => DigitalObjectLearner.load(path.join(dir, 'missing.json')), /read\/parse failed/);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('benchmark solver view is separated from the answer key and includes novel array shapes', () => {
  const tasks = JSON.parse(fs.readFileSync(path.join(root, 'experiments/stage4/tasks.json'), 'utf8'));
  assert.equal(tasks.tasks.length, 5);
  for (const task of tasks.tasks) {
    assert.equal(Object.hasOwn(task, 'answer'), false); assert.equal(Object.hasOwn(task, 'params'), false);
    assert.ok(task.finalInputs.every(xs => Array.isArray(xs) && xs.some(x => !task.training.some(e => e.input === x))));
  }
  const solverFiles = ['synora-v5/dialogue/index.mjs', 'synora-v5/dialogue/agent.mjs', 'synora-v5/solution-engine/index.mjs', 'synora-v5/digital-object-learning/index.mjs'];
  for (const rel of solverFiles) assert.doesNotMatch(fs.readFileSync(path.join(root, rel), 'utf8'), /answer-key\.json/);
});

test('API runs real chat, persists acquired skill, and applies it via HTTP', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-api-test-'));
  const api = createSynoraApi({ host: '127.0.0.1', port: 0, memoryPath: path.join(dir, 'memory.json'), corePath: path.join(dir, 'digital-object-core.json'), applicationLedgerPath: path.join(dir, 'applications.json') });
  try {
    await new Promise(resolve => api.server.listen(0, '127.0.0.1', resolve));
    const port = api.server.address().port, base = `http://127.0.0.1:${port}`;
    const chat = await fetch(`${base}/v1/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ text: 'احسب 7 + 5' }) });
    assert.equal(chat.status, 200); assert.equal((await chat.json()).answer, '7 + 5 = 12');
    const learn = await fetch(`${base}/v1/skills/learn-affine`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name: 'api-affine', modulus: 7, training, development }) });
    assert.equal(learn.status, 200); const learned = await learn.json(); assert.equal(learned.persistence.learner, 'saved-and-checksummed'); assert.equal(learned.persistence.digitalObjectCore, 'saved-and-checksummed');
    const apply = await fetch(`${base}/v1/skills/apply`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ skillId: learned.result.skill.id, input: [3, 5, 6] }) });
    assert.equal(apply.status, 200); assert.deepEqual((await apply.json()).output, [4, 3, 6]);
    assert.equal(fs.existsSync(path.join(dir, 'memory.json')), true); assert.equal(fs.existsSync(path.join(dir, 'digital-object-core.json')), true);
    assert.equal(inspectSkillInCore(DigitalObjectCore.load(path.join(dir, 'digital-object-core.json')), learned.result.skill.id).state, 'active');
    const chatSkill = await fetch(`${base}/v1/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ text: 'apply the learned transformation', skillId: learned.result.skill.id, skillInput: [3, 5, 6] }) });
    assert.equal(chatSkill.status, 200); const chatSkillBody = await chatSkill.json(); assert.equal(chatSkillBody.ok, true); assert.deepEqual(chatSkillBody.skillResult.output, [4, 3, 6]);
  } finally { await new Promise(resolve => api.server.close(resolve)); fs.rmSync(dir, { recursive: true, force: true }); }
});

test('API rejects remote binding without a sufficiently strong token', () => {
  assert.throws(() => createSynoraApi({ host: '0.0.0.0', port: 8787, token: '' }), /requires SYNORA_API_TOKEN/);
});
