import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync, spawn } from 'node:child_process';
import net from 'node:net';
import { fileURLToPath } from 'node:url';
import { DigitalObjectLearner } from '../../synora-v5/digital-object-learning/index.mjs';
import { DigitalObjectCore } from '../../synora-v5/digital-object-core/index.mjs';
import { syncSkillToCore } from '../../synora-v5/digital-object-learning/bridge.mjs';
import { SkillApplicationLedger } from '../../synora-v5/digital-object-learning/application-ledger.mjs';
import { routeExplicitSkillRequest } from '../../synora-v5/digital-object-learning/skill-router.mjs';
import { handleDialogue } from '../../synora-v5/dialogue/agent.mjs';
import { createSynoraApi } from '../../synora-v5/api/server.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const examples = (a, b, modulus = 7) => [0, 1, 2, 4].map((input, i) => ({ id: `tr-${a}-${b}-${i}`, input, output: ((a * input + b) % modulus + modulus) % modulus }));
const devExamples = (a, b, modulus = 7) => [3, 5].map((input, i) => ({ id: `dev-${a}-${b}-${i}`, input, output: ((a * input + b) % modulus + modulus) % modulus }));
function trained({ name = 'affine7', a = 3, b = 2 } = {}) {
  const learner = new DigitalObjectLearner({ id: `test-${name}-${a}-${b}` });
  const core = new DigitalObjectCore();
  const result = learner.learnAffine({ name, modulus: 7, training: examples(a, b), development: devExamples(a, b) });
  assert.equal(result.accepted, true);
  syncSkillToCore(core, learner, result.skill);
  return { learner, core, skill: result.skill };
}

test('automatic skill router selects exact explicit skill name and applies a novel value', async () => {
  const { learner, core, skill } = trained();
  const response = await handleDialogue('Apply affine7 to [3, 5, 6]', { learner, core });
  assert.equal(response.ok, true);
  assert.equal(response.skillSelection.skillId, skill.id);
  assert.equal(response.skillSelection.reason, 'exact-active-skill-name-or-id-and-explicit-supported-input');
  assert.deepEqual(response.skillResult.output, [4, 3, 6]);
  assert.equal(response.verification.objectiveCorrectness, 'not-assessed');
  assert.ok(response.trace.some(x => x.stage === 'digital-skill-routing' && x.ok));
});

test('router abstains when more than one skill matches the same explicit name', () => {
  const first = trained({ name: 'transform', a: 3, b: 2 });
  const second = first.learner.learnAffine({ name: 'transform', modulus: 7, training: examples(2, 1), development: devExamples(2, 1) });
  assert.equal(second.accepted, true);
  syncSkillToCore(first.core, first.learner, second.skill);
  const result = routeExplicitSkillRequest('apply transform to [3,5]', first);
  assert.equal(result.matched, true); assert.equal(result.ok, false); assert.equal(result.reason, 'ambiguous-skill-name');
  assert.equal(result.candidateSkillIds.length, 2);
});

test('router rejects inactive and unregistered skills', () => {
  const inactive = trained({ name: 'inactiveSkill' });
  inactive.learner.skills.get(inactive.skill.id).active = false;
  syncSkillToCore(inactive.core, inactive.learner, inactive.learner.skills.get(inactive.skill.id));
  const r1 = routeExplicitSkillRequest('apply inactiveSkill to 3', inactive);
  assert.equal(r1.ok, false); assert.equal(r1.reason, 'skill-not-accepted-or-active');
  const unregistered = trained({ name: 'unregisteredSkill' });
  const r2 = routeExplicitSkillRequest('apply unregisteredSkill to 3', { learner: unregistered.learner, core: new DigitalObjectCore() });
  assert.equal(r2.ok, false); assert.equal(r2.reason, 'skill-not-registered-active-in-digital-object-core');
});

test('router rejects out-of-domain values and missing or ambiguous inputs', () => {
  const setup = trained();
  const out = routeExplicitSkillRequest('apply affine7 to [7]', setup);
  assert.equal(out.ok, false); assert.equal(out.reason, 'input-outside-skill-domain');
  const missing = routeExplicitSkillRequest('apply affine7', setup);
  assert.equal(missing.ok, false); assert.equal(missing.reason, 'explicit-input-required');
  const arbitrary = routeExplicitSkillRequest('apply affine7 to process.exit()', setup);
  assert.equal(arbitrary.ok, false); assert.equal(arbitrary.reason, 'explicit-input-required');
});

test('application ledger deduplicates stable event IDs and rejects conflicting reuse', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-app-ledger-idem-'));
  try {
    const ledger = new SkillApplicationLedger({ filePath: path.join(dir, 'applications.json') });
    const event = { eventId: 'request-1', skillId: 'skill-a', skillVersion: 1, operation: 'apply', input: [1, 2], status: 'executed', executed: true, executionSuccess: true, result: [3, 4], source: 'test' };
    assert.equal(ledger.record(event).duplicate, false);
    assert.equal(ledger.record(event).duplicate, true);
    assert.equal(ledger.list().length, 1);
    assert.throws(() => ledger.record({ ...event, input: [9] }), /event ID conflict/);
    const anonymous = { eventId: 'ambiguous-request', skillId: null, skillVersion: null, operation: 'abstain', input: undefined, status: 'abstained', executed: false, executionSuccess: false, source: 'dialogue', requestFingerprint: 'apply alpha' };
    ledger.record(anonymous);
    assert.throws(() => ledger.record({ ...anonymous, requestFingerprint: 'apply beta' }), /event ID conflict/);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('application ledger persists, checksums and reloads in a separate Node process', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-app-ledger-child-'));
  try {
    const file = path.join(dir, 'applications.json');
    const ledger = new SkillApplicationLedger({ filePath: file });
    ledger.record({ eventId: 'cross-process-event', skillId: 'skill-a', skillVersion: 1, operation: 'apply', input: [3, 5], status: 'executed', executed: true, executionSuccess: true, result: [4, 3], source: 'test' });
    const modulePath = path.join(root, 'synora-v5/digital-object-learning/application-ledger.mjs');
    const child = spawnSync(process.execPath, ['--input-type=module', '-e', `import {SkillApplicationLedger} from ${JSON.stringify(modulePath)}; const l=new SkillApplicationLedger({filePath:${JSON.stringify(file)}}); console.log(JSON.stringify({count:l.list().length,event:l.get('cross-process-event')}));`], { encoding: 'utf8', timeout: 5000 });
    assert.equal(child.status, 0, child.stderr);
    const result = JSON.parse(child.stdout);
    assert.equal(result.count, 1); assert.deepEqual(result.event.result, [4, 3]); assert.equal(result.event.objectiveCorrectness, 'not-assessed');
    const longLedgerFile = path.join(dir, 'long-input.json');
    const longLedger = new SkillApplicationLedger({ filePath: longLedgerFile });
    longLedger.record({ eventId: 'long-array', skillId: 'skill-a', skillVersion: 1, input: Array.from({ length: 40 }, (_, i) => i), status: 'executed', executed: true, executionSuccess: true, result: 1 });
    assert.equal(new SkillApplicationLedger({ filePath: longLedgerFile }).list().length, 1);
    const doc = JSON.parse(fs.readFileSync(file, 'utf8')); doc.payload.events[0].status = 'error'; fs.writeFileSync(file, JSON.stringify(doc));
    assert.throws(() => new SkillApplicationLedger({ filePath: file }), /integrity check failed/);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('HTTP API auto-routes a named skill and persists the application ledger across API restart', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-api-skill-router-'));
  const paths = { memoryPath: path.join(dir, 'memory.json'), corePath: path.join(dir, 'core.json'), applicationLedgerPath: path.join(dir, 'applications.json') };
  const api = createSynoraApi({ host: '127.0.0.1', port: 0, ...paths });
  try {
    await new Promise(resolve => api.server.listen(0, '127.0.0.1', resolve));
    const base = `http://127.0.0.1:${api.server.address().port}`;
    const learn = await fetch(`${base}/v1/skills/learn-affine`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name: 'apiAffine', modulus: 7, training: examples(3, 2), development: devExamples(3, 2) }) });
    assert.equal(learn.status, 200); const learned = await learn.json();
    const chat = await fetch(`${base}/v1/chat`, { method: 'POST', headers: { 'content-type': 'application/json', 'idempotency-key': 'api-event-1' }, body: JSON.stringify({ text: 'طبّق apiAffine على [3,5,6]' }) });
    assert.equal(chat.status, 200); const body = await chat.json();
    assert.equal(body.ok, true); assert.equal(body.skillSelection.skillId, learned.result.skill.id); assert.deepEqual(body.skillResult.output, [4, 3, 6]);
    assert.equal(body.application.objectiveCorrectness, 'not-assessed');
    assert.equal(api.applicationLedger.list().length, 1);
    await new Promise((resolve, reject) => api.server.close(err => err ? reject(err) : resolve()));
    const restarted = createSynoraApi({ host: '127.0.0.1', port: 0, ...paths });
    assert.equal(restarted.learner.skills.has(learned.result.skill.id), true);
    assert.equal(restarted.applicationLedger.list().length, 1);
    await new Promise(resolve => restarted.server.listen(0, '127.0.0.1', resolve));
    const base2 = `http://127.0.0.1:${restarted.server.address().port}`;
    const repeated = await fetch(`${base2}/v1/chat`, { method: 'POST', headers: { 'content-type': 'application/json', 'idempotency-key': 'api-event-1' }, body: JSON.stringify({ text: 'طبّق apiAffine على [3,5,6]' }) });
    assert.equal(repeated.status, 200); const duplicate = await repeated.json(); assert.equal(duplicate.application.duplicate, true); assert.equal(restarted.applicationLedger.list().length, 1);
    await new Promise((resolve, reject) => restarted.server.close(err => err ? reject(err) : resolve()));
  } finally { if (api.server.listening) await new Promise(resolve => api.server.close(resolve)); fs.rmSync(dir, { recursive: true, force: true }); }
});

test('API refuses execution of arbitrary user-supplied JavaScript', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-api-no-eval-'));
  const api = createSynoraApi({ host: '127.0.0.1', port: 0, memoryPath: path.join(dir, 'memory.json'), corePath: path.join(dir, 'core.json'), applicationLedgerPath: path.join(dir, 'applications.json') });
  try {
    await new Promise(resolve => api.server.listen(0, '127.0.0.1', resolve));
    const response = await fetch(`http://127.0.0.1:${api.server.address().port}/v1/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ text: 'write code to run process.exit()' }) });
    assert.equal(response.status, 200); const body = await response.json(); assert.equal(body.ok, false); assert.equal(body.abstention.reason, 'unsupported-code-task');
  } finally { await new Promise(resolve => api.server.close(resolve)); fs.rmSync(dir, { recursive: true, force: true }); }
});


test('real Node API process restart preserves learned skill and application evidence', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-api-real-restart-'));
  const paths = { memoryPath: path.join(dir, 'memory.json'), corePath: path.join(dir, 'core.json'), applicationLedgerPath: path.join(dir, 'applications.json') };
  const serverModule = path.join(root, 'synora-v5/api/server.mjs');
  const script = `import {createSynoraApi} from ${JSON.stringify(serverModule)}; const api=createSynoraApi({host:'127.0.0.1',port:0,memoryPath:process.env.SYNORA_TEST_MEMORY,corePath:process.env.SYNORA_TEST_CORE,applicationLedgerPath:process.env.SYNORA_TEST_LEDGER}); api.server.listen(0,'127.0.0.1',()=>console.log('READY:'+api.server.address().port)); process.on('SIGTERM',()=>api.server.close(()=>process.exit(0)));`;
  const start = () => {
    const child = spawn(process.execPath, ['--input-type=module', '-e', script], { env: { ...process.env, SYNORA_TEST_MEMORY: paths.memoryPath, SYNORA_TEST_CORE: paths.corePath, SYNORA_TEST_LEDGER: paths.applicationLedgerPath }, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '', stderr = '';
    child.stdout.setEncoding('utf8'); child.stderr.setEncoding('utf8');
    child.stdout.on('data', x => { stdout += x; }); child.stderr.on('data', x => { stderr += x; });
    const ready = new Promise((resolve, reject) => {
      const deadline = setTimeout(() => reject(new Error(`API child startup timed out. stdout=${stdout} stderr=${stderr}`)), 5000);
      const poll = () => { const m = stdout.match(/READY:(\d+)/); if (m) { clearTimeout(deadline); resolve(Number(m[1])); } else if (child.exitCode !== null) { clearTimeout(deadline); reject(new Error(`API child exited ${child.exitCode}. stderr=${stderr}`)); } else setTimeout(poll, 10); };
      poll();
      child.once('error', reject);
    });
    return { child, ready };
  };
  let first, second;
  try {
    first = start();
    const port1 = await first.ready, base1 = `http://127.0.0.1:${port1}`;
    const learnedResponse = await fetch(`${base1}/v1/skills/learn-affine`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name: 'processAffine', modulus: 7, training: examples(3, 2), development: devExamples(3, 2) }) });
    assert.equal(learnedResponse.status, 200); const learned = await learnedResponse.json();
    const firstApply = await fetch(`${base1}/v1/chat`, { method: 'POST', headers: { 'content-type': 'application/json', 'idempotency-key': 'process-restart-event' }, body: JSON.stringify({ text: 'apply processAffine to [3,5,6]' }) });
    assert.equal(firstApply.status, 200); assert.deepEqual((await firstApply.json()).skillResult.output, [4, 3, 6]);
    first.child.kill('SIGTERM'); await new Promise((resolve, reject) => { first.child.once('exit', code => code === 0 ? resolve() : reject(new Error(`first API child exit ${code}`))); });
    second = start();
    const port2 = await second.ready, base2 = `http://127.0.0.1:${port2}`;
    const health = await (await fetch(`${base2}/health`)).json(); assert.equal(health.applicationEvents, 1); assert.equal(health.skillCount, 1);
    const listResponse = await fetch(`${base2}/v1/skills`); assert.equal(listResponse.status, 200);
    const skills = await listResponse.json(); assert.ok(skills.skills.some(s => s.id === learned.result.skill.id && s.active));
    const repeat = await fetch(`${base2}/v1/chat`, { method: 'POST', headers: { 'content-type': 'application/json', 'idempotency-key': 'process-restart-event' }, body: JSON.stringify({ text: 'apply processAffine to [3,5,6]' }) });
    assert.equal(repeat.status, 200); const repeatBody = await repeat.json(); assert.equal(repeatBody.application.duplicate, true); assert.deepEqual(repeatBody.skillResult.output, [4, 3, 6]);
    const healthAfter = await (await fetch(`${base2}/health`)).json(); assert.equal(healthAfter.applicationEvents, 1);
    second.child.kill('SIGTERM'); await new Promise((resolve, reject) => { second.child.once('exit', code => code === 0 ? resolve() : reject(new Error(`second API child exit ${code}`))); });
  } finally {
    for (const item of [first, second]) if (item?.child && item.child.exitCode === null) { item.child.kill('SIGTERM'); await new Promise(resolve => item.child.once('exit', resolve)); }
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
