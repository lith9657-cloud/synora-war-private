import test from 'node:test';
import assert from 'node:assert/strict';
import { scheduleShifts } from '../synora-v5/domains/workforce-scheduling/scheduler.mjs';
test('workforce scheduler fills eligible shifts and respects skills', () => {
 const r=scheduleShifts({workers:[{id:'a',skills:['cashier'],availableShifts:['s1','s2'],maxShifts:1},{id:'b',skills:['first-aid'],availableShifts:['s2']}],shifts:[{id:'s1',requiredSkills:['cashier']},{id:'s2',requiredSkills:['first-aid']}]});
 assert.equal(r.assigned.length,2); assert.deepEqual(r.unfilled,[]); assert.equal(r.coverage,1);
});
test('workforce scheduler reports impossible coverage rather than violating constraints',()=>{
 const r=scheduleShifts({workers:[{id:'a',skills:['cashier'],availableShifts:['s1']}],shifts:[{id:'s1',requiredSkills:['cashier']},{id:'s2',requiredSkills:['nurse']}]});
 assert.deepEqual(r.unfilled,['s2']); assert.equal(r.coverage,.5);
});
test('empty schedule has full coverage',()=>assert.equal(scheduleShifts({workers:[],shifts:[]}).coverage,1));
test('scheduler protects scarce workers by filling the most constrained shift first',()=>{
 const r=scheduleShifts({workers:[{id:'a',skills:['x','y'],availableShifts:['x-shift','y-shift']},{id:'b',skills:['x'],availableShifts:['x-shift']}],shifts:[{id:'x-shift',requiredSkills:['x']},{id:'y-shift',requiredSkills:['y']}]});
 assert.equal(r.assigned.length,2); assert.deepEqual(r.unfilled,[]);
});
test('scheduler rejects duplicate IDs instead of silently overwriting workers',()=>assert.throws(()=>scheduleShifts({workers:[{id:'a'},{id:'a'}],shifts:[]}),/duplicate worker id/));
test('scheduler rejects duplicate shift IDs',()=>assert.throws(()=>scheduleShifts({workers:[],shifts:[{id:'s'},{id:'s'}]}),/duplicate shift id/));
