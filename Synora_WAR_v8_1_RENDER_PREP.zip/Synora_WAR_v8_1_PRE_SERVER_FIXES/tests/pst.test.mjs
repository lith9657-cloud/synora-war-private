/**
 * Synora WAR v5 — PST phase: the test suite.
 *
 * These tests check the PROPERTIES the experiment depends on. If any of them fails, the
 * numbers in docs/REPORT-PST.md are meaningless.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Grader } from '../synora-v5/pst/grader.mjs';
import { PstEngine, familiesFor } from '../synora-v5/pst/engine.mjs';
import { TASKS, byId, bySet, taskInput } from '../synora-v5/pst/tasks.mjs';
import { PLANS } from '../synora-v5/pst/secrets.mjs';
import { Ledger } from '../synora-v5/ledger.mjs';
import { applyEdit, editsFor, findCalls, setArg, removeCall, insertCall, fieldSet } from '../synora-v5/pst/operators.mjs';
import { TOOLS } from '../synora-v5/pst/environment.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(HERE, '..');

let passed = 0;
let failed = 0;
const failures = [];

async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  ok  ${name}`);
  } catch (err) {
    failed++;
    failures.push({ name, err });
    console.log(`  FAIL ${name}: ${err.message}`);
  }
}

/** Build the reference program of a task from its private plan (test-side only). */
function buildFromPlan(plan) {
  let expr = 'input';
  for (const call of plan.calls) {
    const [name, ...args] = call;
    const contract = TOOLS[name].args;
    const parts = args.map(a => JSON.stringify(a));
    if (contract[0] === 'entries' || contract[0] === 'text') parts.unshift(expr);
    expr = `${name}(${parts.join(', ')})`;
  }
  if (plan.field === 'length') expr += '.length';
  else if (plan.field) expr += `.${plan.field}`;
  return `function solution(input){return ${expr}}`;
}

const grader = new Grader({ size: 2, timeoutMs: 700 });
await grader.init();

/* ------------------------------------------------------------------ tests */

await test('tasks: 12 tasks, 6 per set, every seed is a valid program', () => {
  assert.equal(TASKS.length, 12);
  assert.equal(bySet('A').length, 6);
  assert.equal(bySet('B').length, 6);
  for (const task of TASKS) {
    assert.ok(task.required.length >= 2, `${task.id} needs required tools`);
    assert.ok(task.maxCalls > 0);
    assert.match(task.seed, /function solution\(input\)/);
  }
});

await test('grader: the reference program of every task scores a perfect score', async () => {
  for (const task of TASKS) {
    const code = buildFromPlan(PLANS[task.id]);
    const result = await grader.grade(code, task, taskInput(task));
    assert.ok(result.private.full, `${task.id} reference should be perfect, got ${result.public.score}`);
    assert.deepEqual(result.public.violations, []);
  }
});

await test('grader: every seed is wrong, and the reported categories are precise', async () => {
  for (const task of TASKS) {
    const result = await grader.grade(task.seed, task, taskInput(task));
    assert.ok(!result.private.full, `${task.id} seed must not be perfect`);
    assert.ok(result.public.violations.length > 0);
    assert.ok(result.public.violations.includes('wrong_value'), `${task.id} must report a wrong value`);
  }
});

await test('grader: the solver-visible view never contains the expected value', async () => {
  for (const task of TASKS) {
    const result = await grader.grade(task.seed, task, taskInput(task));
    const serialised = JSON.stringify(result.public);
    assert.ok(!serialised.includes('expected'), `${task.id} public view leaks the field name`);
    if (typeof result.private.expected === 'string') {
      assert.ok(!serialised.includes(result.private.expected), `${task.id} public view leaks the answer`);
    }
  }
});

await test('no-leak: the engine and the operators never import the answer key', () => {
  for (const file of ['engine.mjs', 'operators.mjs', 'tasks.mjs', 'environment.mjs']) {
    const source = fs.readFileSync(path.join(ROOT, 'synora-v5', 'pst', file), 'utf8');
    assert.ok(!/from '\.\/secrets\.mjs'/.test(source), `${file} imports secrets.mjs`);
    assert.ok(!/secrets/i.test(source.replace(/^\s*\*.*$/gm, '')), `${file} mentions secrets`);
  }
  const graderSource = fs.readFileSync(path.join(ROOT, 'synora-v5', 'pst', 'grader.mjs'), 'utf8');
  assert.ok(/from '\.\/secrets\.mjs'/.test(graderSource), 'the grader must be the only importer');
});

await test('no-leak: the ledger stores repair shapes and parameters, never answers', async () => {
  const ledger = new Ledger();
  const engine = new PstEngine({ grader, ledger, mode: 'cri', seed: 5, budget: 200, generations: 60 });
  await engine.runTask(byId('A1_largest_txt_names'));
  const dump = JSON.stringify(ledger.toJSON ? ledger.toJSON() : [...ledger.skills.values()]);
  const answers = [Grader.expectedValue(byId('A1_largest_txt_names'))];
  for (const answer of answers) {
    if (typeof answer !== 'string') continue;
    assert.ok(!dump.includes(answer), `the ledger leaked the answer "${answer}"`);
  }
});

await test('operators: SET_ARG addresses a named slot, not a position', () => {
  const code = "function solution(input){return sortBy(listDir(),'name','asc')}";
  const next = setArg(code, 'sortBy', 'dir', 'desc');
  assert.ok(next.includes("'desc'"));
  assert.ok(next.includes("'name'"), 'the other slot must stay untouched');
});

await test('operators: INSERT_CALL wraps the pipeline head', () => {
  const code = 'function solution(input){return toArabicDigits(input)}';
  const next = insertCall(code, 'normalizeSpaces');
  assert.equal(next, 'function solution(input){return toArabicDigits(normalizeSpaces(input))}');
});

await test('operators: REMOVE_CALL re-threads the pipeline', () => {
  const code = "function solution(input){return countByExt(filterByExt(listDir(),'txt'))}";
  const next = removeCall(code, 'filterByExt');
  assert.equal(next, "function solution(input){return countByExt(listDir())}");
});

await test('operators: FIELD_SET renames the trailing property', () => {
  const code = "function solution(input){return countByExt(listDir()).csv}";
  assert.ok(fieldSet(code, 'md').endsWith('.md}'));
});

await test('operators: the argument offsets are absolute in the source', () => {
  const code = "function solution(input){return joinNames(take(sortBy(filterByExt(listDir(),'txt'),'size','asc'),2),'-')}";
  const calls = findCalls(code, 'take');
  assert.equal(calls.length, 1);
  assert.equal(code.slice(calls[0].args[1].start, calls[0].args[1].end), '2');
});

await test('composition is necessary: no single operator solves the strict tasks', async () => {
  const strict = TASKS.filter(t => t.strict);
  assert.ok(strict.length >= 3, 'the domain must contain composition-only tasks');
  for (const task of strict) {
    const seedGrade = await grader.grade(task.seed, task, taskInput(task));
    const edits = editsFor(seedGrade.public.violations, task.seed);
    let best = 0;
    for (const edit of edits) {
      const code = applyEdit(task.seed, edit);
      if (!code) continue;
      const grade = await grader.grade(code, task, taskInput(task));
      if (grade.public.score > best) best = grade.public.score;
    }
    assert.ok(best < 1, `${task.id} must NOT be solvable by a single operator (best=${best})`);
  }
});

await test('composition is sufficient: the reference program needs several repairs', () => {
  const task = byId('A1_largest_txt_names');
  const families = familiesFor(['wrong_arg:sortBy:dir', 'wrong_arg:take:n', 'wrong_arg:joinNames:sep']);
  assert.equal(families.filter(f => f.kind !== 'GENERIC').length, 3);
});

await test('engine: determinism — the same seed gives the same result', async () => {
  const run = async () => {
    const ledger = new Ledger();
    const engine = new PstEngine({ grader, ledger, mode: 'cri', seed: 42, budget: 120, generations: 40 });
    const result = await engine.runTask(byId('A2_type_counts'));
    return `${result.success}|${result.evaluations}|${result.champion.code}`;
  };
  assert.equal(await run(), await run());
});

await test('engine: the memory never invents a repair for a category it has not seen', async () => {
  const ledger = new Ledger();
  const engine = new PstEngine({ grader, ledger, mode: 'cri', seed: 3, budget: 120, generations: 40 });
  await engine.runTask(byId('A3_total_txt_size'));
  const categories = [...ledger.skills.values()].map(s => s.signature);
  assert.ok(categories.includes('wrong_arg:filterByExt:ext'));
  assert.ok(!categories.some(c => c.startsWith('missing_tool:listDir')), 'no invented categories');
});

await test('engine: the budget is respected', async () => {
  const engine = new PstEngine({ grader, ledger: new Ledger(), mode: 'cri', seed: 9, budget: 25, generations: 100 });
  const result = await engine.runTask(byId('A1_largest_txt_names'));
  assert.ok(result.evaluations <= 26, `the budget was exceeded: ${result.evaluations}`);
});

await test('engine: the base arm and the CRI arm both reach the goal on an easy task', async () => {
  for (const mode of ['base', 'cri']) {
    const engine = new PstEngine({ grader, ledger: new Ledger(), mode, seed: 1, budget: 60, generations: 40 });
    const result = await engine.runTask(byId('A3_total_txt_size'));
    assert.ok(result.success, `${mode} failed A3`);
  }
});

await test('engine: a wrong inherited hint costs one evaluation and does not break the search', async () => {
  const shared = new Ledger();
  const first = new PstEngine({ grader, ledger: shared, mode: 'cri', seed: 1, budget: 200, generations: 60 });
  await first.runTask(byId('A3_total_txt_size'));        // learns the hint ext='txt'
  const second = new PstEngine({ grader, ledger: shared, mode: 'cri', seed: 1, budget: 200, generations: 60 });
  const result = await second.runTask(byId('B3_total_csv_size'));  // needs ext='csv'
  assert.ok(result.success, 'the wrong hint must not prevent the solution');
});

await test('the whole PST package is inside synora-v5/pst and does not touch v4', () => {
  const files = fs.readdirSync(path.join(ROOT, 'synora-v5', 'pst'));
  for (const expected of ['tasks.mjs', 'secrets.mjs', 'grader.mjs', 'sandbox-worker.mjs', 'operators.mjs', 'engine.mjs', 'experiments.mjs', 'environment.mjs']) {
    assert.ok(files.includes(expected), `missing ${expected}`);
  }
});

await grader.close();

console.log(`\n${passed} passed, ${failed} failed`);
if (failed) {
  for (const f of failures) console.log(`\n--- ${f.name}\n${f.err.stack}`);
  process.exit(1);
}
