import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const tribes = ['marketing', 'coding', 'arabic', 'english', 'discussion'];
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-war-test-'));
let passed = 0;
function ok(name) { passed++; console.log(`PASS ${name}`); }
function run(cwd, args, env = {}) {
  return spawnSync(process.execPath, args, { cwd, encoding: 'utf8', timeout: 30000, env: { ...process.env, ...env } });
}
try {
  for (const file of ['synora-evo-farm-v4.mjs', 'convert-skill.js']) {
    const r = run(here, ['--check', file]);
    assert.equal(r.status, 0, r.stderr); ok(`syntax ${file}`);
  }
  // Full integration runs in a disposable copy so the test itself does not mutate the delivered package.
  const fresh = path.join(tmp, 'fresh');
  fs.cpSync(here, fresh, { recursive: true, filter: p => !p.includes(`${path.sep}.git${path.sep}`) });
  for (const tribe of tribes) {
    const r = run(fresh, ['synora-evo-farm-v4.mjs', `--tribe=${tribe}`, '--with-teacher', '--once'], { SYNORA_TIMEOUT_MS: '1000' });
    assert.equal(r.status, 0, `${tribe}: ${r.stderr}\n${r.stdout}`);
    const summary = JSON.parse(r.stdout);
    assert.equal(summary.evaluated, 20, `${tribe} evaluated count`);
    assert.ok(summary.validationTests > 0, `${tribe} has validation tests`);
    const p = path.join(fresh, 'tribes', tribe);
    const ark = JSON.parse(fs.readFileSync(path.join(p, `ark_${tribe}.json`), 'utf8'));
    assert.ok(ark.organisms.length <= 100);
    for (const o of ark.organisms) assert.ok(Buffer.byteLength(o.code, 'utf8') <= 144, `${tribe} genome >144 bytes`);
    const teacher = fs.readFileSync(path.join(p, 'teacher.js'), 'utf8').trim();
    assert.ok(teacher.startsWith('function solution('));
    ok(`integration ${tribe}: 20 candidates, validation gate, Ark/genome limits`);
  }
  // Missing tests must stop evolution and preserve the current teacher byte-for-byte.
  const noTests = path.join(tmp, 'no-tests'); fs.cpSync(fresh, noTests, { recursive: true });
  const nt = path.join(noTests, 'tribes/coding');
  fs.writeFileSync(path.join(nt, 'killers_coding.jsonl'), '');
  const before = fs.readFileSync(path.join(nt, 'teacher.js'), 'utf8');
  const noTestRun = run(noTests, ['synora-evo-farm-v4.mjs', '--tribe=coding', '--with-teacher', '--once']);
  assert.notEqual(noTestRun.status, 0); assert.equal(fs.readFileSync(path.join(nt, 'teacher.js'), 'utf8'), before);
  ok('fail closed when test suite is empty; teacher remains unchanged');
  // Infinite-loop teacher must time out and must not be replaced by a worse pupil.
  const hang = path.join(tmp, 'hang'); fs.cpSync(fresh, hang, { recursive: true });
  const ht = path.join(hang, 'tribes/coding/teacher.js');
  const hangingCode = 'function solution(a){while(true){}}';
  fs.writeFileSync(ht, hangingCode + '\n');
  const hangRun = run(hang, ['synora-evo-farm-v4.mjs', '--tribe=coding', '--with-teacher', '--once'], { SYNORA_TIMEOUT_MS: '50' });
  assert.equal(hangRun.status, 0, hangRun.stderr);
  assert.equal(fs.readFileSync(ht, 'utf8').trim(), hangingCode);
  assert.ok(fs.readFileSync(path.join(hang, 'synora-sleep.jsonl'), 'utf8').includes('Execution timeout'));
  ok('infinite-loop candidate is timed out, logged, and cannot overwrite teacher');
  // Converter must parse only explicitly tagged rules and produce valid JSONL.
  const conv = path.join(tmp, 'converter'); fs.cpSync(fresh, conv, { recursive: true });
  fs.writeFileSync(path.join(conv, 'sample.md'), '- [KILLER:coding] Invalid input must return error\nnot a killer\n');
  const cr = run(conv, ['convert-skill.js', 'sample.md']); assert.equal(cr.status, 0, cr.stderr);
  const rows = fs.readFileSync(path.join(conv, 'tribes/coding/killers_coding.jsonl'), 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  assert.ok(rows.some(x => x.rule === 'Invalid input must return error'));
  ok('converter creates valid JSONL from explicit tagged rules');
  // Atomic save leaves no temp artifacts.
  const tmpFiles = [];
  function walk(d) { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else if (/\.tmp$/.test(e.name)) tmpFiles.push(p); } }
  walk(fresh); assert.deepEqual(tmpFiles, []); ok('no orphaned atomic-write temp files');
  console.log(`\nRESULT: ${passed} checks passed.`);
} finally {
  fs.rmSync(tmp, { recursive: true, force: true });
}
