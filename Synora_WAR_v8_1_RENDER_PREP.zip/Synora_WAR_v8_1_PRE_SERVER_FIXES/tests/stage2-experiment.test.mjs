import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PstEngine } from '../synora-v5/pst/engine.mjs';
import { AdaptivePstEngine } from '../synora-v5/phase4/adaptive-engine.mjs';
import { captureNativeMemory, restoreNativeMemory } from '../scripts/stage2/native-memory.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const base=path.join(root,'experiments/stage2');
const cases=JSON.parse(fs.readFileSync(path.join(base,'benchmark-cases.json'),'utf8'));
const answers=JSON.parse(fs.readFileSync(path.join(base,'answer-key.json'),'utf8'));
const all=[...cases.development,...cases.validation,...cases.finalTest];
test('stage2 task IDs are unique and reference keys are separate',()=>{
  const ids=all.map(x=>x.id); assert.equal(new Set(ids).size,ids.length);
  for(const c of all){assert.ok(answers[c.id],`missing answer key for ${c.id}`);assert.equal(Object.hasOwn(c,'expected'),false);}
  assert.equal(Object.keys(answers).length,all.length);
});
test('stage2 final test includes required symbolic reasoning categories',()=>{
  const cats=new Set(cases.finalTest.map(x=>x.category));
  for(const c of ['fact_retrieval','one_rule','multi_step','multi_premise_3','new_entity_transfer','changed_fact_retraction','contradiction_detection','insufficient_evidence','hypothesis_not_premise','restart_persistence','novel_conjunctive_chain','valid_multivalue_relation']) assert.ok(cats.has(c),`missing ${c}`);
});
test('stage2 answer key keeps abstention and contradiction expectations explicit',()=>{
  assert.equal(answers['FINAL-CONFLICT-2C'].expected,null);
  assert.equal(answers['FINAL-ABSTAIN-5D'].expected,null);
  assert.equal(answers['FINAL-HYPOTHESIS-1F'].expected,null);
  assert.deepEqual(answers['FINAL-MULTIVALUE-4N'].expected,['read','write']);
});
test('stage2 split definitions separate development, validation and held-out final test',()=>{
  assert.equal(cases.development.length,3); assert.equal(cases.validation.length,3); assert.equal(cases.finalTest.length,12);
  assert.ok(cases.finalTest.every(x=>x.id.startsWith('FINAL-')));
  assert.ok(!cases.finalTest.some(x=>x.id.startsWith('A')||x.id.startsWith('B')));
});


test('native memory persistence restores both hint maps and verified ledger skills',()=>{
  for (const Engine of [PstEngine, AdaptivePstEngine]) {
    const mode = Engine === AdaptivePstEngine ? 'adaptive' : 'cri';
    const original = new Engine({mode, seed:17, budget:20});
    original.hints.set('SET_ARG:sortBy:dir','asc');
    original.ledger.noteSuccess({taskId:'stage2-memory-test',signature:'wrong_arg:sortBy:dir',transformId:'set-dir',gen:1,hint:{key:'SET_ARG:sortBy:dir',value:'asc'}});
    const saved = captureNativeMemory(original);
    const restored = restoreNativeMemory(new Engine({mode, seed:17, budget:20}), JSON.parse(JSON.stringify(saved)));
    assert.equal(restored.hintFor('SET_ARG:sortBy:dir'), 'asc');
    assert.ok(restored.ledger.skills.size > 0);
  }
});

test('the worker uses the declared generation budget instead of a hidden hard-coded value',()=>{
  const worker=fs.readFileSync(path.join(root,'scripts/stage2/engine-worker.mjs'),'utf8');
  assert.match(worker,/generations:\s*config\.generations\s*\?\?\s*20/);
  assert.match(worker,/populationSize:\s*config\.populationSize\s*\?\?\s*8/);
});

test('the final run includes fresh-process native-memory and additive native-plus-core arms',()=>{
  const results=JSON.parse(fs.readFileSync(path.join(base,'results-raw.json'),'utf8'));
  assert.ok(results.engine.some(r=>r.condition==='fresh-process-native-memory'));
  assert.ok(results.engine.some(r=>r.condition==='fresh-process-native-and-digital-core-memory'));
  assert.equal(results.meta.config.engineGenerations,20);
  assert.equal(results.meta.results.failures,0);
  assert.ok(results.core.some(r=>r.taskId==='SESSION-TRANSFER-COLD-CONTROL'&&r.success&&r.answer===null),'cross-process transfer needs a matched no-rule control');
});

test('paired ablation rows match each seed/task and trace core hits separately from outcome changes',()=>{
  const p=JSON.parse(fs.readFileSync(path.join(base,'paired-ablation.json'),'utf8'));
  assert.equal(p.rows.length,36);
  for(const r of p.rows) {
    assert.ok([17,43,101].includes(r.seed));
    assert.ok(['B3_total_csv_size','B4_clean_amount_en','B5_min_size_50'].includes(r.taskId));
    assert.equal(r.successChanged,false,'core changed success outcome in a matched run');
  }
  const adaptiveCoreOnly=p.rows.filter(r=>r.mode==='adaptive'&&r.comparison==='cold-vs-digital-core-only');
  assert.ok(adaptiveCoreOnly.every(r=>r.coreHintHits===0),'Adaptive V2 arm must not be credited for calls without hits');
  const criCoreOnly=p.rows.filter(r=>r.mode==='cri'&&r.comparison==='cold-vs-digital-core-only');
  assert.ok(criCoreOnly.some(r=>r.coreHintHits>0),'CRI core arm should have traceable hits on supported tasks');
});
