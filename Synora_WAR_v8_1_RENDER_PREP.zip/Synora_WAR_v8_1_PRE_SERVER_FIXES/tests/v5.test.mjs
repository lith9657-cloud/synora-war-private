/**
 * Synora WAR v5 — automated test suite.
 *
 *   node tests/v5.test.mjs
 *
 * The suite covers: benchmark validity, the CRI mechanism (causal attribution, skill promotion,
 * witness soundness, pruning), the anti-leak rule, determinism, budget enforcement, and two
 * claims about the v4 engine that the diagnosis rests on (the "wisdom" comment is behaviourally
 * inert, and it leaks across tribes).
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const v5 = name => path.join(here, 'synora-v5', name);

const { Judge } = await import(v5('judge.mjs'));
const { Ledger } = await import(v5('ledger.mjs'));
const { Engine } = await import(v5('engine.mjs'));
const { TASKS, byId, bySet } = await import(v5('tasks.mjs'));
const { expectedFromTestSource, expectedLiteral, signatureOf, applyTransform, insertGuard } = await import(v5('genome.mjs'));

let passed = 0;
const ok = name => { passed++; console.log(`PASS ${name}`); };
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-v5-test-'));

try {
  const judge = new Judge({ size: 2, timeoutMs: 800 });
  await judge.init();

  /* ---------------------------------------------------------------- 1. benchmark */
  for (const task of TASKS) {
    const problems = await judge.validateTask(task);
    assert.deepEqual(problems, [], `${task.id}: ${problems.join('; ')}`);
  }
  ok(`benchmark: ${TASKS.length} tasks valid (oracle passes, seed fails train+validation, probe/holdout disjoint)`);

  const a = byId('A1_sum_list');
  const b = byId('B1_count_digits');
  assert.equal(a.bugClass, b.bugClass, 'paired tasks must share a bug class');
  assert.equal(bySet('A').length, 4);
  assert.equal(bySet('B').length, 4);
  ok('benchmark: paired bug classes and held-out set B are declared');

  /* ------------------------------------------------------- 2. failure algebra */
  assert.equal(expectedLiteral('Expected 3, got 2'), '3');
  assert.equal(expectedLiteral('Expected "hi", got "ho"'), '"hi"');
  assert.equal(expectedFromTestSource('const r=solution(input); if(r!=="") throw new Error("x")'), '""');
  assert.equal(expectedFromTestSource('const r=solution(input); if(r!==0) throw new Error("x")'), '0');
  assert.equal(signatureOf({ error: 'Expected 3, got 2' }), 'below_by_1');
  assert.equal(signatureOf({ error: 'Expected 3, got 1' }), 'below');
  assert.equal(signatureOf({ error: 'TypeError: Cannot read properties of null' }), 'threw:TypeError');
  assert.equal(signatureOf({ error: 'Expected "a", got "b"' }), 'string_mismatch');
  ok('algebra: demanded value extracted from message AND from test source; signatures are task-independent');

  /* ------------------------------------------------------- 3. causal attribution */
  const engine = new Engine({ judge, ledger: new Ledger(), mode: 'full', seed: 5 });
  const ledger = engine.ledger;
  const parent = {
    id: 'p', lineageOps: [],
    evaluation: { train: { passed: 2, total: 2, failures: [] }, validation: { passed: 1, total: 1 }, witnesses: { passed: 0, total: 0, violations: [] } },
  };
  const child = {
    id: 'c', transformId: 'ADD_NULL_GUARD', lineageOps: [],
    evaluation: { train: { passed: 1, total: 2, failures: [{ name: 'k1', error: 'Expected 0, got 1' }] }, validation: { passed: 0, total: 1 }, witnesses: { passed: 0, total: 0, violations: [] } },
  };
  const events = [];
  engine.attribute(parent, child, a, 1, events);
  assert.equal(events.filter(e => e.type === 'failure' && e.attributable).length, 1, 'parent passed k1, child failed it -> attributable');
  assert.equal(ledger.refutations.size, 1, 'the refutation must be recorded');

  // the same failure when the PARENT also failed it is inherited, not caused
  const parentFailing = { ...parent, evaluation: { ...parent.evaluation, train: { passed: 1, total: 2, failures: [{ name: 'k1', error: 'Expected 0, got 1' }] } } };
  const events2 = [];
  const ledger2 = new Ledger();
  const engine2 = new Engine({ judge, ledger: ledger2, mode: 'full', seed: 5 });
  engine2.attribute(parentFailing, child, a, 2, events2);
  assert.equal(events2.filter(e => e.type === 'failure' && e.attributable).length, 0, 'inherited failure must not be attributed');
  assert.equal(ledger2.refutations.size, 0, 'no false lesson from an inherited failure');
  ok('CRI: failure is attributed only when the parent passed the same killer (attribution by intervention)');

  /* ------------------------- 3b. a coincidental fix must not earn credit */
  const ledgerCoincide = new Ledger();
  const engineCoincide = new Engine({ judge, ledger: ledgerCoincide, mode: 'full', seed: 5 });
  const luckyChild = {
    id: 'c2', transformId: 'LITERAL_PERTURB', lineageOps: [],
    evaluation: {
      train: { passed: 2, total: 2, failures: [] },
      validation: { passed: 1, total: 1 },
      // the child satisfies the failing test by luck, but breaks an inherited witness
      witnesses: { passed: 0, total: 1, violations: ['witness:leak'] },
    },
  };
  const eventsCoincide = [];
  engineCoincide.attribute(parent, luckyChild, a, 3, eventsCoincide);
  assert.equal(ledgerCoincide.skills.size, 0, 'a fix that violates an inherited witness must not become a skill');
  assert.equal(eventsCoincide.filter(e => e.type === 'repair').every(e => e.credible === false), true, 'the event must be flagged as not credible');
  ok('CRI: a coincidental pass (violating a witness) earns no credit');

  /* --------------------------------------------------- 4. skill promotion rules */
  const ledger3 = new Ledger();
  ledger3.noteAttributableFailure({ taskId: 'T', signature: 'below_by_1', transformId: 'X', gen: 1, message: 'm' });
  assert.equal(ledger3.skills.size, 0, 'an unverified refutation must not become a skill');
  assert.equal(ledger3.skillsFor('below_by_1').length, 0);
  ledger3.noteSuccess({ taskId: 'T', signature: 'below_by_1', transformId: 'X', gen: 2, witnesses: ['w1'] });
  assert.equal(ledger3.skills.size, 1, 'a verified success promotes the refutation to a skill');
  assert.equal(ledger3.skillsFor('below_by_1')[0].transformId, 'X');
  assert.equal(ledger3.rankedOperatorsFor('below_by_1')[0].verified, true);
  ok('CRI: skills are promoted only by a verified success; unverified refutations stay hypotheses');

  /* ------------------------------------------------------- 5. witness soundness */
  const ledger4 = new Ledger();
  const thrown = await judge.differential('function solution(a){return a.length}', a.reference, [null]);
  assert.equal(thrown.length, 0, 'a disagreement where the ORACLE itself throws is not a witness');
  const real = await judge.differential(a.buggy, a.reference, a.probes);
  assert.ok(real.length > 0, 'the buggy seed must produce sound counterexamples');
  for (const witness of real) {
    ledger4.addWitness({ taskId: a.id, input: witness.input, expected: witness.expected, actual: witness.actual, signature: 'witness', origin: 'breaker', gen: 1 });
  }
  assert.equal(ledger4.witnesses.size, real.length);
  assert.equal(ledger4.witnessesFor(a.id).length, real.length);
  ok('witnesses: only sound counterexamples are filed; oracle-domain errors are excluded');

  /* ------------------------------------------------------------ 6. anti-leak */
  const evalResult = await engine.evaluate(a.buggy, a);
  assert.deepEqual(Object.keys(evalResult.validation).sort(), ['passed', 'total'], 'validation must expose counts only');
  assert.ok(evalResult.train.failures.every(f => 'error' in f), 'train failures keep the error message');
  assert.ok(!('failures' in evalResult.validation), 'validation details must never reach the engine');
  ok('anti-leak: held-out validation results are exposed as counts only');

  /* ------------------------------------------------------- 7. memory hygiene */
  const ledger5 = new Ledger();
  ledger5.noteAttributableFailure({ taskId: 'T', signature: 's', transformId: 'X', gen: 1, message: 'm' });
  ledger5.prune({ gen: 100, staleGens: 12 });
  assert.equal(ledger5.refutations.size, 0, 'stale uncredited refutations must be pruned');
  ok('memory hygiene: uncredited knowledge ages out instead of flooding the store');

  /* ------------------------------------------------------- 8. guard composition */
  const guarded = insertGuard('function solution(a){return a[0]}', 'if(a==null)return "";');
  const composed = insertGuard(guarded, 'if(a.length===0)return "";');
  assert.ok(composed.indexOf('a==null') < composed.indexOf('a.length===0'), 'null guard must precede the length guard');
  ok('composition: guards are inserted in dependency order');

  /* -------------------------------------------------------- 9. determinism */
  const runOnce = async () => {
    const localJudge = new Judge({ size: 1, timeoutMs: 500 });
    await localJudge.init();
    const local = new Engine({ judge: localJudge, ledger: new Ledger(), mode: 'full', seed: 42, budget: 200, generations: 40 });
    const r = await local.runTask(byId('A2_safe_length'));
    await localJudge.close();
    return `${r.success}|${r.evaluations}|${r.champion.code}`;
  };
  const first = await runOnce();
  const second = await runOnce();
  assert.equal(first, second, 'the same seed must reproduce the same run');
  ok('determinism: identical seeds reproduce identical runs');

  /* ------------------------------------------------------ 10. budget ceiling */
  const bounded = new Engine({ judge, ledger: new Ledger(), mode: 'full', seed: 3, budget: 25, generations: 500 });
  const boundedResult = await bounded.runTask(byId('A3_count_vowels_ar'));
  assert.ok(boundedResult.evaluations <= 26, `evaluation budget exceeded: ${boundedResult.evaluations}`);
  ok('budget: the engine never exceeds its evaluation budget');

  /* --------------------------------------- 11. the memory ablation is real */
  const randomEngine = new Engine({ judge, ledger: new Ledger(), mode: 'random', seed: 9, budget: 200, generations: 40 });
  assert.equal(randomEngine.memoryEnabled, false);
  const randomResult = await randomEngine.runTask(byId('A2_safe_length'));
  assert.equal(randomEngine.ledger.skills.size, 0, 'the no-memory arm must not accumulate skills');
  assert.equal(randomResult.success || !randomResult.success, true);
  ok('ablation: the no-memory arm runs the same operators without the ledger');

  await judge.close();

  /* ------------------------------- 12. v4 claim A: the "wisdom" comment is inert */
  const commented = 'function solution(a){/*W:sum_empty*/return a.length}';
  const judge2 = new Judge({ size: 1, timeoutMs: 500 });
  await judge2.init();
  const plain = await judge2.runKillers('function solution(a){return a.length}', [a.train[0]]);
  const withComment = await judge2.runKillers(commented, [a.train[0]]);
  assert.equal(plain.passed, withComment.passed, 'the wisdom comment changed the outcome');
  assert.deepEqual(plain.failures.map(f => f.name), withComment.failures.map(f => f.name));
  await judge2.close();
  ok('v4 claim A: the graveyard-derived "wisdom" comment is behaviourally inert');

  /* ------------------- 13. v4 claim B: the wisdom leaks across tribes (empirical) */
  const leakRoot = path.join(tmp, 'leak');
  fs.mkdirSync(path.join(leakRoot, 'tribes', 'coding'), { recursive: true });
  fs.writeFileSync(path.join(leakRoot, 'tribes', 'coding', 'teacher.js'), 'function solution(a){return typeof a===\'number\'?a*2:\'error\'}\n', 'utf8');
  fs.writeFileSync(path.join(leakRoot, 'tribes', 'coding', 'killers_coding.jsonl'),
    JSON.stringify({ type: 'js_test', name: 'coding_doubles_number', input: 2, test: 'const r=solution(input); if(r!==4) throw new Error("x");' }) + '\n', 'utf8');
  // a failure that belongs to a DIFFERENT tribe
  fs.writeFileSync(path.join(leakRoot, 'synora-sleep.jsonl'),
    JSON.stringify({ tribe: 'arabic', code: 'x', error: 'arabic failure marker', killer: 'arabic_only_marker', at: new Date().toISOString() }) + '\n', 'utf8');
  const v4src = fs.readFileSync(path.join(here, 'synora-evo-farm-v4.mjs'), 'utf8');
  const patchedV4 = v4src.replace(/const TRIBES = \[[^\]]*\];/, `const TRIBES = ['coding'];`);
  const v4path = path.join(leakRoot, 'engine.mjs');
  fs.writeFileSync(v4path, patchedV4, 'utf8');
  const leakRun = spawnSync(process.execPath, [v4path, '--tribe=coding', '--with-teacher', '--once'], { cwd: leakRoot, encoding: 'utf8', timeout: 60000 });
  assert.equal(leakRun.status, 0, leakRun.stderr);
  const leaked = fs.readFileSync(path.join(leakRoot, 'tribes', 'coding', 'teacher.js'), 'utf8');
  const arkText = fs.readFileSync(path.join(leakRoot, 'tribes', 'coding', 'ark_coding.json'), 'utf8');
  const corpus = leaked + arkText;
  // the comment is truncated to 10 characters by v4 itself, so we look for the truncated marker
  assert.ok(/W:arabic/.test(corpus), `expected the arabic failure to leak into the coding tribe, got: ${corpus.slice(0, 300)}`);
  assert.ok(!/W:coding/.test(corpus.split('W:arabic')[0] + ''), 'sanity: the leaked marker is the foreign one');
  ok('v4 claim B: the failure graveyard is global — a tribe can inherit another tribe\'s "wisdom"');

  console.log(`\nRESULT: ${passed} checks passed.`);
} finally {
  fs.rmSync(tmp, { recursive: true, force: true });
}
