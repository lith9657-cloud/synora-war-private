import test from 'node:test';
import assert from 'node:assert/strict';
import { SafeTransferLedger } from '../synora-v5/safe-transfer-ledger.mjs';

test('safe-transfer ledger exposes inherited ledger API and isolates misses by target task',()=>{
 const l=new SafeTransferLedger();
 assert.equal(typeof l.noteSuccess,'function'); assert.equal(typeof l.noteOperatorMiss,'function'); assert.equal(typeof l.rankedOperatorsFor,'function');
 l.noteSuccess({taskId:'task-a',signature:'sig',transformId:'op',gen:1});
 l.noteOperatorMiss({taskId:'task-b',signature:'sig',transformId:'op',gen:2});
 const skill=l.skills.get(l.refutationKey('sig','op'));
 assert.ok(skill); assert.equal(skill.taskMisses['task-b'],1);
});

test('one task success is not transferred to an unrelated task',()=>{
 const l=new SafeTransferLedger();
 l.noteSuccess({taskId:'task-a',signature:'same-surface-symptom',transformId:'op',gen:1});
 assert.deepEqual(l.rankedOperatorsFor('same-surface-symptom',{taskId:'task-b'}),[]);
 assert.equal(l.rankedOperatorsFor('same-surface-symptom',{taskId:'task-a'}).some(x=>x.transformId==='op'),true);
});

test('cross-task transfer requires two distinct task successes',()=>{
 const l=new SafeTransferLedger();
 l.noteSuccess({taskId:'task-a',signature:'same-surface-symptom',transformId:'op',gen:1});
 l.noteSuccess({taskId:'task-a',signature:'same-surface-symptom',transformId:'op',gen:2});
 assert.deepEqual(l.rankedOperatorsFor('same-surface-symptom',{taskId:'task-c'}),[]);
 l.noteSuccess({taskId:'task-b',signature:'same-surface-symptom',transformId:'op',gen:3});
 assert.equal(l.rankedOperatorsFor('same-surface-symptom',{taskId:'task-c'}).some(x=>x.transformId==='op'),true);
});

test('a failed transfer is blocked for that target task even if another task verified it',()=>{
 const l=new SafeTransferLedger();
 l.noteSuccess({taskId:'task-a',signature:'same-surface-symptom',transformId:'op',gen:1});
 l.noteSuccess({taskId:'task-b',signature:'same-surface-symptom',transformId:'op',gen:2});
 l.noteOperatorMiss({taskId:'task-c',signature:'same-surface-symptom',transformId:'op',gen:3});
 assert.equal(l.rankedOperatorsFor('same-surface-symptom',{taskId:'task-c'}).some(x=>x.transformId==='op'),false);
 assert.equal(l.rankedOperatorsFor('same-surface-symptom',{taskId:'task-d'}).some(x=>x.transformId==='op'),true);
});
