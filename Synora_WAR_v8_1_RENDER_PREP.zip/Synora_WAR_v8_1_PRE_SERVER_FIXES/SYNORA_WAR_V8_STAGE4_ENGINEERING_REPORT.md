# Synora WAR V8 — Stage 4 engineering report

**Status:** implemented bounded prototype; V7 baseline retained; tests must be read with the scope and limits below.

## 1. Baseline provenance

- Input archive: `Synora_WAR_v7_DIGITAL_OBJECTS_EVALUATED_FINAL.zip`.
- SHA-256 checked before changes: `8d6e326c94346813ddb280af2b52255b68dc7931ef63371ed397cfed5e2a1476` — exact match to the supplied reference.
- The original archive was not modified. A baseline extraction and a separate development copy were used.
- Node.js: v22.16.0; package target remains Node.js >=20; no new third-party dependencies.
- The unmodified V7 baseline test suite was rerun and exited 0: 172 checks/subtests passed, 0 failed.

## 2. What V7 already had

V7 includes the CRI and Adaptive V2 experimental engines, the existing evolutionary engine, a bounded symbolic digital-object core with facts/relations/rules and persistent state, the opt-in adapter, previous stage tests, and the stage-2 experiment artifacts. These systems do not by themselves provide general natural-language understanding or open-ended code generation.

## 3. Stage 4 additions

- `synora-v5/dialogue/index.mjs`: bounded Arabic/English lexical intent parser, limited slots, request evidence, and explicit resolution of a small class of follow-up requests.
- `synora-v5/dialogue/agent.mjs`: traces the parse/tool/template/skill steps and returns either a validated result or an explicit abstention.
- `synora-v5/solution-engine/index.mjs`: reviewed JavaScript templates for sum-array, max-array, and factorial; positive and negative test cases; rejects unsupported requests; does not execute arbitrary user source.
- `synora-v5/tools/registry.mjs`: inspectable capability registry and a validated arithmetic tool.
- `synora-v5/digital-object-learning/index.mjs`: bounded affine-mod induction, provenance, development checks, duplicate-experience guard, composition, evaluation events, candidate mutation gate, and checksum-protected persistence.
- `synora-v5/digital-object-learning/bridge.mjs`: registers accepted skills as objects, ownership relations, and evidence-bearing facts in the existing `DigitalObjectCore`. The API verifies that a skill is registered and active before applying it through the chat path.
- `synora-v5/api/server.mjs`: dependency-free HTTP API with a 64 KiB body cap, bounded history/text size, local-only default bind, optional bearer token, simple request rate limit, and persistence of both the learner ledger and digital-object core.
- `experiments/stage4/`: versioned task data, evaluator answer key, a retained pilot run, final V2 run, raw JSON/CSV, and a reproducible runner.
- `tests/stage4/stage4.test.mjs`: dialogue, follow-up context, skill invocation through dialogue, code-template positive/negative tests, tool validation, induction, mutation rollback, cross-process persistence, corruption rejection, core bridge, data separation, HTTP integration, and remote-bind protection.

## 4. Important repairs and safeguards

- Fixed a duplicated `candidate.history` assignment in the new skill-learning module.
- Fixed unsupported programming requests so the dialogue path explicitly abstains instead of returning an ambiguous code-generation result.
- Added input validation and clear HTTP error mapping for malformed skill requests.
- Added explicit synchronization between learned skills and the existing digital-object core; registration is idempotent and includes source/provenance facts.
- Added recovery synchronization at API startup so a learner skill persisted before a core-store write failure can be registered on the next startup.
- Added negative code tests for invalid arrays, overflow, empty maximum input, and factorial bounds.
- Kept the original CRI and Adaptive V2 source implementations unchanged. New components are additive and opt-in.

## 5. Verification

- Baseline V7: `npm test` — exit 0, 172 checks/subtests passed.
- Stage 4 focused: `npm run test:stage4` — 15/15 passed in the final source tree.
- Full V8 source suite: `npm test` — see the separate `SYNORA_WAR_V8_STAGE4_FULL_TEST_LOG.txt` supplied with the release; this includes all inherited suites and Stage 4.
- API smoke: a separate API process listened on `127.0.0.1:18787`; `GET /health` returned success and `POST /v1/chat` for `احسب 7 + 5` returned `7 + 5 = 12`. The automated API integration test also learns a skill, persists it, registers it in DigitalObjectCore, and applies it through `/v1/chat`.
- Persistence test: a skill was saved in one Node.js process and loaded/applied in a separately spawned Node.js process. Corrupted and missing files are rejected loudly.
- The package manifest is regenerated after release reports/results are in place. The release archive is separately extracted and tested before handoff; final extracted logs are supplied separately.

## 6. API

Run `npm run api:stage4`; the default is `127.0.0.1:8787`.

- `GET /health`
- `POST /v1/chat` with `{ "text": "احسب 7 + 5" }`; optionally include `history` (up to 20 turns). To apply a skill through the dialogue path, include `skillId` and `skillInput`.
- `POST /v1/skills/learn-affine` with a bounded modulus, training examples, and development examples.
- `GET /v1/skills`
- `POST /v1/skills/apply`

The API is an initial local prototype, not production-ready. A non-loopback bind requires a bearer token of at least 24 characters, but production use still needs TLS, managed authentication, robust rate limiting, observability, and an OS/container-level isolation boundary for any future untrusted code execution.

## 7. Acceptance boundaries

**Implemented and tested:** bounded dialogue intents, arithmetic tool selection and verification, three template-based JavaScript solutions, explicit abstention, constrained symbolic skill induction, use of a learned skill on unseen numeric inputs, skill persistence across processes, digital-object-core registration, a gated harmful mutation rejection/rollback, and a local HTTP API round-trip.

**Not implemented:** general-purpose natural-language semantics, arbitrary program synthesis, safe execution of arbitrary user code, autonomous selection of stored skills from free-form language, automatic extraction of skills from arbitrary conversations, robust feedback learning from untrusted corrections, distributed/multi-writer storage transactions, production authentication/TLS, or broad multi-domain generalization.

The mutation study only demonstrates that a deliberately worse candidate is rejected; it does not demonstrate discovery of a beneficial mutation. The symbolic study is narrow and synthetic. No claim is made about Llama 2 equivalence, general intelligence, consciousness, or energy superiority.

## 8. Reproduction commands

```sh
npm test
npm run test:stage4
npm run study:stage4
npm run api:stage4
```

See `SYNORA_WAR_V8_STAGE4_RUNBOOK.md` for persistence, API request examples, limits, and recovery.

## 9. Archive fingerprint

The SHA-256 of the final ZIP is supplied in the external `SYNORA_WAR_V8_STAGE4_SHA256.txt` and `.sha256` sidecar. The ZIP cannot contain its own final digest without changing that digest; the internal package therefore documents the sidecar convention rather than claiming a self-consistent embedded hash.
