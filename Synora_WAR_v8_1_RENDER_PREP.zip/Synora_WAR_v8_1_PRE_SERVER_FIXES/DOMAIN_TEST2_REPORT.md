# Synora WAR v6 — Test 2: Three application domains

## Result
- Full Node test suite: **15 test files/suites passed, 0 failed**.
- Focused domain + memory tests: **13 tests passed, 0 failed**.
- Programming transformation / repair tests passed.
- Freight tariff Phase-4 validation suite passed, including grader isolation, group separation, memory round-trip, and reproducibility checks.
- Workforce scheduling tests passed after a discovered greedy-assignment defect was fixed.

## Defect found and fixed
The original scheduler could assign a flexible worker to an easy shift before a shift that only that worker could cover, leaving the second shift unfilled even when a complete assignment existed. The scheduler now prioritizes shifts with fewer eligible workers, with deterministic tie-breaking. Added regression coverage for this case.

Additional validation now rejects duplicate worker IDs, duplicate shift IDs, and invalid negative/non-integer maxShifts values instead of silently producing ambiguous schedules.

## Scope note
The three domains are separate application workloads: programming repair, freight tariff calculation, and workforce shift scheduling. Workforce scheduling is a standalone domain adapter and is not claimed to be a new learned representation inside the evolutionary core.
