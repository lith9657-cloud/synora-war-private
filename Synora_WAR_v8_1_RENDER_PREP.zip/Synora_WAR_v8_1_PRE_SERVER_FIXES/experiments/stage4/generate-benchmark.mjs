import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
const dir = path.dirname(fileURLToPath(import.meta.url));
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const mod = (n, m) => ((n % m) + m) % m;
// Fixed preregistered symbolic DSL benchmark. Solver view omits a,b and all final outputs.
const spec = [
  { id: 'heldout-v2-mod23', modulus: 23, a: 7, b: 4, finalInputs: [[4, 6, 9], [10, 12], [14, 17, 20]] },
  { id: 'heldout-v2-mod29', modulus: 29, a: 11, b: 8, finalInputs: [[4, 6, 9], [10, 12], [14, 17, 20]] },
  { id: 'heldout-v2-mod31', modulus: 31, a: 9, b: 13, finalInputs: [[4, 6, 9], [10, 12], [14, 17, 20]] },
  { id: 'heldout-v2-mod37', modulus: 37, a: 16, b: 5, finalInputs: [[4, 6, 9], [10, 12], [14, 17, 20]] },
  { id: 'heldout-v2-mod41', modulus: 41, a: 13, b: 19, finalInputs: [[4, 6, 9], [10, 12], [14, 17, 20]] }
];
const tasks = spec.map(t => ({
  id: t.id, domain: { kind: 'affine-mod', modulus: t.modulus },
  training: [1, 3, 5, 8].map((input, i) => ({ id: `${t.id}-train-${i + 1}`, input, output: mod(t.a * input + t.b, t.modulus) })),
  development: [0, 2].map((input, i) => ({ id: `${t.id}-dev-${i + 1}`, input, output: mod(t.a * input + t.b, t.modulus) })),
  finalInputs: t.finalInputs,
  split: 'final-test', taskShape: 'learn scalar mapping from training examples; apply it to unseen arrays'
}));
const answerKey = Object.fromEntries(spec.map(t => [t.id, {
  params: { modulus: t.modulus, a: t.a, b: t.b },
  finalOutputs: t.finalInputs.map(xs => xs.map(x => mod(t.a * x + t.b, t.modulus)))
}]));
const manifest = {
  schema: 'synora-stage4-benchmark/2', protocolVersion: 2,
  note: 'The solver view intentionally omits final outputs and affine parameters. Answer key is evaluator-only and must not be imported by solver modules.',
  generation: { fixedTasks: 5, domain: 'affine-mod arithmetic', trainingScalarInputs: [1, 3, 5, 8], developmentScalarInputs: [0, 2], finalArrayInputs: 'unseen scalar values grouped into arrays; new task IDs and moduli relative to pilot v1', answerKeySha256: sha(JSON.stringify(answerKey)) },
  tasks
};
fs.writeFileSync(path.join(dir, 'tasks.json'), JSON.stringify(manifest, null, 2) + '\n');
fs.writeFileSync(path.join(dir, 'answer-key.json'), JSON.stringify({ schema: 'synora-stage4-answer-key/1', tasks: answerKey }, null, 2) + '\n');
console.log(`Generated ${tasks.length} fixed tasks. Solver view omits final outputs; key SHA-256 ${sha(JSON.stringify(answerKey))}`);
