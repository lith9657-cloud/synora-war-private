# Final matched validation — Adaptive Memory v2

## Setup

- Evaluated Adaptive v2 on the same four seeds (1, 2, 6, 7), task groups B/C (18 tasks per seed), budgets 80 and 150, and 250 generations as the prior adaptive-250 benchmark.
- 8 evaluation processes; 144 task evaluations total for v2.
- Acquisition memories for seeds 6 and 7 were generated with the same acquisition budget and generation count (250).
- Previous adaptive per-seed numbers are compared from `experiments/adaptive-250/summary.csv`.

## Matched results

| Budget | Seed | Previous Adaptive | Adaptive v2 | Delta |
|---:|---:|---:|---:|---:|
| 80 | 1 | 14/18 | 14/18 | +0 |
| 150 | 1 | 16/18 | 16/18 | +0 |
| 80 | 2 | 15/18 | 15/18 | +0 |
| 150 | 2 | 17/18 | 17/18 | +0 |
| 80 | 6 | 15/18 | 15/18 | +0 |
| 150 | 6 | 17/18 | 17/18 | +0 |
| 80 | 7 | 17/18 | 17/18 | +0 |
| 150 | 7 | 17/18 | 17/18 | +0 |

**Budget 80: 61/72 (84.7%).**

**Budget 150: 67/72 (93.1%).**

## Interpretation

Adaptive v2 exactly matches the previous adaptive policy on all 8 seed/budget cells at budgets 80 and 150. This is expected: both versions retain unconditional abstention from inherited value hints when budget >= 80, so per-hint evidence does not affect hint selection in these cells. Therefore this benchmark is a regression/non-regression check, not evidence that per-hint evidence improves outcomes.

The change is designed to affect low/medium budgets (<80), where the per-hint miss threshold is active. Those budgets were not part of this final 250-generation matched comparison; the previous low-budget benchmark used a different generation count, so it must not be mixed into a direct comparison.

## Decision

- Regression at tested high budgets: none observed; outcome counts are identical to previous Adaptive.
- Evidence of superiority: not established.
- Default-policy promotion: **not recommended yet**. Keep v2 experimental until a same-generation matched test includes budgets 10/20/40 and the prior Adaptive implementation as a separate arm.

## Reproducibility

- Raw per-run JSON: `experiments/adaptive-v2-matched/`.
- Summary: `experiments/adaptive-v2-matched/summary.csv`.
- Paired per-seed comparison: `experiments/adaptive-v2-matched/comparison.csv`.
- Focused tests: `tests/adaptive-engine.test.mjs` (10/10 passed).
- These are descriptive benchmark counts over four seeds, not statistical proof of universal superiority.
