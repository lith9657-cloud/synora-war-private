# Synora WAR V7 — Stage 2 Comparative Experiment Report

**Status:** completed as a small, reproducible engineering experiment; not evidence of broad generalization.

## Research question

Does the Digital Object Core (facts, relations, rules, persisted memory) add measurable value over Synora WAR's existing CRI baseline and Adaptive V2 experimental engine, without changing either engine's source?

## Provenance and protocol

- Starting artifact: `Synora_WAR_v7_ENGINEERING_STAGE1.zip`.
- Stage 1 archive SHA-256: `77b78fe2bdc9324e86ef6dcdf9c43cab97e5cbe0e3a7d1859890bf6f43151125`.
- Experiment protocol: `synora-war-stage2-1.0`.
- Node: `v22.16.0`; Linux x64; 3 reported CPUs; about 6.24 GB total memory.
- Seeds: `17`, `43`, `101`, using xorshift32 to vary task/fact/rule insertion order. These are not independent model initializations.
- PST budget: 20 evaluations per task; 20 generations; population 8; grader timeout 600 ms; two grader workers. The runner and worker now pass through the declared generation budget. An earlier exploratory run accidentally used 60 generations despite the config saying 20; it is preserved under `archive/pre-fix-run/` and explicitly excluded from primary inference.
- Core symbolic suite: 3 development cases, 3 validation cases, 12 held-out symbolic cases; each is executed under all three seeds. Cross-process learned-rule transfer and its matched no-rule control are each run once per seed.
- The 12 symbolic held-out cases were authored before the final run and use distinct task IDs and structures. They are a small hand-authored suite, not a statistically representative sample. Seed repeats vary insertion order only.
- `benchmark-cases.json` contains no `expected` field; `answer-key.json` is read by the evaluator only after the core inference result is produced. The engine and task data do not receive the expected answer. Static checks reduce obvious leakage but cannot prove the absence of every semantic shortcut.

## Arms and their meaning

| Arm | Implementation | Actual scope |
|---|---|---|
| A — CRI alone | `PstEngine` | Existing PST program-repair task interface; measured cold and with its own restored native memory |
| B — Adaptive V2 alone | `AdaptivePstEngine` | Same PST task interface; measured cold and with its own restored native memory |
| C — CRI + Digital Object Core | CRI native memory plus persisted core snapshot (additive arm) | Actual core fallback was traced; no successful hits in this additive condition |
| D — Adaptive V2 + Digital Object Core | Adaptive V2 native memory plus persisted core snapshot (additive arm) | Actual fallback was traced; zero successful hits and extra lookups |
| Extra ablation: core-only memory | Fresh CRI/Adaptive V2 process with native memory withheld and only the core bridge loaded | Isolates whether the core bridge can help when native memory is absent |
| Standalone Digital Object Core | Symbolic fact/rule tasks | Tests core capabilities directly; not an A/B comparison against PST engines |

CRI and Adaptive V2 are program-repair engines. Their real `runTask(task)` contract is not a general symbolic QA API, so the project does **not** report fabricated CRI/Adaptive answers for the 12 symbolic tasks. The separate core suite is not counted as proof that C or D improves the PST engine.

## Main results

### Standalone Digital Object Core

| Split | Rows | Correct | Rate |
|---|---:|---:|---:|
| Development | 9 | 9 | 100% |
| Validation | 9 | 9 | 100% |
| Held-out symbolic final test | 36 | 36 | 100% |
| Cross-process persisted-rule transfer | 3 | 3 | 100% |
| Matched no-rule transfer control (correct abstention) | 3 | 3 | 100% |
| All core/control rows | 60 | 60 | 100% |

The 36 held-out rows are 12 task specifications repeated across three insertion-order seeds; they are not 36 independent task designs. Categories cover fact retrieval, one-rule inference, multi-step inference, three-premise conjunction, new-entity transfer, changed-fact retraction, contradiction abstention, insufficient evidence, hypothesis exclusion, restart persistence, a novel conjunctive chain, and valid multi-valued relations. In addition, the transfer test saves two rules in one Node process, exits, and has a separate process apply those rules to a new subject fact (3/3 correct). A matched cold process receives the same new-subject fact without the learned rules and abstains in all three seeds (3/3), confirming the transfer depends on the saved rule set.

### PST engine comparison (9 validation rows per condition; 3 tasks × 3 seeds)

| Condition | Success | Mean score | Mean evaluations/task | Mean task elapsed time |
|---|---:|---:|---:|---:|
| A — CRI, cold process | 9/9 (100%) | 1.000 | 6.78 | 60.43 ms |
| A — CRI, native memory restored after restart | 9/9 (100%) | 1.000 | 7.00 | 65.47 ms |
| C — CRI native memory + digital core | 9/9 (100%) | 1.000 | 7.00 | 47.69 ms |
| C-only ablation — CRI with core-only memory | 9/9 (100%) | 1.000 | 3.67 | 110.66 ms |
| B — Adaptive V2, cold process | 3/9 (33.3%) | 0.652 | 2.67 | 43.07 ms |
| B — Adaptive V2, native memory restored after restart | 3/9 (33.3%) | 0.652 | 2.67 | 54.08 ms |
| D — Adaptive V2 native memory + digital core | 3/9 (33.3%) | 0.652 | 2.67 | 113.19 ms |
| D-only ablation — Adaptive V2 with core-only memory | 3/9 (33.3%) | 0.652 | 2.67 | 46.52 ms |

Task elapsed time is measured around each task run and is highly noisy at this small scale; it should not be treated as a reliable performance win. Heap deltas are process-local GC-sensitive measurements, not peak resident memory. No formal confidence interval or p-value is used for the PST integration comparison: there are only three task identities per condition, and seed repeats vary insertion order rather than providing independent task samples. These are descriptive paired results, not a test of equivalence. The exact per-task, per-seed values are in `results-detailed.csv` and `results-raw.json`.

### Matched counterfactual / ablation evidence

There are 36 paired rows: for each engine, seed, and validation task, compare cold vs core-only memory and native-memory-after-restart vs native-plus-core memory.

- **Success changes:** 0/18 for cold-vs-core-only; 0/18 for native-memory-vs-native-plus-core. The core did not change any binary success outcome in this task sample.
- **Primary additive arm C (CRI native + core):** 0 successful core fallback hits across 51 lookups; success and evaluation counts are identical to native CRI memory alone. No incremental benefit was measured.
- **Primary additive arm D (Adaptive V2 native + core):** 0 successful core fallback hits across 540 lookups; success and evaluation counts are identical to native Adaptive V2 memory alone. The extra fallback lookups add overhead without evidence of benefit.
- **Core-only ablation on CRI:** 18 successful fallback hint hits across 75 lookups. On `B5_min_size_50`, evaluations fell from 14/14/15 to 5/5/5 across the three seeds, while correctness was unchanged. The average evaluation delta across all nine CRI paired tasks was −3.11; the median was 0 because two task families showed no evaluation reduction. However, measured mean task time was higher for the core-only condition (110.66 ms vs 60.43 ms cold baseline) in this run. Therefore, this is only a search-evaluation-count reduction on one task family—not a demonstrated end-to-end speedup.
- **Core-only ablation on Adaptive V2:** 540 fallback lookups, **zero hits**. The core was loaded and queried, but did not contribute a hint to any measured task.
- CRI was already at 100% success on these validation tasks, so this small suite has a ceiling effect for accuracy. The strongest observed positive result is fewer evaluations on one CRI task family only when native memory is withheld; neither primary additive arm showed a measurable gain.

## Session boundary, update and retraction

- Standalone symbolic restart persistence: 3/3 across new Node processes.
- Cross-process learned-rule transfer to a new subject: 3/3; matched no-rule control abstained correctly 3/3.
- Changed-fact cases remove the old premise, add the replacement fact, then re-infer; all 6 executions (two task definitions × three seeds) returned the replacement-supported result, not the stale derived result.
- The PST comparison includes cold, native-memory-restored, core-only, and native-plus-core processes. The native memory snapshot is generated from the same development run used to create the core memory.
- Insertion order is varied with three seeds. This is a limited order sensitivity control, not a large randomized study.

## Failures, exclusions, and corrections

- The corrected final run has zero runner/runtime exceptions (`failures: []`). This does **not** mean every engine task succeeded: unsuccessful task outcomes remain explicitly recorded as `success: false` in the raw rows. Adaptive V2 has 3/9 successes per validation condition, and its failures are part of the result rather than being filtered out.
- The first exploratory run was invalid for primary inference because the worker used 60 generations despite the config declaring 20, and it did not yet include the post-restart native-memory control. The raw files and log are retained under `archive/pre-fix-run/` and must not be pooled with corrected results.
- A second intermediate run declared 20 generations but still pooled different memory conditions under one arm label and did not restore the native `hints` map in the new process. It is retained under `archive/intermediate-run/` and excluded. The worker now restores both hints and ledger through `native-memory.mjs`, the arms have distinct labels, and the complete experiment was rerun.
- The cross-process learning test originally lacked a matched no-rule control. The corrected final run now runs a second independent process with the same new-subject fact but an empty saved core; it abstains as expected in all three seeds.
- A test initially exposed a package-manifest hash mismatch after Stage 2 changed `package.json`; the manifest was regenerated before release and the full test suite was rerun.
- Existing PST set B is not presented as a new independent final test because it predates Stage 2.
- CRI/Adaptive V2 are excluded from the standalone symbolic benchmark because their native interface does not accept that task type. No substitute/mock results were generated.
- Strict multi-edit PST tasks were not included in this small matched integration study because of known combinatorial runtime spikes; prior reports remain historical context, not part of these Stage 2 arm metrics.

## Decision

**Keep the Digital Object Core experimental; do not claim it improves Synora WAR generally.** The standalone symbolic engine passes this small synthetic suite, and cross-process rules survive restart. The integration evidence is narrow: CRI sees fewer evaluations on one task family with no accuracy change; Adaptive V2 has no successful core hint hits; and the core adds no measurable value over native memory in the additive arm. Larger preregistered task sets, more structurally diverse independent tasks, and broader budgets are needed before adoption claims.

## Reproduction

From the extracted project root, with Node.js 20+:

```sh
npm test
npm run study:stage2 -- all
npm run test:digital-objects
node --test tests/stage2-experiment.test.mjs
```

`npm run study:stage2 -- all` writes new raw/CSV/paired outputs and updates its timestamp. Do not merge those fresh outputs with the archived pre-fix run. Wall time and heap deltas may vary by host. The declared generation/evaluation budgets, task files, seeds, and answer-key hash are captured in `config.json`, `seeds.json`, and `results-raw.json`. The complete `npm test` command exited successfully on the finalized project tree. In one clean-extraction check, the combined `npm test` command printed passing output for all component suites but did not return before the execution wrapper timeout; the Stage 2 reproduction command from that extracted archive did exit successfully and reproduced 60 core/control rows, 108 engine rows, 36 paired-ablation rows, and zero runner/runtime exceptions. The Stage 2 and Digital Object Core suites also passed when run separately. Timing values are expected to vary by host and run.

## Release integrity

The package manifest is `audit/package-manifest.json` and is regenerated after all source, task, result, report, and test-log files are finalized. The final ZIP's SHA-256 is supplied as a separate `.sha256` sidecar and in the external release report; the archive does not embed its own final ZIP hash because adding it would change that hash.
