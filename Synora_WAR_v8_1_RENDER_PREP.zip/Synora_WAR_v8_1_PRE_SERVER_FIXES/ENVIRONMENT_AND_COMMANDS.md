# Environment and command reference

## Required environment

- Node.js 20 or newer (validated here on v22.16.0).
- No third-party npm dependencies are required for the shipped tests and experiments.
- Bash is required for the `scripts/reproduce-phase*.sh` reproduction wrappers on Unix-like systems.

## Common commands

```sh
# Run all 146 automated checks
npm test

# Adaptive context-memory regression suite
npm run test:adaptive

# Re-run the matched low-budget experiment (seeds 1–5, budgets 10/20/40)
npm run study:adaptive

# Run an individual Phase-4 evaluation, with an existing acquisition memory
node synora-v5/phase4/evaluate.mjs --mode=adaptive --seed=1 --budget=20 --generations=200 --groups=B,C --memory=experiments/phase4/memory/acquire-seed1.json --out=experiments/example-adaptive.json

# Rebuild package hashes after changing files
npm run manifest
```

The study script writes per-run raw JSON plus aggregate JSON/CSV to `experiments/adaptive-final/`. The separate new-seed outputs are in `experiments/adaptive-final/generalization/`. The study takes multiple Node subprocesses; allow several minutes on slower devices.
