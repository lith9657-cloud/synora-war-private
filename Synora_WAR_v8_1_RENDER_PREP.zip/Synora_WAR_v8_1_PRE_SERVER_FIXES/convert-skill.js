#!/usr/bin/env node
'use strict';
const fs = require('fs');
const inputFile = process.argv[2];
if (!inputFile) {
  console.error('Usage: node convert-skill.js SKILL.md');
  process.exit(1);
}
let source;
try { source = fs.readFileSync(inputFile, 'utf8'); }
catch (error) { console.error(`Cannot read ${inputFile}: ${error.message}`); process.exit(1); }
const pattern = /^\s*-\s*\[KILLER:([a-z0-9_-]+)\]\s*(.+?)\s*$/i;
const groups = Object.create(null);
for (const line of source.split(/\r?\n/)) {
  const match = line.match(pattern);
  if (!match) continue;
  const tribe = match[1].toLowerCase();
  const rule = match[2].trim();
  if (!rule) continue;
  if (!groups[tribe]) groups[tribe] = [];
  groups[tribe].push(JSON.stringify({ type: 'structural', tribe, rule }));
}
const tribes = Object.keys(groups);
if (!tribes.length) {
  console.error('No - [KILLER:tribe] rule lines found.');
  process.exit(2);
}
for (const tribe of tribes) {
  const dir = `tribes/${tribe}`;
  fs.mkdirSync(dir, { recursive: true });
  const output = `${dir}/killers_${tribe}.jsonl`;
  const previous = fs.existsSync(output) ? fs.readFileSync(output, 'utf8').split(/\r?\n/).filter(Boolean) : [];
  const merged = [...previous, ...groups[tribe]];
  const unique = [...new Set(merged)];
  const tmp = `${output}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, unique.join('\n') + '\n', 'utf8');
  fs.renameSync(tmp, output);
  console.log(`${output}: ${groups[tribe].length} rule(s) added; ${unique.length} unique rule(s) total`);
}
