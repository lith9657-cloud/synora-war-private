# Synora WAR V8 — Stage 4 experiment report

## Protocol and versioning

The input archive SHA-256 matched the reference before modification. The final symbolic benchmark is `experiments/stage4/tasks.json`, schema `synora-stage4-benchmark/2`. It was created after the initial pilot surfaced a defect in how unsupported code requests were reported. The pilot files `tasks-pilot-v1.json`, `answer-key-pilot-v1.json`, `results-pilot-v1.json`, and `results-pilot-v1.csv` are retained as exploratory evidence and are not pooled into the final result.

The final benchmark has five task designs with new IDs and moduli 23, 29, 31, 37, and 41. Training examples are scalar values `[1,3,5,8]`; development examples use `[0,2]`; final evaluation applies the learned rule to arrays of unseen values. The solver task file has no final outputs or affine parameters. The evaluator answer key is separate and is not imported by solver modules. It is shipped for reproducibility, so this is a process-separation guard rather than cryptographic secrecy.

Seeds 17, 43, and 101 rotate training order, development order, and held-out case order. They are **order-sensitivity repetitions**, not independent random datasets. There are five underlying task designs and three held-out array cases per design; 45 rows per symbolic arm are 15 task/case combinations repeated under three orderings, not 45 independent task families.

## Arms and final results

| Arm | Rows | Successful outcomes | Wrong answers | Abstentions | Train | Development | Final interpretation |
|---|---:|---:|---:|---:|---:|---:|---|
| A — cold baseline | 45 | 0/45 | 0 | 45 | no examples | no examples | No acquired rule; correctly abstains |
| B — exact example retrieval | 45 | 0/45 | 0 | 45 | 4/4 examples available | 0/2 dev values found | Stored examples do not cover unseen array values |
| C — induced skill | 45 | 45/45 | 0 | 4/4 per task | 2/2 per task | Learned affine rule generalizes within the bounded DSL |
| D — gated evolution | 45 | 45/45 | 0 | 4/4 per task | 2/2 per task | Same held-out accuracy as C; 15/15 harmful mutation proposals rejected with rollback verified |
| E — dialogue/tool/template smoke | 4 | 4/4 expected outcomes | 0 | 1 correct abstention | n/a | 1 Arabic calculation, 2 code-template requests, and 1 unsupported broad code request all handled as expected |

Per symbolic task, A and B scored 0/9 outcomes; C and D scored 9/9. The three repetitions are order permutations. There are no wrong numeric outputs from A/B because both abstain on unseen values rather than guess. C/D each learned one unique affine rule per task/order and validated it against the two development examples before final evaluation.

## Resource observations

These are local, process-level measurements from this run and should not be treated as portable benchmarks. `durationMs` measures the per-case application path; `learningDurationMs` measures induction separately. `heapUsedBytes` is the whole Node.js process heap snapshot, not memory attributable only to a single arm.

| Arm | Median application time | Median learning time | Median internal operations | Median process heap snapshot |
|---|---:|---:|---:|---:|
| A | ~0.0005 ms | n/a | 0 | ~5.76 MB |
| B | ~0.0017 ms | n/a | 3 retrieval checks | ~5.76 MB |
| C | ~0.0110 ms | ~0.334 ms | 1,955 induction operations | ~5.84 MB |
| D | ~0.0124 ms | ~0.312 ms | 1,955 induction operations | ~5.76 MB |
| E | ~7.93 ms | n/a | 1–3 trace stages | ~7.19 MB |

Timing values are extremely small, environment-sensitive, and include measurement overhead; they do not establish an energy advantage or an end-to-end system speedup. The baseline/retrieval arms do less work because they abstain, so raw timing is not an equal-quality comparison.

## Dialogue and code path

The four smoke cases produced four expected outcomes. The sum-array template passed 5/5 built-in positive/negative cases, the maximum template passed 5/5, and factorial passed 6/6. These are template tests, not a broad code benchmark. The generated templates are fixed reviewed code; arbitrary user-supplied source is never executed.

## Reproducibility

```sh
npm run test:stage4
npm run study:stage4
```

The runner writes `experiments/stage4/results.json` and `results.csv`, recording task/key SHA-256 and source-file hashes. Fresh runs have different timestamps and timing/heap observations; outcome labels and task successes should remain the same. The final package was separately extracted and its study was rerun; outcome consistency is recorded in the external release reproduction log.

## Conclusion

This supports a narrow, falsifiable claim: a bounded symbolic learner can infer an affine-mod transformation from four examples, pass two development checks, and apply the rule to held-out arrays with unseen values, while exact lookup cannot. The mutation gate can reject a deliberately worse candidate without losing the accepted skill. It does not show that the system can learn arbitrary skills, synthesize arbitrary programs, understand natural language generally, or improve itself autonomously. The stage-4 learning extension is useful in its demonstrated symbolic domain; the broader Synora conversational model remains a prototype with strict capability boundaries.
