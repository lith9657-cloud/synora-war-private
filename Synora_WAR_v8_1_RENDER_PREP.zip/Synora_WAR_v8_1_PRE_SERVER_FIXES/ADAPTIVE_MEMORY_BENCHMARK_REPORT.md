# Synora WAR — Adaptive Memory matched benchmark report

## Scope and reproducibility
- Compared five arms (`base`, `cri`, `adaptive`, `noise`, `notransfer`) on the same tasks (groups B,C), seeds 1, 2, 6, 7 and budgets 10, 20, 40, 80, 150.
- Every arm used the same per-task seed formula and evaluation budget within each seed/budget cell.
- To fit the available execution window, this benchmark used `generations=80` for all arms. It is a matched experiment at that setting and must not be directly equated with the earlier packaged `generations=250` study.
- Seeds 6 and 7 were held-out validation seeds relative to the initial adaptive smoke runs (seed 1, budgets 80 and 150). The policy itself is a fixed rule, not a learned model.
- Each budget/arm includes 72 task-runs (4 seeds x 18 tasks); total 1,800 task-runs across five arms and five budgets.

## Main results
| Budget | Base | CRI | Adaptive | Noise | No transfer |
|---:|---:|---:|---:|---:|---:|
| 10 | 0/72 (0.0%) | 20/72 (27.8%) | 20/72 (27.8%) | 1/72 (1.4%) | 0/72 (0.0%) |
| 20 | 14/72 (19.4%) | 22/72 (30.6%) | 22/72 (30.6%) | 13/72 (18.1%) | 14/72 (19.4%) |
| 40 | 33/72 (45.8%) | 40/72 (55.6%) | 40/72 (55.6%) | 31/72 (43.1%) | 34/72 (47.2%) |
| 80 | 60/72 (83.3%) | 57/72 (79.2%) | 61/72 (84.7%) | 53/72 (73.6%) | 61/72 (84.7%) |
| 150 | 67/72 (93.1%) | 65/72 (90.3%) | 67/72 (93.1%) | 62/72 (86.1%) | 67/72 (93.1%) |

## Interpretation
- Adaptive matches CRI at budgets 10, 20, and 40, preserving the observed small-budget benefit in this matched study.
- At budget 80, adaptive solves 61/72 vs CRI 57/72 and base 60/72. At budget 150, adaptive solves 67/72 vs CRI 65/72 and base 67/72. Thus the large-budget CRI regression is not present in this sample for adaptive; it is at baseline level or slightly above.
- Adaptive is not yet proven statistically superior. These are descriptive rates over four seeds, not a final promotion-grade significance claim. The held-out seeds 6-7 individually show the same broad pattern: adaptive equals CRI at low budgets and abstains from value hints at high budgets.
- Noise performs below the useful-memory arms, which supports (but does not by itself prove) that useful memory rather than arbitrary hints accounts for the low-budget gain.

## Decision-quality checks
The adaptive rule currently has two deterministic gates:
1. For budget >=80, it abstains from inherited value hints while retaining the ledger for within-task evidence/refutations.
2. At lower budgets, it abstains after at least two directed misses when misses exceed hits.

This is a conservative heuristic, not a learned confidence estimator. The experiment supports the high-budget abstention choice on these tasks, but does not yet establish that it always distinguishes a useful hint from a harmful one, or that it avoids abandoning a good hint after a transient miss. That needs dedicated controlled cases with sequences of helpful, misleading, and one-off-failure hints.

## Integrity checks
- The two chunk runs completed all five arms and all five budgets for seeds 1,2 and 6,7.
- Cross-process vs in-process control was IDENTICAL for each executed seed (1, 2, 6, 7).
- Memory answer-leak scans reported 0 hits for each executed seed.
- Existing packaged Phase-4 results were not overwritten; the new JSON/CSV outputs are separately named.

## Recommendation
Keep Adaptive Memory as the candidate policy and do not silently change the audited default yet. Next, add explicit unit tests for helpful-hint retention, misleading-hint rejection, and single transient misses, then run a larger multi-seed benchmark at the original `generations=250` setting before promotion.
