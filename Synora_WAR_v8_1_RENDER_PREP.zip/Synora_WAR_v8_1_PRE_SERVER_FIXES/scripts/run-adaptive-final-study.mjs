import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EVAL = path.join(ROOT, 'synora-v5/phase4/evaluate.mjs');
const outDir = path.join(ROOT, 'experiments/adaptive-final');
fs.mkdirSync(outDir, { recursive: true });
const modeArg = process.argv.find(x => x.startsWith('--modes='));
const seedArg = process.argv.find(x => x.startsWith('--seeds='));
const budgetArg = process.argv.find(x => x.startsWith('--budgets='));
const modes = (modeArg?.split('=')[1] ?? 'base,cri,adaptive-legacy,adaptive').split(',');
const seeds = (seedArg?.split('=')[1] ?? '1,2,3,4,5').split(',').map(Number);
const budgets = (budgetArg?.split('=')[1] ?? '10,20,40').split(',').map(Number);
const all = [];
for (const seed of seeds) {
  const memory = path.join(ROOT, `experiments/phase4/memory/acquire-seed${seed}.json`);
  for (const budget of budgets) for (const mode of modes) {
    const output = path.join(outDir, `eval-${mode}-seed${seed}-budget${budget}.json`);
    const args = [EVAL, `--mode=${mode}`, `--seed=${seed}`, `--budget=${budget}`, '--generations=200', '--groups=B,C', `--out=${path.relative(ROOT, output)}`];
    if (['cri','adaptive','adaptive-legacy'].includes(mode)) args.push(`--memory=${path.relative(ROOT, memory)}`);
    const proc = spawnSync(process.execPath, args, { cwd: path.join(ROOT,'synora-v5/phase4'), encoding:'utf8', maxBuffer: 64*1024*1024 });
    if (proc.status !== 0) {
      all.push({ seed, budget, mode, status:'error', error:(proc.stderr || proc.stdout || `exit ${proc.status}`).slice(-3000) });
      fs.writeFileSync(path.join(outDir, 'study-partial.json'), JSON.stringify(all,null,2));
      console.error(`FAIL ${mode} seed=${seed} budget=${budget}`);
      process.exit(1);
    }
    const payload = JSON.parse(fs.readFileSync(output,'utf8'));
    const results = payload.results.map(r => ({ taskId:r.taskId, group:r.group, success:r.success, score:r.score, evaluations:r.evaluations, violations:r.violations }));
    all.push({ seed, budget, mode, status:'ok', success:results.filter(r=>r.success).length, n:results.length, results, output:path.relative(ROOT,output) });
    console.log(`${mode.padEnd(15)} seed=${seed} budget=${budget}: ${results.filter(r=>r.success).length}/${results.length}`);
  }
}
fs.writeFileSync(path.join(outDir,'low-budget-raw.json'), JSON.stringify({ protocol:{seeds,budgets,modes,generations:200,groups:['B','C']}, runs:all },null,2)+'\n');
const rows=[];
for(const budget of budgets) for(const mode of modes){
 const runs=all.filter(r=>r.status==='ok'&&r.budget===budget&&r.mode===mode);
 const success=runs.reduce((s,r)=>s+r.success,0), n=runs.reduce((s,r)=>s+r.n,0);
 const perSeed=runs.map(r=>({seed:r.seed,success:r.success,n:r.n,rate:r.n?r.success/r.n:0}));
 rows.push({mode,budget,seeds:runs.length,success,n,rate:n?success/n:0,perSeed});
}
fs.writeFileSync(path.join(outDir,'low-budget-summary.json'),JSON.stringify(rows,null,2)+'\n');
const csv=['mode,budget,seeds,success,n,success_rate,per_seed'].concat(rows.map(r=>[r.mode,r.budget,r.seeds,r.success,r.n,r.rate.toFixed(4),JSON.stringify(r.perSeed)].join(','))).join('\n')+'\n';
fs.writeFileSync(path.join(outDir,'low-budget-summary.csv'),csv);
console.log(`Wrote ${all.length} runs to experiments/adaptive-final`);
