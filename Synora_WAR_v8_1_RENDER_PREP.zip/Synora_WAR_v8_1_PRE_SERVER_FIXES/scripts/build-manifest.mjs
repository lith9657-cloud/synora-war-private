/**
 * Synora WAR v5 — package manifest builder.
 *
 *   node scripts/build-manifest.mjs [--out=audit/package-manifest.json]
 *
 * Produces the list of every file in the package with its SHA-256 and size, so that the
 * delivered archive can be verified byte-for-byte after extraction.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(HERE, '..');

const SKIP_DIRS = new Set(['node_modules', '.git']);
const SKIP_FILES = new Set(['package-manifest.json']);

function walk(dir, base = '') {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue;
      out.push(...walk(path.join(dir, entry.name), path.join(base, entry.name)));
    } else {
      const rel = path.join(base, entry.name);
      // the manifest cannot contain its own hash -> never list itself
      if (SKIP_FILES.has(entry.name) || SKIP_FILES.has(rel)) continue;
      out.push(rel);
    }
  }
  return out;
}

const files = walk(ROOT).sort();
const entries = files.map(rel => {
  const full = path.join(ROOT, rel);
  const data = fs.readFileSync(full);
  return { path: rel, bytes: data.length, sha256: crypto.createHash('sha256').update(data).digest('hex') };
});

const out = {
  format: 'synora-package-manifest/1',
  generatedAt: new Date().toISOString(),
  fileCount: entries.length,
  totalBytes: entries.reduce((a, e) => a + e.bytes, 0),
  files: entries,
};

const argOut = process.argv.slice(2).find(a => a.startsWith('--out='));
const outPath = argOut ? argOut.slice(6) : path.join(ROOT, 'audit', 'package-manifest.json');
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, JSON.stringify(out, null, 1));
console.log(`manifest: ${out.fileCount} files, ${(out.totalBytes / 1048576).toFixed(2)} MB -> ${outPath}`);
