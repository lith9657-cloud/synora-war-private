#!/usr/bin/env bash
# =============================================================================
# Synora WAR v5 — CRI — PHASE 3: reproduce the long-term-memory experiment.
#
#   bash scripts/reproduce-phase3.sh [seeds] [budgets]
#   bash scripts/reproduce-phase3.sh 5 10,30,60,250
#
# Requirements: Node.js >= 18. No GPU, no API keys, no network.
# Runtime: about 4 minutes on 2 cores / 3GB RAM.
# =============================================================================
set -euo pipefail

SEEDS="${1:-5}"
BUDGETS="${2:-10,30,60,250}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "=============================================================================="
echo " Synora WAR v5 — Phase 3 — long-term memory & generalisation"
echo " node $(node --version) | seeds=$SEEDS | budgets=$BUDGETS"
echo "=============================================================================="

echo
echo "### 1/4  Test suites (Phase 1 + Phase 2 + Phase 3 + audit)"
node tests/self-test.mjs
node tests/v5.test.mjs
node tests/pst.test.mjs
node tests/phase3.test.mjs
node tests/audit.test.mjs

echo
echo "### 2/4  A single session pair, by hand (process 1 -> file -> process 2)"
mkdir -p experiments/phase3/memory experiments/memory
node synora-v5/phase3/acquire.mjs  --seed=1 --budget=250 \
     --out=experiments/memory/acquire-seed1.json | tail -20
node synora-v5/phase3/evaluate.mjs --mode=cri --seed=1 --budget=250 \
     --memory=experiments/memory/acquire-seed1.json \
     --groups=B,C --out=experiments/phase3/manual-cri-seed1.json

echo
echo "### 3/4  The full study: $SEEDS seeds x 5 arms x budgets $BUDGETS"
node synora-v5/phase3/experiments.mjs --seeds="$SEEDS" --budgets="$BUDGETS" \
     --out=experiments/results-phase3.json

echo
echo "### 4/4  Raw artefacts"
echo "  memory files      : experiments/phase3/memory/acquire-seed<N>.json"
echo "  per-run receipts  : experiments/phase3/eval-<arm>-seed<N>-budget<B>.json"
echo "  aggregated result : experiments/results-phase3.json"
echo "  report            : docs/06-REPORT-LONG-TERM-MEMORY.md"
echo "  final audit       : docs/07-FINAL-AUDIT-AND-REPRODUCTION.md"
echo
echo "Done."
