/**
 * Synora WAR v5 — CORE HASHES.
 *
 * The Phase-4 experiment must NOT change the engine's capabilities. This script hashes the
 * files that carry those capabilities, so that "the core did not change" is a MEASUREMENT
 * (two SHA-256 lists taken before and after the experiment) and not a promise.
 *
 *   node scripts/core-hashes.mjs --out=audit/phase4-core-hashes-before.json
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(HERE, '..');

/**
 * The protected set:
 *   - the v5 core (engine, genome, judge, worker, ledger = the CRI core)
 *   - the shared statistics
 *   - the Phase-2 and Phase-3 engines/graders/operators (the domains this experiment compares with)
 *   - the Phase-3 memory layer and the Phase-3 analysis
 *   - the existing test suites
 * Nothing in this list may change during Phase 4. The Phase-4 files live in a NEW directory
 * (synora-v5/phase4/) and are deliberately NOT in this list.
 */
export const PROTECTED = [
  'synora-v5/engine.mjs',
  'synora-v5/genome.mjs',
  'synora-v5/judge.mjs',
  'synora-v5/worker.mjs',
  'synora-v5/ledger.mjs',
  'synora-v5/stats.mjs',
  'synora-v5/cli.mjs',
  'synora-v5/tasks.mjs',
  'synora-v5/phase3/engine.mjs',
  'synora-v5/phase3/operators.mjs',
  'synora-v5/phase3/grader.mjs',
  'synora-v5/phase3/tasks.mjs',
  'synora-v5/phase3/secrets.mjs',
  'synora-v5/phase3/memory.mjs',
  'synora-v5/phase3/acquire.mjs',
  'synora-v5/phase3/evaluate.mjs',
  'synora-v5/phase3/experiments.mjs',
  'synora-v5/phase3/analysis.mjs',
  'synora-v5/pst/environment.mjs',
  'synora-v5/pst/operators.mjs',
  'synora-v5/pst/tasks.mjs',
  'synora-v5/pst/grader.mjs',
  'synora-v5/pst/sandbox-worker.mjs',
  'tests/self-test.mjs',
  'tests/v5.test.mjs',
  'tests/pst.test.mjs',
  'tests/phase3.test.mjs',
];

function hashFile(rel) {
  const full = path.join(ROOT, rel);
  const data = fs.readFileSync(full);
  return { path: rel, bytes: data.length, sha256: crypto.createHash('sha256').update(data).digest('hex') };
}

function main() {
  const out = process.argv.find(a => a.startsWith('--out='));
  const outPath = out ? out.slice(6) : path.join(ROOT, 'audit', 'core-hashes.json');
  const files = PROTECTED.map(hashFile);
  const combined = crypto.createHash('sha256')
    .update(files.map(f => `${f.path}:${f.sha256}`).join('\n'))
    .digest('hex');
  const payload = {
    format: 'synora-core-hashes/1',
    generatedAt: new Date().toISOString(),
    note: 'SHA-256 of the engine files that carry the capabilities. Identical lists before and after an experiment prove the core was not modified.',
    files,
    combinedSha256: combined,
  };
  const abs = path.isAbsolute(outPath) ? outPath : path.join(ROOT, outPath);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, JSON.stringify(payload, null, 2));
  console.log(`core hashes: ${files.length} files -> ${path.relative(ROOT, abs)}`);
  console.log(`combined   : ${combined}`);
}

main();
