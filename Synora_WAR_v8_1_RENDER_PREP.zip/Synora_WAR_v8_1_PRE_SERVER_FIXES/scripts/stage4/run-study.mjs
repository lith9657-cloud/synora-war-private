import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { DigitalObjectLearner } from '../../synora-v5/digital-object-learning/index.mjs';
import { handleDialogue } from '../../synora-v5/dialogue/agent.mjs';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const taskPath = path.join(root, 'experiments/stage4/tasks.json');
const keyPath = path.join(root, 'experiments/stage4/answer-key.json');
const tasksDoc = JSON.parse(fs.readFileSync(taskPath, 'utf8'));
const keyDoc = JSON.parse(fs.readFileSync(keyPath, 'utf8'));
const sha = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const results = [];
const rotate = (items, amount) => items.length ? [...items.slice(amount % items.length), ...items.slice(0, amount % items.length)] : [];
for (const seed of [17, 43, 101]) {
  for (const task of tasksDoc.tasks) {
    const answer = keyDoc.tasks[task.id];
    const cases = rotate(task.finalInputs.map((input, i) => ({ input, expected: answer.finalOutputs[i] })), seed % task.finalInputs.length);
    const trainingOrder = rotate(task.training, seed % task.training.length);
    const developmentOrder = rotate(task.development, (seed + 1) % task.development.length);
    // A: no acquired skill or examples; abstains rather than guessing.
    for (const c of cases) {
      const caseStart = performance.now();
      results.push({ arm: 'A-cold-baseline', seed, taskId: task.id, caseInput: c.input, expected: c.expected, actual: null, success: false, wrongAnswer: false, abstained: true, operations: 0, skillCount: 0, trainingCount: 0, trainingCorrect: 0, developmentCount: 0, developmentCorrect: 0, durationMs: performance.now() - caseStart, heapUsedBytes: process.memoryUsage().heapUsed, note: 'cold baseline has no rule and correctly abstains' });
    }
    // B: exact-value lookup memory; arrays containing unseen values abstain.
    const lookup = new Map(task.training.map(e => [e.input, e.output]));
    for (const c of cases) {
      const caseStart = performance.now();
      const found = c.input.every(x => lookup.has(x));
      const actual = found ? c.input.map(x => lookup.get(x)) : null;
      results.push({ arm: 'B-example-retrieval', seed, taskId: task.id, caseInput: c.input, expected: c.expected, actual, success: found && JSON.stringify(actual) === JSON.stringify(c.expected), wrongAnswer: found && JSON.stringify(actual) !== JSON.stringify(c.expected), abstained: !found, operations: c.input.length, skillCount: lookup.size, trainingCount: task.training.length, trainingCorrect: task.training.length, developmentCount: task.development.length, developmentCorrect: task.development.filter(e => lookup.has(e.input)).length, durationMs: performance.now() - caseStart, heapUsedBytes: process.memoryUsage().heapUsed, note: 'retrieval only; no rule induction' });
    }
    // C: induced bounded rule, trained on public training examples and checked on dev only.
    const learner = new DigitalObjectLearner({ id: `study-${seed}-${task.id}` });
    const learnStart = performance.now();
    const learned = learner.learnAffine({ name: task.id, modulus: task.domain.modulus, training: trainingOrder, development: developmentOrder });
    const learningDurationMs = performance.now() - learnStart;
    for (const c of cases) {
      const caseStart = performance.now();
      const applied = learned.accepted ? learner.apply(learned.skill.id, c.input) : { ok: false, abstain: true, reason: learned.reason };
      results.push({ arm: 'C-induced-skill', seed, taskId: task.id, caseInput: c.input, expected: c.expected, actual: applied.ok ? applied.output : null, success: applied.ok && JSON.stringify(applied.output) === JSON.stringify(c.expected), wrongAnswer: applied.ok && JSON.stringify(applied.output) !== JSON.stringify(c.expected), abstained: !applied.ok, operations: learner.operations, skillCount: learner.skills.size, learned: learned.accepted, trainingCount: task.training.length, trainingCorrect: learned.accepted ? task.training.length : 0, developmentCount: task.development.length, developmentCorrect: learned.skill?.validation?.developmentPassed ?? 0, learningDurationMs, durationMs: performance.now() - caseStart, heapUsedBytes: process.memoryUsage().heapUsed, note: learned.accepted ? 'unique bounded DSL rule learned and dev-checked' : learned.reason });
    }
    // D: induce, propose an intentionally worse candidate, and check rollback/no regression.
    const learnerD = new DigitalObjectLearner({ id: `study-mutation-${seed}-${task.id}` });
    const learnStartD = performance.now();
    const learnedD = learnerD.learnAffine({ name: task.id, modulus: task.domain.modulus, training: trainingOrder, development: developmentOrder });
    const learningDurationMsD = performance.now() - learnStartD;
    let mutation = null; const mutationStart = performance.now();
    if (learnedD.accepted) mutation = learnerD.proposeMutation(learnedD.skill.id, { param: 'b', value: (learnedD.skill.params.b + 1) % task.domain.modulus, development: developmentOrder, regression: trainingOrder });
    const mutationDurationMs = performance.now() - mutationStart;
    for (const c of cases) {
      const caseStart = performance.now();
      const active = [...learnerD.skills.values()].find(s => s.active && s.status === 'accepted');
      const applied = active ? learnerD.apply(active.id, c.input) : { ok: false };
      results.push({ arm: 'D-evolution-with-gate', seed, taskId: task.id, caseInput: c.input, expected: c.expected, actual: applied.ok ? applied.output : null, success: applied.ok && JSON.stringify(applied.output) === JSON.stringify(c.expected), wrongAnswer: applied.ok && JSON.stringify(applied.output) !== JSON.stringify(c.expected), abstained: !applied.ok, operations: learnerD.operations, skillCount: learnerD.skills.size, mutationAttempted: Boolean(mutation), mutationAccepted: mutation?.accepted ?? false, rollbackVerified: Boolean(mutation && !mutation.accepted && [...learnerD.skills.values()].some(s => s.id === learnedD.skill.id && s.active)), trainingCount: task.training.length, trainingCorrect: learnedD.accepted ? task.training.length : 0, developmentCount: task.development.length, developmentCorrect: learnedD.skill?.validation?.developmentPassed ?? 0, learningDurationMs: learningDurationMsD, mutationDurationMs, durationMs: performance.now() - caseStart, heapUsedBytes: process.memoryUsage().heapUsed, note: mutation?.reason ?? 'induction-failed' });
    }
  }
}
// E: dialogue/code route evaluated separately because it is not the same symbolic task distribution.
const dialogueCases = [
  { text: 'احسب 7 + 5', kind: 'calculation', expected: true },
  { text: 'Write a JavaScript function to sum an array', kind: 'code.sum', expected: true },
  { text: 'Write a factorial function', kind: 'code.factorial', expected: true },
  { text: 'Write a program that solves every possible problem', kind: 'abstention', expected: true }
];
for (const c of dialogueCases) {
  const caseStart = performance.now();
  const response = await handleDialogue(c.text);
  const success = c.kind === 'abstention' ? response.ok === false && response.abstention !== undefined : c.kind === 'calculation' ? response.ok && response.verification?.parserToolAgreement === true : response.ok && response.solution?.verification?.testsPassed === response.solution?.verification?.testsTotal;
  results.push({ arm: 'E-dialogue-solution', seed: 0, taskId: `dialogue-${c.kind}`, caseInput: c.text, expected: c.expected, actual: success, success, wrongAnswer: !success, abstained: c.kind === 'abstention' && success, operations: response.trace?.length ?? 0, skillCount: 0, trainingCount: 0, trainingCorrect: 0, developmentCount: 0, developmentCorrect: 0, durationMs: performance.now() - caseStart, heapUsedBytes: process.memoryUsage().heapUsed, note: response.request?.intent ?? 'no-intent' });
}
const csvFields = [...new Set(results.flatMap(r => Object.keys(r)))];
const cell = v => { const s = v === undefined ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v); return /[",\n]/.test(s) ? `"${s.replaceAll('"', '""')}"` : s; };
const csv = [csvFields.join(','), ...results.map(r => csvFields.map(k => cell(r[k])).join(','))].join('\n') + '\n';
fs.writeFileSync(path.join(root, 'experiments/stage4/results.json'), JSON.stringify({ schema: 'synora-stage4-results/2', generatedAt: new Date().toISOString(), taskFileSha256: sha(taskPath), answerKeySha256: sha(keyPath), codeRevision: 'stage4-v2-final-heldout', sourceHashes: Object.fromEntries(['synora-v5/dialogue/index.mjs','synora-v5/dialogue/agent.mjs','synora-v5/solution-engine/index.mjs','synora-v5/digital-object-learning/index.mjs','synora-v5/digital-object-learning/bridge.mjs','synora-v5/digital-object-core/index.mjs','synora-v5/api/server.mjs'].map(rel => [rel, sha(path.join(root, rel))])), results }, null, 2) + '\n');
fs.writeFileSync(path.join(root, 'experiments/stage4/results.csv'), csv);
const summary = {};
for (const r of results) { const k = r.arm; summary[k] ??= { n: 0, successes: 0, failures: 0, wrongAnswers: 0, abstentions: 0 }; summary[k].n++; if (r.success) summary[k].successes++; else summary[k].failures++; if (r.wrongAnswer) summary[k].wrongAnswers++; if (r.abstained) summary[k].abstentions++; }
console.log(JSON.stringify({ rows: results.length, summary, files: ['experiments/stage4/results.json', 'experiments/stage4/results.csv'] }, null, 2));
