import fs from 'node:fs';
import { PstEngine } from '../../synora-v5/pst/engine.mjs';
import { AdaptivePstEngine } from '../../synora-v5/phase4/adaptive-engine.mjs';
import { Grader } from '../../synora-v5/pst/grader.mjs';
import { TASKS } from '../../synora-v5/pst/tasks.mjs';
import { DigitalObjectCore } from '../../synora-v5/digital-object-core/index.mjs';
import { captureNativeMemory, restoreNativeMemory } from './native-memory.mjs';
const config = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const { phase, mode, seed, budget, corePath, taskIds, memoryPath } = config;
const Engine = mode === 'adaptive' ? AdaptivePstEngine : PstEngine;
const engineOptions = { mode, seed, budget, generations: config.generations ?? 20, populationSize: config.populationSize ?? 8 };
const getTask = id => { const t = TASKS.find(x => x.id === id); if (!t) throw new Error(`unknown task ${id}`); return t; };
const grader = new Grader({ timeoutMs: 600, size: 2 });
await grader.init();
const rows = [];
let engine;
let core = null;
let coreHintCalls = 0, coreHintHits = 0;
const makeEngine = (overrides = {}) => new Engine({ ...engineOptions, ...overrides, grader });
function attachCore(e, c) {
  const original = e.hintFor.bind(e);
  const cache = new Map();
  for (const f of c.infer().facts) if (f.predicate === 'portable-hint') {
    if (!cache.has(f.subject)) cache.set(f.subject, []);
    cache.get(f.subject).push(f.object);
  }
  e.hintFor = function(key, ...args) {
    const native = original(key, ...args);
    if (native !== null && native !== undefined) return native;
    coreHintCalls++;
    const values = [...new Map((cache.get(key) ?? []).map(v => [JSON.stringify(v), v])).values()];
    if (values.length === 1) { coreHintHits++; return values[0]; }
    return null;
  };
}
function verifiedPortableHints(e) {
  const out = new Map(e.hints);
  // Adaptive V2 promotes verified skills in the CRI ledger; its useful parameter
  // hints may therefore live in ledger.skills rather than e.hints. Export only
  // explicitly verified hints so the digital-core bridge is not accidentally empty.
  for (const skill of e.ledger.skills.values()) {
    if (skill.verified !== true || !skill.hint || skill.hint.key == null || skill.hint.value === undefined) continue;
    out.set(skill.hint.key, skill.hint.value);
  }
  return out;
}
if (phase === 'train') {
  engine = makeEngine();
  for (const id of taskIds) {
    const t = getTask(id); const start = process.hrtime.bigint(); const beforeHeap = process.memoryUsage().heapUsed;
    const r = await engine.runTask(t);
    rows.push({ phase: 'train', mode, seed, taskId: id, success: r.success, score: r.score, evaluations: r.evaluations, violations: r.violations.length, elapsedMs: Number(process.hrtime.bigint() - start) / 1e6, heapDeltaBytes: process.memoryUsage().heapUsed - beforeHeap });
  }
  const memory = captureNativeMemory(engine);
  if (memoryPath) fs.writeFileSync(memoryPath, JSON.stringify(memory));
  if (Array.isArray(config.evalTaskIds) && config.evalTaskIds.length) {
    for (const id of config.evalTaskIds) {
      const t = getTask(id);
      const e = restoreNativeMemory(makeEngine(), memory);
      const start = process.hrtime.bigint(); const beforeHeap = process.memoryUsage().heapUsed;
      const r = await e.runTask(t);
      rows.push({ phase: 'warm-eval', mode, arm: `${mode}-native-memory`, seed, taskId: id, success: r.success, score: r.score, evaluations: r.evaluations, violations: r.violations.length, elapsedMs: Number(process.hrtime.bigint() - start) / 1e6, heapDeltaBytes: process.memoryUsage().heapUsed - beforeHeap, coreHintCalls: 0, coreHintHits: 0 });
    }
  }
  if (corePath) {
    core = new DigitalObjectCore();
    core.addRule({ id: 'stage2:portable-hint', premise: { predicate: 'verified-hint' }, conclusion: { subjectFrom: 'premise.subject', predicate: 'portable-hint', objectValueFrom: 'premise.object' }, source: 'stage2-experiment' }, 'stage2:portable-hint:rule');
    const portableHints = verifiedPortableHints(engine);
    for (const [i, [key, value]] of [...portableHints.entries()].entries()) {
      core.addFact({ subject: key, predicate: 'verified-hint', object: value, source: 'engine-experience', kind: 'direct', status: 'accepted', confidence: 1, evidence: [{ kind: 'training-run', mode, seed, taskIds, verified: true }] }, `stage2:hint:${mode}:${seed}:${i}`);
    }
    const save = core.save(corePath);
    process.stdout.write(JSON.stringify({ phase, mode, seed, rows, hintCount: engine.hints.size, portableHintCount: portableHints.size, skillCount: engine.ledger.skills.size, coreFactCount: core.facts.size, coreRuleCount: core.rules.size, coreHash: save.sha256, memoryPath: memoryPath ?? null }));
  } else {
    process.stdout.write(JSON.stringify({ phase, mode, seed, rows, hintCount: engine.hints.size, skillCount: engine.ledger.skills.size, memoryPath: memoryPath ?? null }));
  }
} else if (phase === 'eval') {
  if (corePath) core = DigitalObjectCore.load(corePath);
  let memory = null;
  if (memoryPath) memory = JSON.parse(fs.readFileSync(memoryPath, 'utf8'));
  for (const id of taskIds) {
    const t = getTask(id); const overrides = {};
    const e = makeEngine(overrides);
    if (memory) restoreNativeMemory(e, memory);
    if (core) attachCore(e, core);
    const start = process.hrtime.bigint(); const beforeHeap = process.memoryUsage().heapUsed;
    const r = await e.runTask(t);
    rows.push({ phase: 'eval', mode, arm: config.arm, seed, taskId: id, success: r.success, score: r.score, evaluations: r.evaluations, violations: r.violations.length, elapsedMs: Number(process.hrtime.bigint() - start) / 1e6, heapDeltaBytes: process.memoryUsage().heapUsed - beforeHeap, coreHintCalls, coreHintHits, coreKnowledgeFacts: core?.facts.size ?? 0, coreDerivedFacts: core?.infer().derived.length ?? 0 });
    coreHintCalls = 0; coreHintHits = 0;
  }
  process.stdout.write(JSON.stringify({ phase, mode, arm: config.arm, seed, rows }));
} else {
  throw new Error(`unknown phase ${phase}`);
}
await grader.close();
