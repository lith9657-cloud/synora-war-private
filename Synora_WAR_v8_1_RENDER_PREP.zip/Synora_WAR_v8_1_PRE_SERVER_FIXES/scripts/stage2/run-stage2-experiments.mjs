import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { DigitalObjectCore } from '../../synora-v5/digital-object-core/index.mjs';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const OUT = path.join(ROOT, 'experiments/stage2');
const CFG = JSON.parse(fs.readFileSync(path.join(OUT, 'config.json'), 'utf8'));
const CASES = JSON.parse(fs.readFileSync(path.join(OUT, 'benchmark-cases.json'), 'utf8'));
const ANSWERS = JSON.parse(fs.readFileSync(path.join(OUT, 'answer-key.json'), 'utf8'));
const SEEDS = JSON.parse(fs.readFileSync(path.join(OUT, 'seeds.json'), 'utf8')).seeds;
const allCases = [...CASES.development.map(x=>({...x,split:'development'})), ...CASES.validation.map(x=>({...x,split:'validation'})), ...CASES.finalTest.map(x=>({...x,split:'final-test'}))];
const raw = [];
const engineRaw = [];
const failures = [];
function rng(seed) { let s = (seed >>> 0) || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s >>>= 0; s ^= s << 5; s >>>= 0; return s / 0x100000000; }; }
function shuffled(a, seed) { const out=[...a], r=rng(seed); for(let i=out.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[out[i],out[j]]=[out[j],out[i]];} return out; }
function queryCore(core, query, functional) {
  const t0=process.hrtime.bigint(), heap0=process.memoryUsage().heapUsed;
  const result=core.infer();
  const vals=result.facts.filter(f=>f.subject===query.subject&&f.predicate===query.predicate).map(f=>f.object);
  const unique=[...new Map(vals.map(v=>[JSON.stringify(v),v])).values()];
  let answer=null;
  if(functional) answer=unique.length===1?unique[0]:null;
  else if(unique.length===1) answer=unique[0];
  else if(unique.length>1) answer=unique.sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
  return {answer,values:unique,derivedCount:result.derived.length,rounds:result.rounds,exhausted:result.exhausted,conflicts:result.conflicts.length,inferMs:Number(process.hrtime.bigint()-t0)/1e6,heapDeltaBytes:process.memoryUsage().heapUsed-heap0,sourceFactCount:core.facts.size,ruleCount:core.rules.size};
}
function loadCase(c, seed) {
  const core=new DigitalObjectCore({ functionalPredicates:c.functionalPredicates??[] });
  const facts=shuffled(c.facts, seed ^ 0x55aa);
  for(let i=0;i<facts.length;i++) core.addFact({...facts[i],source:facts[i].source??'user',kind:facts[i].kind??'direct',status:facts[i].status??'accepted'},`bench:${c.id}:fact:${i}`);
  const rules=shuffled(c.rules, seed ^ 0x7733);
  for(let i=0;i<rules.length;i++) core.addRule({...rules[i],source:'benchmark-provided'},`bench:${c.id}:rule:${i}`);
  return core;
}
function compareAnswer(got, expected) { return JSON.stringify(got)===JSON.stringify(expected); }
function csvCell(v) { if(v===null||v===undefined)return ''; const s=typeof v==='object'?JSON.stringify(v):String(v); return /[",\n]/.test(s)?`"${s.replaceAll('"','""')}"`:s; }
function toCsv(rows) { const keys=[...new Set(rows.flatMap(r=>Object.keys(r)))]; return [keys.join(','),...rows.map(r=>keys.map(k=>csvCell(r[k])).join(','))].join('\n')+'\n'; }
function runCoreCases() {
  for (const seed of SEEDS) {
    for (const c0 of shuffled(allCases, seed)) {
      const c={...c0}; const expectedRec=ANSWERS[c.id];
      if(!expectedRec){failures.push({stage:'core',seed,taskId:c.id,error:'missing answer key'});continue;}
      const start=process.hrtime.bigint(); let core; let beforeAnswer=null; let mutationApplied=false; let restartUsed=false; let result;
      try {
        core=loadCase(c,seed);
        if(expectedRec.mode==='single_after_mutation') {
          const before=queryCore(core,c.query,(c.functionalPredicates??[]).includes(c.query.predicate));
          beforeAnswer=before.answer;
          const m=c.mutation;
          core.removeFact(m.remove,`bench:${c.id}:remove`);
          core.addFact({...m.add,kind:'direct',status:'accepted'},`bench:${c.id}:add`);
          mutationApplied=true;
        }
        if(expectedRec.mode==='restart') {
          const dir=fs.mkdtempSync(path.join(os.tmpdir(),'synora-stage2-restart-'));
          const snap=path.join(dir,'memory.json'); const queryFile=path.join(dir,'query.json');
          const save=core.save(snap);
          fs.writeFileSync(queryFile,JSON.stringify({query:c.query,facts:[],functional:(c.functionalPredicates??[]).includes(c.query.predicate)}));
          const child=spawnSync(process.execPath,[path.join(ROOT,'scripts/stage2/core-child.mjs'),snap,queryFile],{encoding:'utf8',timeout:15000});
          if(child.status!==0) throw new Error(`restart child failed: ${child.stderr||child.error||child.status}`);
          result=JSON.parse(child.stdout); result.inferMs=0; result.heapDeltaBytes=0; result.sourceFactCount=core.facts.size; result.ruleCount=core.rules.size; result.rounds=result.rounds; result.exhausted=false; result.saveSha256=save.sha256; result.snapshotBytes=fs.statSync(snap).size; restartUsed=true;
          fs.rmSync(dir,{recursive:true,force:true});
        } else result=queryCore(core,c.query,(c.functionalPredicates??[]).includes(c.query.predicate));
        const success=compareAnswer(result.answer,expectedRec.expected);
        const row={track:'digital-object-core',split:c.split,taskId:c.id,category:c.category,seed,success,expected:expectedRec.expected,answer:result.answer,values:result.values??result.values,derivedCount:result.derivedCount,rounds:result.rounds,exhausted:result.exhausted,conflicts:result.conflicts,inferMs:result.inferMs,elapsedMs:Number(process.hrtime.bigint()-start)/1e6,heapDeltaBytes:result.heapDeltaBytes,sourceFactCount:result.sourceFactCount,ruleCount:result.ruleCount,mutationApplied,beforeAnswer,restartUsed,snapshotBytes:result.snapshotBytes??null,saveSha256:result.saveSha256??null};
        raw.push(row);
        if(!success) failures.push({stage:'core',seed,taskId:c.id,error:'answer mismatch',expected:expectedRec.expected,actual:result.answer,details:row});
      } catch(e) { failures.push({stage:'core',seed,taskId:c.id,error:String(e?.stack??e)}); raw.push({track:'digital-object-core',split:c.split,taskId:c.id,category:c.category,seed,success:false,error:String(e?.message??e)}); }
    }
  }
  // Explicit cross-process learning transfer: the first process receives the rule from prior experience;
  // a second process receives only a new subject fact and must use the saved rule.
  for (const seed of SEEDS) {
    const dir=fs.mkdtempSync(path.join(os.tmpdir(),'synora-stage2-transfer-'));
    try {
      const core=new DigitalObjectCore();
      core.addFact({subject:'operator-old',predicate:'credential',object:'tier-2',source:'training-session'},`transfer:${seed}:old`);
      core.addRule({id:'learned:credential-to-trained',premise:{predicate:'credential',object:'tier-2'},conclusion:{subjectFrom:'premise.subject',predicate:'trained',objectValue:true},source:'experience-session'},`transfer:${seed}:rule1`);
      core.addRule({id:'learned:trained-to-operation',premise:{predicate:'trained',object:true},conclusion:{subjectFrom:'premise.subject',predicate:'can-operate',objectValue:'unit-8'},source:'experience-session'},`transfer:${seed}:rule2`);
      const snap=path.join(dir,'memory.json'), coldSnap=path.join(dir,'cold-memory.json'), queryFile=path.join(dir,'query.json'); const saved=core.save(snap);
      const coldCore = new DigitalObjectCore();
      coldCore.save(coldSnap);
      fs.writeFileSync(queryFile,JSON.stringify({query:{subject:'operator-new-'+seed,predicate:'can-operate'},facts:[{subject:'operator-new-'+seed,predicate:'credential',object:'tier-2'}],functional:false}));
      const child=spawnSync(process.execPath,[path.join(ROOT,'scripts/stage2/core-child.mjs'),snap,queryFile],{encoding:'utf8',timeout:15000});
      const coldChild=spawnSync(process.execPath,[path.join(ROOT,'scripts/stage2/core-child.mjs'),coldSnap,queryFile],{encoding:'utf8',timeout:15000});
      if(child.status!==0) throw new Error(child.stderr||child.error||'learned-rule child failed');
      if(coldChild.status!==0) throw new Error(coldChild.stderr||coldChild.error||'cold-control child failed');
      const got=JSON.parse(child.stdout); const coldGot=JSON.parse(coldChild.stdout); const expected='unit-8'; const success=got.answer===expected; const coldSuccess=coldGot.answer===null;
      raw.push({track:'cross-process-learning',split:'final-test',taskId:'SESSION-TRANSFER-RESTART',category:'persisted-rule-transfer',seed,success,expected,answer:got.answer,derivedCount:got.derivedCount,rounds:got.rounds,conflicts:got.conflicts,elapsedMs:null,heapDeltaBytes:null,sourceFactCount:core.facts.size+1,ruleCount:core.rules.size,restartUsed:true,snapshotBytes:fs.statSync(snap).size,saveSha256:saved.sha256,notes:'rule supplied/recorded in process 1; new subject fact added only in process 2'});
      raw.push({track:'cross-process-learning-control',split:'final-test',taskId:'SESSION-TRANSFER-COLD-CONTROL',category:'no-prior-rule-control',seed,success:coldSuccess,expected:null,answer:coldGot.answer,derivedCount:coldGot.derivedCount,rounds:coldGot.rounds,conflicts:coldGot.conflicts,elapsedMs:null,heapDeltaBytes:null,sourceFactCount:1,ruleCount:0,restartUsed:true,snapshotBytes:fs.statSync(coldSnap).size,saveSha256:null,notes:'matched new-subject fact in a separate process, but no learned rules'});
      if(!success) failures.push({stage:'cross-process-learning',seed,taskId:'SESSION-TRANSFER-RESTART',expected,actual:got.answer});
      if(!coldSuccess) failures.push({stage:'cross-process-learning-control',seed,taskId:'SESSION-TRANSFER-COLD-CONTROL',expected:null,actual:coldGot.answer});
    } catch(e) { failures.push({stage:'cross-process-learning',seed,error:String(e?.stack??e)}); }
    finally { fs.rmSync(dir,{recursive:true,force:true}); }
  }
}
let workerConfigCounter = 0;
function runEngineModeSeed(mode, seed) {
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'synora-stage2-engine-'));
  const corePath=path.join(temp,'core-memory.json');
  const memoryPath=path.join(temp,'native-memory.json');
  const runWorker=(cfg)=>{
    const file=path.join(temp,`args-${++workerConfigCounter}.json`); fs.writeFileSync(file,JSON.stringify({generations:CFG.engineGenerations,populationSize:CFG.enginePopulationSize,...cfg}));
    const res=spawnSync(process.execPath,[path.join(ROOT,'scripts/stage2/engine-worker.mjs'),file],{cwd:ROOT,encoding:'utf8',timeout:600000,maxBuffer:30*1024*1024});
    fs.rmSync(file,{force:true});
    if(res.status!==0) throw new Error(`engine worker failed (${mode}/${seed}): ${res.stderr||res.error||res.status}`);
    return JSON.parse(res.stdout);
  };
  try {
    // One shared development run produces both native-memory and Digital Object Core memory
    // from exactly the same experience; this avoids training-set drift between arms.
    const train=runWorker({phase:'train',mode,seed,budget:CFG.engineBudget,generations:CFG.engineGenerations,populationSize:CFG.enginePopulationSize,taskIds:CFG.developmentTaskIds,evalTaskIds:CFG.validationTaskIds,corePath,memoryPath});
    const warmArm=mode==='cri'?'A-CRI-alone':'B-AdaptiveV2-alone';
    const hybridArm=mode==='cri'?'C-CRI-plus-digital-core':'D-AdaptiveV2-plus-digital-core';
    for(const r of train.rows.filter(x=>x.phase==='warm-eval')) engineRaw.push({...r,arm:warmArm,condition:'native-memory-retained-snapshot-clone'});
    for(const r of train.rows.filter(x=>x.phase==='train')) engineRaw.push({...r,arm:`${warmArm}-training`,condition:'development-training'});
    // Matched cold control: fresh process, same mode and task set, no persisted memory.
    const cold=runWorker({phase:'eval',mode,seed,budget:CFG.engineBudget,generations:CFG.engineGenerations,populationSize:CFG.enginePopulationSize,taskIds:CFG.validationTaskIds,arm:`${warmArm}-cold-after-restart`});
    for(const r of cold.rows) engineRaw.push({...r,arm:`${warmArm}-cold-no-memory`,condition:'fresh-process-no-persisted-memory'});
    // Fair post-restart native-memory arm: same development experience, persisted native hints/ledger.
    const nativeRestart=runWorker({phase:'eval',mode,seed,budget:CFG.engineBudget,generations:CFG.engineGenerations,populationSize:CFG.enginePopulationSize,taskIds:CFG.validationTaskIds,memoryPath,arm:`${warmArm}-native-memory-after-restart`});
    for(const r of nativeRestart.rows) engineRaw.push({...r,arm:`${warmArm}-native-memory-after-restart`,condition:'fresh-process-native-memory'});
    // Hybrid: fresh process with only the saved Digital Object Core knowledge bridge.
    const hybrid=runWorker({phase:'eval',mode,seed,budget:CFG.engineBudget,generations:CFG.engineGenerations,populationSize:CFG.enginePopulationSize,taskIds:CFG.validationTaskIds,corePath,arm:hybridArm});
    for(const r of hybrid.rows) engineRaw.push({...r,arm:`${hybridArm}-core-only-ablation`,condition:'fresh-process-digital-core-only-memory',trainingHints:train.hintCount,trainingSkills:train.skillCount,coreFacts:train.coreFactCount,coreRules:train.coreRuleCount,portableHints:train.portableHintCount});
    // Additive arm: keep the engine's native memory and add the core as a fallback.
    const hybridNative=runWorker({phase:'eval',mode,seed,budget:CFG.engineBudget,generations:CFG.engineGenerations,populationSize:CFG.enginePopulationSize,taskIds:CFG.validationTaskIds,corePath,memoryPath,arm:`${hybridArm}-plus-native-memory`});
    for(const r of hybridNative.rows) engineRaw.push({...r,arm:hybridArm,condition:'fresh-process-native-and-digital-core-memory',trainingHints:train.hintCount,trainingSkills:train.skillCount,coreFacts:train.coreFactCount,coreRules:train.coreRuleCount,portableHints:train.portableHintCount});
    fs.writeFileSync(path.join(OUT,'results-progress.json'),JSON.stringify({seed,mode,core:raw,engine:engineRaw,failures},null,2)+'\n');
  } catch(e) { failures.push({stage:'engine',mode,seed,error:String(e?.stack??e)}); }
  finally { fs.rmSync(temp,{recursive:true,force:true}); }
}
const selectedTrack = process.argv[2] ?? 'all';
if (!['all','core','engine'].includes(selectedTrack)) throw new Error('usage: run-stage2-experiments.mjs [all|core|engine]');
if (selectedTrack !== 'engine') runCoreCases();
if (selectedTrack !== 'core') {
  for (const seed of SEEDS) {
    runEngineModeSeed('cri',seed);
    runEngineModeSeed('adaptive',seed);
  }
}
const runMeta={protocolVersion:CFG.protocolVersion,track:selectedTrack,startedAt:new Date().toISOString(),node:process.version,platform:process.platform,arch:process.arch,cpus:os.cpus().length,totalMemoryBytes:os.totalmem(),seeds:SEEDS,config:CFG,caseFileSha256:createHash('sha256').update(fs.readFileSync(path.join(OUT,'benchmark-cases.json'))).digest('hex'),answerKeySha256:createHash('sha256').update(fs.readFileSync(path.join(OUT,'answer-key.json'))).digest('hex'),results:{coreRows:raw.length,engineRows:engineRaw.length,failures:failures.length}};
const pairedAblation=[];
const pairSpecs=[
  {mode:'cri',baseArm:'A-CRI-alone-cold-no-memory',baseCondition:'fresh-process-no-persisted-memory',coreArm:'C-CRI-plus-digital-core-core-only-ablation',coreCondition:'fresh-process-digital-core-only-memory',comparison:'cold-vs-digital-core-only'},
  {mode:'adaptive',baseArm:'B-AdaptiveV2-alone-cold-no-memory',baseCondition:'fresh-process-no-persisted-memory',coreArm:'D-AdaptiveV2-plus-digital-core-core-only-ablation',coreCondition:'fresh-process-digital-core-only-memory',comparison:'cold-vs-digital-core-only'},
  {mode:'cri',baseArm:'A-CRI-alone-native-memory-after-restart',baseCondition:'fresh-process-native-memory',coreArm:'C-CRI-plus-digital-core',coreCondition:'fresh-process-native-and-digital-core-memory',comparison:'native-memory-vs-native-plus-core'},
  {mode:'adaptive',baseArm:'B-AdaptiveV2-alone-native-memory-after-restart',baseCondition:'fresh-process-native-memory',coreArm:'D-AdaptiveV2-plus-digital-core',coreCondition:'fresh-process-native-and-digital-core-memory',comparison:'native-memory-vs-native-plus-core'}
];
for (const spec of pairSpecs) {
  const base=engineRaw.filter(r=>r.arm===spec.baseArm&&r.condition===spec.baseCondition);
  const hybrid=engineRaw.filter(r=>r.arm===spec.coreArm&&r.condition===spec.coreCondition);
  const idx=new Map(hybrid.map(r=>[`${r.seed}::${r.taskId}`,r]));
  for(const a of base) {
    const b=idx.get(`${a.seed}::${a.taskId}`);
    if(!b) { failures.push({stage:'paired-ablation',mode:spec.mode,comparison:spec.comparison,seed:a.seed,taskId:a.taskId,error:'missing matched core arm row'}); continue; }
    pairedAblation.push({mode:spec.mode,comparison:spec.comparison,seed:a.seed,taskId:a.taskId,baselineSuccess:a.success,coreSuccess:b.success,successChanged:a.success!==b.success,baselineScore:a.score,coreScore:b.score,scoreDelta:Number((b.score-a.score).toFixed(6)),baselineEvaluations:a.evaluations,coreEvaluations:b.evaluations,evaluationDelta:b.evaluations-a.evaluations,baselineElapsedMs:a.elapsedMs,coreElapsedMs:b.elapsedMs,elapsedDeltaMs:Number((b.elapsedMs-a.elapsedMs).toFixed(3)),coreHintCalls:b.coreHintCalls??0,coreHintHits:b.coreHintHits??0,coreFactCount:b.coreKnowledgeFacts??0,coreDerivedFactCount:b.coreDerivedFacts??0});
  }
}
runMeta.results.failures=failures.length;
fs.writeFileSync(path.join(OUT,'results-raw.json'),JSON.stringify({meta:runMeta,core:raw,engine:engineRaw,pairedAblation,failures},null,2)+'\n');
fs.writeFileSync(path.join(OUT,'results-detailed.csv'),toCsv([...raw,...engineRaw]) );
fs.writeFileSync(path.join(OUT,'paired-ablation.json'),JSON.stringify({protocolVersion:CFG.protocolVersion,method:'matched mode, seed and validation task in fresh processes; includes cold-vs-core-only and persisted-native-memory-vs-native-plus-core comparisons; all memory comes from the same development run; no CRI or Adaptive V2 source changes',rows:pairedAblation},null,2)+'\n');
fs.writeFileSync(path.join(OUT,'paired-ablation.csv'),toCsv(pairedAblation));
fs.writeFileSync(path.join(OUT,'failures-and-exclusions.json'),JSON.stringify({failures,excluded:[
  {item:'Initial exploratory run (archive/pre-fix-run)',reason:'worker used 60 generations while config declared 20, and no fresh-process native-memory control was included; preserved for audit only, excluded from primary inference.'},
  {item:'Intermediate 20-generation run (archive/intermediate-run)',reason:'warm, cold, and native-restart rows were pooled under misleading arm labels and fresh-process restore omitted engine.hints; preserved for audit only, excluded from primary inference.'},
  {item:'Existing PST set B as independent final test',reason:'these task IDs and task structures were already in the Stage 1 archive and earlier experiments; retained only as validation/transfer tasks.'},
  {item:'CRI/Adaptive V2 on symbolic final-test tasks',reason:'their actual runTask(task) contract is a program-repair grader for PST tool programs, not a general symbolic QA interface; no simulated outputs were substituted.'}
]},null,2)+'\n');
console.log(JSON.stringify(runMeta,null,2));
console.log(`Wrote ${path.join(OUT,'results-raw.json')}`);
