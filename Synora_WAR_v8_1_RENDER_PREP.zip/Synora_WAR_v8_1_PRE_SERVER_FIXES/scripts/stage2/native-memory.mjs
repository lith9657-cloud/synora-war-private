import { Ledger } from '../../synora-v5/ledger.mjs';

export function serializeLedger(ledger) {
  return {
    refutations: [...ledger.refutations.entries()],
    skills: [...ledger.skills.entries()],
    witnesses: [...ledger.witnesses.entries()],
    prohibitions: [...ledger.prohibitions.entries()],
    documented: [...ledger.documented],
    stats: ledger.stats,
  };
}

export function restoreLedger(data) {
  const ledger = new Ledger();
  if (!data) return ledger;
  ledger.refutations = new Map(data.refutations ?? []);
  ledger.skills = new Map(data.skills ?? []);
  ledger.witnesses = new Map(data.witnesses ?? []);
  ledger.prohibitions = new Map(data.prohibitions ?? []);
  ledger.documented = new Set(data.documented ?? []);
  ledger.stats = data.stats ?? ledger.stats;
  return ledger;
}

export function captureNativeMemory(engine) {
  return { hints: [...engine.hints.entries()], ledger: serializeLedger(engine.ledger) };
}

export function restoreNativeMemory(engine, data) {
  engine.ledger = restoreLedger(data?.ledger);
  engine.hints = new Map(data?.hints ?? []);
  return engine;
}
