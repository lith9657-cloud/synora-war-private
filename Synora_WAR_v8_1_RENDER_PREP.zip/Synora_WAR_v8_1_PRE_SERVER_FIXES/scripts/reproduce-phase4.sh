#!/usr/bin/env bash
# Synora WAR v5 — PHASE 4: reproduce the cross-domain experiment end to end.
#
#   bash scripts/reproduce-phase4.sh [seeds] [budgets]
#
# Defaults: 5 seeds, budgets 10,20,40,80,150.
#
# The script runs, in order:
#   1. the five test suites (Phase 1, 2, 3, the audit suite, and the Phase-4 suite),
#   2. one acquisition session + one evaluation session BY HAND (process 1 -> file -> process 2),
#   3. the full study: 4 arms x N seeds x budgets, every arm in its own process,
#   4. the raw artefacts and the report tables.
#
# Nothing here needs a GPU, a network, or an API key.
set -euo pipefail

cd "$(dirname "$0")/.."
ROOT="$(pwd)"

SEEDS="${1:-5}"
BUDGETS="${2:-10,20,40,80,150}"
OUT="experiments/results-phase4.json"
RAW="experiments/phase4"

# Snapshot all fixed-path Phase-4 outputs. Restore them on normal exit or catchable signals.
BACKUP="$(mktemp -d)"
restore_outputs() {
  local status=$?
  trap - EXIT INT TERM
  if [[ -f "$BACKUP/results-phase4.json.present" ]]; then cp -a "$BACKUP/results-phase4.json" experiments/results-phase4.json; else rm -f experiments/results-phase4.json; fi
  if [[ -f "$BACKUP/results-phase4.csv.present" ]]; then cp -a "$BACKUP/results-phase4.csv" experiments/results-phase4.csv; else rm -f experiments/results-phase4.csv; fi
  if [[ -d "$BACKUP/phase4" ]]; then rm -rf experiments/phase4; cp -a "$BACKUP/phase4" experiments/phase4; else rm -rf experiments/phase4; fi
  rm -rf "$BACKUP"
  return "$status"
}
if [[ -f experiments/results-phase4.json ]]; then cp -a experiments/results-phase4.json "$BACKUP/results-phase4.json"; touch "$BACKUP/results-phase4.json.present"; fi
if [[ -f experiments/results-phase4.csv ]]; then cp -a experiments/results-phase4.csv "$BACKUP/results-phase4.csv"; touch "$BACKUP/results-phase4.csv.present"; fi
if [[ -d experiments/phase4 ]]; then cp -a experiments/phase4 "$BACKUP/phase4"; fi
trap restore_outputs EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

echo "### Synora WAR v5 — Phase 4 (cross-domain) reproduction"
echo "    root    : $ROOT"
echo "    seeds   : $SEEDS"
echo "    budgets : $BUDGETS"
echo

echo "### 1/5  Test suites (Phase 1 + Phase 2 + Phase 3 + audit + Phase 4)"
node tests/self-test.mjs
node tests/v5.test.mjs
node tests/pst.test.mjs
node tests/phase3.test.mjs
node tests/audit.test.mjs
node tests/phase4.test.mjs
echo

echo "### 2/5  One session pair by hand (process 1 -> file -> process 2)"
mkdir -p "$RAW/memory"
node synora-v5/phase4/acquire.mjs --seed=1 --budget=250 --generations=250 --out="$RAW/memory/hand-seed1.json" > "$RAW/memory/hand-receipt-seed1.json"
node synora-v5/phase4/evaluate.mjs --mode=cri --seed=1 --budget=40 --generations=250 --groups=C \
     --memory="$RAW/memory/hand-seed1.json" --out="$RAW/hand-eval-cri-seed1.json"
echo "  memory file : $RAW/memory/hand-seed1.json"
echo "  evaluation  : $RAW/hand-eval-cri-seed1.json"
echo

echo "### 3/5  The full study ($SEEDS seeds x 4 arms x budgets $BUDGETS)"
node synora-v5/phase4/experiments.mjs --seeds="$SEEDS" --budgets="$BUDGETS" --generations=250 --out="$OUT"
echo

echo "### 4/5  Raw artefacts"
echo "  aggregated  : $OUT"
echo "  flat CSV    : ${OUT%.json}.csv"
echo "  per-run     : $RAW/eval-<arm>-seed<N>-budget<B>.json"
echo "  memories    : $RAW/memory/acquire-seed<N>.json"
echo

echo "### 5/5  The report tables (generated from the raw results)"
node synora-v5/phase4/report-tables.mjs --phase4="$OUT" | tee "$RAW/report-tables.txt"
echo
echo "  final audit : docs/07-FINAL-AUDIT-AND-REPRODUCTION.md"
echo "  phase 4     : docs/08-REPORT-PHASE4-CROSS-DOMAIN.md"
echo "  deviations  : docs/09-PHASE4-PROTOCOL-DEVIATIONS.md"
echo
echo "Done. Original packaged result files have been restored; this run did not mutate the shipped evidence."
