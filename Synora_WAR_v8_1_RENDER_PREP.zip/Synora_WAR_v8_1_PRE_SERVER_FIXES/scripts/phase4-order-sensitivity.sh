#!/usr/bin/env bash
# Synora WAR v5 — PHASE 4: the ACQUISITION-ORDER sensitivity control.
#
#   bash scripts/phase4-order-sensitivity.sh [seeds] [budgets]
#
# WHY THIS CONTROL EXISTS
# The existing CRI memory returns the FIRST skill whose hint matches a slot key. The rule that
# is therefore INHERITED is the rule that was learned FIRST. This control runs the SAME
# acquisition session in the opposite order and measures what happens to the transfer:
#
#   - if the transfer survives the reversal, the effect does not depend on the acquisition order;
#   - if it collapses, the effect depends on WHICH rule was learned first, and that is a
#     property of the memory mechanism, not of the domain.
#
# Nothing about the engine changes: only the order in which the acquisition group is met.
set -euo pipefail

cd "$(dirname "$0")/.."
ROOT="$(pwd)"

SEEDS="${1:-3}"
BUDGETS="${2:-10,20,40,80,150}"
RAW="experiments/phase4/order-sensitivity"
mkdir -p "$RAW/memory"

echo "### The acquisition-order sensitivity control"
echo "    seeds: $SEEDS   budgets: $BUDGETS"
echo

for order in forward reverse; do
  echo "--- acquisition order: $order ---"
  for seed in $(seq 1 "$SEEDS"); do
    mem="$RAW/memory/${order}-seed${seed}.json"
    extra=""
    if [ "$order" = "reverse" ]; then extra="--reverse=1"; fi
    node synora-v5/phase4/acquire.mjs --seed="$seed" --budget=250 --generations=250 $extra --out="$mem" > "$RAW/${order}-receipt-seed${seed}.json"
    echo "  seed $seed: $(node -e "
      const r = require('./$RAW/${order}-receipt-seed${seed}.json');
      const hints = {};
      for (const s of r.skillTable) if (s.hint && !(s.hint.key in hints)) hints[s.hint.key] = s.hint.value;
      console.log('skills', r.memory.skills, '| first hints:', JSON.stringify(hints));
    ")"
  done
done

echo
echo "--- the held-out group under each memory (cri arm) ---"
for order in forward reverse; do
  for seed in $(seq 1 "$SEEDS"); do
    mem="$RAW/memory/${order}-seed${seed}.json"
    node synora-v5/phase4/evaluate.mjs --mode=cri --seed="$seed" --budget=40 --generations=250 --groups=C \
         --memory="$mem" --out="$RAW/eval-${order}-seed${seed}.json" > /dev/null
  done
done

node - <<'EOF'
const fs = require('fs');
const path = require('path');
const dir = 'experiments/phase4/order-sensitivity';
const out = {};
for (const order of ['forward', 'reverse']) {
  const runs = [];
  for (const file of fs.readdirSync(dir).filter(f => f.startsWith(`eval-${order}-`))) {
    const payload = JSON.parse(fs.readFileSync(path.join(dir, file), 'utf8'));
    for (const r of payload.results) runs.push(r);
  }
  const ok = runs.filter(r => r.success);
  const acquired = runs.filter(r => ['C1_settle_b2_num','C2_settle_b2_str','C3_settle_b2_rate','C4_largest_in_band2','C5_second_in_band2'].includes(r.taskId));
  const okAcq = acquired.filter(r => r.success);
  const med = v => { if (!v.length) return null; const s=[...v].sort((a,b)=>a-b); const m=s.length>>1; return s.length%2?s[m]:(s[m-1]+s[m])/2; };
  out[order] = {
    tasks: runs.length,
    solved: ok.length,
    successRate: Number((ok.length / runs.length).toFixed(4)),
    acquiredSolved: `${okAcq.length}/${acquired.length}`,
    acquiredMedianEvals: med(okAcq.map(r => r.evaluations)),
    hintHits: runs.reduce((a,r)=>a+((r.memoryStats&&r.memoryStats.hintHits)||0),0),
    hintMisses: runs.reduce((a,r)=>a+((r.memoryStats&&r.memoryStats.hintMisses)||0),0),
  };
}
fs.writeFileSync(path.join(dir, 'order-sensitivity.json'), JSON.stringify(out, null, 2));
console.log('order | solved | rate | acquired solved | acquired median evals | hint hits | hint misses');
for (const [k, v] of Object.entries(out)) {
  console.log(`${k.padEnd(6)} | ${String(v.solved).padStart(2)}/${v.tasks} | ${(v.successRate*100).toFixed(1)}% | ${v.acquiredSolved.padEnd(15)} | ${String(v.acquiredMedianEvals).padStart(4)} | ${String(v.hintHits).padStart(3)} | ${String(v.hintMisses).padStart(3)}`);
}
EOF
echo
echo "written: $RAW/order-sensitivity.json"
