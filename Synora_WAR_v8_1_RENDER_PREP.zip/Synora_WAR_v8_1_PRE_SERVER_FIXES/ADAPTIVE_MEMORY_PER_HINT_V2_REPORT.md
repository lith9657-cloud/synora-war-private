# Adaptive Memory v2 — Per-hint evidence

## What changed

The experimental `AdaptivePstEngine` now tracks evidence by exact `(hint key, hint value)` rather than using task-wide `hintHits` / `hintMisses` as the abstention trigger. Each evidence record also stores outcomes by the violation string supplied as context. The policy abstains from a low-budget hint only after at least two misses for that same key/value and misses exceed hits. One miss is not sufficient. The existing high-budget abstention at budget >= 80 is retained as a separate conservative benchmark heuristic; it is not a learned confidence decision.

When a directed child is attributed, the engine compares parent and child violation sets and records outcomes against the corresponding SET_ARG / INSERT_CALL_ARG edit value and changed violation context. The existing Phase-4 global counters and ledger attribution remain owned by `PstEngine`.

## Focused tests

`tests/adaptive-engine.test.mjs`: 10/10 pass, including verified hint use, high-budget abstention, two misses for the same hint, tied evidence, transient single miss, unverified hint rejection, isolation between values, context accounting, and mode isolation.

## Important limits

- This is a deterministic heuristic, not a calibrated probabilistic confidence model.
- Context outcomes are recorded, but current `hintFor(key)` does not receive the target violation context, so abstention aggregates evidence for the same key/value across contexts. The context map is currently diagnostic, not a context-specific decision boundary.
- The paired 250-generation benchmark included in the package predates this per-hint implementation. Do not attribute those benchmark results to v2. A fresh paired benchmark must compare v2 against the prior adaptive policy and CRI using identical task/seed/budget cells before any default-policy promotion.
- The policy's budget >= 80 abstention remains unchanged; this update specifically addresses cross-hint contamination in the low/medium-budget miss rule.

## Validation

The package's regression tests are rerun after regenerating `audit/package-manifest.json`. Benchmark claims remain descriptive and separate from unit-test claims.
