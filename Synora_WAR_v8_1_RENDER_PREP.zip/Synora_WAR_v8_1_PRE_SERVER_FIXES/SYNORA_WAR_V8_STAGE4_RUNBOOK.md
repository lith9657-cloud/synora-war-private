# Synora WAR V8 Stage 4 — runbook

## Requirements

- Node.js 20 or newer (validated here with Node.js v22.16.0).
- No npm install is required; the new components use Node.js built-ins only.

## Test and reproduce

From the extracted project root:

```sh
npm test
npm run test:stage4
npm run study:stage4
```

`npm test` runs the inherited suites plus the Stage 4 suite. `npm run study:stage4` runs the symbolic and dialogue smoke study and writes fresh files to `experiments/stage4/results.json` and `experiments/stage4/results.csv`. The pilot files ending in `pilot-v1` are retained for provenance and must not be combined with the final V2 results.

## Start the API

```sh
npm run api:stage4
```

Default bind: `127.0.0.1:8787`. The learner memory defaults to `data/digital-object-learning.json`. Override with `SYNORA_LEARNING_MEMORY=/absolute/path/to/memory.json`.

Endpoints:

- `GET /health` — status, learner ID, skill count, available code templates, and application-ledger event count.
- `GET /v1/skills` — list learned skill metadata.
- `POST /v1/chat` — JSON `{ "text": "احسب 7 + 5", "history": [] }`. For a bounded named-skill request, send text such as `{ "text": "Apply affine7 to [3,5,6]" }`; no `skillId`/`skillInput` is needed if exactly one accepted, active skill with that exact name or ID is registered in DigitalObjectCore and the input is explicit. Arabic equivalents such as `طبّق affine7 على [3,5,6]` are supported. Ambiguous, inactive, unregistered, missing-input, and out-of-domain requests abstain. The explicit `skillId`/`skillInput` form remains supported.
- `POST /v1/skills/learn-affine` — bounded symbolic induction from `name`, `modulus`, `training`, and optional `development` examples.
- `POST /v1/skills/apply` — JSON `{ "skillId": "...", "input": [3,5,6] }`.

The API accepts at most 64 KiB JSON bodies, at most 16,000 characters of user text, at most 20 history turns, and applies a simple 120-request/minute per-IP limit. Skill application events are stored separately in `data/digital-skill-applications.json` by default; override this path with `SYNORA_SKILL_APPLICATION_LEDGER=/absolute/path/to/applications.json`. Supply `eventId` in the request or an `Idempotency-Key` header to make retries idempotent. Reusing the same key for a different request is rejected. Ledger entries distinguish execution success from objective correctness, which remains `not-assessed`. If `SYNORA_API_TOKEN` is set, all endpoints require `Authorization: Bearer <token>`. A non-loopback host is refused unless the token has at least 24 characters. For any non-local deployment, place the API behind TLS and a production-grade authentication/rate-limit boundary; the built-in controls are prototype safeguards, not a full deployment security model.

Example curl:

```sh
curl -s http://127.0.0.1:8787/v1/chat \
  -H 'content-type: application/json' \
  -d '{"text":"Write a JavaScript function to sum an array"}'
```

## Memory and recovery

The learner store is checksum-protected and written via a temporary file and atomic rename. `save()` keeps a `.bak` of a prior verified target. `DigitalObjectLearner.load(path)` rejects a missing, corrupted, unsupported-schema, or structurally invalid file rather than silently creating empty memory. Back up the memory file and its `.bak` together before manual maintenance. The current store is designed for one local writer; do not assume distributed or multi-writer transaction safety. The dialogue/API can route a narrowly scoped request when the user names exactly one accepted, active skill (name or ID) and supplies an explicit integer or bracketed integer array. This is exact bounded matching, not general language understanding. Application evidence is stored in a separate checksummed ledger; back up that file with the learner and DigitalObjectCore stores. It is a local single-writer store, not a distributed transaction system.

## Security boundaries

Only built-in, reviewed code templates are executed for the code-generation smoke path. Arbitrary user-supplied JavaScript is not executed. The `vm` context is not a hostile-code security sandbox. Do not add arbitrary code execution to the API without OS/container-level isolation, CPU/memory/process limits, and explicit file/network permissions.
