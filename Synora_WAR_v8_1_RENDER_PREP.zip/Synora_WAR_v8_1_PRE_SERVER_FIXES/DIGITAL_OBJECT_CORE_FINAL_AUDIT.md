# Synora WAR V6 — Digital Object Core final audit

Audit date: 2026-10-26

## 1. Scope and preserved components

Audited the previously delivered `Synora_WAR_v6_DIGITAL_OBJECT_CORE.zip` and patched that extracted project in place. No rebuild from the original baseline was performed. The original CRI ledger, `synora-v5/phase4/engine.mjs`, `synora-v5/phase4/adaptive-engine.mjs`, Adaptive Legacy engine, and their memory formats were not changed. The bridge is opt-in and records engine results after `runTask(task)` returns; it does not feed conclusions back into search or modify the CRI ledger.

## 2. Files added or changed

- **Changed** `synora-v5/digital-object-core/index.mjs`: schema v2; event-ID preflight and content conflict detection; idempotent replay; source-scoped facts; explicit fact retraction; conservative conflict handling; chained proof lineage; stricter persistence validation; safer atomic save.
- **Added** `synora-v5/digital-object-core/synora-adapter.mjs`: opt-in adapter for the public `runTask(task)` result boundary.
- **Changed** `tests/digital-object-core.test.mjs`: expanded from 6 to 11 focused tests.
- **Changed** `synora-v5/digital-object-core/README.md`, `synora-v5/digital-object-core/ENGINEERING-REPORT.md`, and root `README.md`: actual semantics and integration limits.
- **Changed** `docs/CHANGE-LOG.md`: final-closure changes and their rationale.
- **Added** this report. `audit/package-manifest.json` is regenerated after the report is finalized.

## 3. Root causes and repairs

1. **Duplicate event IDs were not a transaction boundary.** Earlier code mutated state before checking for duplicates and silently treated a reused ID with changed content as a duplicate. The core now compares the event's canonical request before mutation. Same ID + same request is a no-op; same ID + different request throws `event id conflict`. Creation, transition, relation, fact, rule, enablement, and outcome paths are covered.
2. **Failed operations could be difficult to distinguish from successful history.** Operations now validate and preflight before committing the event. Rejected transitions, unknown references, and unknown rules leave state and event history unchanged.
3. **Premise status did not implement reliable retraction/conflict semantics.** Facts are stored per proposition and source. A rejected or contested record for any source blocks that proposition from inference until the conflicting record is removed or reconciled. `removeFact()` explicitly removes one source record. `infer()` rebuilds derived facts from current accepted premises, so unsupported old conclusions are not retained.
4. **Proof and limit coverage was too narrow.** Tests now cover multi-step derivation, premise lineage, cycle deduplication, round exhaustion, and conflicting evidence. The rule language remains deliberately single-premise and bounded.
5. **Persistence validation and failure behavior were under-tested.** Schema version 2 validates collection shapes, references, fact/rule fields, event IDs/sequences, checksum, truncation, and incompatible schema. Save uses a unique temporary file, fsync, rename, and cleanup. A failed replacement test verifies existing target contents remain intact.
6. **There was no exercised engine boundary.** The new opt-in adapter records public task-result data through the real `PstEngine` and `AdaptivePstEngine` `runTask(task)` method boundary. The adapter does not change candidate generation, scoring, CRI storage, or Adaptive V2 policy.

## 4. Actual test results

Node.js runtime: `v22.16.0` (package target is Node.js 20+).

The complete `npm test` command was run on the working extracted project after the code changes. All original suites passed except the package-manifest audit initially detected the expected stale hashes after edits; the manifest was regenerated and the complete command was run again from the final extracted archive before delivery.

Final complete-suite counts:

| Suite | Result |
|---|---:|
| `tests/self-test.mjs` | 11 passed |
| `tests/v5.test.mjs` | 15 passed |
| `tests/pst.test.mjs` | 19 passed |
| `tests/phase3.test.mjs` | 20 passed |
| `tests/phase4.test.mjs` | 32 passed |
| `tests/adaptive-engine.test.mjs` | 16 passed |
| `tests/safe-transfer-ledger.test.mjs` | 4 passed |
| `tests/third-domain.test.mjs` | 6 passed |
| `tests/audit.test.mjs` | 23 passed |
| `tests/digital-object-core.test.mjs` | 11 passed |
| **Total** | **157 passed, 0 failed** |

Focused command: `npm run test:digital-objects` — **11 passed, 0 failed**.

The first full-suite run after code edits found one expected packaging failure: stale hashes for changed files in `audit/package-manifest.json` (22 audit checks passed, 1 failed). The manifest was rebuilt and the full suite was rerun; the final archive acceptance run is the authority for the final status.

## 5. Persistence and process-boundary evidence

The digital-object suite launches one child Node.js process to create and save a store, then a separate child process to load it and re-infer. It verifies objects, relations, rules, facts, evidence, event history, rule outcome counters, inference reconstruction, and event replay deduplication after restart. Additional tests reject truncated JSON, incompatible schema versions, and checksum tampering; simulate a failed replacement while checking the existing target remains unchanged; and verify conflicting replay does not increment counters.

## 6. CRI / Adaptive V2 integration status

- **CRI-compatible `PstEngine`:** opt-in `DigitalObjectSynoraAdapter` attached to the real engine's `runTask(task)` boundary and tested end-to-end with the actual Phase-4 grader/task.
- **Adaptive V2 (`AdaptivePstEngine`):** the same adapter was attached to the actual subclass and tested with a real task result.
- **Not implemented:** no feedback from digital-object inference to the search engine; no replacement of CRI memory; no alteration of Adaptive V2 decisions. This is a one-way, explicit result-recording bridge, not full cognitive integration.
- **Baseline safety:** the CRI/Adaptive engine and memory files were not edited. Existing protected-hash and regression checks passed in the final suite.

## 7. Experimental protocol review and limits

The existing Phase-3/Phase-4 tests check task-group separation, held-out IDs, solver/grader separation, budgets, seed-driven search changes, reproducibility, and raw-result/report consistency. The digital-object changes do not modify those task generators, seeds, budgets, or experimental engines. As an additional non-inferential smoke check, `node scripts/run-adaptive-final-study.mjs --seeds=1 --budgets=10` was run in a separate temporary copy: base 0/18, CRI 3/18, Adaptive Legacy 0/18, Adaptive V2 3/18. This is one seed at one budget, not a powered comparison, and no conclusion about superiority or generalization is drawn from it. No new multi-seed generalization claim is made from this closure run, and no Llama 2 comparison was run. Existing benchmark reports remain separate evidence for their original CRI/Adaptive protocols; they are not evidence that the Digital Object Core generalizes or outperforms them.

## 8. Remaining limitations

- The inference language is a bounded single-premise rule system, not general first-order logic or natural-language reasoning.
- Conflicting or contested provenance is handled conservatively by abstaining from inference; no full truth-maintenance network or non-monotonic belief revision is implemented.
- Confidence is an observed rule-outcome fraction, not neural learning or general-purpose learning.
- The adapter is opt-in and one-way; search does not consume object-core facts.
- SHA-256 detects accidental corruption, not an attacker who can rewrite both payload and digest.
- No Llama 2 benchmark or broad generalization experiment was performed.

## 9. Reproduction

From the extracted project directory:

```sh
npm run test:digital-objects
npm test
```

The package file manifest is `audit/package-manifest.json`; regenerate it with `npm run manifest` after intentional changes. The final ZIP is tested after extraction, not just from the development directory.

## 10. Archive checksum

The exact SHA-256 of the final ZIP is provided in the adjacent `Synora_WAR_v6_DIGITAL_OBJECT_CORE_FINAL.zip.sha256` checksum file and in the delivery message. Embedding a ZIP's own final digest as a literal inside that same ZIP would change the ZIP bytes and therefore invalidate the embedded digest; the adjacent checksum is computed from the final archive bytes.


> **Superseded status note (2026-10-26):** This file records the V6 closeout state and is retained as historical evidence. The V7 Stage 1 engineering pass supersedes its schema/test-count/feature statements: current Digital Object Core schema is v3, schema v2 migrates deterministically, rules support bounded same-subject conjunctions, evidence kinds are explicit, persistence retains a verified `.bak`, and the focused suite now contains 18 tests. See `SYNORA_WAR_V7_STAGE1_ENGINEERING_REPORT.md` for the current audit and exact results.
