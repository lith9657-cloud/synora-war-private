# Final package structure

- `synora-v5/digital-object-core/` — digital-object fact/rule/persistence engine and adapter.
- `synora-v5/pst/` — CRI reference engine, tasks, grader, operators, and sandbox worker.
- `synora-v5/phase4/` — Adaptive V2 experimental engine.
- `tests/` — historical suites plus Digital Object Core and Stage 2 experiment tests.
- `scripts/stage2/` — reproducible Stage 2 runner and worker.
- `experiments/stage2/` — task definitions, answer key, configuration, seeds, exact raw/detailed results, paired ablation, logs, and preserved excluded runs.
- `audit/` — package manifest and historical integrity snapshots.
- `SYNORA_WAR_V7_FINAL_AUDIT.md` — final audit and release decision.
- `SYNORA_WAR_V7_RUNBOOK.md` — installation, testing, experiment reproduction, and persistence instructions.
- `SYNORA_WAR_V7_EXPERIMENT_RESULTS.csv` / `.json` — standalone copies of the released detailed CSV and raw JSON results.
- `SYNORA_WAR_V7_SHA256.txt` — checksum sidecar explanation and source archive hashes.
