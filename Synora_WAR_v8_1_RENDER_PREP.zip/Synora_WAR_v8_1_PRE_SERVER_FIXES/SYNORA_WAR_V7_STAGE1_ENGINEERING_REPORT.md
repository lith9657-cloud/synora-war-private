# Synora WAR V7 — Stage 1 Engineering Report

Date: 2026-10-26  
Status: engineering hardening; not a scientific superiority evaluation.

## 1. Source provenance and protection

The working source was the actual file `Synora_WAR_v6_DIGITAL_OBJECT_CORE_FINAL.zip` available in the work environment. Its SHA-256 was independently computed as:

`074430b7313e111a913b959d7f7fe7d87338532075e54c521f3f19779ef966a9`

The ZIP passed `ZipFile.testzip()` and contained 619 entries. This matches the previously declared digest exactly. An unmodified copy was retained outside the development tree at `source/Synora_WAR_v6_DIGITAL_OBJECT_CORE_FINAL.original.zip`; all edits were made in a separate extracted working tree.

Other available archives were not silently treated as identical: `Synora_WAR_FINAL.zip` has SHA-256 `5e503125a291a08320b5012e7f901b092c915c9977d407a00783750b5e02f5b6` and 583 entries, while `Synora_WAR_v6_DIGITAL_OBJECT_CORE.zip` has SHA-256 `be39c18b76b524207f0dd1a39f810a623ae3442bc307771ecc212b69b259c18e`. They are different archives. The Stage 1 work therefore uses the exact-hash V6 FINAL source, not either repacked variant.

## 2. Files changed

- `synora-v5/digital-object-core/index.mjs` — event idempotency, source kinds, bounded conjunctive inference, contradiction handling, schema v3 migration, backup/lock-safe persistence, and validation.
- `synora-v5/digital-object-core/synora-adapter.mjs` — preserve engine results if object-core recording fails; expose explicit failure and retryability.
- `tests/digital-object-core.test.mjs` — expanded focused suite from 11 to 18 tests.
- `synora-v5/digital-object-core/README.md` and `ENGINEERING-REPORT.md` — current semantics and limits.
- root `README.md` — current API and verification pointer.
- `docs/CHANGE-LOG.md` — stage 1 change rationale and regression evidence.
- `DIGITAL_OBJECT_CORE_DELIVERY_REPORT.md` and `DIGITAL_OBJECT_CORE_FINAL_AUDIT.md` — retained as historical V6 records, explicitly marked as superseded for current schema/test counts.
- `audit/package-manifest.json` — regenerated package inventory and hashes.
- `SYNORA_WAR_V7_STAGE1_ENGINEERING_REPORT.md` — this stage report.

No source files implementing the CRI/PST search engine, Adaptive V2 policy, Adaptive Legacy, or their existing memory formats were changed.

## 3. Defects reproduced and repairs

1. **Semantic duplicate fact events were not recorded.** A new event ID for a semantically identical fact returned a no-op without reserving the event ID, allowing later reuse of that ID with a different payload. The no-op now commits an event record, so changed-payload reuse is rejected.
2. **Removal selectors could collide.** An omitted object selector (wildcard) and explicit `object: null` serialized identically. The event request now records whether the object selector was supplied.
3. **Predicates were implicitly treated as single-valued.** This incorrectly blocked valid multi-valued relations such as `is-a human` and `is-a mortal`. Predicates are multi-valued by default; only configured `functionalPredicates` are single-valued. Source contradictions on configured functional predicates block inference. Derived conflicts remove the conflicting derived alternatives and dependent descendants from the returned closure.
4. **Rules only supported one premise.** Rules now accept a bounded conjunction of premise patterns for the same subject. Every derived fact records all premise IDs. The rule language remains deliberately limited and is not general first-order logic.
5. **Evidence classes were implicit.** Source facts now distinguish `direct`, `retrieved`, and `hypothesis`; hypotheses are reported separately and do not serve as premises. Inferred facts are explicitly marked `kind: inference`. Rejected/contested records remain distinct and conflicts are surfaced rather than silently selecting a winner.
6. **Schema evolution was absent.** The persistence schema is now v3. Valid v2 snapshots are checksum-verified before a deterministic migration; fact kinds and legacy event requests are normalized. Unsupported schema versions are rejected.
7. **Backup and writer contention were under-protected.** Saving now uses an exclusive lock, temporary file, fsync and atomic rename; the prior verified target is retained as `.bak`. A corrupt/incompatible target is not rotated over the backup. A concurrent save is refused. Clearly stale locks are reclaimed conservatively.
8. **Adapter errors could discard a completed engine result.** The wrapper now returns the original result with `digitalObjectRecording.ok=false` and an explicit error. Non-conflict failures are retryable through `recordTaskResult`; event-ID conflicts are surfaced as non-retryable without changing the engine's result or search policy.

## 4. Actual tests

Runtime: Node.js `v22.16.0`; package declares Node.js `>=20`.

Baseline before edits: `npm test` exited 0. Original suite counts were 11, 15, 19, 20, 32, 16, 4, 6, 23, and 11 focused Digital Object Core tests: **157 checks/subtests, 0 failures**.

After edits, the final full command is `npm test`, which runs all original suites and the focused object-core suite. Expected final count from the suite summaries is **164 checks/subtests, 0 failures**; the final post-extraction run recorded below is authoritative.

Focused tests cover: object identity and property validation; relation references; duplicate and conflicting event IDs across operation types; failed operations with no partial success events; explicit removal selectors; chained inference and retraction; rejected/contested evidence; multi-valued and configured functional predicates; conflicting derived conclusions and descendant pruning; hypothesis/retrieved evidence; conjunctive rules and proof lineage; cycles and inference limits; schema v2 migration; corrupt/tampered/truncated data; backups and lock contention; process-separated save/restore; replay deduplication after restart; real PstEngine and AdaptivePstEngine integration; adapter failure and retry.

## 5. Persistence and independent process tests

The focused suite starts a child Node.js process to create and save a store, then a separate Node.js process loads it and reconstructs inference. It checks objects, relations, facts, rules, evidence, event history, experience counters, and duplicate replay. It also checks a deterministic v2 migration, malformed/truncated JSON, checksum tampering, unsupported schema, failed replacement, a verified `.bak`, refusal to overwrite a corrupt current snapshot, and writer-lock contention.

SHA-256 is an integrity checksum, not authentication: an actor who can rewrite both payload and digest can forge a matching envelope.

## 6. CRI and Adaptive V2 integration

The opt-in `DigitalObjectSynoraAdapter` is exercised against actual `PstEngine` and `AdaptivePstEngine` instances through their public `runTask(task)` boundary. It records a result fact and allows idempotent re-recording. A simulated recording failure preserves the completed engine result and can be retried. CRI remains the reference baseline; Adaptive V2 remains experimental. No object-core inference is fed back into search, scoring, or either engine's memory format. This is tested one-way integration, not full cognitive integration.

## 7. Remaining limitations

- The inference engine is a bounded symbolic pattern matcher with same-subject conjunctions, not a general first-order theorem prover or natural-language reasoner.
- Multi-premise joins are limited by `maxDerivedFacts`; a limit hit throws rather than returning a partial closure as complete.
- No distributed transaction or multi-writer database is implemented. Snapshot writes are lock-protected and atomic for cooperating writers, but this is not a replacement for a transactional database on network filesystems with unreliable lock semantics.
- Adapter integration is opt-in and one-way; search does not consume digital-object knowledge.
- Rule confidence is an observed outcome fraction, not general learning.
- No new superiority/generalization experiment or Llama 2 comparison was run in Stage 1. No intelligence or performance claim is made.

## 8. Reproduction commands

From the extracted project root:

```sh
npm run test:digital-objects
npm test
npm run manifest
```

The final archive was extracted to a new directory and tested from that extracted copy. The exact archive SHA-256 is provided in the adjacent `.sha256` file and in the delivery message. A ZIP cannot contain its own final digest as a literal without changing the ZIP bytes; the sidecar is computed from the final archive itself.

## 9. Final extracted-archive acceptance

The package was created, extracted into a new clean directory, and tested from that extracted copy with `npm test`. The acceptance run exited **0**. Suite results: self-test 11/11; v5 15/15; PST 19/19; Phase 3 20/20; Phase 4 32/32; Adaptive engine 16/16; safe-transfer ledger 4/4; third-domain 6/6; audit 23/23; Digital Object Core 18/18. Total: **164 checks/subtests passed, 0 failed**. The package manifest audit passed, and the archive passed ZIP integrity testing. The final rebuild is re-extracted and re-tested after this report and manifest are frozen.

The exact SHA-256 of the final ZIP is supplied in the adjacent `.sha256` sidecar and the external report. It is intentionally not embedded as a literal in the archive because doing so would change the archive bytes and invalidate the digest.
