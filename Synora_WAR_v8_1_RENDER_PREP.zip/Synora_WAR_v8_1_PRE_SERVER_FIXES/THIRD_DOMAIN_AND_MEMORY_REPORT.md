# Synora WAR v6 — implementation notes

## Added third application domain
`workforce-scheduling` is a standalone workforce scheduling adapter. It assigns workers to shifts only when availability, required skills, and per-worker shift limits permit. Impossible shifts are returned as unfilled rather than silently violating constraints. This is an independent application domain, not a claim that the core engine's internal representation has changed.

## Conservative memory-transfer adapter
`SafeTransferLedger` is an opt-in subclass; the legacy `Ledger` and protected audit files remain unchanged. It records task-level success evidence and task-specific operator misses. For a verified skill to transfer across tasks, it requires evidence from at least two distinct task IDs; a miss for a target task suppresses that skill for that task. This is a conservative policy prototype and should be evaluated experimentally before being made the default.

## Verification
The focused tests in `tests/third-domain.test.mjs` and `tests/safe-transfer-ledger.test.mjs` cover scheduling constraints and the memory adapter API/task-specific miss bookkeeping. The complete legacy suite is run separately; its result is recorded in `V6_TEST_REPORT.txt`.

## Suite summary

Full Node test suite: PASS (exit code 0). Includes 9 test files, with 4 focused checks for the new memory adapter and workforce scheduling domain.
