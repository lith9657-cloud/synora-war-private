# Synora WAR — Adaptive Memory Validation, follow-up

## Scope

This follow-up adds focused policy tests and a matched 250-generation benchmark for budgets 80 and 150. It supplements, rather than overwrites, the earlier 4-seed/80-generation comparison. Seeds: 1, 2, 6, 7; task groups B,C; 18 tasks per seed/arm/budget; all five arms use the same seed/budget/task set. The CRI/adaptive/noise arms restore the corresponding seed's acquisition memory produced with budget=250 and generations=250.

## Matched 250-generation results

| Budget | Base | CRI | Adaptive | Noise | No-transfer |
|---:|---:|---:|---:|---:|---:|
| 80 | 60/72 (83.3%) | 57/72 (79.2%) | 61/72 (84.7%) | 53/72 (73.6%) | 61/72 (84.7%) |
| 150 | 67/72 (93.1%) | 65/72 (90.3%) | 67/72 (93.1%) | 62/72 (86.1%) | 67/72 (93.1%) |

Per-seed rows and task-level raw output are in `experiments/adaptive-250/summary.csv` and `experiments/adaptive-250/raw-40-runs.json`.

## Controlled policy checks

`tests/adaptive-engine.test.mjs` passes 6/6 checks: unique verified hint accepted at low budget; high-budget abstention; abstention after two misses when misses exceed hits; no abstention when hits tie misses; one miss does not disable the hint; unverified hints are ignored.

These are deterministic unit tests of the implemented policy, not a causal proof that it identifies helpful hints in every task. In particular, the current policy uses aggregate task-local `hintHits`/`hintMisses`, not a per-hint confidence estimate. Two misses can be enough to suppress a useful hint even when failures are contextual. A future policy should track evidence by hint key and context, with controlled mixed-context tests.

## Interpretation

At budgets 80 and 150, Adaptive is at or above the base arm in aggregate in this sample and avoids the observed CRI regression. At budget 80, Adaptive = 84.7%, compared with CRI 79.2% and Base 83.3%. At budget 150, Adaptive = Base = 93.1%, while CRI is 90.3%. Noise is lower than Adaptive at both budgets, which is consistent with value hints carrying useful information; it is not by itself proof of causality.

These are descriptive results from four seeds and 18 tasks per seed, not a statistical guarantee. Do not promote Adaptive as universally superior yet. The result supports keeping it as a candidate policy for these tested budgets. Small-budget results from the earlier benchmark remain separate and were not rerun at 250 generations in this follow-up.
