#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fork } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = process.cwd();
const ENGINE = fileURLToPath(import.meta.url);
const TRIBES = ['marketing', 'coding', 'arabic', 'english', 'discussion'];
const MAX_BYTES = 144;
const TIMEOUT_MS = Math.max(50, Number(process.env.SYNORA_TIMEOUT_MS || 500));
const STARTUP_TIMEOUT_MS = 8000;
const ARK_LIMIT = 100;
const GRAVEYARD = path.join(ROOT, 'synora-sleep.jsonl');
const WORKER_FLAG = '--synora-worker';

function atomicWrite(file, data) {
  const dir = path.dirname(file);
  fs.mkdirSync(dir, { recursive: true });
  const tmp = `${file}.${process.pid}.${Math.random().toString(16).slice(2)}.tmp`;
  let fd;
  try {
    fd = fs.openSync(tmp, 'w');
    fs.writeFileSync(fd, data, 'utf8');
    fs.fsyncSync(fd);
    fs.closeSync(fd); fd = undefined;
    fs.renameSync(tmp, file);
  } catch (error) {
    if (fd !== undefined) try { fs.closeSync(fd); } catch {}
    try { fs.unlinkSync(tmp); } catch {}
    throw error;
  }
}
function appendJsonl(file, value) { fs.appendFileSync(file, JSON.stringify(value) + '\n', 'utf8'); }
function rand(n) { return Math.floor(Math.random() * n); }
function pathsFor(tribe) {
  const dir = path.join(ROOT, 'tribes', tribe);
  return { dir, teacher: path.join(dir, 'teacher.js'), teacherBackup: path.join(dir, 'teacher.js.bak'), ark: path.join(dir, `ark_${tribe}.json`), killers: path.join(dir, `killers_${tribe}.jsonl`) };
}
function seedFor(tribe) {
  if (tribe === 'marketing') return 'function solution(a){return {hook:a,pain:a,cta:a}}';
  if (tribe === 'coding') return "function solution(a){return typeof a==='number'?a*2:'error'}";
  if (tribe === 'discussion') return 'function solution(a){return {question:"هدف؟",answer:"مساعدة",next_step:"ابدأ"}}';
  if (tribe === 'arabic') return 'function solution(a){return {text:String(a),language:"ar"}}';
  return 'function solution(a){return {text:String(a),language:"en"}}';
}
function validCode(code) {
  return typeof code === 'string' && Buffer.byteLength(code, 'utf8') <= MAX_BYTES && /^\s*function\s+solution\s*\(/.test(code);
}
function readJsonl(file) {
  if (!fs.existsSync(file)) return [];
  const out = [];
  for (const [index, line] of fs.readFileSync(file, 'utf8').split(/\r?\n/).entries()) {
    if (!line.trim()) continue;
    try { out.push(JSON.parse(line)); }
    catch { throw new Error(`Invalid JSONL at ${file}:${index + 1}`); }
  }
  return out;
}
function readArk(file) {
  if (!fs.existsSync(file)) return [];
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  const list = Array.isArray(data) ? data : data.organisms;
  if (!Array.isArray(list)) throw new Error(`Invalid Ark format: ${file}`);
  return list.map(x => typeof x === 'string' ? { code: x, score: 0, validationScore: 0 } : x)
    .filter(x => validCode(x.code));
}
function randomCode(tribe) {
  const pool = {
    marketing: [seedFor(tribe), 'function solution(a){return {hook:String(a),pain:"مشكلة",cta:"ابدأ"}}'],
    coding: [seedFor(tribe), "function solution(a){return typeof a==='number'?a+1:'error'}", 'function solution(a){return a}'],
    arabic: [seedFor(tribe), 'function solution(a){return {text:"الجواب: "+String(a),language:"ar"}}'],
    english: [seedFor(tribe), 'function solution(a){return {text:"Answer: "+String(a),language:"en"}}'],
    discussion: [seedFor(tribe), 'function solution(a){return {question:"ما هدفك؟",answer:String(a),next_step:"ابدأ"}}']
  }[tribe];
  return pool[rand(pool.length)];
}
function mutateOnce(code) {
  const ops = [
    s => { const i = rand(s.length); const chars = 'abcdefghijklmnopqrstuvwxyz0123456789'; return s.slice(0, i) + chars[rand(chars.length)] + s.slice(i + 1); },
    s => s.replace(/return\s+([^;}]+)(?=[;}])/, (_, expr) => `return ${expr}+"!"`),
    s => s.replace(/return\s+([^;}]+)(?=[;}])/, (_, expr) => `return ${expr}+" جدا"`),
    s => { const m = s.match(/\d+/); return m ? s.slice(0, m.index) + String(Number(m[0]) + 1) + s.slice(m.index + m[0].length) : s; }
  ];
  for (let i = 0; i < 24; i++) {
    const candidate = ops[rand(ops.length)](code);
    if (candidate !== code && validCode(candidate)) return candidate;
  }
  for (let i = 0; i < code.length; i++) {
    for (const c of ['x', 'y', 'z', '1', '2']) {
      const candidate = code.slice(0, i) + c + code.slice(i + 1);
      if (candidate !== code && validCode(candidate)) return candidate;
    }
  }
  return code;
}
function pickWisdom() {
  if (!fs.existsSync(GRAVEYARD)) return [];
  const lines = fs.readFileSync(GRAVEYARD, 'utf8').split(/\r?\n/).filter(line => line && line.includes('error'));
  for (let i = lines.length - 1; i > 0; i--) { const j = rand(i + 1); [lines[i], lines[j]] = [lines[j], lines[i]]; }
  return lines.slice(0, 10).map(line => { try { return JSON.parse(line); } catch { return { error: line }; } });
}
function addWisdomComment(code, wisdom) {
  if (!wisdom.length) return code;
  const w = String(wisdom[rand(wisdom.length)].killer || wisdom[0].error || 'failure').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 10);
  const at = code.indexOf('{') + 1;
  const candidate = code.slice(0, at) + `/*W:${w}*/` + code.slice(at);
  return validCode(candidate) ? candidate : code;
}
function getInput(killer, test) {
  if (test && Object.hasOwn(test, 'input')) return test.input;
  if (Object.hasOwn(killer, 'input')) return killer.input;
  return null;
}
function runStructuralRule(killer, solution) {
  const rule = String(killer.rule || killer.code || '').toLowerCase();
  const result = solution(Object.hasOwn(killer, 'input') ? killer.input : 'Synora');
  const fieldMatch = rule.match(/(?:contain|include|required fields?)[^a-z0-9_]*([a-z0-9_ ,]+)$/i);
  if (fieldMatch) {
    const fields = fieldMatch[1].split(/[\s,]+/).filter(Boolean);
    if (!fields.length) throw new Error('Structural rule has no fields');
    for (const field of fields) if (!result || typeof result !== 'object' || !(field in result)) throw new Error(`Missing required field: ${field}`);
    return;
  }
  if (rule.includes('invalid input') && rule.includes('error')) {
    const bad = solution({ __synora_invalid__: true });
    const errorLike = bad === 'error' || (bad && typeof bad === 'object' && (bad.error || bad.ok === false));
    if (!errorLike) throw new Error('Invalid input did not return an error');
    return;
  }
  throw new Error(`Unsupported structural rule: ${killer.rule || killer.code || '(empty)'}`);
}
function evaluateCandidate({ code, killers }) {
  const failures = [];
  let solution;
  try { solution = Function(`${code}; return solution;`)(); }
  catch (e) { return { trainScore: 0, validationScore: 0, trainTotal: 0, validationTotal: 0, failures: [{ error: String(e), killer: 'load' }], survived: false }; }
  let trainScore = 0, validationScore = 0, trainTotal = 0, validationTotal = 0;
  for (const killer of killers) {
    const isValidation = killer.split === 'validation';
    if (isValidation) validationTotal++; else trainTotal++;
    try {
      if (killer.type === 'js_test' && typeof killer.test === 'string') {
        Function('solution', 'input', killer.test)(solution, killer.input);
      } else if (Array.isArray(killer.tests) && killer.tests.length) {
        for (const test of killer.tests) {
          const actual = solution(getInput(killer, test));
          if (JSON.stringify(actual) !== JSON.stringify(test.expected)) throw new Error(`Expected ${JSON.stringify(test.expected)}, got ${JSON.stringify(actual)}`);
        }
      } else if (killer.type === 'structural' || killer.type === 'structural_rule' || killer.rule) {
        runStructuralRule(killer, solution);
      } else {
        throw new Error('Unsupported killer record schema');
      }
      if (isValidation) validationScore++; else trainScore++;
    } catch (e) {
      failures.push({ error: String(e?.stack || e), killer: killer.name || killer.rule || killer.code || 'unknown', split: isValidation ? 'validation' : 'train' });
    }
  }
  return { trainScore, validationScore, trainTotal, validationTotal, failures, survived: failures.length === 0 };
}
if (process.argv.includes(WORKER_FLAG)) {
  if (process.send) process.send({ type: 'ready' });
  process.on('message', message => {
    try { process.send?.({ type: 'result', result: evaluateCandidate(message) }); }
    catch (e) { process.send?.({ type: 'error', error: String(e) }); }
    finally { process.disconnect?.(); }
  });
} else {
  function runCandidate(code, killers) {
    return new Promise(resolve => {
      const child = fork(ENGINE, [WORKER_FLAG], { stdio: ['ignore', 'ignore', 'ignore', 'ipc'], env: { ...process.env, NODE_OPTIONS: '' } });
      let done = false, ready = false, executionTimer = null, startupTimer = null;
      const finish = result => {
        if (done) return;
        done = true;
        clearTimeout(executionTimer); clearTimeout(startupTimer);
        child.removeAllListeners();
        try { if (child.connected) child.disconnect(); } catch {}
        if (child.exitCode === null && child.signalCode === null) try { child.kill('SIGKILL'); } catch {}
        resolve(result);
      };
      startupTimer = setTimeout(() => finish({ trainScore: 0, validationScore: 0, trainTotal: 0, validationTotal: 0, survived: false, failures: [{ error: `Worker startup timeout after ${STARTUP_TIMEOUT_MS}ms`, killer: 'startup-timeout' }] }), STARTUP_TIMEOUT_MS);
      child.on('message', msg => {
        if (msg?.type === 'ready' && !ready) {
          ready = true; clearTimeout(startupTimer);
          executionTimer = setTimeout(() => finish({ trainScore: 0, validationScore: 0, trainTotal: 0, validationTotal: 0, survived: false, failures: [{ error: `Execution timeout after ${TIMEOUT_MS}ms`, killer: 'timeout' }] }), TIMEOUT_MS);
          try { child.send({ code, killers }); } catch (e) { finish({ trainScore: 0, validationScore: 0, trainTotal: 0, validationTotal: 0, survived: false, failures: [{ error: String(e), killer: 'ipc-send' }] }); }
        } else if (msg?.type === 'result') finish(msg.result);
        else if (msg?.type === 'error') finish({ trainScore: 0, validationScore: 0, trainTotal: 0, validationTotal: 0, survived: false, failures: [{ error: msg.error || 'worker error', killer: 'worker' }] });
      });
      child.once('error', e => finish({ trainScore: 0, validationScore: 0, trainTotal: 0, validationTotal: 0, survived: false, failures: [{ error: String(e), killer: 'fork' }] }));
      child.once('exit', (code, signal) => { if (!done) finish({ trainScore: 0, validationScore: 0, trainTotal: 0, validationTotal: 0, survived: false, failures: [{ error: `Worker exited (${code ?? signal ?? 'unknown'})`, killer: 'worker-exit' }] }); });
    });
  }
  function metric(candidate, key) { return candidate?.[key] ?? 0; }
  function better(candidate, incumbent, validationEnabled) {
    if (!incumbent) return false;
    if (validationEnabled) {
      const c = metric(candidate, 'validationScore') / Math.max(1, metric(candidate, 'validationTotal'));
      const i = metric(incumbent, 'validationScore') / Math.max(1, metric(incumbent, 'validationTotal'));
      if (c < i) return false;
      if (c > i) return metric(candidate, 'trainScore') > metric(incumbent, 'trainScore') || c > i;
    }
    return metric(candidate, 'trainScore') > metric(incumbent, 'trainScore');
  }
  async function main() {
    const args = process.argv.slice(2);
    if (args.includes('--help')) { console.log(`Usage: node synora-evo-farm-v4.mjs --tribe=${TRIBES.join('|')} [--with-teacher] [--once]\nTimeout=${TIMEOUT_MS}ms after worker readiness; max genome=${MAX_BYTES} UTF-8 bytes.`); return; }
    const tribeArg = args.find(x => x.startsWith('--tribe='));
    const tribe = tribeArg ? tribeArg.slice('--tribe='.length) : 'coding';
    if (!TRIBES.includes(tribe)) throw new Error(`Unknown tribe '${tribe}'. Allowed: ${TRIBES.join(', ')}`);
    const p = pathsFor(tribe);
    fs.mkdirSync(p.dir, { recursive: true });
    if (!fs.existsSync(GRAVEYARD)) fs.writeFileSync(GRAVEYARD, '', 'utf8');
    if (!fs.existsSync(p.killers)) fs.writeFileSync(p.killers, '', 'utf8');
    const killers = readJsonl(p.killers);
    const trainCount = killers.filter(k => k.split !== 'validation').length;
    const validationCount = killers.filter(k => k.split === 'validation').length;
    if (killers.length === 0) throw new Error(`No killers found for ${tribe}; refusing to evolve without tests.`);
    const ark = readArk(p.ark);
    const teacherMode = args.includes('--with-teacher');
    let teacherCode = null, wisdom = [], candidates;
    if (teacherMode) {
      teacherCode = fs.existsSync(p.teacher) ? fs.readFileSync(p.teacher, 'utf8').trim() : seedFor(tribe);
      if (!validCode(teacherCode)) throw new Error(`Teacher source invalid or over ${MAX_BYTES} bytes: ${p.teacher}`);
      wisdom = pickWisdom();
      const seen = new Set([teacherCode]);
      const pupils = [];
      for (let i = 0; i < 10; i++) {
        let code = mutateOnce(teacherCode);
        if (wisdom.length) code = addWisdomComment(code, wisdom);
        if (!validCode(code) || seen.has(code)) code = mutateOnce(teacherCode);
        seen.add(code); pupils.push({ code, role: 'pupil' });
      }
      const warriors = ark.filter(x => x.code !== teacherCode).slice(0, 9).map(x => ({ ...x, role: 'warrior' }));
      candidates = [{ code: teacherCode, role: 'teacher' }, ...warriors, ...pupils];
    } else candidates = Array.from({ length: 100 }, () => ({ code: randomCode(tribe), role: 'random' }));

    const evaluated = [];
    for (const candidate of candidates) {
      if (!validCode(candidate.code)) {
        appendJsonl(GRAVEYARD, { tribe, code: candidate.code, error: 'Invalid genome or UTF-8 byte limit exceeded', killer: 'validation', at: new Date().toISOString() });
        continue;
      }
      const result = await runCandidate(candidate.code, killers);
      for (const failure of result.failures || []) appendJsonl(GRAVEYARD, { tribe, code: candidate.code, error: failure.error, killer: failure.killer, split: failure.split, at: new Date().toISOString() });
      evaluated.push({ code: candidate.code, role: candidate.role, ...result, evaluatedAt: new Date().toISOString() });
    }
    const currentTeacher = teacherMode ? evaluated.find(x => x.role === 'teacher') : null;
    const contenders = evaluated.filter(x => x.role === 'pupil' || x.role === 'warrior');
    let nextTeacher = currentTeacher;
    let promoted = false;
    // No validation set means no promotion: the engine must not reward unverified overfitting.
    if (teacherMode && validationCount > 0 && currentTeacher && currentTeacher.trainTotal === trainCount && currentTeacher.validationTotal === validationCount) {
      const viable = contenders.filter(x => x.validationTotal === validationCount && x.trainTotal === trainCount && x.validationScore >= currentTeacher.validationScore && x.trainScore >= currentTeacher.trainScore);
      viable.sort((a, b) => (b.validationScore - a.validationScore) || (b.trainScore - a.trainScore));
      const best = viable[0];
      if (best && (best.validationScore > currentTeacher.validationScore || (best.validationScore === currentTeacher.validationScore && best.trainScore > currentTeacher.trainScore))) {
        nextTeacher = best; promoted = best.code !== currentTeacher.code;
      }
    }
    if (teacherMode && nextTeacher) {
      if (promoted) {
        atomicWrite(p.teacherBackup, currentTeacher.code + '\n');
        ark.unshift({ ...currentTeacher, role: 'warrior' });
      }
      atomicWrite(p.teacher, nextTeacher.code + '\n');
    }
    const archiveCandidates = [...evaluated.filter(x => x.survived), ...ark];
    if (teacherMode && nextTeacher) archiveCandidates.push({ ...nextTeacher, role: 'teacher' });
    const merged = archiveCandidates.filter((x, i, all) => validCode(x.code) && all.findIndex(y => y.code === x.code) === i)
      .sort((a, b) => (b.validationScore ?? -1) - (a.validationScore ?? -1) || (b.trainScore ?? b.score ?? 0) - (a.trainScore ?? a.score ?? 0)).slice(0, ARK_LIMIT);
    atomicWrite(p.ark, JSON.stringify({ tribe, updatedAt: new Date().toISOString(), trainCount, validationCount, organisms: merged }, null, 2) + '\n');
    const report = { tribe, mode: teacherMode ? 'teacher' : 'random', timeoutMs: TIMEOUT_MS, trainTests: trainCount, validationTests: validationCount, evaluated: evaluated.length, survived: evaluated.filter(x => x.survived).length, teacherScore: currentTeacher ? { train: currentTeacher.trainScore, trainTotal: currentTeacher.trainTotal, validation: currentTeacher.validationScore, validationTotal: currentTeacher.validationTotal } : null, teacherPromoted: promoted, ark: merged.length, wisdomRead: wisdom.length };
    console.log(JSON.stringify(report, null, 2));
  }
  main().catch(error => { console.error(error?.stack || error); process.exitCode = 1; });
}
