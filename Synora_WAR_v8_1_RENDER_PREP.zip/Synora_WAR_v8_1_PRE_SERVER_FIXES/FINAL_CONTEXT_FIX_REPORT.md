# Synora WAR v5 CRI — Context-safe hint selection validation

## What changed

`PstEngine.hintFor(key)` no longer returns the first stored skill hint matching a key. It now gathers distinct values from verified skills:

- one distinct value: use it as an advisory hint;
- more than one distinct value: abstain (`null`) rather than choosing by insertion order;
- no verified value: fall back to the engine's normal systematic search.

This is a conservative conflict-handling fix, not a claim of semantic context understanding. The engine currently has no validated context discriminator that can reliably choose among contradictory values, so abstention is safer than arbitrary selection.

## Verification actually completed on this modified tree

| Suite | Result |
|---|---:|
| self-test | 11 passed |
| v5 | 15 passed |
| PST | 19 passed |
| Phase 3 | 20 passed |
| Phase 4, including two new conflict tests | 32 passed |
| package audit | 23 passed |
| **Total** | **120 passed, 0 failed** |

The new regression tests verify that (1) two conflicting verified hints return `null` regardless of insertion order and (2) a single verified hint remains available.

## Reproduction status

A full Phase-4 reproduction was attempted after the change using five seeds and budgets 10, 20, 40, 80, and 150. It did not complete within the available execution window; the process reached seed 2/5 before stopping. Therefore this package does **not** claim new full-study performance numbers for the modified engine. Historical results from the unmodified engine must not be represented as results of this fix.

## Generalization status

The repository contains prior tests for a programming-repair benchmark (Phase 3) and a separate shipment-tariff calculation benchmark (Phase 4). Those are useful evidence across two designed task settings, but they do not establish broad generalization across many independent real-world domains. Additional domain benchmarks must be designed and run before making such a claim.

## Limitations / next evidence needed

1. Complete a full five-seed Phase-4 reproduction on this exact modified package and report paired comparisons with multiple-comparison correction.
2. Run an independent third domain with its own task generator, oracle/grader, held-out cases, and no answer leakage.
3. Compare poisoned-memory, conflict-abstention, and no-memory arms on the same paired cases to measure whether abstention prevents harm without losing useful low-budget gains.

## Interpretation

The code-level order-dependence bug is fixed conservatively and regression-tested. Contextual selection between conflicting rules is **not** implemented; the engine abstains when it cannot justify a choice. Performance of the modified engine is not yet established by a complete rerun, and broad generalization remains unproven.
