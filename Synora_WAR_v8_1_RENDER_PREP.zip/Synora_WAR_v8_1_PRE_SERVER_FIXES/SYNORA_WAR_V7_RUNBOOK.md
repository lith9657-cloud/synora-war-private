# Synora WAR V7 — Runbook

This package is the audited continuation of the Stage 1 engineering archive plus Stage 2 experiment artifacts. It does not change CRI's baseline behavior or promote the digital-object bridge to a default path.

## Requirements

- Node.js 20 or newer (release audit ran on Node.js v22.16.0, Linux x64).
- No third-party npm install is required by the included `package.json` scripts; the project uses Node built-ins and local source modules.
- Run from the extracted `Synora_WAR_v6_FINAL_READY/` project root.

## Run the full test suite

```sh
npm test
```

The full command runs the existing integration/self-tests, V5/PST/Phase 3/Phase 4/adaptive engine/transfer ledger/third-domain/audit suites, the Digital Object Core suite, and the Stage 2 experiment harness tests. Suites are partly overlapping; do not add their counts as if every assertion were an independent scientific observation.

## Focused Digital Object Core tests

```sh
npm run test:digital-objects
```

This includes persistence, schema migration, event replay/deduplication, contradiction handling, retraction, rule proof lineage, and adapter integration against real `PstEngine` / `AdaptivePstEngine` instances.

## Stage 2 experiment harness tests

```sh
node --test tests/stage2-experiment.test.mjs
```

## Re-run Stage 2 experiment

```sh
npm run study:stage2 -- all
```

This writes fresh outputs to `experiments/stage2/` (including `results-raw.json`, `results-detailed.csv`, `paired-ablation.json`, `paired-ablation.csv`, `results-progress.json`, and `failures-and-exclusions.json`). It overwrites the local result files, so preserve or copy the delivered raw files before running if you want to retain the exact released run. Wall time, heap deltas, and some instrumentation counters can vary by host/run; compare success, scores, evaluation counts, and task/seed IDs first. The held-out symbolic set is small and hand-authored; seed repetitions alter insertion order, not the underlying task design.

The answer key is `experiments/stage2/answer-key.json`; the task data provided to the core is `experiments/stage2/benchmark-cases.json`. The runner reads the expected answers only in the evaluator path after inference. Do not copy answer-key values into facts, rules, hints, or engine memory.

## Persistence / restart

The Digital Object Core persistence API and native-memory persistence tests are part of the focused core and Stage 2 suites. The cross-process transfer experiment is run by `npm run study:stage2 -- all`; it saves rules in one Node process and verifies their use in a separate process, with a matched no-rule control.

## Release integrity

- `audit/package-manifest.json` lists each packaged file except itself and stores its size and SHA-256.
- `SYNORA_WAR_V7_SHA256.txt` inside the package explains that the archive's own final digest is provided externally, since embedding a ZIP's own digest in that ZIP changes the bytes and therefore changes the digest.
- The downloadable sidecar `Synora_WAR_v7_DIGITAL_OBJECTS_EVALUATED_FINAL.zip.sha256` is computed from the actual final ZIP bytes.
- To verify the ZIP, run `sha256sum -c Synora_WAR_v7_DIGITAL_OBJECTS_EVALUATED_FINAL.zip.sha256` in the directory containing both files, then extract and run the commands above.
