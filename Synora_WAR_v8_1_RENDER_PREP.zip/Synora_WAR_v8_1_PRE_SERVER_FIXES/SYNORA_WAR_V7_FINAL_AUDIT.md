# Synora WAR V7 — Final Audit and Release Decision

**Audit status:** release package built and independently tested. This is an engineering and evidence audit, not a claim that the Digital Object Core is a general intelligence upgrade.

## 1. Provenance and continuity

The actual source-stage filenames differ slightly from the names in the request:

- Stage 1 archive: `Synora_WAR_v7_ENGINEERING_STAGE1.zip`, SHA-256 `77b78fe2bdc9324e86ef6dcdf9c43cab97e5cbe0e3a7d1859890bf6f43151125`.
- Stage 1 report: `SYNORA_WAR_V7_STAGE1_ENGINEERING_REPORT.md`.
- Stage 2 archive: `Synora_WAR_v7_EXPERIMENT_STAGE2.zip`, SHA-256 `a87a1dcbc310229dd17d8eb3d6d133789b5d9048908f0cb8295b1d6bca32342b`.
- Stage 2 report: `SYNORA_WAR_V7_STAGE2_EXPERIMENT_REPORT.md`.

The Stage 2 report records the Stage 1 archive SHA-256 above as its source. Both stage archive hashes were recomputed from the actual ZIP files. The Digital Object Core engine (`synora-v5/digital-object-core/index.mjs`), adapter (`synora-v5/digital-object-core/synora-adapter.mjs`), CRI PST engine, and Adaptive V2 engine files are byte-identical between the extracted Stage 1 and Stage 2 archives. Stage 2 added the experiment runner, task/config/seed/answer files, results, and tests; `package.json` was updated to include Stage 2 tests.

The Stage 2 case-file hash in the raw result is `033f133f6d2fd106bfb908c14c18abc529c55d6e02956c4569880961b78ba85a`; the answer-key hash is `222ef485601e260483b0114829fdce06f3d0517294c1f5cbbda920cb278e7f36`. These match the actual packaged task and answer-key files.

## 2. Audit defect found and repaired

The first full-suite audit exposed a stale historical immutability check: the Stage 2 test harness `tests/self-test.mjs` had been intentionally refactored to copy only runtime fixtures rather than recursively copying the full experiment archive into each disposable scenario, but older snapshot checks still treated that test harness as an immutable engine file. The same stale snapshot appeared in both `tests/phase4.test.mjs` and `tests/audit.test.mjs`.

Repair: both checks now explicitly exclude only `tests/self-test.mjs` from engine immutability comparisons; all other protected engine and prior-phase files remain checked against the historical snapshots. The change is documented in `docs/CHANGE-LOG.md`. The runtime assertions in the self-test were not removed. The package manifest is regenerated only after all files are finalized.

## 3. Environment and final archive validation

- Runtime: Node.js `v22.16.0`, Linux x64.
- Minimum declared runtime: Node.js 20+.
- Archive integrity: `unzip -t` / ZIP CRC test must pass.
- The final archive is extracted to a fresh directory; all commands below are run from that extracted copy, not the development tree.
- The archive manifest is checked against every packaged file after extraction. The manifest excludes itself because it cannot contain its own digest.
- The final archive's own SHA-256 is in the external sidecar and `SYNORA_WAR_V7_SHA256.txt`; the sidecar is the authoritative digest. An archive cannot contain its own final hash without changing the hash.

## 4. Tests and their interpretation

Final acceptance commands:

```sh
npm test
npm run test:digital-objects
node --test tests/stage2-experiment.test.mjs
npm run study:stage2 -- all
```

`npm test` combines suites that test different layers and partly overlap; its assertion/subtest counts are not independent scientific samples. On the final source tree it exited 0 in 24.50 seconds: self-test 11/11, V5 15/15, PST 19/19, Phase 3 20/20, Phase 4 32/32, Adaptive engine 16/16, safe-transfer ledger 4/4, third-domain 6/6, audit 23/23, Digital Object Core 18/18, Stage 2 harness 8/8. Total: **172 checks/subtests passed, 0 failed**. The focused `npm run test:digital-objects` command passed 18/18, and `node --test tests/stage2-experiment.test.mjs` passed 8/8. The final archive is independently extracted and tested after packaging; the exact commands, exit codes, counts, and any limitations are recorded in external `SYNORA_WAR_V7_FINAL_TEST_LOG.txt`. The Stage 2 experiment runner should report 60 core/control rows, 108 engine rows, 36 paired-ablation rows, and zero runner/runtime exceptions. Engine tasks that return `success: false` remain in the raw data and are not runner exceptions.

The pre-package command output is preserved at `audit/release-validation/prepackage-tests.log`. Final-archive extraction results are captured separately after the ZIP is built; “command ran” is not treated as “all tests passed.”

## 5. Experiment result integrity

The exact Stage 2 result set delivered here is preserved from the Stage 2 archive rather than silently replacing it with audit reproduction data. The report and released raw JSON/CSV correspond to that recorded run. A clean extraction of the final release archive was rerun: it produced 60 core/control rows, 108 engine rows, 36 paired rows, and zero runner exceptions. It matched all checked core answers, engine success/score/evaluation outcomes, and paired success/evaluation outcomes. One CRI core-only row's instrumentation counters (`coreHintCalls` / `coreHintHits`) differed on rerun, despite unchanged task outcomes and evaluation counts; an earlier intermediate worktree run showed the same kind of single-row telemetry variation. This is retained as a limitation: hint-call counts are diagnostic and not an exactly reproducible performance outcome, while the correctness and evaluation-count results were stable in the checked rows. The released run's raw counters are preserved unchanged.

Stage 2's key reported findings remain appropriately narrow:

- Standalone Digital Object Core: 60/60 core/control rows passed in the released synthetic suite, including 36 rows representing 12 held-out task designs repeated over three insertion-order seeds.
- Cross-process learned-rule transfer: 3/3; matched no-rule control abstention: 3/3.
- Changed-fact retraction: 6/6 executions in the released run.
- CRI validation rows: 9/9 successful across cold, native-memory, additive core, and core-only conditions.
- Adaptive V2 validation rows: 3/9 successful across those conditions; failures are retained, not filtered.
- In the additive conditions, the Digital Object Core did not change binary success outcomes and had zero successful hint hits in the released run. The CRI core-only ablation reduced evaluations on one task family, without changing correctness; end-to-end speedup was not demonstrated. Adaptive V2 core-only had zero successful hint hits.

The rerun's instrumentation counters differed slightly for one CRI core-only row, while task outcomes, scores, evaluation counts, and core answers matched. Therefore the exact hint-hit count should not be used as a reproducible standalone claim. This does not support a general performance improvement claim.

## 6. Leakage and split limits

- The task file has no `expected` answer field; the evaluator loads the answer key separately after the core produces its answer.
- Static tests check obvious answer-key leakage, duplicate task IDs, disjoint splits, and required categories. These tests cannot prove the absence of every semantic shortcut.
- The final symbolic test contains 12 hand-authored task designs, repeated under three insertion-order seeds. This is not 36 independent designs, nor a broad representative sample.
- The PST comparison uses three validation task identities per condition. It is descriptive and budget-limited, not a general statistical superiority test.
- CRI and Adaptive V2 are program-repair engines whose actual `runTask(task)` contract is not general symbolic QA; no fake outputs were substituted for those unsupported tasks.
- No claim of equivalence, broad generalization, consciousness, general learning, or superiority to Llama 2 is made.

## 7. Memory and integration status

The Digital Object Core persistence and adapter tests exercise actual `PstEngine` and `AdaptivePstEngine` instances. The adapter is opt-in and one-way: it records engine results in the core but does not feed core inference back into search, ranking, or the engines' native memory. Cross-process symbolic rule transfer was separately tested with a no-rule control. This establishes persistence for the tested rule use cases, not broad autonomous learning.

## 8. Final decision

**Keep CRI as the reference baseline. Keep Adaptive V2 experimental. Keep Digital Object Core as an independently usable symbolic engine and make its integration opt-in for narrowly scoped use cases; do not enable it by default as a general engine improvement.**

This is not a rejection of building for the long term. A long-lived system should ship only the claims its evidence supports. The core demonstrates useful symbolic mechanics and restart persistence, but the current comparison does not establish a repeatable end-to-end gain when added to the existing engines. The package is release-ready as an evaluated build with a clearly stated integration boundary; the scientific performance claim remains unproven.

## 9. Remaining limitations

- Small hand-authored benchmark; limited independent task designs and no formal confidence intervals for the PST comparison.
- Timing and heap deltas are noisy; the repeated run showed one row with varying hint instrumentation counts.
- No distributed multi-writer database or transactional integration between engine state and the Digital Object Core.
- SHA-256 detects accidental corruption but is not authentication against an attacker who can replace both the file and its digest.
- No LLM comparison was performed.

## 10. Operating commands

See `SYNORA_WAR_V7_RUNBOOK.md`. From the extracted project root:

```sh
npm test
npm run test:digital-objects
node --test tests/stage2-experiment.test.mjs
npm run study:stage2 -- all
```

The final archive SHA-256 is supplied in `SYNORA_WAR_V7_SHA256.txt` and the external `.sha256` sidecar.
