/** Explicit capability registry: descriptions are inspectable and tools validate inputs. */
export class ToolRegistry {
  #tools = new Map();
  register({ name, description, inputSchema, execute }) {
    if (typeof name !== 'string' || !/^[a-z][a-z0-9_.-]{1,63}$/.test(name) || typeof description !== 'string' || typeof execute !== 'function') throw new TypeError('invalid tool definition');
    if (this.#tools.has(name)) throw new Error(`tool already registered: ${name}`);
    this.#tools.set(name, { name, description, inputSchema, execute });
  }
  describe() { return [...this.#tools.values()].map(({ name, description, inputSchema }) => ({ name, description, inputSchema })); }
  async call(name, input, { timeoutMs = 1000 } = {}) {
    const tool = this.#tools.get(name);
    if (!tool) return { ok: false, error: { kind: 'unknown-tool', message: `Unknown tool: ${name}` } };
    if (!input || typeof input !== 'object' || Array.isArray(input)) return { ok: false, error: { kind: 'invalid-input', message: 'Tool input must be an object' } };
    let timer;
    try {
      const output = await Promise.race([
        Promise.resolve().then(() => tool.execute(input)),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('tool-timeout')), timeoutMs); })
      ]);
      if (!output || typeof output !== 'object' || output.ok !== true) return { ok: false, error: { kind: 'invalid-tool-result', message: 'Tool returned no validated success result' } };
      return { ok: true, tool: name, output, validated: true };
    } catch (error) {
      return { ok: false, tool: name, error: { kind: error.message === 'tool-timeout' ? 'timeout' : 'execution-failed', message: String(error.message ?? error) } };
    } finally { clearTimeout(timer); }
  }
}

export function createDefaultToolRegistry() {
  const registry = new ToolRegistry();
  registry.register({
    name: 'calculator.basic', description: 'Calculate one finite arithmetic operation.',
    inputSchema: { type: 'object', required: ['left', 'operator', 'right'] },
    execute({ left, operator, right }) {
      if (![left, right].every(Number.isFinite) || !['+', '-', '*', '/'].includes(operator) || (operator === '/' && right === 0)) return { ok: false, error: 'invalid-arithmetic-input' };
      const value = operator === '+' ? left + right : operator === '-' ? left - right : operator === '*' ? left * right : left / right;
      if (!Number.isFinite(value)) return { ok: false, error: 'non-finite-result' };
      return { ok: true, value, expression: `${left} ${operator} ${right}` };
    }
  });
  return registry;
}
