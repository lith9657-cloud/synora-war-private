/**
 * Synora WAR v5 — experiment runner.
 *
 * Runs every arm of the study on the identical benchmark and writes a machine-readable result
 * plus a markdown table. Arms:
 *
 *   v5-full        CRI memory ON.  SET_A and SET_B.
 *   v5-random      same operators, same budget, memory OFF (the ablation that isolates the
 *                  contribution of the memory from the contribution of the operator library).
 *   v5-warm        memory ON, and the ledger learned on SET_A is carried into SET_B
 *                  (the transfer measurement).
 *   v4-baseline    the unmodified v4 engine on the same tasks with the same budget.
 *
 *   node synora-v5/experiments.mjs --seeds=5 --budget=800 --out=experiments/results.json
 */
import fs from 'node:fs';
import path from 'node:path';
import { Judge } from './judge.mjs';
import { Ledger } from './ledger.mjs';
import { Engine } from './engine.mjs';
import { TASKS, bySet } from './tasks.mjs';
import { parseArgs } from './cli.mjs';
import { runBaseline } from './baseline-v4.mjs';

const mean = xs => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);
const median = xs => {
  const s = [...xs].sort((a, b) => a - b);
  return s.length ? s[Math.floor(s.length / 2)] : 0;
};

async function runArm({ mode, tasks, seed, budget, generations, ledger, judge, label, distractors = 0 }) {
  const engine = new Engine({ judge, ledger, mode, seed, budget, generations, distractorCount: distractors });
  const results = [];
  for (const task of tasks) results.push(await engine.runTask(task));
  const success = results.filter(r => r.success).length;
  const evaluations = results.map(r => r.evaluations);
  const witnessViolations = results.reduce((a, r) => a + (r.witnessViolationEvents || 0), 0);
  const totalEvaluations = evaluations.reduce((a, b) => a + b, 0);
  let failureEvents = 0, attributable = 0, attributableRepeats = 0;
  for (const r of results) {
    const seen = new Set();
    for (const event of r.events) {
      if (event.type !== 'failure') continue;
      failureEvents++;
      if (!event.attributable) continue;
      attributable++;
      if (seen.has(event.signature)) attributableRepeats++;
      seen.add(event.signature);
    }
  }
  return {
    label,
    mode,
    seed,
    success,
    tasks: tasks.length,
    successRate: success / tasks.length,
    medianEvaluations: median(evaluations),
    meanEvaluations: mean(evaluations),
    totalEvaluations,
    failureEvents,
    attributableFailures: attributable,
    attributableRepeats,
    recurrenceRate: attributable ? attributableRepeats / attributable : null,
    witnessViolations,
    witnessViolationRate: totalEvaluations ? witnessViolations / totalEvaluations : 0,
    results,
    ledgerSize: { skills: ledger.skills.size, refutations: ledger.refutations.size, witnesses: ledger.witnesses.size },
  };
}

export async function runExperiments(args = {}) {
  const seeds = Number(args.seeds ?? 5);
  const budget = Number(args.budget ?? 800);
  const generations = Number(args.generations ?? 120);
  const distractors = Number(args.distractors ?? 0);
  const setA = bySet('A');
  const setB = bySet('B');

  const judge = new Judge({ size: 2, timeoutMs: 500 });
  await judge.init();

  const arms = { full: [], random: [], warm: [], coldB: [], v4: [] };

  for (let i = 0; i < seeds; i++) {
    const seed = 1000 + i * 7;
    // --- v5 full (memory ON), all tasks, one shared ledger
    arms.full.push(await runArm({
      mode: 'full', tasks: TASKS, seed, budget, generations, ledger: new Ledger(), judge, label: 'v5-full', distractors,
    }));
    // --- v5 random (memory OFF), all tasks
    arms.random.push(await runArm({
      mode: 'random', tasks: TASKS, seed, budget, generations, ledger: new Ledger(), judge, label: 'v5-random', distractors,
    }));
    // --- v5 cold-B: the SAME engine on SET_B with a FRESH ledger (the transfer control)
    arms.coldB.push(await runArm({
      mode: 'full', tasks: setB, seed, budget, generations, ledger: new Ledger(), judge, label: 'v5-cold-B', distractors,
    }));
    // --- v5 warm: learn on SET_A, then run SET_B with the SAME ledger
    const shared = new Ledger();
    await runArm({ mode: 'full', tasks: setA, seed, budget, generations, ledger: shared, judge, label: 'v5-warm-A', distractors });
    arms.warm.push(await runArm({
      mode: 'full', tasks: setB, seed, budget, generations, ledger: shared, judge, label: 'v5-warm-B', distractors,
    }));
    // --- v4 baseline (same tasks, same budget) — expensive, so it may be cached or skipped
    if (i === 0 && !args['skip-v4']) {
      if (args['v4-cache'] && fs.existsSync(args['v4-cache'])) {
        arms.v4.push(JSON.parse(fs.readFileSync(args['v4-cache'], 'utf8')));
      } else {
        const v4 = await runBaseline(TASKS, { budget });
        if (args['v4-cache']) fs.writeFileSync(args['v4-cache'], JSON.stringify(v4, null, 2) + '\n', 'utf8');
        arms.v4.push(v4);
      }
    }
    process.stdout.write(`seed ${seed} done\n`);
  }
  await judge.close();

  const aggregate = arm => ({
    label: arm[0].label,
    runs: arm.length,
    successRate: mean(arm.map(a => a.successRate)),
    successRateStd: Math.sqrt(mean(arm.map(a => (a.successRate - mean(arm.map(b => b.successRate))) ** 2))),
    medianEvaluations: median(arm.map(a => a.medianEvaluations)),
    meanEvaluations: mean(arm.map(a => a.meanEvaluations)),
    recurrenceRate: mean(arm.map(a => (a.recurrenceRate === null ? 0 : a.recurrenceRate))),
    witnessViolationRate: mean(arm.map(a => a.witnessViolationRate)),
    skills: mean(arm.map(a => a.ledgerSize.skills)),
    witnesses: mean(arm.map(a => a.ledgerSize.witnesses)),
  });

  // cold SET_B comparison for the transfer question
  const coldB = arms.random.filter(a => a.label === 'v5-random');
  const perSet = (arm, set) => {
    const rows = arm.flatMap(a => a.results.filter(r => r.set === set));
    if (!rows.length) return null;
    return {
      set,
      tasks: rows.length,
      successRate: mean(rows.map(r => (r.success ? 1 : 0))),
      medianEvaluations: median(rows.map(r => r.evaluations)),
      meanEvaluations: mean(rows.map(r => r.evaluations)),
    };
  };
  const summary = {
    v5_full: aggregate(arms.full),
    v5_full_setA: perSet(arms.full, 'A'),
    v5_full_setB: perSet(arms.full, 'B'),
    v5_random: aggregate(arms.random),
    v5_random_setA: perSet(arms.random, 'A'),
    v5_random_setB: perSet(arms.random, 'B'),
    v5_cold_B: aggregate(arms.coldB),
    v5_cold_B_setB: perSet(arms.coldB, 'B'),
    v5_warm_B: aggregate(arms.warm),
    v5_warm_B_setB: perSet(arms.warm, 'B'),
    v4_baseline: arms.v4[0] ? { label: 'v4-baseline', runs: 1, successRate: arms.v4[0].summary.successRate, medianEvaluations: arms.v4[0].summary.medianEvaluations, meanEvaluations: arms.v4[0].summary.totalEvaluations / TASKS.length, recurrenceRate: null, witnessViolationRate: null, skills: 0, witnesses: 0 } : null,
  };

  const out = {
    generatedAt: new Date().toISOString(),
    config: { seeds, budget, generations, distractors, tasks: TASKS.length, sets: { A: setA.map(t => t.id), B: setB.map(t => t.id) } },
    summary,
    arms: { full: arms.full, random: arms.random, warm: arms.warm, coldB: arms.coldB, v4: arms.v4 },
  };
  if (args.out) {
    fs.mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
    fs.writeFileSync(args.out, JSON.stringify(out, null, 2) + '\n', 'utf8');
    console.log(`wrote ${args.out}`);
  }
  console.log(JSON.stringify(summary, null, 2));
  return out;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  runExperiments(parseArgs(process.argv.slice(2))).catch(error => {
    console.error(error && error.stack || error);
    process.exitCode = 1;
  });
}
