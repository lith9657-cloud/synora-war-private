/**
 * Synora WAR v5 — Benchmark task suite.
 *
 * DESIGN RULES (kept honest on purpose):
 *  - Every task is a real JavaScript repair problem in the SAME artifact format the v4 engine
 *    already uses: a single `function solution(a)` string, judged by "killer" records.
 *    That is what makes the v4 baseline runnable on the identical tasks (apples to apples).
 *  - `buggy` is the seed organism. It MUST fail at least one train killer and one validation killer.
 *  - `reference` is the trusted oracle. It MUST pass every killer. The ENGINE NEVER SEES IT.
 *    It is used by the judge only: (a) to validate that killers are sound, and (b) to build
 *    differential witnesses (inputs where the candidate differs from the oracle).
 *  - `probes` are inputs the engine's BREAKER family may use to search for counterexamples.
 *  - `holdout` are inputs used ONLY by the final evaluation (generalization exam).
 *    They are disjoint from `probes` and never enter the evolution loop.
 *
 * Task sets:
 *  - SET_A = development set (the engine may be tuned on it).
 *  - SET_B = held-out set (never used for tuning; used to measure transfer).
 *
 * PAIRED BUG CLASSES: A1~B1, A2~B2, A3~B3 share a failure signature so that skill transfer
 * is measurable. A4~B4 (string edge cases) is a NEGATIVE CONTROL: similar family, different
 * failure mode, so we can show that transfer is selective rather than universal.
 */

const t = (id, set, bugClass, title, spec, buggy, reference, train, validation, probes, holdout) =>
  ({ id, set, bugClass, title, spec, buggy, reference, train, validation, probes, holdout });

/** helper: a js_test killer in the v4 on-disk format */
const js = (name, input, test, split) => ({ type: 'js_test', name, input, test, split });

export const TASKS = [
  // ---------------------------------------------------------------- SET A
  t('A1_sum_list', 'A', 'off_by_one_loop_bound',
    'Sum all elements of an array',
    'Return the sum of every element of the numeric array a. Empty array sums to 0.',
    'function solution(a){let s=0;for(let i=0;i<a.length-1;i++)s+=a[i];return s}',
    'function solution(a){let s=0;for(let i=0;i<a.length;i++)s+=a[i];return s}',
    [
      js('sum_drops_last', [2, 1], 'const r=solution(input); if(r!==3) throw new Error("Expected 3, got "+r);', 'train'),
      js('sum_empty', [], 'const r=solution(input); if(r!==0) throw new Error("Expected 0, got "+r);', 'train'),
    ],
    [js('sum_two', [5, 5], 'const r=solution(input); if(r!==10) throw new Error("Expected 10, got "+r);', 'validation')],
    [[1, 2, 3], [], [4], [-1, 2]],
    [[7, 3], [0, 0, 1]]),

  t('A2_safe_length', 'A', 'type_guard',
    'Length of a possibly-null collection',
    'Return the length of a. If a is null or undefined return 0.',
    'function solution(a){return a.length}',
    'function solution(a){return a==null?0:a.length}',
    [
      js('null_is_zero', null, 'const r=solution(input); if(r!==0) throw new Error("Expected 0, got "+r);', 'train'),
      js('length_of_array', [1, 2], 'const r=solution(input); if(r!==2) throw new Error("Expected 2, got "+r);', 'train'),
    ],
    [js('undefined_is_zero', undefined, 'const r=solution(input); if(r!==0) throw new Error("Expected 0, got "+r);', 'validation')],
    [[], 'abcd', null, undefined, { a: 1 }],
    [[1, 2, 3], 'xy']),

  t('A3_count_vowels_ar', 'A', 'unicode_feature',
    'Count Arabic and English vowels',
    'Count vowels in the text, including Arabic vowels (ا و ي أ إ آ ؤ ئ) and English vowels.',
    "function solution(a){let n=0;for(const c of String(a))if('aeiouAEIOU'.includes(c))n++;return n}",
    "function solution(a){let n=0;for(const c of String(a))if('aeiouAEIOUاويوأإآؤئ'.includes(c))n++;return n}",
    [
      js('arabic_vowels_counted', 'العربية', 'const r=solution(input); if(r!==2) throw new Error("Expected 2, got "+r);', 'train'),
      js('english_vowels_counted', 'hello', 'const r=solution(input); if(r!==2) throw new Error("Expected 2, got "+r);', 'train'),
    ],
    [js('arabic_sentence', 'كيف حالك', 'const r=solution(input); if(r!==2) throw new Error("Expected 2, got "+r);', 'validation')],
    ['سلام', 'AEIOU', 'مرحبا بكم'],
    ['أهلا', 'xyz', undefined]),

  t('A4_trim_spaces', 'A', 'string_whitespace',
    'Trim surrounding whitespace',
    'Remove leading and trailing whitespace (spaces, tabs, newlines) and return the trimmed text.',
    "function solution(a){return String(a).replace(/^ +| +$/g,'')}",
    "function solution(a){return String(a).replace(/^\\s+|\\s+$/g,'')}",
    [
      js('trims_tabs', '\t hi \t', 'const r=solution(input); if(r!=="hi") throw new Error("Expected \\"hi\\", got "+JSON.stringify(r));', 'train'),
      js('trims_plain', '  ok  ', 'const r=solution(input); if(r!=="ok") throw new Error("Expected \\"ok\\", got "+JSON.stringify(r));', 'train'),
    ],
    [js('trims_newline', '\nmid\n', 'const r=solution(input); if(r!=="mid") throw new Error("Expected \\"mid\\", got "+JSON.stringify(r));', 'validation')],
    [' hi ', '\tx\t', 'plain'],
    ['  done  ', '\tlast\t', null]),

  // ---------------------------------------------------------------- SET B (held out)
  t('B1_count_digits', 'B', 'off_by_one_loop_bound',
    'Count the digits of a number',
    'Count the decimal digits of a. Non-digit characters are ignored.',
    "function solution(a){let s=String(a);let n=0;for(let i=0;i<s.length-1;i++)if(s[i]>='0'&&s[i]<='9')n++;return n}",
    "function solution(a){let s=String(a);let n=0;for(let i=0;i<s.length;i++)if(s[i]>='0'&&s[i]<='9')n++;return n}",
    [
      js('digits_of_1234', 1234, 'const r=solution(input); if(r!==4) throw new Error("Expected 4, got "+r);', 'train'),
      js('no_digits', 'abc', 'const r=solution(input); if(r!==0) throw new Error("Expected 0, got "+r);', 'train'),
    ],
    [js('digits_of_90', 90, 'const r=solution(input); if(r!==2) throw new Error("Expected 2, got "+r);', 'validation')],
    [123, 'a1b2', 0],
    [56789, 'no digits']),

  t('B2_first_char', 'B', 'type_guard',
    'First character of a possibly-null string',
    'Return the first character of the text. If the text is null, undefined or empty return an empty string.',
    'function solution(a){return a[0]}',
    "function solution(a){return a==null||a.length===0?'':a[0]}",
    [
      js('null_is_empty', null, 'const r=solution(input); if(r!=="") throw new Error("Expected \\"\\", got "+JSON.stringify(r));', 'train'),
      js('first_of_abc', 'abc', 'const r=solution(input); if(r!=="a") throw new Error("Expected \\"a\\", got "+JSON.stringify(r));', 'train'),
    ],
    [js('empty_is_empty', '', 'const r=solution(input); if(r!=="") throw new Error("Expected \\"\\", got "+JSON.stringify(r));', 'validation')],
    ['xy', null, '', undefined],
    ['z', 'abc']),

  t('B3_count_vowels_ar_long', 'B', 'unicode_feature',
    'Count vowels in a long Arabic phrase',
    'Count vowels in the text, including Arabic vowels (ا و ي أ إ آ ؤ ئ) and English vowels.',
    "function solution(a){let n=0;for(const c of String(a))if('aeiouAEIOU'.includes(c))n++;return n}",
    "function solution(a){let n=0;for(const c of String(a))if('aeiouAEIOUاويوأإآؤئ'.includes(c))n++;return n}",
    [
      js('phrase_vowels', 'العربية', 'const r=solution(input); if(r!==2) throw new Error("Expected 2, got "+r);', 'train'),
      js('english_still_works', 'hello', 'const r=solution(input); if(r!==2) throw new Error("Expected 2, got "+r);', 'train'),
    ],
    [js('bismillah_vowels', 'بسم الله', 'const r=solution(input); if(r!==1) throw new Error("Expected 1, got "+r);', 'validation')],
    ['أهلا وسهلا', 'xyz'],
    ['مرحبا', 'aeiou']),

  t('B4_slugify', 'B', 'string_normalisation',
    'URL slug from a title',
    'Convert a title to a lowercase ASCII slug: keep letters and digits, replace every other run of characters with a single dash, and never start or end with a dash.',
    "function solution(a){return String(a).toLowerCase().replace(/[^a-z0-9]+/g,'-')}",
    "function solution(a){return String(a).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'')}",
    [
      js('slug_trims_dashes', 'Hello World!', 'const r=solution(input); if(r!=="hello-world") throw new Error("Expected \\"hello-world\\", got "+JSON.stringify(r));', 'train'),
      js('slug_simple', 'Simple Title', 'const r=solution(input); if(r!=="simple-title") throw new Error("Expected \\"simple-title\\", got "+JSON.stringify(r));', 'train'),
    ],
    [js('slug_no_trailing', 'Trailing!', 'const r=solution(input); if(r!=="trailing") throw new Error("Expected \\"trailing\\", got "+JSON.stringify(r));', 'validation')],
    ['A B C', 'One--Two', 'Hello World!'],
    ['Final Answer!', 'No Problem', undefined]),
];

export const TASK_IDS = TASKS.map(x => x.id);
export const byId = id => TASKS.find(x => x.id === id);
export const bySet = set => TASKS.filter(x => x.set === set);
