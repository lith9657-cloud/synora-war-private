import { Ledger } from './ledger.mjs';
/** Conservative cross-task memory adapter. Legacy Ledger behavior remains unchanged. */
export class SafeTransferLedger extends Ledger {
  noteSuccess(args) {
    const key = this.refutationKey(args.signature, args.transformId);
    const before = this.skills.get(key);
    const prior = before?.verifiedTaskIds || (before ? [before.taskId] : []);
    super.noteSuccess(args);
    const skill = this.skills.get(key);
    if (skill) skill.verifiedTaskIds = [...new Set([...prior, args.taskId])];
  }
  noteOperatorMiss(args) {
    super.noteOperatorMiss(args);
    const skill = this.skills.get(this.refutationKey(args.signature, args.transformId));
    if (skill) { skill.taskMisses ||= {}; skill.taskMisses[args.taskId] = (skill.taskMisses[args.taskId] || 0) + 1; }
  }
  rankedOperatorsFor(signature, options = {}) {
    const { taskId } = options;
    return super.rankedOperatorsFor(signature, options).filter(item => {
      if (!taskId) return true;
      const skill = this.skills.get(this.refutationKey(signature, item.transformId));
      // A miss in this target task blocks this operator whether it is currently a skill
      // or was demoted to a hypothesis by the legacy ledger.
      if (skill?.taskMisses?.[taskId] > 0) return false;
      if (!item.verified) return true;
      if (!skill) return false;
      const tasks = skill.verifiedTaskIds || [skill.taskId];
      return skill.taskId === taskId || tasks.length >= 2;
    });
  }
}
