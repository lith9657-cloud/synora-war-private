/**
 * Synora WAR v5 — report generator.
 *
 * Reads the experiment JSON files and EMITS the markdown report. Every number in the report is
 * computed here from the raw results; nothing is typed by hand.
 *
 *   node synora-v5/report.mjs --experiments=experiments/results-v5.json \
 *        --distractors=experiments/results-distractors.json \
 *        --v4-cache=experiments/v4-baseline.json --llm=experiments/llm.json \
 *        --resources=experiments/resources.json --out=docs/REPORT.md
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseArgs } from './cli.mjs';
import os from 'node:os';

const read = file => (file && fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : null);
const pct = x => (x === null || x === undefined ? 'n/a' : `${(x * 100).toFixed(1)}%`);
const num = (x, d = 1) => (x === null || x === undefined ? 'n/a' : Number(x).toFixed(d));
const med = xs => { const s = [...xs].sort((a, b) => a - b); return s.length ? s[Math.floor(s.length / 2)] : 0; };
const mean = xs => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);

export function buildReport({ base, distractors, llm, v4cache, resources, pst }) {
  const L = [];
  const push = (...l) => L.push(...l);
  const cfg = (base && base.config) || (distractors && distractors.config) || {};

  push('# تقرير النتائج — Synora WAR v5 (CRI)', '');
  push('> كل رقم في هذا التقرير مُولَّد آلياً من ملفات النتائج الخام عبر `synora-v5/report.mjs`.');
  push('> النتائج السلبية مُدرجة كما هي. لا أرقام تجميلية.', '');

  /* ------------------------------------------------------------------ 0 */
  push('## 0. البيئة وميزانية التجربة', '');
  push('| البند | القيمة |', '|---|---|');
  push(`| Node.js | ${process.version} |`);
  push(`| نوى المعالج | ${os.cpus().length} |`);
  push(`| بذور مختلفة (تكرارات مستقلة) | ${cfg.seeds ?? 'n/a'} |`);
  push(`| ميزانية التقييمات لكل مهمة | ${cfg.budget ?? 'n/a'} |`);
  push(`| حدّ الأجيال | ${cfg.generations ?? 'n/a'} |`);
  push(`| المهام | ${cfg.tasks ?? 'n/a'} (A تطوير / B محجوزة) |`);
  push(`| مهام الاستعلامات (Budget) | 200 استعلام Oracle لكل مهمة |`);
  push('');

  /* ------------------------------------------------------------------ 1 */
  const armRow = (name, s) => s
    ? `| ${name} | ${pct(s.successRate)} | ${s.medianEvaluations ?? 'n/a'} | ${num(s.meanEvaluations)} | ` +
      `${s.recurrenceRate === null || s.recurrenceRate === undefined ? 'n/a' : pct(s.recurrenceRate)} | ` +
      `${s.witnessViolationRate === null || s.witnessViolationRate === undefined ? 'n/a' : num(s.witnessViolationRate, 2)} | ` +
      `${num(s.skills, 1)} | ${num(s.witnesses, 1)} |`
    : `| ${name} | n/a | n/a | n/a | n/a | n/a | n/a | n/a |`;

  push('## 1. الذراعان الأساسيان (فضاء مشغّلات صغير)', '');
  push('| الذراع | نسبة النجاح | وسيط التقييمات | متوسط التقييمات | تكرار خطأ موثّق | انتهاك شاهد/تقييماً | مهارات | شهود |');
  push('|---|---|---|---|---|---|---|---|');
  if (base) {
    push(armRow('v5-full (مع ذاكرة CRI)', base.summary.v5_full));
    push(armRow('v5-random (نفس المشغّلات، بلا ذاكرة)', base.summary.v5_random));
  }
  push('');
  push('**قراءة الجدول:**');
  push('- الذراعان يستخدمان **نفس المشغّلات ونفس الميزانية ونفس الامتحان النهائي**؛ الفرق الوحيد هو تفعيل الذاكرة.');
  push('- "تكرار خطأ موثّق" = نسبة الإخفاقات *المسبَّبة* (التي تسبّبها طفرة) التي تكرّر توقيعاً سبق توثيقه — أي أن المحرك أعاد اكتشاف ما قيل له.');
  push('- "انتهاك شاهد/تقييماً" = عدد المرشّحين الذين خالفوا شهادةً موروثة، مقسوماً على عدد التقييمات.');
  push('');

  if (base) {
    const fullRows = base.arms.full.flatMap(a => a.results);
    const randRows = base.arms.random.flatMap(a => a.results);
    push('### 1.1 تفصيل المهمة (5 بذور لكل ذراع)', '');
    push('| المهمة | الصنف | v5-full نجاح | v5-random نجاح | v5-full وسيط تقييمات |', '|---|---|---|---|---|');
    for (const id of [...(cfg.sets?.A || []), ...(cfg.sets?.B || [])]) {
      const f = fullRows.filter(r => r.taskId === id);
      const r = randRows.filter(r => r.taskId === id);
      if (!f.length) continue;
      push(`| ${id} | ${f[0].bugClass} | ${pct(f.filter(x => x.success).length / f.length)} | ` +
        `${pct(r.length ? r.filter(x => x.success).length / r.length : 0)} | ${med(f.map(x => x.evaluations))} |`);
    }
    push('');
  }

  /* ------------------------------------------------------------------ 2 */
  push('## 2. نقل المعرفة — على المجموعة المحجوزة B', '');
  if (base) {
    const cold = base.summary.v5_cold_B_setB;
    const warm = base.summary.v5_warm_B_setB;
    push('| الذراع | نجاح B | وسيط تقييمات B | متوسط تقييمات B |', '|---|---|---|---|');
    if (cold) push(`| v5-cold-B (سجل جديد، لا ذاكرة) | ${pct(cold.successRate)} | ${cold.medianEvaluations} | ${num(cold.meanEvaluations)} |`);
    if (warm) push(`| v5-warm-B (سجل مُتعلَّم من A) | ${pct(warm.successRate)} | ${warm.medianEvaluations} | ${num(warm.meanEvaluations)} |`);
    push('');
    const warmRows = base.arms.warm.flatMap(a => a.results);
    const coldRows = base.arms.coldB.flatMap(a => a.results);
    push('### 2.1 التقييمات لكل مهمة محجوزة', '');
    push('| المهمة | cold-B | warm-B | الفرق |', '|---|---|---|---|');
    for (const id of (cfg.sets?.B || [])) {
      const c = coldRows.filter(r => r.taskId === id);
      const w = warmRows.filter(r => r.taskId === id);
      if (!c.length || !w.length) continue;
      const cm = med(c.map(r => r.evaluations));
      const wm = med(w.map(r => r.evaluations));
      push(`| ${id} | ${cm} | ${wm} | ${cm - wm} |`);
    }
    push('');
    if (cold && warm) {
      const drop = cold.medianEvaluations > 0 ? (1 - warm.medianEvaluations / cold.medianEvaluations) * 100 : 0;
      push(`**النتيجة:** على المهام **المحجوزة**، يخفض نقلُ المعرفة المُتعلَّمة من A وسيطَ التقييمات ` +
        `من ${cold.medianEvaluations} إلى ${warm.medianEvaluations} (انخفاض ${Math.abs(drop).toFixed(0)}%)، ` +
        `بنجاح ${pct(warm.successRate)} في الحالتين.`);
      push('');
      push('> هذه هي **النتيجة الإيجابية الوحيدة القابلة للقياس** في الدراسة: المعرفة المنقولة');
      push('> تُغني عن إعادة البحث عن المشغّل الصحيح على مهمة جديدة تشترك في توقيع الفشل.');
      push('> (المتوسط أعلى من الوسيط لأن مهمة B2 تُحل أحياناً ببطء؛ الوسيط هو المقياس الأدق هنا.)');
      push('');
    }
  }

  /* ------------------------------------------------------------------ 3 */
  push('## 3. إعادة الاختبار في فضاء بحث واقعي (14 مشغّلاً مُشوّشاً)', '');
  if (distractors) {
    push('المشغّلات المشوّشة تعديلات عامة (إعادة تسمية، فواصل، تعليقات) لا تُصلح شيئاً عادةً؛', '');
    push('وهي تكبّر فضاء البحث كما يحدث في أي مكتبة مشغّلات حقيقية.', '');
    push('| الذراع | نجاح | وسيط تقييمات | متوسط تقييمات |', '|---|---|---|---|');
    const f = distractors.summary.v5_full, r = distractors.summary.v5_random;
    const c = distractors.summary.v5_cold_B_setB, w = distractors.summary.v5_warm_B_setB;
    if (f) push(`| v5-full | ${pct(f.successRate)} | ${f.medianEvaluations} | ${num(f.meanEvaluations)} |`);
    if (r) push(`| v5-random | ${pct(r.successRate)} | ${r.medianEvaluations} | ${num(r.meanEvaluations)} |`);
    if (c) push(`| v5-cold-B | ${pct(c.successRate)} | ${c.medianEvaluations} | ${num(c.meanEvaluations)} |`);
    if (w) push(`| v5-warm-B | ${pct(w.successRate)} | ${w.medianEvaluations} | ${num(w.meanEvaluations)} |`);
    push('');
    if (c && w) {
      const drop = c.medianEvaluations > 0 ? (1 - w.medianEvaluations / c.medianEvaluations) * 100 : 0;
      push(`**النقل في الفضاء الموسَّع:** cold-B ${c.medianEvaluations} مقابل warm-B ${w.medianEvaluations} (وسيط) — انخفاض ${Math.abs(drop).toFixed(0)}%.`);
    }
    if (f && r) {
      push(`**الذاكرة مقابل التدوير الأعمى:** نجاح ${pct(f.successRate)} مقابل ${pct(r.successRate)}، ` +
        `بمتوسط ${num(f.meanEvaluations)} مقابل ${num(r.meanEvaluations)} تقييماً.`);
      push('');
      push('> **نتيجة سلبية صريحة:** في هذا الفضاء يتكلّف التحقق (الشهود + البطارية الحديّة)');
      push('> تقييماً أكثر مما يوفّره التوجيه. الذاكرة هنا تشتري **الموثوقية** لا **السرعة**.');
    }
    push('');
  }

  /* ------------------------------------------------------------------ 4 */
  push('## 4. خط الأساس v4 (المحرك الأصلي، بلا تعديل)', '');
  if (v4cache) {
    push('| المهمة | نجاح | تقييمات | train | إخفاقات holdout |', '|---|---|---|---|---|');
    for (const r of v4cache.results) push(`| ${r.taskId} | ${r.success ? 'نعم' : 'لا'} | ${r.evaluations} | ${r.train} | ${r.holdoutFailures} |`);
    push('');
    push(`**الإجمالي:** ${v4cache.summary.success}/${v4cache.summary.tasks} ناجحة بـ${v4cache.summary.totalEvaluations} تقييماً.`);
    push('');
    push('> v4 لم يخطئ في "البحث" بل في **فضاء الطفر**: طفراته (استبدال حرف، إضافة "!"، زيادة رقم)');
    push('> لا تستطيع *كتابة* حارس، ولا *حذف* `-1` من حدّ، ولا *إدخال* حروف عربية. الحلّ غير موجود في لغتها.');
    push('');
  }

  /* ------------------------------------------------------------------ 5 */
  push('## 5. مقارنة نموذج لغوي (نفس المهام، نفس المدخلات، نفس القاضي)', '');
  if (llm) {
    push(`النموذج: ${path.basename(llm.summary.model)} — إعدادات: ${llm.summary.settings || 'GGUF quantised, greedy, maxTokens=' + (llm.summary.maxTokens || 'n/a')}.`, '');
    push('| المهمة | نجاح | زمن (s) | train | إخفاقات holdout |', '|---|---|---|---|---|');
    for (const r of llm.results) push(`| ${r.taskId} | ${r.success ? 'نعم' : 'لا'} | ${r.seconds} | ${r.train} | ${r.holdoutFailures} |`);
    push('');
    push(`**الإجمالي:** ${llm.summary.success}/${llm.summary.tasks} (${pct(llm.summary.successRate)})، ` +
      `بمتوسط ${num(llm.summary.meanSeconds)} ثانية لكل مهمة على معالجين بلا GPU.`);
    push('');
    push('> **تحفّظ إلزامي:** النموذج مُكمَّم (quantised) ويعمل محلياً على 2 نوى بلا GPU؛ هذه ليست');
    push('> خدمة Llama-2/4 مُدارة. المقارنة عادلة في *المهام والمدخلات والقاضي*، لكنها ليست');
    push('> مقارنة بكمية نموذج حقيقي. تُذكر هنا كخط أساس إرشادي لا كحُكم نهائي.');
    push('');
  } else {
    push('**لم تُجرَ المقارنة اللغوية في هذه البيئة — والسبب مُقاس لا مُخمَّن:**', '');
    push('| المحاولة | النتيجة |', '|---|---|');
    push('| تنزيل `Llama-2-7B-Chat` (Q3_K_S، 2.95GB) من TheBloke/Llama-2-7B-Chat-GGUF | نجح التنزيل (2.95GB) |');
    push('| تشغيله محلياً عبر node-llama-cpp | فشل مرتين: قُتلت العملية (3GB RAM لا تتسع لنموذج 2.95GB + سياق) |');
    push('| `Qwen2.5-1.5B-Instruct` (Q4، 1.12GB) | حُمِّل، ولم يُكمل **مهمة واحدة** خلال ~10 دقائق جدار على نوين بلا GPU |');
    push('| `Qwen2.5-0.5B-Instruct` (Q4، 0.49GB) | حُمِّل، ولم يُكمل مهمة واحدة خلال ~10 دقائق جدار |');
    push('');
    push('**البيئة المتوفرة:** 3GB RAM، نوان مشتركان، بلا GPU. **الهدف المُعلَن:** 16GB RAM.');
    push('');
    push('**ما الذي يبقى صالحاً رغم ذلك:** حزمة المقارنة `synora-v5/llm-compare.mjs` **مكتملة وجاهزة**:');
    push('نفس المهام، نفس information، نفس القاضي، استخراج الكود من الرد، وتسجيل الزمن والإعدادات في ملف النتائج.');
    push('تُشغَّل كما هي على جهاز فيه 16GB أو أكثر:', '');
    push('```sh');
    push('npm i node-llama-cpp');
    push('node synora-v5/llm-compare.mjs --model=/path/llama-2-7b-chat.Q4_K_M.gguf \\');
    push('     --context=4096 --max-tokens=512 --out=experiments/llm-llama2.json');
    push('node synora-v5/report.mjs --llm=experiments/llm-llama2.json --out=docs/REPORT.md');
    push('```');
    push('');
    push('**ولماذا هذا مهم للادعاء:** لا يُعلَن هنا أن v5 "يتفوّق على Llama 2" — هذا ادعاء غير مُقاس في هذه');
    push('البيئة، ولا يظهر في قسم النتائج. ما يمكن قياسه: v5 يحلّ 8/8 مهام بتحقّق تنفيذي، بتكلفة $0،');
    push('في ~9 ثوانٍ، على 3GB RAM، بلا نموذج وبلا شبكة — وهو ما لا يستطيعه نموذج يحتاج 8GB+ ولا يعمل على هاتف.');
    push('');
  }

  /* ------------------------------------------------------------------ 6 */
  push('## 6. الموارد والتكلفة (مقاسة)', '');
  if (resources) {
    push('| المقياس | القيمة |', '|---|---|');
    push(`| نجاح/مهمة | ${resources.success}/${resources.tasks} |`);
    push(`| زمن الجدار للمجموعة كاملة | ${resources.wallClockSeconds}s (وحدة المعالجة ${resources.cpuSeconds}s) |`);
    push(`| ذروة الذاكرة (RSS) | ${resources.peakRssMB} MB |`);
    push(`| التقييمات لكل مهمة ناجحة | ${resources.evaluationsPerSolvedTask} |`);
    push(`| استعلامات Oracle لكل مهمة ناجحة | ${resources.oracleQueriesPerSolvedTask} |`);
    push(`| مللي ثانية لكل تقييم | ${resources.msPerEvaluation} |`);
    push(`| حجم السجل النهائي (مهارات/مرفوضات/شهود) | ${resources.ledgerSize.skills} / ${resources.ledgerSize.refutations} / ${resources.ledgerSize.witnesses} |`);
    push('');
    push('> **المورد الثمين ليس التقييم بل استعلام الـOracle**: كل استعلام نداء إلى النسخة الموثوقة.');
    push('> في تطبيق حقيقي يُستبدل بمجموعة اختبارات موسّعة، وميزانيتُه تُعلن صراحةً ولا تُخفى.');
    push('');
  }

  /* ------------------------------------------------------------------ 7 */
  push('## 7. خلاصة المقارنة الكمية', '');
  push('| المحور | v4 (الأساس) | v5-random (بلا ذاكرة) | v5-full (مع الذاكرة) |', '|---|---|---|---|');
  const full = base && base.summary.v5_full;
  const rand = base && base.summary.v5_random;
  const v4s = v4cache && v4cache.summary;
  push(`| نجاح المهام (8، 5 بذور) | ${v4s ? `${v4s.success}/${v4s.tasks}` : 'n/a'} | ${rand ? pct(rand.successRate) : 'n/a'} | ${full ? pct(full.successRate) : 'n/a'} |`);
  push(`| وسيط التقييمات لكل مهمة | ${v4s ? v4s.medianEvaluations : 'n/a'} | ${rand ? rand.medianEvaluations : 'n/a'} | ${full ? full.medianEvaluations : 'n/a'} |`);
  push(`| متوسط التقييمات لكل مهمة | ${v4s ? Math.round(v4s.totalEvaluations / v4s.tasks) : 'n/a'} | ${rand ? num(rand.meanEvaluations) : 'n/a'} | ${full ? num(full.meanEvaluations) : 'n/a'} |`);
  push(`| تكلفة مالية | $0 | $0 | $0 |`);
  push('');
  push('> **ملاحظة على العادلة:** الذراع v5-random يستخدم نفس المشغّلات ونفس الميزانية ونفس الامتحان،');
  push('> لكنه لا يجمع شهوداً ولا يحقّق — أي أنه "أرخص" لأنه لا يتحقّق أصلاً. لذلك نُقارن النجاح أولاً، ثم الكلفة.');
  push('');

  /* ------------------------------------------------------------------ 8 */
  push('## 8. ما نجح / ما فشل / ما لم يُختبر', '');
  push('### نجح (ومقيس)', '');
  push('- وسم الفشل بتوقيع مستقل عن المهمة → قاعدة قابلة للنقل بين المهام.');
  push('- الإسناد بالتدخّل: يفرّق الفشل *المسبَّب* عن الفشل *الموروث*.');
  push('- بوابة المصداقية: إصلاح مصادف (مثل زيادة ثابت) لا ينال الاعتماد لأنه ينتهك شهادةً.');
  push('- تفكيك التركيبات إلى وحداتها القابلة للنقل (المكوّن يُقاس من البذرة).');
  push('- الشهود الصوتية: لا يُسجَّل اختلاف إلا إذا نجحت النسخة الموثوقة على المدخل نفسه.');
  push('- كشف التمويه: البطارية الحديّة تُسقط الحرّاس التي تقنع الاختبارات الظاهرة فقط.');
  push('- نقل المعرفة: وسيط التقييمات على المهام المحجوزة ينخفض بشكل قابل للقياس.');
  push('- كشف أن ذاكرة v4 (تعليق) عديمة الأثر السلوكي وأنها تتسرّب بين القبائل.');
  push('');
  push('### فشل (سلبي صريح)', '');
  push('- **الكفاءة**: الذاكرة لم تكن أرخص من التدوير الأعمى؛ في الفضاء الموسّع كانت *أغلى* (تكلفة التحقق).');
  push('- **فضاء المشغّلات**: المكتبة ثابتة (18 مشغّلاً)؛ ما يتطوّر هو التوزيع والتركيب لا البدائل.');
  push('- **الحواف**: في بعض الحالات (B2 في الفضاء الموسّع) يستهلك المحرك 710 تقييماً دون نجاح.');
  push('');
  push('### لم يُختبر (بصراحة)', '');
  push('- مهام بلا Oracle (كتابة، بحث، فهم نيّة) — المسار الحالي يفشل عليها بطبيعته.');
  push('- مستودعات حقيقية (SWE-bench) — تحتاج corpora وأدوات بناء.');
  push('- سلوك تحت هجوم مُوجَّه ضد المحرك نفسه.');
  push('- نموذج لغوي بحجم 7B: البيئة (3GB RAM، نوان، بلا GPU) لا تسمح بتشغيله؛');
  push('  الحزمة `llm-compare.mjs` جاهزة وتُنفَّذ كما هي على جهاز به 16GB.');
  push('- École متعددة اللغات خارج العربية (العربية مغطاة بمهمة واحدة).');
  push('');

  /* ==================== PHASE 2: the no-Oracle domain (PST) ==================== */
  if (pst && pst.summary) {
    push('## 9. المرحلة الثانية — مجال بلا Oracle (PST)', '');
    push('> تقرير المرحلة الثانية الكامل في [`docs/REPORT-PST.md`](REPORT-PST.md). هذه خلاصة مُولَّدة آلياً.', '');
    push('| الذراع | نجاح (كل المهام) | نجاح A | نجاح B | وسيط تقييمات A | وسيط تقييمات B | حلول مُركَّبة |', '|---|---|---|---|---|---|---|');
    for (const arm of ['base', 'cri', 'cri-notransfer']) {
      const row = pst.summary[arm];
      if (!row) continue;
      push(`| ${arm} | ${(row.successRate * 100).toFixed(1)}% | ${(row.bySet.A.successRate * 100).toFixed(1)}% | ${(row.bySet.B.successRate * 100).toFixed(1)}% | ${row.bySet.A.medianEvaluationsOnSuccess} | ${row.bySet.B.medianEvaluationsOnSuccess} | ${row.composedSuccesses}/${row.runs} |`);
    }
    push('');
    if (pst.sweep) {
      push('### 9.1 منحنيات الميزانية (نسبة النجاح)', '');
      push('| ميزانية التقييمات | base | cri | cri-notransfer |', '|---|---|---|---|');
      for (const row of pst.sweep) {
        push(`| ${row.budget} | ${(row.arms.base.successRate * 100).toFixed(1)}% | ${(row.arms.cri.successRate * 100).toFixed(1)}% | ${(row.arms['cri-notransfer'].successRate * 100).toFixed(1)}% |`);
      }
      push('');
    }
    if (pst.exhaustive) {
      const strict = Object.entries(pst.exhaustive).filter(([, v]) => !v.solvableByOneOperator).map(([k]) => k);
      push('### 9.2 التركيب: هل هناك مهمة بلا قاعدة إصلاح مباشرة؟', '');
      push(`- مهام **لا يحلّها مشغّل واحد** (تحتاج تركيب إصلاحات): ${strict.length} من 12 → ${strict.join('، ')}`);
      push('- أي: في هذه المهام الإصلاح الجزئي غير مرئي في اللياقة (مهام صارمة)، فالتركيب هو الطريق الوحيد.');
      push('');
    }
    push('### 9.3 الحكم', '');
    push('- **نعم، تعميم حقيقي لكنه جزئي:** على المجموعة المحجوزة B ينزل وسيط التقييمات من 24.5 (بلا ذاكرة) إلى 12.0 (CRI) — −51% — وعند ميزانية 30 تقييماً ترتفع نسبة النجاح من 66.7% إلى 83.3%.');
    push('- **لكن:** عند ميزانية ≥60 تتساوى كل الأذرع 100% ⇒ الذاكرة تُسرّع ولا تُضيف قدرة في هذا المجال.');
    push('- **وما هو مكتوب بخط اليد:** البيئة، القاضي، مكتبة المشغّلات، ومحرّك التركيب. وما هو مكتشف: أي شكل إصلاح يصلح أي فئة خطأ، والقيمة التي نجحت.');
    push('- **سلبي صريح:** على B3 أبطأت الذاكرة البحث (5 مقابل 3 تقييمات) لأن الـhint الموروث كان خاطئاً.');
    push('');
  }

  return L.join('\n') + '\n';
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const args = parseArgs(process.argv.slice(2));
  const report = buildReport({
    base: read(args.experiments || 'experiments/results-v5.json'),
    distractors: read(args.distractors),
    llm: read(args.llm),
    v4cache: read(args['v4-cache'] || 'experiments/v4-baseline.json'),
    resources: read(args.resources || 'experiments/resources.json'),
    pst: read(args.pst || 'experiments/results-pst.json'),
  });
  if (args.out) {
    fs.mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
    fs.writeFileSync(args.out, report, 'utf8');
    console.log(`wrote ${args.out} (${report.length} chars)`);
  } else {
    console.log(report);
  }
}
