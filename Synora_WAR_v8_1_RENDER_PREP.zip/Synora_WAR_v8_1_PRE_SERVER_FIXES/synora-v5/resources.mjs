/**
 * Synora WAR v5 — resource measurement.
 *
 * Measures, for one full run of the engine over the benchmark: wall-clock, peak RSS of the
 * engine process, oracle queries (the expensive resource: each one costs a reference call), and
 * evaluations per solved task. This is the "cost of evolution vs. what it buys" measurement.
 *
 *   node synora-v5/resources.mjs --budget=800 --out=experiments/resources.json
 */
import fs from 'node:fs';
import path from 'node:path';
import { Judge } from './judge.mjs';
import { Ledger } from './ledger.mjs';
import { Engine } from './engine.mjs';
import { TASKS } from './tasks.mjs';
import { parseArgs } from './cli.mjs';

export async function measureResources(args = {}) {
  const budget = Number(args.budget ?? 800);
  const generations = Number(args.generations ?? 120);
  const mode = args.mode || 'full';
  const distractors = Number(args.distractors ?? 0);

  const judge = new Judge({ size: 2, timeoutMs: 500 });
  await judge.init();
  const ledger = new Ledger();
  const engine = new Engine({ judge, ledger, mode, seed: Number(args.seed ?? 1000), budget, generations, distractorCount: distractors });

  const cpu0 = process.cpuUsage();
  const t0 = Date.now();
  const results = [];
  for (const task of TASKS) results.push(await engine.runTask(task));
  const wallMs = Date.now() - t0;
  const cpu = process.cpuUsage(cpu0);
  await judge.close();

  const success = results.filter(r => r.success).length;
  const evaluations = results.reduce((a, r) => a + r.evaluations, 0);
  const oracleQueries = results.reduce((a, r) => a + r.oracleQueries, 0);
  const out = {
    mode, budget, generations, distractors,
    tasks: TASKS.length,
    success,
    successRate: success / TASKS.length,
    wallClockSeconds: Number((wallMs / 1000).toFixed(2)),
    cpuSeconds: Number(((cpu.user + cpu.system) / 1e6).toFixed(2)),
    peakRssMB: Number((process.memoryUsage().rss / 1048576).toFixed(1)),
    evaluations,
    evaluationsPerSolvedTask: success ? Number((evaluations / success).toFixed(1)) : null,
    oracleQueries,
    oracleQueriesPerSolvedTask: success ? Number((oracleQueries / success).toFixed(1)) : null,
    msPerEvaluation: evaluations ? Number((wallMs / evaluations).toFixed(2)) : null,
    ledgerSize: { skills: ledger.skills.size, refutations: ledger.refutations.size, witnesses: ledger.witnesses.size },
    perTask: results.map(r => ({
      taskId: r.taskId, success: r.success, evaluations: r.evaluations, oracleQueries: r.oracleQueries, seconds: null,
    })),
  };
  if (args.out) {
    fs.mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
    fs.writeFileSync(args.out, JSON.stringify(out, null, 2) + '\n', 'utf8');
    console.log(`wrote ${args.out}`);
  }
  console.log(JSON.stringify(out, null, 2));
  return out;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  measureResources(parseArgs(process.argv.slice(2))).catch(e => { console.error(e && e.stack || e); process.exitCode = 1; });
}
