/**
 * Synora WAR v5 — LLM comparison harness.
 *
 * Runs a local instruction model on EXACTLY the same benchmark, with EXACTLY the same prompt
 * information the v5 engine is allowed to see (the buggy source, the failing train test, the
 * task specification), and scores the answer with the SAME judge (train + validation + the
 * held-out holdout inputs).
 *
 * Fairness rules enforced here:
 *  - one attempt per task, greedy decoding, fixed seed;
 *  - identical prompt content per task for every model;
 *  - identical final exam (same judge, same holdout);
 *  - the model cannot execute anything: no execution feedback is given to it, exactly like the
 *    v5 engine gets no oracle output.
 *
 * The model settings (quantisation, context size, threads, wall-clock) are recorded in the
 * output so the comparison can be judged honestly.
 */
import fs from 'node:fs';
import { Judge } from './judge.mjs';
import { TASKS, byId } from './tasks.mjs';
import { parseArgs } from './cli.mjs';

/** The prompt. Identical for every task and every model. */
export function buildPrompt(task) {
  const failing = task.train.find(k => /if\s*\(/.test(k.test)) || task.train[0];
  return [
    'You repair a single JavaScript function. Reply with ONLY the complete fixed function,',
    'starting with "function solution(a)" and nothing else. No explanation, no markdown.',
    '',
    'TASK SPECIFICATION:',
    task.spec,
    '',
    'CURRENT (BROKEN) CODE:',
    task.buggy,
    '',
    'FAILING TEST (this is the behaviour that must hold):',
    failing.test,
    '',
    'FIXED CODE:',
  ].join('\n');
}

export function extractCode(text) {
  if (!text) return null;
  const fenced = /```(?:javascript|js)?\s*([\s\S]*?)```/.exec(text);
  const body = fenced ? fenced[1] : text;
  const start = body.indexOf('function solution');
  if (start < 0) return null;
  let depth = 0, end = -1;
  for (let i = start; i < body.length; i++) {
    if (body[i] === '{') depth++;
    else if (body[i] === '}') { depth--; if (depth === 0) { end = i + 1; break; } }
  }
  if (end < 0) return null;
  return body.slice(start, end);
}

export async function runLlmComparison(args = {}) {
  const modelPath = args.model || process.env.SYNORA_LLM_MODEL;
  if (!modelPath) throw new Error('Pass --model=<path to a gguf file> or set SYNORA_LLM_MODEL');
  const tasks = args.tasks ? String(args.tasks).split(',').map(s => byId(s.trim())).filter(Boolean) : TASKS;
  const { getLlama, LlamaChatSession } = await import('node-llama-cpp');

  const t0 = Date.now();
  const llama = await getLlama({ logLevel: 'error' });
  const model = await llama.loadModel({ modelPath });
  const context = await model.createContext({ contextSize: Number(args.context || 2048) });
  const session = new LlamaChatSession({ contextSequence: context.getSequence() });

  const judge = new Judge({ size: 2, timeoutMs: 800 });
  await judge.init();

  const results = [];
  for (const task of tasks) {
    const started = Date.now();
    const prompt = buildPrompt(task);
    let raw = '';
    let error = null;
    try {
      raw = await session.prompt(prompt, {
        maxTokens: Number(args['max-tokens'] || 400),
        temperature: 0,
        topP: 1,
        seed: Number(args.seed || 7),
      });
    } catch (e) { error = String(e && e.message || e); }
    const seconds = (Date.now() - started) / 1000;
    const code = extractCode(raw);
    let scored = { passed: 0, total: 0, failures: [] };
    let holdout = [];
    if (code) {
      scored = await judge.runKillers(code, [...task.train, ...task.validation]);
      holdout = await judge.differential(code, task.reference, task.holdout);
    }
    const success = Boolean(code) && scored.passed === scored.total && holdout.length === 0;
    results.push({
      taskId: task.id,
      success,
      seconds: Number(seconds.toFixed(2)),
      extracted: Boolean(code),
      train: `${scored.passed}/${scored.total}`,
      holdoutFailures: holdout.length,
      code,
      raw: String(raw || '').slice(0, 1200),
      error,
    });
    console.log(`${success ? 'PASS' : 'fail'} ${task.id.padEnd(24)} ${seconds.toFixed(1)}s train=${scored.passed}/${scored.total} holdoutFails=${holdout.length} ${code ? code.slice(0, 70) : '(no code extracted)'}`);
  }
  await judge.close();
  await context.dispose();
  await model.dispose();
  await llama.dispose?.();

  const success = results.filter(r => r.success).length;
  const summary = {
    model: modelPath,
    tasks: results.length,
    success,
    successRate: success / results.length,
    meanSeconds: results.reduce((a, r) => a + r.seconds, 0) / results.length,
    totalSeconds: (Date.now() - t0) / 1000,
  };
  const out = { summary, results };
  if (args.out) {
    fs.mkdirSync(args.out.replace(/\/[^/]+$/, ''), { recursive: true });
    fs.writeFileSync(args.out, JSON.stringify(out, null, 2) + '\n', 'utf8');
    console.log(`wrote ${args.out}`);
  }
  console.log(JSON.stringify(summary, null, 2));
  return out;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  runLlmComparison(parseArgs(process.argv.slice(2))).catch(error => {
    console.error(error && error.stack || error);
    process.exitCode = 1;
  });
}
