import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DigitalObjectLearner } from '../digital-object-learning/index.mjs';
import { DigitalObjectCore } from '../digital-object-core/index.mjs';
import { SkillApplicationLedger } from '../digital-object-learning/application-ledger.mjs';
import { inspectSkillInCore, syncAllSkillsToCore, syncSkillToCore } from '../digital-object-learning/bridge.mjs';
import { handleDialogue } from '../dialogue/agent.mjs';
import { listSolutionTemplates } from '../solution-engine/index.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const cryptoRandomId = () => crypto.randomUUID();
const send = (res, status, body) => { const text = JSON.stringify(body); res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(text), 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }); res.end(text); };
async function readBody(req, maxBytes = 64 * 1024) {
  const chunks = []; let total = 0;
  for await (const chunk of req) { total += chunk.length; if (total > maxBytes) throw Object.assign(new Error('request body too large'), { statusCode: 413 }); chunks.push(chunk); }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw Object.assign(new Error('body must be valid JSON'), { statusCode: 400 }); }
}
function loopback(host) { return ['127.0.0.1', '::1', 'localhost'].includes(host); }

export function createSynoraApi({ host = process.env.SYNORA_API_HOST ?? '127.0.0.1', port = Number(process.env.SYNORA_API_PORT ?? process.env.PORT ?? 8787), token = process.env.SYNORA_API_TOKEN ?? '', memoryPath = process.env.SYNORA_LEARNING_MEMORY ?? path.resolve(here, '../../data/digital-object-learning.json'), corePath = process.env.SYNORA_DIGITAL_OBJECT_CORE ?? path.resolve(here, '../../data/digital-object-core.json'), applicationLedgerPath = process.env.SYNORA_SKILL_APPLICATION_LEDGER ?? path.resolve(here, '../../data/digital-skill-applications.json') } = {}) {
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new RangeError('invalid API port');
  if (!loopback(host) && token.length < 24) throw new Error('non-loopback API binding requires SYNORA_API_TOKEN of at least 24 characters');
  fs.mkdirSync(path.dirname(memoryPath), { recursive: true });
  let learner = fs.existsSync(memoryPath) ? DigitalObjectLearner.load(memoryPath) : new DigitalObjectLearner({ id: 'synora-api-learner-v1' });
  const core = fs.existsSync(corePath) ? DigitalObjectCore.load(corePath) : new DigitalObjectCore();
  const applicationLedger = new SkillApplicationLedger({ filePath: applicationLedgerPath });
  const recoverySync = syncAllSkillsToCore(core, learner);
  if (recoverySync.changed) core.save(corePath);
  const hits = new Map();
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, `http://${host}:${port}`);
      // Render's health checker cannot attach a Bearer token. Expose only a minimal
      // liveness response publicly; all detailed API data remains authenticated.
      if (req.method === 'GET' && url.pathname === '/health' && token && req.headers.authorization !== `Bearer ${token}`) {
        return send(res, 200, { ok: true, service: 'synora-api-stage4', apiVersion: '1' });
      }
      if (token && req.headers.authorization !== `Bearer ${token}`) return send(res, 401, { ok: false, error: { code: 'unauthorized', message: 'Bearer token required' } });
      const ip = req.socket.remoteAddress ?? 'unknown', now = Date.now();
      const recent = (hits.get(ip) ?? []).filter(t => now - t < 60_000);
      if (recent.length >= 120) return send(res, 429, { ok: false, error: { code: 'rate_limited', message: 'Maximum 120 requests per minute' } });
      recent.push(now); hits.set(ip, recent);
      if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { ok: true, service: 'synora-api-stage4', apiVersion: '1', learnerId: learner.id, skillCount: learner.skills.size, digitalObjectCount: core.objects.size, templates: listSolutionTemplates(), applicationEvents: applicationLedger.list().length });
      if (req.method === 'GET' && url.pathname === '/v1/skills') return send(res, 200, { ok: true, skills: [...learner.skills.values()].map(s => ({ id: s.id, name: s.name, kind: s.kind, version: s.version, status: s.status, active: s.active, provenance: s.provenance?.source })) });
      if (req.method !== 'POST') return send(res, 405, { ok: false, error: { code: 'method_not_allowed', message: 'Use GET /health, GET /v1/skills, or POST /v1/...' } });
      const body = await readBody(req);
      if (url.pathname === '/v1/chat') {
        if (typeof body.text !== 'string' || !body.text.trim()) return send(res, 400, { ok: false, error: { code: 'invalid_request', message: 'text is required' } });
        if (body.text.length > 16_000) return send(res, 413, { ok: false, error: { code: 'request_too_large', message: 'text exceeds 16000 characters' } });
        if (body.history !== undefined && (!Array.isArray(body.history) || body.history.length > 20 || body.history.some(t => !t || !['user', 'assistant'].includes(t.role) || typeof t.content !== 'string' || t.content.length > 4000))) return send(res, 400, { ok: false, error: { code: 'invalid_history', message: 'history must contain at most 20 user/assistant turns' } });
        if ((body.skillId !== undefined || body.skillInput !== undefined) && (typeof body.skillId !== 'string' || !Object.hasOwn(body, 'skillInput'))) return send(res, 400, { ok: false, error: { code: 'invalid_skill_invocation', message: 'skillId and skillInput must be supplied together' } });
        const result = await handleDialogue(body.text, { history: body.history ?? [], learner, core, skillId: body.skillId ?? null, skillInput: body.skillInput, applicationLedger, eventId: body.eventId ?? req.headers['idempotency-key'] ?? null, source: 'api-chat' });
        return send(res, result.error?.kind === 'idempotency-key-conflict' ? 409 : result.error?.kind === 'application-ledger-persistence-failed' ? 500 : 200, result);
      }
      if (url.pathname === '/v1/skills/learn-affine') {
        const result = learner.learnAffine({ name: body.name, modulus: body.modulus, training: body.training, development: body.development ?? [] });
        learner.save(memoryPath); // preserve accepted and rejected learning evidence
        if (result.accepted) {
          const sync = syncSkillToCore(core, learner, result.skill);
          if (sync.changed) core.save(corePath);
          return send(res, 200, { ok: true, result, digitalObjectRegistration: sync, persistence: { learner: 'saved-and-checksummed', digitalObjectCore: sync.changed ? 'saved-and-checksummed' : 'already-synchronized' } });
        }
        return send(res, 422, { ok: false, result, persistence: 'rejection-event-saved' });
      }
      if (url.pathname === '/v1/skills/apply') {
        if (typeof body.skillId !== 'string' || !Object.hasOwn(body, 'input')) return send(res, 400, { ok: false, error: { code: 'invalid_request', message: 'skillId and input are required' } });
        const skill = learner.skills.get(body.skillId);
        const object = inspectSkillInCore(core, body.skillId);
        const eventId = body.eventId ?? req.headers['idempotency-key'] ?? cryptoRandomId();
        const registrationOk = Boolean(skill && skill.status === 'accepted' && skill.active !== false && object && object.state === 'active' && object.type === 'digital-skill' && object.properties?.skillId === body.skillId && object.properties?.skillStatus === 'accepted');
        if (!registrationOk) {
          const reason = 'skill-not-accepted-active-and-registered-in-digital-object-core';
          const saved = applicationLedger.record({ eventId, skillId: body.skillId, skillVersion: skill?.version ?? null, operation: 'abstain', input: body.input, status: 'abstained', executed: false, executionSuccess: false, reason, result: null, source: 'api-skills-apply' });
          return send(res, 422, { ok: false, error: { code: 'skill_not_registered', message: reason }, application: saved.event });
        }
        const result = learner.apply(body.skillId, body.input);
        const executed = Boolean(result.ok);
        const saved = applicationLedger.record({ eventId, skillId: body.skillId, skillVersion: skill.version, operation: result.ok ? 'apply' : 'abstain', input: body.input, status: result.ok ? 'executed' : 'abstained', executed, executionSuccess: result.ok, reason: result.reason ?? null, result: result.ok ? result.output : null, source: 'api-skills-apply' });
        if (saved.duplicate) return send(res, saved.event.executionSuccess ? 200 : 422, { ok: saved.event.executionSuccess, output: saved.event.result, duplicate: true, application: saved.event, objectiveCorrectness: 'not-assessed' });
        return send(res, result.ok ? 200 : 422, { ...result, application: saved.event, objectiveCorrectness: 'not-assessed' });
      }
      if (url.pathname === '/v1/skills') return send(res, 200, { ok: true, skills: [...learner.skills.values()].map(s => ({ id: s.id, name: s.name, kind: s.kind, version: s.version, status: s.status, active: s.active, provenance: s.provenance?.source })) });
      return send(res, 404, { ok: false, error: { code: 'not_found', message: 'Unknown endpoint' } });
    } catch (error) {
      const status = error.statusCode ?? (/application event ID conflict/.test(String(error.message)) ? 409 : error instanceof TypeError ? 400 : error instanceof RangeError ? 422 : 500);
      return send(res, status, { ok: false, error: { code: status === 400 ? 'bad_request' : status === 413 ? 'payload_too_large' : status === 422 ? 'validation_failed' : 'internal_error', message: String(error.message ?? error) } });
    }
  });
  server.headersTimeout = 10_000;
  server.requestTimeout = 15_000;
  server.keepAliveTimeout = 5_000;
  return { server, host, port, memoryPath, corePath, applicationLedgerPath, applicationLedger, learner, core };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const api = createSynoraApi();
  api.server.listen(api.port, api.host, () => process.stdout.write(`Synora API listening on http://${api.host}:${api.port}\n`));
}
