const response = await fetch('http://127.0.0.1:8787/v1/chat', {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ text: 'Write a JavaScript function to sum an array and test it' })
});
console.log(JSON.stringify(await response.json(), null, 2));
