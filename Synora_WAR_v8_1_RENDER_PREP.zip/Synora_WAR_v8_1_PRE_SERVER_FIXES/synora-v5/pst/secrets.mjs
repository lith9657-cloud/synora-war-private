/**
 * Synora WAR v5 — PST phase: THE ANSWER KEY (grader-private).
 *
 * IMPORTANT: this module is imported ONLY by ./grader.mjs. The engine never imports it, and a
 * test asserts that (see tests/pst.test.mjs). The solver therefore cannot obtain the expected
 * output by any means — there is no differential channel, exactly like a contest problem with
 * hidden tests.
 *
 * A plan is the sequence of tool invocations that a correct solution performs. The grader
 * EXECUTES the plan to obtain the expected value; the solver must produce a program that
 * produces the same value.
 */

export const PLANS = {
  A1_largest_txt_names: { calls: [['listDir'], ['filterByExt', 'txt'], ['sortBy', 'size', 'desc'], ['take', 3], ['joinNames', ', ']] },
  A2_type_counts: { calls: [['listDir'], ['countByExt']] },
  A3_total_txt_size: { calls: [['listDir'], ['filterByExt', 'txt'], ['sumSize']] },
  A4_clean_amount: { calls: [['normalizeSpaces'], ['toArabicDigits']] },
  A5_big_files_count: { calls: [['listDir'], ['filterByMinSize', 100]], field: 'length' },
  A6_names_sorted_asc: { calls: [['listDir'], ['sortBy', 'name', 'asc'], ['joinNames', '-']] },

  B1_largest_csv_names: { calls: [['listDir'], ['filterByExt', 'csv'], ['sortBy', 'size', 'desc'], ['take', 2], ['joinNames', ', ']] },
  B2_md_count: { calls: [['listDir'], ['filterByExt', 'md'], ['countByExt']], field: 'md' },
  B3_total_csv_size: { calls: [['listDir'], ['filterByExt', 'csv'], ['sumSize']] },
  B4_clean_amount_en: { calls: [['normalizeSpaces'], ['toArabicDigits']] },
  B5_min_size_50: { calls: [['listDir'], ['filterByMinSize', 50]], field: 'length' },
  B6_names_sorted_desc: { calls: [['listDir'], ['sortBy', 'size', 'desc'], ['joinNames', '-']] },
};

export const planFor = taskId => PLANS[taskId];
