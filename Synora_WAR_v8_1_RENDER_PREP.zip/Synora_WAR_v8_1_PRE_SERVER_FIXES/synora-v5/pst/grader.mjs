/**
 * Synora WAR v5 — PST phase: the ONE-WAY GRADER.
 *
 * A candidate is submitted, and the grader answers with:
 *   - a score in [0,1] (partial credit),
 *   - the list of VIOLATED CHECKS, expressed as transferable categories
 *     ('missing_tool:take', 'wrong_arg:sortBy:dir', 'wrong_value', 'exception', ...),
 *   - the tool trace and the candidate's own output.
 *
 * What the grader NEVER returns to the solver: the expected value. The expected value is
 * computed here by executing the private plan (./secrets.mjs) and comparing. The solver can
 * therefore never learn "what the right answer is" for an input; it can only learn *which
 * requirement it violated* — exactly like a compiler diagnostic or a failing test name.
 *
 * This is the operational difference from the v5 repair benchmark, where the oracle could be
 * queried differentially (submit an input, learn what the reference does) and that knowledge
 * entered the memory. Here there is no such channel at all.
 */
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Worker } from 'node:worker_threads';
import { makeTools, TOOLS as TOOLS_CONTRACT } from './environment.mjs';
import { planFor } from './secrets.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const WORKER_FILE = path.join(HERE, 'sandbox-worker.mjs');

export class Grader {
  constructor({ timeoutMs = 600, size = 2 } = {}) {
    this.timeoutMs = timeoutMs;
    this.size = size;
    this.workers = [];
    this.idle = [];
    this.queue = [];
    this.nextId = 1;
    this.runs = 0;
    this.timeouts = 0;
  }

  spawn() {
    const worker = new Worker(WORKER_FILE);
    worker.__busy = false;
    return worker;
  }

  async init() {
    for (let i = 0; i < this.size; i++) { const w = this.spawn(); this.workers.push(w); this.idle.push(w); }
  }

  async close() {
    for (const w of this.workers) { try { await w.terminate(); } catch { /* ignore */ } }
    this.workers = []; this.idle = [];
  }

  acquire() {
    if (this.idle.length) return this.idle.pop();
    return new Promise(resolve => this.queue.push(resolve));
  }

  release(worker) {
    const next = this.queue.shift();
    if (next) next(worker); else this.idle.push(worker);
  }

  async run(code, input) {
    const worker = await this.acquire();
    const id = this.nextId++;
    this.runs++;
    return new Promise(resolve => {
      let settled = false;
      const finish = value => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        worker.removeAllListeners('message');
        worker.removeAllListeners('error');
        // a healthy worker is reused; only a timed-out or crashed one is replaced
        if (value && value.__replace) {
          try { worker.terminate(); } catch { /* ignore */ }
          const replacement = this.spawn();
          this.workers[this.workers.indexOf(worker)] = replacement;
          this.release(replacement);
        } else {
          this.release(worker);
        }
        resolve(value);
      };
      const timer = setTimeout(() => { this.timeouts++; finish({ ok: false, error: `timeout after ${this.timeoutMs}ms`, trace: [], __replace: true }); }, this.timeoutMs);
      const onError = err => finish({ ok: false, error: String((err && err.message) || err || 'worker error'), trace: [], __replace: true });
      worker.on('error', onError);
      worker.on('message', message => {
        if (message && message.id === id) finish({ ok: message.ok, value: message.value, error: message.error, trace: message.trace || [] });
      });
      worker.postMessage({ id, code, input });
    });
  }

  /** Compute the expected value by executing the private plan. */
  static expectedValue(task, input = null) {
    if (!task || !task.id) throw new Error('grade(): a task with an id is required');
    const plan = planFor(task.id);
    if (!plan) throw new Error(`unknown task id: ${task.id}`);
    const tools = makeTools(null);
    let value = input;          // the pipeline starts from the task's input
    for (const call of plan.calls) {
      const [name, ...args] = call;
      const contract = (TOOLS_CONTRACT[name] || { args: [] }).args;
      const parts = [...args];
      // thread the previous result into the first slot when that slot consumes the pipeline
      if (contract[0] === 'entries' || contract[0] === 'text') parts.unshift(value);
      value = tools[name](...parts);
    }
    if (plan.field && value && typeof value === 'object') value = value[plan.field];
    return value;
  }

  /**
   * Grade a candidate. Returns BOTH the solver-visible view and the private view.
   * The solver-visible view deliberately contains no expected value.
   */
  async grade(code, task, input) {
    const expected = Grader.expectedValue(task, input);
    const plan = planFor(task.id);
    const run = await this.run(code, input);
    const trace = run.trace || [];

    const violations = [];
    const satisfied = [];

    // 1. terminates
    if (!run.ok) violations.push('exception');
    else satisfied.push('terminates');

    // 2. no direct filesystem access (the tools are the only way in)
    if (/require\s*\(|\bprocess\b|\bimport\s+|globalThis/.test(code)) violations.push('forbidden_io');
    else satisfied.push('no_forbidden_io');

    // 3. tool-call budget
    if (trace.length > task.maxCalls) violations.push('budget_exceeded');
    else satisfied.push('budget');

    // 4/5. required tools called, with the required arguments
    // Partial credit PER ARGUMENT: a call that is half right must score better than a call
    // that is entirely wrong, otherwise a hill-climb cannot see progress and the engine
    // cannot discover which slot it already repaired.
    let toolScore = 0;
    for (const tool of task.required) {
      const calls = trace.filter(c => c.tool === tool);
      const contract = (TOOLS_CONTRACT[tool] || { args: [] }).args;
      const wanted = (plan.calls.find(c => c[0] === tool) || []).slice(1);
      if (!calls.length) { violations.push(`missing_tool:${tool}`); continue; }
      if (!wanted.length) { toolScore += 1; satisfied.push(`tool:${tool}`); continue; }
      const offset = (contract[0] === 'entries' || contract[0] === 'text') ? 1 : 0;
      const slot = new Map();
      wanted.forEach((value, index) => { slot.set(contract[offset + index] || `arg${index}`, value); });
      let best = 0;
      for (const call of calls) {
        let hits = 0;
        for (const [param, value] of slot.entries()) {
          const index = contract.indexOf(param);
          if (index < 0) continue;
          if (call.args[index] === value) hits++;
        }
        if (hits > best) best = hits;
      }
      toolScore += best / slot.size;
      if (best === slot.size) { satisfied.push(`tool:${tool}`); continue; }
      // report EVERY wrong slot of this call, not only the first one: the solver must be able
      // to see all the defects it has to repair (and to compose them)
      for (const [param, value] of slot.entries()) {
        const index = contract.indexOf(param);
        if (index < 0) continue;
        if (!calls.some(call => call.args[index] === value)) violations.push(`wrong_arg:${tool}:${param}`);
      }
    }

    // 6. output type
    const typeOk = run.ok && typeMatches(run.value, task.valueType);
    if (typeOk) satisfied.push('output_type'); else violations.push('wrong_output_type');

    // 7. the value itself (hidden)
    const valueOk = run.ok && deepEqual(run.value, expected);
    if (valueOk) satisfied.push('output_value'); else violations.push('wrong_value');

    const weights = { terminates: 1, no_forbidden_io: 1, budget: 1, output_type: 1, output_value: 5 };
    let score = toolScore;
    let max = task.required.length;
    for (const key of satisfied) {
      if (key.startsWith('tool:')) continue;
      score += weights[key] ?? 1;
    }
    for (const key of ['terminates', 'no_forbidden_io', 'budget', 'output_type', 'output_value']) max += weights[key];

    // STRICT tasks are graded like a hidden test suite: the score is the VALUE, nothing else.
    // A partial repair is invisible in the fitness, so a hill-climb cannot find the goal —
    // only a COMPOSED repair (several coordinated fixes at once) can.
    if (task.strict) {
      // STRICT = all-or-nothing: every required tool, every required argument AND the value
      // must be right. A partial repair is worth nothing, so a hill-climb is blind here and
      // only a COMPOSED repair can reach the goal.
      const strictMax = 1;
      score = violations.length === 0 ? strictMax : 0;
      max = strictMax;
    }

    return {
      // solver-visible view (no expected value)
      public: { score: max ? score / max : 0, scoreRaw: score, max, violations, satisfied, trace, output: run.value, error: run.error || null },
      // private view (grader/report only)
      private: { expected, full: score === max },
    };
  }
}

function typeMatches(value, type) {
  if (type === 'string') return typeof value === 'string';
  if (type === 'number') return typeof value === 'number';
  if (type === 'object') return value !== null && typeof value === 'object';
  return true;
}

function deepEqual(a, b) {
  if (a === b) return true;
  if (typeof a !== typeof b) return false;
  if (a === null || b === null) return false;
  if (typeof a !== 'object') return false;
  const ka = Object.keys(a), kb = Object.keys(b);
  if (ka.length !== kb.length) return false;
  return ka.every(k => deepEqual(a[k], b[k]));
}
