/**
 * Synora WAR v5 — PST phase: how far does the OLD library get?
 *
 * The v5 repair library (18 expression-level operators: guards, literal nudges, loop bounds...)
 * was built for a different domain. Before claiming that a NEW operator library was necessary,
 * the old one is measured on the PST domain with the same protocol used for the new library:
 * apply every operator to every seed, grade the result, and report the best score.
 *
 * Run: node synora-v5/pst/old-library-check.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { TRANSFORMS, applyTransform } from '../genome.mjs';
import { Grader } from './grader.mjs';
import { TASKS, taskInput } from './tasks.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));

async function main() {
  const grader = new Grader({ size: 2, timeoutMs: 700 });
  await grader.init();
  const ctx = { signature: 'mismatch', expected: null, expectedFromSource: null, message: '' };
  const out = {};
  for (const task of TASKS) {
    const input = taskInput(task);
    const seedGrade = await grader.grade(task.seed, task, input);
    let best = seedGrade.public.score;
    let bestTransform = null;
    const applicable = [];
    for (const transform of TRANSFORMS) {
      const code = applyTransform(transform.id, task.seed, ctx);
      if (!code) continue;
      applicable.push(transform.id);
      const grade = await grader.grade(code, task, input);
      if (grade.public.score > best) { best = grade.public.score; bestTransform = transform.id; }
    }
    out[task.id] = {
      seedScore: Number(seedGrade.public.score.toFixed(3)),
      applicableTransforms: applicable,
      bestScore: Number(best.toFixed(3)),
      bestTransform,
      solved: best >= 1,
    };
  }
  // A FAIRNESS PROBE: can the old library solve the tasks with a blind SEQUENCE of operators?
  // (the "no aiming ability" argument must be measured, not asserted)
  const walkSteps = 400;
  for (const task of TASKS) {
    const input = taskInput(task);
    let code = task.seed;
    let best = out[task.id].bestScore;
    let bestCode = null;
    let seedState = 987654321 + task.id.length * 7919;
    const rnd = () => { seedState = (seedState * 1103515245 + 12345) & 0x7fffffff; return seedState / 0x7fffffff; };
    for (let step = 0; step < walkSteps; step++) {
      const applicable = TRANSFORMS.map(t => applyTransform(t.id, code, ctx)).filter(Boolean);
      if (!applicable.length) break;
      const next = applicable[Math.floor(rnd() * applicable.length) % applicable.length];
      if (!next || next === code) continue;
      code = next;
      const grade = await grader.grade(code, task, input);
      if (grade.public.score > best) { best = grade.public.score; bestCode = code; }
      if (best >= 1) break;
    }
    out[task.id].blindWalkBest = Number(best.toFixed(3));
    out[task.id].blindWalkSolved = best >= 1;
    out[task.id].blindWalkSteps = walkSteps;
    out[task.id].blindWalkCode = bestCode;
  }

  await grader.close();
  const solved = Object.values(out).filter(r => r.solved).length;
  const walkSolved = Object.values(out).filter(r => r.blindWalkSolved).length;
  const payload = {
    generatedAt: new Date().toISOString(),
    transformCount: TRANSFORMS.length,
    tasks: Object.keys(out).length,
    solvedWithOldLibrary: solved,
    blindWalkSteps: walkSteps,
    solvedWithOldLibraryBlindWalk: walkSolved,
    perTask: out,
  };
  const file = path.join(HERE, '..', '..', 'experiments', 'pst-old-library.json');
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(payload, null, 2));
  console.log(`old library: ${solved}/${Object.keys(out).length} PST tasks solvable with ONE old operator`);
  console.log(`old library blind walk (${walkSteps} random applications/task): ${walkSolved}/${Object.keys(out).length} solved`);
  for (const [id, row] of Object.entries(out)) {
    console.log(`  ${id.padEnd(24)} seed=${row.seedScore} best1op=${row.bestScore} blindWalk=${row.blindWalkBest} applicable=${row.applicableTransforms.length}/${TRANSFORMS.length}`);
  }
  console.log(`-> ${file}`);
}

main().catch(err => { console.error(err); process.exit(1); });
