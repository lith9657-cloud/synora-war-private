/**
 * Synora WAR v5 — PST phase: the tool environment.
 *
 * A tiny, fully deterministic "computer" the organisms can program:
 * a fixed workspace of files, two text buffers, and ten tools with explicit argument slots.
 * Nothing here is hidden from the solver — the workspace and the tool contracts are PUBLIC.
 * What is hidden is only the *expected output* of a task (see ./secrets.mjs, which only the
 * grader may import).
 */

/** PUBLIC workspace. */
export const WORKSPACE = [
  { name: 'notes.txt', size: 120, ext: 'txt' },
  { name: 'report.txt', size: 340, ext: 'txt' },
  { name: 'data.csv', size: 90, ext: 'csv' },
  { name: 'big.txt', size: 210, ext: 'txt' },
  { name: 'readme.md', size: 45, ext: 'md' },
  { name: 'summary.txt', size: 95, ext: 'txt' },
  { name: 'log.csv', size: 150, ext: 'csv' },
];

/** PUBLIC text buffers (addressed by key). */
export const TEXTS = {
  greeting: '  مرحبا   بكم  ',
  amount: 'العدد  450 ريال',
};

/**
 * Tool contracts. `args` names the argument slots in order, so an operator can address
 * "the third argument of sortBy" without parsing the source.
 */
export const TOOLS = {
  listDir: { args: [], ret: 'entries' },
  filterByExt: { args: ['entries', 'ext'], ret: 'entries' },
  filterByMinSize: { args: ['entries', 'min'], ret: 'entries' },
  sortBy: { args: ['entries', 'key', 'dir'], ret: 'entries' },
  take: { args: ['entries', 'n'], ret: 'entries' },
  joinNames: { args: ['entries', 'sep'], ret: 'string' },
  countByExt: { args: ['entries'], ret: 'object' },
  sumSize: { args: ['entries'], ret: 'number' },
  normalizeSpaces: { args: ['text'], ret: 'string' },
  toArabicDigits: { args: ['text'], ret: 'string' },
};

/** Implementations, bound inside the sandbox worker. */
export function makeTools(trace) {
  const t = (name, fn) => (...args) => {
    if (trace) trace.push({ tool: name, args: args.map(a => (typeof a === 'object' ? JSON.parse(JSON.stringify(a)) : a)) });
    return fn(...args);
  };
  return {
    listDir: t('listDir', () => WORKSPACE.map(e => ({ ...e }))),
    filterByExt: t('filterByExt', (entries, ext) => (entries || []).filter(e => e.ext === ext)),
    filterByMinSize: t('filterByMinSize', (entries, min) => (entries || []).filter(e => e.size >= min)),
    sortBy: t('sortBy', (entries, key, dir) => {
      const list = [...(entries || [])];
      list.sort((x, y) => {
        const a = x[key], b = y[key];
        const cmp = a < b ? -1 : a > b ? 1 : 0;
        return dir === 'desc' ? -cmp : cmp;
      });
      return list;
    }),
    take: t('take', (entries, n) => (entries || []).slice(0, n)),
    joinNames: t('joinNames', (entries, sep) => (entries || []).map(e => e.name).join(sep)),
    countByExt: t('countByExt', (entries) => {
      const out = {};
      for (const e of entries || []) out[e.ext] = (out[e.ext] || 0) + 1;
      return out;
    }),
    sumSize: t('sumSize', (entries) => (entries || []).reduce((a, e) => a + e.size, 0)),
    normalizeSpaces: t('normalizeSpaces', (text) => String(text).replace(/\s+/g, ' ').trim()),
    toArabicDigits: t('toArabicDigits', (text) => String(text).replace(/[0-9]/g, d => '٠١٢٣٤٥٦٧٨٩'[Number(d)])),
  };
}

/** Values a solver may legitimately put into an argument slot (PUBLIC parameter pool). */
export const VALUE_POOL = ['txt', 'csv', 'md', 2, 3, 1, 100, 50, 1000, 'desc', 'asc', 'name', 'size', ', ', '-', '، '];

export const TOOL_NAMES = Object.keys(TOOLS);
