/**
 * Synora WAR v5 — PST phase: the experiment.
 *
 * Three arms, one fixed budget, several seeds, one held-out set:
 *   A0 base            — no memory at all (the ablation)
 *   A1 cri             — the CRI ledger, shared across tasks (cross-task inheritance)
 *   A2 cri-notransfer  — the same engine, but the ledger is reset before every task
 *                        (within-task learning only)
 *
 * Tasks are always executed in the same order: set A (development) then set B (held out).
 * Set B is never seen during development, and no memory of set A is allowed to contain any
 * answer of set B — the ledger stores operator shapes keyed by grader categories only.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Ledger } from '../ledger.mjs';
import { Grader } from './grader.mjs';
import { PstEngine } from './engine.mjs';
import { TASKS, bySet, taskInput } from './tasks.mjs';
import { editsFor, applyEdit, editSignature } from './operators.mjs';
import { pairedUnits, compareArms } from '../phase3/analysis.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));

function parseArgs(argv) {
  const args = { seeds: 3, budget: 250, generations: 80, out: 'experiments/results-pst.json', skipExhaustive: false, sweep: '15,30,60,120,250' };
  for (const raw of argv) {
    const m = /^--([^=]+)(?:=(.*))?$/.exec(raw);
    if (!m) continue;
    const key = m[1]; const value = m[2] ?? 'true';
    if (key in args) args[key] = value === 'true' ? true : (key === 'out' ? value : Number(value));
  }
  return args;
}

/**
 * EXHAUSTIVE SINGLE-OPERATOR CHECK.
 * For every task: apply every single edit (every operator, every parameter combination) to the
 * seed program and grade the result. If no single edit reaches a perfect score, then a perfect
 * solution REQUIRES the composition of at least two repairs — there is no direct repair rule.
 */
async function exhaustiveSingleOperator(grader, tasks) {
  const out = {};
  for (const task of tasks) {
    const input = taskInput(task);
    const seedGrade = await grader.grade(task.seed, task, input);
    const edits = editsFor(seedGrade.public.violations, task.seed);
    let best = 0; let bestEdit = null; let tested = 0;
    for (const edit of edits) {
      const code = applyEdit(task.seed, edit);
      if (!code) continue;
      tested++;
      const grade = await grader.grade(code, task, input);
      if (grade.public.score > best) { best = grade.public.score; bestEdit = editSignature(edit); }
    }
    out[task.id] = {
      seedScore: Number(seedGrade.public.score.toFixed(3)),
      editsTested: tested,
      bestSingleScore: Number(best.toFixed(3)),
      bestSingleEdit: bestEdit,
      solvableByOneOperator: best >= 1,
      seedViolations: seedGrade.public.violations,
    };
  }
  return out;
}

async function runArm(grader, arm, tasks, { seed, budget, generations }) {
  const shared = new Ledger();
  const results = [];
  for (const task of tasks) {
    const ledger = arm === 'base' ? new Ledger() : (arm === 'cri' ? shared : new Ledger());
    const engine = new PstEngine({
      grader, ledger, mode: arm === 'base' ? 'base' : 'cri',
      seed: seed * 977 + hash(task.id), budget, generations,
    });
    const result = await engine.runTask(task);
    result.arm = arm;
    result.seed = seed;
    results.push(result);
  }
  return { results, ledger: shared };
}

function hash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

function summarize(results) {
  const out = {};
  for (const arm of ['base', 'cri', 'cri-notransfer']) {
    const mine = results.filter(r => r.arm === arm);
    if (!mine.length) continue;
    const solved = mine.filter(r => r.success);
    const evalsOnSuccess = solved.map(r => r.evaluations).sort((a, b) => a - b);
    const median = arr => arr.length ? (arr.length % 2 ? arr[(arr.length - 1) / 2] : (arr[arr.length / 2 - 1] + arr[arr.length / 2]) / 2) : null;
    out[arm] = {
      runs: mine.length,
      solved: solved.length,
      successRate: Number((solved.length / mine.length).toFixed(4)),
      meanScore: Number((mine.reduce((a, r) => a + r.score, 0) / mine.length).toFixed(4)),
      medianEvaluationsOnSuccess: median(evalsOnSuccess),
      meanEvaluationsOnSuccess: evalsOnSuccess.length ? Number((evalsOnSuccess.reduce((a, b) => a + b, 0) / evalsOnSuccess.length).toFixed(2)) : null,
      bySet: Object.fromEntries(['A', 'B'].map(set => {
        const rows = mine.filter(r => r.set === set);
        const ok = rows.filter(r => r.success);
        return [set, {
          runs: rows.length,
          solved: ok.length,
          successRate: Number((ok.length / rows.length).toFixed(4)),
          medianEvaluationsOnSuccess: median(ok.map(r => r.evaluations).sort((a, b) => a - b)),
        }];
      })),
      composedSuccesses: mine.filter(r => r.solvedByComposition).length,
      repeatedViolations: mine.reduce((a, r) => a + r.violations.length, 0),
    };
  }
  return out;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const grader = new Grader({ size: 2, timeoutMs: 700 });
  await grader.init();
  const started = Date.now();

  const allResults = [];
  const ledgerSnapshots = [];
  let exhaustive = null;
  if (!args.skipExhaustive) {
    exhaustive = await exhaustiveSingleOperator(grader, TASKS);
  }

  for (let seed = 1; seed <= args.seeds; seed++) {
    for (const arm of ['base', 'cri', 'cri-notransfer']) {
      const { results, ledger } = await runArm(grader, arm, TASKS, { seed, budget: args.budget, generations: args.generations });
      allResults.push(...results);
      ledgerSnapshots.push({
        seed, arm,
        skills: [...ledger.skills.values()].map(s => ({ signature: s.signature, transformId: s.transformId, credit: s.credit, wins: s.wins })),
        refutations: [...ledger.refutations.values()].map(r => ({ signature: r.signature, transformId: r.transformId, credit: r.credit, misses: r.misses, hits: r.hits })),
        stats: ledger.stats,
      });
    }
  }

  const summary = summarize(allResults);

  // PAIRED statistics (unit = task#seed), computed with the shared module in synora-v5/stats.mjs
  const paired = {};
  for (const arm of ['cri', 'cri-notransfer']) {
    for (const group of ['A', 'B']) {
      const units = pairedUnits(
        allResults.filter(r => r.arm === arm && r.set === group),
        allResults.filter(r => r.arm === 'base' && r.set === group),
      );
      if (units.length) paired[`${arm}-vs-base@${group}`] = compareArms(units, args.budget);
    }
  }

  // ---- BUDGET SWEEP: success rate as a function of the evaluation budget ----
  // The comparison that matters: at a TIGHT budget, does the memory still deliver the goal?
  let sweep = null;
  const budgets = String(args.sweep || '').split(',').map(x => Number(x)).filter(Boolean);
  if (budgets.length) {
    const sweepResults = [];
    for (const budget of budgets) {
      for (let seed = 1; seed <= args.seeds; seed++) {
        for (const arm of ['base', 'cri', 'cri-notransfer']) {
          const { results } = await runArm(grader, arm, TASKS, { seed, budget, generations: args.generations });
          for (const r of results) sweepResults.push({ ...r, budget });
        }
      }
    }
    sweep = budgets.map(budget => {
      const rows = sweepResults.filter(r => r.budget === budget);
      const perArm = {};
      for (const arm of ['base', 'cri', 'cri-notransfer']) {
        const mine = rows.filter(r => r.arm === arm);
        const solved = mine.filter(r => r.success);
        const evals = solved.map(r => r.evaluations).sort((a, b) => a - b);
        perArm[arm] = {
          runs: mine.length,
          solved: solved.length,
          successRate: Number((solved.length / mine.length).toFixed(4)),
          medianEvaluationsOnSuccess: evals.length ? (evals.length % 2 ? evals[(evals.length - 1) / 2] : (evals[evals.length / 2 - 1] + evals[evals.length / 2]) / 2) : null,
          bySet: Object.fromEntries(['A', 'B'].map(set => {
            const s = mine.filter(r => r.set === set);
            const ok = s.filter(r => r.success);
            return [set, { runs: s.length, solved: ok.length, successRate: Number((ok.length / s.length).toFixed(4)) }];
          })),
        };
      }
      return { budget, arms: perArm };
    });
  }

  const payload = {
    generatedAt: new Date().toISOString(),
    config: { seeds: args.seeds, budget: args.budget, generations: args.generations, tasks: TASKS.length },
    exhaustive,
    summary,
    paired,
    sweep,
    ledgerSnapshots,
    results: allResults,
    graderStats: { runs: grader.runs, timeouts: grader.timeouts },
    elapsedMs: Date.now() - started,
  };
  const outPath = path.isAbsolute(args.out) ? args.out : path.join(HERE, '..', '..', args.out);
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, JSON.stringify(payload, null, 2));
  await grader.close();

  console.log(`\nPST experiment -> ${outPath}`);
  console.log(`elapsed ${(payload.elapsedMs / 1000).toFixed(1)}s, grader runs ${grader.runs}, timeouts ${grader.timeouts}\n`);
  console.log('single-operator check:');
  if (exhaustive) {
    for (const [id, row] of Object.entries(exhaustive)) {
      console.log(`  ${id.padEnd(24)} seed=${row.seedScore} bestSingle=${row.bestSingleScore} (${row.bestSingleEdit || 'none'}) solvableByOne=${row.solvableByOneOperator}`);
    }
    console.log('');
  }
  for (const [arm, row] of Object.entries(summary)) {
    console.log(`${arm.padEnd(16)} solved ${row.solved}/${row.runs} (${(row.successRate * 100).toFixed(1)}%)  meanScore=${row.meanScore}  medEvalsOnSuccess=${row.medianEvaluationsOnSuccess}  A=${row.bySet.A.successRate} B=${row.bySet.B.successRate}  composed=${row.composedSuccesses}`);
  }
  if (sweep) {
    console.log('\nbudget sweep (success rate):');
    console.log('  budget   base     cri      cri-notransfer');
    for (const row of sweep) {
      console.log(`  ${String(row.budget).padStart(5)}   ${(row.arms.base.successRate * 100).toFixed(1).padStart(6)}%   ${(row.arms.cri.successRate * 100).toFixed(1).padStart(6)}%   ${(row.arms['cri-notransfer'].successRate * 100).toFixed(1).padStart(6)}%`);
    }
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(err => { console.error(err); process.exit(1); });
}
