/**
 * Synora WAR v5 — PST phase: PUBLIC task specifications.
 *
 * A task gives the solver:
 *   - a natural-language GOAL (public),
 *   - the tools and the workspace (public),
 *   - the PARAMETERS of the task (public: "type = txt", "count = 3", "order = descending"),
 *   - a SEED program that is already close but wrong in specific places,
 *   - a budget of tool calls (public).
 *
 * A task may be STRICT: the grader then awards the score only for the final value, so a
 * partial repair is invisible in the fitness. Strict tasks are the ones where the goal cannot
 * be reached by a single repair rule — they REQUIRE a composed (multi-part) repair.
 *
 * What it does NOT give: the expected output. That lives in ./secrets.mjs and is used only by
 * the grader, in a separate module, after the candidate has been submitted. There is no
 * channel through which the solver can ask "what would the right answer be for X?".
 */

export const TASKS = [
  /* ---------------------------------------------------------------- SET A */
  {
    id: 'A1_largest_txt_names', strict: true, set: 'A', family: 'multi_step_names',
    goal: 'اعرض أسماء أكبر ثلاثة ملفات من نوع txt مفصولة بفواصل',
    goalEn: 'List the names of the three largest txt files, comma separated',
    params: { ext: 'txt', n: 3, dir: 'desc', sep: ', ' },
    required: ['listDir', 'filterByExt', 'sortBy', 'take', 'joinNames'],
    maxCalls: 8, valueType: 'string',
    seed: "function solution(input){return joinNames(take(sortBy(filterByExt(listDir(),'txt'),'size','asc'),2),'-')}",
    note: 'three independent argument defects: order, count, separator',
  },
  {
    id: 'A2_type_counts', set: 'A', family: 'aggregation',
    goal: 'عدّ الملفات حسب نوعها: كم ملفاً من كل نوع',
    goalEn: 'Count the files per type',
    params: {}, required: ['listDir', 'countByExt'], maxCalls: 6, valueType: 'object',
    seed: 'function solution(input){return countByExt(filterByExt(listDir(),\'txt\'))}',
    note: 'counts only one type instead of all',
  },
  {
    id: 'A3_total_txt_size', set: 'A', family: 'aggregation',
    goal: 'ما مجموع أحجام ملفات txt بالبايت؟',
    goalEn: 'Sum the sizes of the txt files',
    params: { ext: 'txt' }, required: ['listDir', 'filterByExt', 'sumSize'], maxCalls: 6, valueType: 'number',
    seed: "function solution(input){return sumSize(filterByExt(listDir(),'csv'))}",
    note: 'wrong extension',
  },
  {
    id: 'A4_clean_amount', set: 'A', family: 'text_pipeline',
    goal: 'نظّف النص: احذف المسافات الزائدة وحوّل الأرقام إلى أرقام عربية',
    goalEn: 'Clean the text: collapse spaces and convert digits to Arabic-Indic',
    params: {}, required: ['normalizeSpaces', 'toArabicDigits'], maxCalls: 4, valueType: 'string',
    seed: 'function solution(input){return toArabicDigits(input)}',
    note: 'missing the space-normalisation step',
  },
  {
    id: 'A5_big_files_count', set: 'A', family: 'threshold',
    goal: 'كم ملفاً حجمه لا يقل عن 100 بايت؟',
    goalEn: 'How many files are at least 100 bytes?',
    params: { min: 100 }, required: ['listDir', 'filterByMinSize'], maxCalls: 5, valueType: 'number',
    seed: 'function solution(input){return filterByMinSize(listDir(),1000).length}',
    note: 'wrong threshold',
  },
  {
    id: 'A6_names_sorted_asc', set: 'A', family: 'multi_step_names',
    goal: 'اعرض أسماء كل الملفات مرتبة أبجدياً مفصولة بشرطة',
    goalEn: 'List all file names sorted alphabetically, dash separated',
    params: { key: 'name', dir: 'asc', sep: '-' },
    required: ['listDir', 'sortBy', 'joinNames'], maxCalls: 6, valueType: 'string',
    seed: "function solution(input){return joinNames(sortBy(listDir(),'size','asc'),'-')}",
    note: 'sorts by size instead of by name',
  },

  /* ---------------------------------------------------------------- SET B (held out) */
  {
    id: 'B1_largest_csv_names', strict: true, set: 'B', family: 'multi_step_names',
    goal: 'اعرض أسماء أكبر ملفين من نوع csv مفصولة بفواصل',
    goalEn: 'List the names of the two largest csv files, comma separated',
    params: { ext: 'csv', n: 2, dir: 'desc', sep: ', ' },
    required: ['listDir', 'filterByExt', 'sortBy', 'take', 'joinNames'],
    maxCalls: 8, valueType: 'string',
    seed: "function solution(input){return joinNames(take(sortBy(filterByExt(listDir(),'csv'),'size','asc'),3),'-')}",
    note: 'same three defect slots as A1, different values — the transfer test',
  },
  {
    id: 'B2_md_count', strict: true, set: 'B', family: 'aggregation',
    goal: 'كم ملفاً من نوع md في المجلد؟',
    goalEn: 'How many md files are there?',
    params: { ext: 'md' }, required: ['listDir', 'filterByExt', 'countByExt'], maxCalls: 6, valueType: 'number',
    seed: "function solution(input){return countByExt(filterByExt(listDir(),'csv')).csv}",
    note: 'wrong extension and wrong field',
  },
  {
    id: 'B3_total_csv_size', set: 'B', family: 'aggregation',
    goal: 'ما مجموع أحجام ملفات csv؟',
    goalEn: 'Sum the sizes of the csv files',
    params: { ext: 'csv' }, required: ['listDir', 'filterByExt', 'sumSize'], maxCalls: 6, valueType: 'number',
    seed: "function solution(input){return sumSize(filterByExt(listDir(),'txt'))}",
    note: 'same defect slot as A3, different extension',
  },
  {
    id: 'B4_clean_amount_en', set: 'B', family: 'text_pipeline',
    goal: 'نظّف النص: المسافات والأرقام العربية',
    goalEn: 'Clean the text: spaces and Arabic-Indic digits',
    params: {}, required: ['normalizeSpaces', 'toArabicDigits'], maxCalls: 4, valueType: 'string',
    seed: 'function solution(input){return toArabicDigits(input)}',
    note: 'same missing step as A4',
  },
  {
    id: 'B5_min_size_50', set: 'B', family: 'threshold',
    goal: 'كم ملفاً حجمه لا يقل عن 50 بايت؟',
    goalEn: 'How many files are at least 50 bytes?',
    params: { min: 50 }, required: ['listDir', 'filterByMinSize'], maxCalls: 5, valueType: 'number',
    seed: 'function solution(input){return filterByMinSize(listDir(),100).length}',
    note: 'same defect slot as A5, different threshold',
  },
  {
    id: 'B6_names_sorted_desc', strict: true, set: 'B', family: 'multi_step_names',
    goal: 'اعرض أسماء كل الملفات تنازلياً بالحجم مفصولة بشرطة',
    goalEn: 'List all file names sorted by size descending, dash separated',
    params: { key: 'size', dir: 'desc', sep: '-' },
    required: ['listDir', 'sortBy', 'joinNames'], maxCalls: 6, valueType: 'string',
    seed: "function solution(input){return joinNames(sortBy(listDir(),'name','asc'),'-')}",
    note: 'sorts by name instead of by size',
  },
];

export const TASK_IDS = TASKS.map(t => t.id);
export const byId = id => TASKS.find(t => t.id === id);
export const bySet = set => TASKS.filter(t => t.set === set);

/** Inputs handed to `solution(input)` at run time (public). */
export function taskInput(task) {
  if (task.family === 'text_pipeline') return 'العدد  450 ريال';
  return null;
}
