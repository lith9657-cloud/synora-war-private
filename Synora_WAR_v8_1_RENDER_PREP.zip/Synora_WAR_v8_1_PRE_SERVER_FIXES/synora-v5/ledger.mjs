/**
 * Synora WAR v5 — CRI ledger.
 *
 * CRI = Causal Inheritance of Refutations.
 *
 * The engine inherits three kinds of knowledge, all of them *verifiable*:
 *
 *  1. REFUTATION  — "mutation T produced failure signature S here". Created only by an
 *     intervention test: the parent PASSED the killer, the child FAILED it, and the child's
 *     mutation is the only difference. That is a causal attribution, not a correlation, and it
 *     is what separates "the organism is wrong" from "the test is wrong".
 *  2. WITNESS     — a sound counterexample: an input where the candidate disagrees with the
 *     trusted oracle. Soundness is enforced by the judge, never by the engine.
 *  3. SKILL       — "when signature S appears, try operator T first". A skill is promoted from a
 *     refutation only after a candidate that applied it actually PASSED the failing killer.
 *     Unverified refutations stay hypotheses and are explored with low priority.
 *
 * Memory hygiene (spec §5.8): refutations and skills that never earn credit and age out are
 * pruned; witnesses are deduplicated by (task, input, expected).
 */

const MAX_REFS = 400;
const MAX_SKILLS = 200;
const MAX_WITNESSES = 400;

export class Ledger {
  constructor() {
    this.refutations = new Map(); // key -> refutation
    this.skills = new Map();      // id -> skill
    this.witnesses = new Map();   // id -> witness
    this.prohibitions = new Map();// key -> prohibition
    this.documented = new Set();  // every signature ever documented (for recurrence measurement)
    this.stats = {
      failureEvents: 0,
      recurrenceEvents: 0,
      attributableFailures: 0,
      witnessesCreated: 0,
      witnessViolations: 0,
      skillUses: 0,
      skillHits: 0,
      skillsPromoted: 0,
      refutationsPruned: 0,
      skillsPruned: 0,
    };
  }

  /* ------------------------------------------------------------- refutations */

  refutationKey(signature, transformId) { return `${signature}::${transformId}`; }

  /**
   * Record an attributable failure: the child failed a killer that the parent passed, and the
   * child's mutation is the operator under test.
   */
  noteAttributableFailure({ taskId, signature, transformId, gen, message }) {
    this.stats.failureEvents++;
    this.stats.attributableFailures++;
    const key = this.refutationKey(signature, transformId);
    let ref = this.refutations.get(key);
    if (!ref) {
      ref = {
        key, signature, transformId, taskId, credit: 0, misses: 0, hits: 0,
        status: 'hypothesis', firstGen: gen, lastGen: gen, messages: [],
      };
      this.refutations.set(key, ref);
    }
    ref.misses++;
    ref.lastGen = gen;
    if (message && ref.messages.length < 3) ref.messages.push(String(message).slice(0, 200));
    if (this.documented.has(signature)) this.stats.recurrenceEvents++;
    else this.documented.add(signature);
    // Prohibition: do not re-apply this operator blindly while this signature is active.
    const pKey = `${taskId}::${signature}::${transformId}`;
    const prohibition = this.prohibitions.get(pKey) || { key: pKey, taskId, signature, transformId, count: 0, lastGen: gen };
    prohibition.count++;
    prohibition.lastGen = gen;
    this.prohibitions.set(pKey, prohibition);
    return ref;
  }

  /**
   * The operator was applied in a context and the result was worse. This is recorded against the
   * signature OF THE CONTEXT (the parent's failure), not only against the child's new failure:
   * otherwise a skill that keeps failing in the same situation stays at the top of the ranking.
   */
  noteOperatorMiss({ taskId, signature, transformId, gen }) {
    const key = this.refutationKey(signature, transformId);
    let ref = this.refutations.get(key);
    if (!ref) {
      ref = { key, signature, transformId, taskId, credit: 0, misses: 0, hits: 0, status: 'hypothesis', firstGen: gen, lastGen: gen, messages: [] };
      this.refutations.set(key, ref);
    }
    ref.misses++;
    ref.lastGen = gen;
    if (ref.status === 'skill') ref.status = 'hypothesis';   // a skill that failed here is no longer trusted here
    const skill = this.skills.get(key);
    if (skill) skill.credit = Math.max(0, (skill.credit || 1) - 1);
    const pKey = `${taskId}::${signature}::${transformId}`;
    const prohibition = this.prohibitions.get(pKey) || { key: pKey, taskId, signature, transformId, count: 0, lastGen: gen };
    prohibition.count++;
    prohibition.lastGen = gen;
    this.prohibitions.set(pKey, prohibition);
    return ref;
  }

  /**
   * Record that an operator actually fixed a failing killer -> credit, and maybe promotion.
   * `hint` is optional: an operator may carry a parameter hint (e.g. the argument value that
   * made it work). The hint is advisory — the engine still re-verifies it in a new context.
   */
  noteSuccess({ taskId, signature, transformId, gen, witnesses = [], hint = null }) {
    const key = this.refutationKey(signature, transformId);
    let ref = this.refutations.get(key);
    if (!ref) {
      ref = {
        key, signature, transformId, taskId, credit: 0, misses: 0, hits: 0,
        status: 'hypothesis', firstGen: gen, lastGen: gen, messages: [],
      };
      this.refutations.set(key, ref);
    }
    ref.hits++;
    ref.credit++;
    ref.lastGen = gen;
    if (!this.documented.has(signature)) this.documented.add(signature);
    if (ref.credit >= 1 && ref.status !== 'skill') {
      ref.status = 'skill';
      this.stats.skillsPromoted++;
      this.promoteSkill({ signature, transformId, taskId, gen, witnesses, hint });
    } else if (hint) {
      // the skill already exists: refresh its advisory hint with the value that just worked
      const skill = this.skills.get(key);
      if (skill) skill.hint = hint;
    }
    // A verified operator clears the prohibition that was blocking it.
    this.prohibitions.delete(`${taskId}::${signature}::${transformId}`);
    return ref;
  }

  /* ----------------------------------------------------------------- skills */

  promoteSkill({ signature, transformId, taskId, gen, witnesses, hint = null }) {
    const id = `${signature}::${transformId}`;
    let skill = this.skills.get(id);
    if (!skill) {
      skill = {
        id, signature, transformId, taskId, credit: 0, uses: 0, wins: 0,
        promotedGen: gen, lastUsedGen: gen, witnesses: [], verified: true,
      };
      this.skills.set(id, skill);
    }
    skill.verified = true;
    skill.credit = (skill.credit || 0) + 1;
    if (hint) skill.hint = hint;              // advisory parameter hint (e.g. the value that worked)
    for (const w of witnesses) {
      if (!skill.witnesses.includes(w)) skill.witnesses.push(w);
    }
    skill.witnesses = skill.witnesses.slice(0, 12);
    return skill;
  }

  /** Skills for a signature, best credit first. */
  skillsFor(signature) {
    const out = [];
    for (const skill of this.skills.values()) if (skill.signature === signature) out.push(skill);
    out.sort((a, b) => (b.credit - a.credit) || (b.wins - a.wins));
    return out;
  }

  /** Operators to try for a signature, ranked by credit: verified skills first, then hypotheses. */
  rankedOperatorsFor(signature, { taskId } = {}) {
    const ranked = [];
    for (const skill of this.skills.values()) {
      if (skill.signature === signature) ranked.push({ transformId: skill.transformId, credit: skill.credit, verified: true });
    }
    for (const ref of this.refutations.values()) {
      if (ref.signature === signature && ref.status !== 'skill') {
        ranked.push({ transformId: ref.transformId, credit: -ref.misses, verified: false });
      }
    }
    ranked.sort((a, b) => (b.verified - a.verified) || (b.credit - a.credit));
    return ranked;
  }

  /** A prohibition blocks an operator for a few generations only: it is a penalty, not a ban. */
  isProhibited(taskId, signature, transformId, gen = 0, ttl = 4) {
    const prohibition = this.prohibitions.get(`${taskId}::${signature}::${transformId}`);
    if (!prohibition) return false;
    return (gen - prohibition.lastGen) <= ttl;
  }

  /* --------------------------------------------------------------- witnesses */

  addWitness({ taskId, input, expected, actual, signature, origin, gen }) {
    const id = `${taskId}::${JSON.stringify(input)}`;
    if (this.witnesses.has(id)) return this.witnesses.get(id);
    const witness = { id, taskId, input, expected, actual, signature, origin, createdGen: gen };
    this.witnesses.set(id, witness);
    this.stats.witnessesCreated++;
    return witness;
  }

  witnessesFor(taskId) {
    return [...this.witnesses.values()].filter(w => w.taskId === taskId);
  }

  noteWitnessViolation() { this.stats.witnessViolations++; }

  /* --------------------------------------------------------------- hygiene */

  prune({ gen, staleGens = 12 } = {}) {
    for (const [key, ref] of [...this.refutations]) {
      if (ref.credit === 0 && gen - ref.lastGen > staleGens) { this.refutations.delete(key); this.stats.refutationsPruned++; }
    }
    for (const [key, skill] of [...this.skills]) {
      if (skill.credit === 0 && gen - skill.lastUsedGen > staleGens) { this.skills.delete(key); this.stats.skillsPruned++; }
    }
    for (const [key, p] of [...this.prohibitions]) {
      if (gen - p.lastGen > staleGens * 2) this.prohibitions.delete(key);
    }
    if (this.refutations.size > MAX_REFS) {
      const sorted = [...this.refutations.values()].sort((a, b) => a.lastGen - b.lastGen);
      for (const ref of sorted.slice(0, this.refutations.size - MAX_REFS)) { this.refutations.delete(ref.key); this.stats.refutationsPruned++; }
    }
    if (this.skills.size > MAX_SKILLS) {
      const sorted = [...this.skills.values()].sort((a, b) => a.credit - b.credit || a.lastUsedGen - b.lastUsedGen);
      for (const skill of sorted.slice(0, this.skills.size - MAX_SKILLS)) { this.skills.delete(skill.id); this.stats.skillsPruned++; }
    }
    if (this.witnesses.size > MAX_WITNESSES) {
      const sorted = [...this.witnesses.values()].sort((a, b) => a.createdGen - b.createdGen);
      for (const w of sorted.slice(0, this.witnesses.size - MAX_WITNESSES)) this.witnesses.delete(w.id);
    }
  }

  /* ----------------------------------------------------------- persistence */

  toJSON() {
    return {
      version: 1,
      refutations: [...this.refutations.values()],
      skills: [...this.skills.values()],
      witnesses: [...this.witnesses.values()],
      prohibitions: [...this.prohibitions.values()],
      documented: [...this.documented],
      stats: this.stats,
    };
  }

  static fromJSON(data) {
    const ledger = new Ledger();
    if (!data) return ledger;
    for (const ref of data.refutations || []) ledger.refutations.set(ref.key, ref);
    for (const skill of data.skills || []) ledger.skills.set(skill.id, skill);
    for (const w of data.witnesses || []) ledger.witnesses.set(w.id, w);
    for (const p of data.prohibitions || []) ledger.prohibitions.set(p.key, p);
    for (const s of data.documented || []) ledger.documented.add(s);
    Object.assign(ledger.stats, data.stats || {});
    return ledger;
  }
}
