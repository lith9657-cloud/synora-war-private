/**
 * Synora WAR v5 — Judge.
 *
 * The judge is the only component that knows about the trusted oracle (`reference`).
 * The engine never sees it. The judge performs three jobs:
 *
 *  1. KILLER EVALUATION  — run a candidate against train/validation/inherited-witness killers.
 *  2. SOUNDNESS GATE      — a killer is admissible only if the trusted oracle PASSES it.
 *     This is how we separate "the organism is wrong" from "the test is wrong" (spec §5.2).
 *  3. DIFFERENTIAL PROBE  — compare candidate vs oracle on an input, producing a *sound*
 *     counterexample (witness) when they disagree. Witnesses are the atoms of inherited memory.
 *
 * A reusable worker pool keeps evaluation cheap; a candidate that hangs terminates its worker
 * and the worker is respawned.
 */
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Worker } from 'node:worker_threads';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const WORKER_FILE = path.join(HERE, 'worker.mjs');

export class Judge {
  constructor({ size = 2, timeoutMs = 400 } = {}) {
    this.size = size;
    this.timeoutMs = timeoutMs;
    this.workers = [];
    this.idle = [];
    this.queue = [];
    this.nextId = 1;
    this.evaluations = 0;
    this.timeouts = 0;
    this.peakWorkers = 0;
  }

  spawn() {
    const worker = new Worker(WORKER_FILE);
    worker.__busy = false;
    worker.on('error', () => { /* handled by the pending promise timeout */ });
    return worker;
  }

  async init() {
    for (let i = 0; i < this.size; i++) {
      const w = this.spawn();
      this.workers.push(w);
      this.idle.push(w);
    }
    this.peakWorkers = this.workers.length;
  }

  async close() {
    for (const w of this.workers) { try { await w.terminate(); } catch { /* ignore */ } }
    this.workers = [];
    this.idle = [];
  }

  acquire() {
    if (this.idle.length) return this.idle.pop();
    if (this.workers.length < this.size) {
      const w = this.spawn();
      this.workers.push(w);
      this.peakWorkers = this.workers.length;
      return w;
    }
    return new Promise(resolve => this.queue.push(resolve));
  }

  release(worker) {
    const next = this.queue.shift();
    if (next) next(worker);
    else this.idle.push(worker);
  }

  /** Send one message to a worker; terminates + respawns the worker on timeout. */
  async request(kind, payload) {
    const worker = await this.acquire();
    const id = this.nextId++;
    this.evaluations++;
    return new Promise(resolve => {
      let settled = false;
      const finish = value => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        worker.removeAllListeners('message');
        try { worker.terminate(); } catch { /* ignore */ }
        const replacement = this.spawn();
        this.workers[this.workers.indexOf(worker)] = replacement;
        this.release(replacement);
        resolve(value);
      };
      const timer = setTimeout(() => {
        this.timeouts++;
        finish({ __timeout: true });
      }, this.timeoutMs);
      worker.on('message', message => {
        if (message && message.id === id) {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          worker.removeAllListeners('message');
          this.release(worker);
          resolve(message.error ? { __error: message.error } : message.result);
        }
      });
      worker.postMessage({ id, kind, ...payload });
    });
  }

  /** Run a candidate against a list of killer records. */
  async runKillers(code, killers) {
    if (!killers || killers.length === 0) return { passed: 0, total: 0, failures: [] };
    const result = await this.request('killers', { code, killers });
    if (result.__timeout) {
      return {
        passed: 0,
        total: killers.length,
        failures: killers.map(k => ({ name: k.name || 'timeout', error: `Execution timeout after ${this.timeoutMs}ms`, split: k.split || 'train' })),
        timedOut: true,
      };
    }
    if (result.__error) {
      return {
        passed: 0,
        total: killers.length,
        failures: killers.map(k => ({ name: k.name || 'error', error: result.__error, split: k.split || 'train' })),
      };
    }
    return result;
  }

  /** Compare candidate vs trusted oracle on inputs -> sound counterexamples (witnesses). */
  async differential(code, reference, inputs) {
    if (!inputs || inputs.length === 0) return [];
    const result = await this.request('probe', { code, inputs });
    if (result.__timeout || result.__error) return [];
    const expected = await this.request('probe', { code: reference, inputs });
    if (expected.__timeout || expected.__error) return [];
    const out = [];
    for (let i = 0; i < inputs.length; i++) {
      const got = result.results[i];
      const want = expected.results[i];
      // If the trusted oracle itself throws on this input, the input is outside the spec domain:
      // we must not file it as a counterexample, or we would punish the candidate for not
      // crashing exactly like the oracle.
      if (!want.ok) continue;
      const same = got.ok && got.value === want.value;
      if (!same) out.push({ input: inputs[i], expected: want.value, expectedError: null, actual: got.value, actualError: got.error || null });
    }
    return out;
  }

  /**
   * Validate a task definition: the trusted oracle must pass every killer, and the buggy seed
   * must fail at least one train killer and one validation killer. Returns problems found.
   */
  async validateTask(task) {
    const problems = [];
    const ref = await this.runKillers(task.reference, [...task.train, ...task.validation]);
    for (const f of ref.failures) problems.push(`oracle fails killer ${f.name} (task is malformed)`);
    const bug = await this.runKillers(task.buggy, [...task.train, ...task.validation]);
    if (!bug.failures.some(f => f.split === 'train')) problems.push('buggy seed does not fail any train killer');
    if (!bug.failures.some(f => f.split === 'validation')) problems.push('buggy seed does not fail any validation killer');
    const overlap = task.probes.filter(p => task.holdout.some(h => JSON.stringify(p) === JSON.stringify(h)));
    if (overlap.length) problems.push(`probe/holdout overlap: ${JSON.stringify(overlap)}`);
    return problems;
  }
}
