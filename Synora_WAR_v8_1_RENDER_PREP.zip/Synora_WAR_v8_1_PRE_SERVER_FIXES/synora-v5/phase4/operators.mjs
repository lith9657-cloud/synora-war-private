/**
 * Synora WAR v5 — PHASE 4: the operator library for tool-use programs.
 *
 * A copy of the Phase-3 library (synora-v5/phase3/operators.mjs). The FIVE operators and their
 * semantics are byte-identical: SET_ARG, INSERT_CALL, INSERT_CALL_ARG, REMOVE_CALL, SWAP_CALLS,
 * FIELD_SET. No operator was added, removed or weakened for the new domain.
 * The only changes are:
 *   - the import of the tool contracts and the parameter pool (the Phase-4 environment),
 *   - the list of property names a trailing field access may carry (the Phase-4 domain has
 *     records with `id`, `cls`, `amount`, `factor`, `mult` instead of file entries).
 *
 * A copy of the Phase-2 library (Phase 2 stays untouched) plus exactly ONE extra operator:
 * INSERT_CALL_ARG — insert a call AND give it an argument in a named slot.
 *
 * WHY THE EXTRA OPERATOR (measured, not assumed): the Phase-2 library can insert a call but
 * cannot give it a value, so a task whose defect is a MISSING filtering step
 * (filterByExt(listDir()) with no extension) is unsolvable: no operator can set the missing
 * argument, and the produced program filters nothing. Three Phase-3 tasks (B3, C2, C3) hit
 * exactly this wall. The extension is the minimum that removes the wall: one new operator, and
 * nothing else in the library changes.
 *
 * WHY THIS LIBRARY IS NEW (and why the previous one was inadequate):
 * The v5 repair library manipulates *expressions* (operators, literals, guards). It has no way
 * to ADD a call, REMOVE one, REORDER calls, or address a specific argument slot of a call.
 * Measured proof: with the old library, none of the 12 PST tasks can be solved at all
 * (see tests/pst.test.mjs and docs/REPORT-PST.md — "no single operator suffices").
 *
 * The four operators below are the MINIMUM set that can express the solutions:
 *   SET_ARG      — change one argument slot of one call (the value comes from the public pool)
 *   INSERT_CALL  — insert a call at the head of the pipeline (wrapping the current input)
 *   REMOVE_CALL  — remove a call from the pipeline
 *   SWAP_CALLS   — swap two adjacent calls in the pipeline
 *   FIELD_SET    — change a trailing property access (e.g. `.csv` -> `.md`)
 *
 * These are HAND-WRIVEN capabilities (like the tool environment and the grader). What the
 * engine DISCOVERS is *which operator repairs which failure category* — that mapping is the
 * thing the CRI ledger accumulates and the thing the experiment measures.
 */
import { TOOLS, VALUE_POOL, FIELD_NAMES } from './environment.mjs';

/** Split the argument list of a call, respecting nested calls and strings. */
function splitArgs(text) {
  const parts = [];
  let depth = 0, quote = null, start = 0;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quote) {
      if (c === '\\') { i++; continue; }
      if (c === quote) quote = null;
      continue;
    }
    if (c === '"' || c === "'") { quote = c; continue; }
    if (c === '(' || c === '[' || c === '{') { depth++; continue; }
    if (c === ')' || c === ']' || c === '}') { depth--; continue; }
    if (c === ',' && depth === 0) { parts.push({ start, end: i, text: text.slice(start, i) }); start = i + 1; }
  }
  parts.push({ start, end: text.length, text: text.slice(start) });
  return parts;
}

/** Locate the calls of a tool in the source: [{start, end, args:[{start,end,text}]}]. */
export function findCalls(code, tool) {
  const out = [];
  const re = new RegExp(`\\b${tool}\\s*\\(`, 'g');
  let m;
  while ((m = re.exec(code)) !== null) {
    const open = code.indexOf('(', m.index);
    let depth = 0, quote = null, close = -1;
    for (let i = open; i < code.length; i++) {
      const c = code[i];
      if (quote) {
        if (c === '\\') { i++; continue; }
        if (c === quote) quote = null;
        continue;
      }
      if (c === '"' || c === "'") { quote = c; continue; }
      if (c === '(') depth++;
      else if (c === ')') { depth--; if (depth === 0) { close = i; break; } }
    }
    if (close < 0) break;
    const inner = code.slice(open + 1, close);
    const innerStart = open + 1;
    // the argument offsets are relative to the inner text: make them absolute in the source
    const args = splitArgs(inner).map(a => ({
      start: a.start + innerStart,
      end: a.end + innerStart,
      text: a.text,
    }));
    out.push({ tool, nameStart: m.index, start: open, end: close + 1, innerStart, innerEnd: close, args });
  }
  return out;
}

/** The literal value of an argument slot, if it is a simple literal. */
function literalValue(text) {
  const trimmed = text.trim();
  if (/^'[^']*'$/.test(trimmed)) return trimmed.slice(1, -1);
  if (/^"[^"]*"$/.test(trimmed)) return trimmed.slice(1, -1);
  if (/^-?\d+(\.\d+)?$/.test(trimmed)) return Number(trimmed);
  return undefined;
}

function quoteValue(value) {
  if (typeof value === 'number') return String(value);
  return `'${String(value).replace(/'/g, "\\'")}'`;
}

/** The tool calls that appear in the program, in source order (outermost last). */
export function pipelineOf(code) {
  const names = [];
  for (const tool of Object.keys(TOOLS)) {
    for (const call of findCalls(code, tool)) names.push({ tool, call });
  }
  return names.sort((a, b) => a.call.start - b.call.start);
}

/* ------------------------------------------------------------------ edits */

/** Change one argument slot of one call. */
export function setArg(code, tool, param, value) {
  const contract = TOOLS[tool] ? TOOLS[tool].args : [];
  const index = contract.indexOf(param);
  if (index < 0) return null;
  const calls = findCalls(code, tool);
  if (!calls.length) return null;
  const target = calls[calls.length - 1];           // the outermost call of that tool
  const slot = target.args[index];
  if (!slot) return null;
  const literal = literalValue(slot.text);
  if (literal === undefined) return null;            // only simple literals are editable
  if (literal === value) return null;
  const next = code.slice(0, slot.start) + quoteValue(value) + code.slice(slot.end);
  return next;
}

/**
 * Insert a call INTO the pipeline, at the innermost position:
 * `f(input)` becomes `f(tool(input))` — the new step runs FIRST and feeds the existing call.
 * That is the semantics of a missing pipeline step (normalize before convert, filter before
 * count, ...), and it is the only placement that keeps the existing order of the other steps.
 */
export function insertCall(code, tool) {
  if (findCalls(code, tool).length) return null;
  const all = [];
  for (const name of Object.keys(TOOLS)) {
    for (const call of findCalls(code, name)) all.push(call);
  }
  const m = /return\s+/.exec(code);
  if (!m) return null;
  const exprStart = m.index + m[0].length;

  // the DEEPEST call: the one whose argument region contains no other call
  let deepest = null;
  for (const call of all) {
    const containsOther = all.some(o => o !== call && o.start >= call.start && o.end <= call.end);
    if (!containsOther) { deepest = call; break; }
  }

  if (!deepest) {
    // no call at all: wrap the returned expression
    let depth = 0, quote = null, end = code.length;
    for (let i = exprStart; i < code.length; i++) {
      const c = code[i];
      if (quote) { if (c === '\\') { i++; continue; } if (c === quote) quote = null; continue; }
      if (c === '"' || c === "'") { quote = c; continue; }
      if (c === '(' || c === '[' || c === '{') depth++;
      else if (c === ')' || c === ']' || c === '}') { if (depth === 0) { end = i; break; } depth--; }
      else if (c === ';' && depth === 0) { end = i; break; }
    }
    const expr = code.slice(exprStart, end);
    const next = code.slice(0, exprStart) + `${tool}(${expr})` + code.slice(end);
    return next === code ? null : next;
  }

  // The new step must run FIRST in the pipeline:
  //   - if the deepest call consumes a plain value (the input), wrap that value;
  //   - otherwise wrap the deepest call itself.
  const contract = TOOLS[deepest.tool] ? TOOLS[deepest.tool].args : [];
  if (contract[0] === 'entries' || contract[0] === 'text') {
    const slot = deepest.args[0];
    const text = slot ? slot.text.trim() : '';
    if (text && !text.includes('(')) {
      const next = code.slice(0, slot.start) + `${tool}(${text})` + code.slice(slot.end);
      return next === code ? null : next;
    }
  }
  const next = code.slice(0, deepest.nameStart) + `${tool}(${code.slice(deepest.nameStart, deepest.end)})` + code.slice(deepest.end);
  return next === code ? null : next;
}

/**
 * Insert a call AND set one of its arguments in a named slot.
 * `insertCall` can add a step to the pipeline but cannot give it a value, so a step like
 * filterByExt would filter by `undefined` — i.e. nothing. Only the first extra slot of the
 * contract is supported (that is the only case the tasks need); anything else returns null.
 */
export function insertCallArg(code, tool, param, value) {
  const contract = TOOLS[tool] ? TOOLS[tool].args : [];
  const index = contract.indexOf(param);
  if (index !== 1) return null;
  const base = insertCall(code, tool);
  if (!base) return null;
  const calls = findCalls(base, tool);
  if (!calls.length) return null;
  const target = calls[calls.length - 1];
  const at = target.innerEnd;                       // just before the closing parenthesis
  const next = base.slice(0, at) + ',' + quoteValue(value) + base.slice(at);
  return next === base ? null : next;
}

/**
 * Remove a call from the pipeline.
 * The pipeline is nested (`f(g(x))` = g feeds f), so removing g means replacing g(...) with the
 * value g was piping — the parent's first argument. Removing the text alone would leave the
 * parent's other arguments dangling.
 */
export function removeCall(code, tool) {
  const calls = findCalls(code, tool);
  if (!calls.length) return null;
  const target = calls[calls.length - 1];
  const contract = TOOLS[tool] ? TOOLS[tool].args : [];
  const piped = (contract[0] === 'entries' || contract[0] === 'text') ? target.args[0] : null;
  if (!piped || !piped.text) return null;
  const full = code.slice(target.nameStart, target.end);

  // the parent call is the one whose argument region contains the target
  let parent = null;
  for (const name of Object.keys(TOOLS)) {
    for (const call of findCalls(code, name)) {
      if (call.start === target.start && call.end === target.end) continue;
      if (call.innerStart <= target.start && call.innerEnd >= target.end) { parent = call; break; }
    }
    if (parent) break;
  }
  if (!parent) return null;                       // the call is the whole expression: not removable

  const inner = code.slice(parent.innerStart, parent.innerEnd);
  const rel = target.nameStart - parent.innerStart;
  if (inner.slice(rel, rel + full.length) !== full) return null;
  const nextInner = inner.slice(0, rel) + piped.text + inner.slice(rel + full.length);
  const next = code.slice(0, parent.innerStart) + nextInner + code.slice(parent.innerEnd);
  return next === code ? null : next;
}

/** Swap two adjacent calls in the pipeline. */
export function swapCalls(code, toolA, toolB) {
  const a = findCalls(code, toolA);
  const b = findCalls(code, toolB);
  if (!a.length || !b.length) return null;
  const callA = a[a.length - 1], callB = b[b.length - 1];
  if (callA.start > callB.start) return null;            // only swap when A is outer/inner neighbour
  // swapping two calls means swapping which one wraps the other: rewrite the inner one
  const innerText = code.slice(callB.innerStart, callB.innerEnd);
  const outerText = code.slice(callA.innerStart, callA.innerEnd);
  if (!outerText.includes(innerText)) return null;
  const swappedOuter = outerText.replace(innerText, `__INNER__`);
  const next = code.slice(0, callA.innerStart) + swappedOuter.replace('__INNER__', `${toolB}(${innerText})`) + code.slice(callA.innerEnd);
  return next === code ? null : next;
}

/** Change a trailing property access, e.g. `.csv` -> `.md`. */
export function fieldSet(code, field) {
  const re = /\)\.([A-Za-z_$][\w$]*)/g;
  let m, last = null;
  while ((m = re.exec(code)) !== null) last = m;
  if (!last) return null;
  if (last[1] === field) return null;
  return code.slice(0, last.index) + `).${field}` + code.slice(last.index + last[0].length);
}

/**
 * Build the candidate edits implied by a list of grader violations.
 * The mapping violation -> edit family is the part the CRI ledger LEARNS; this function is the
 * hand-written connection between the grader's vocabulary and the operator library.
 */
export function editsFor(violations, code) {
  const edits = [];
  const present = pipelineOf(code);
  const presentTools = [...new Set(present.map(p => p.tool))];
  const add = (kind, params) => edits.push({ kind, ...params });

  for (const violation of violations) {
    if (violation.startsWith('wrong_arg:')) {
      const [, tool, param] = violation.split(':');
      for (const value of VALUE_POOL) add('SET_ARG', { tool, param, value });
    } else if (violation.startsWith('missing_tool:')) {
      const tool = violation.split(':')[1];
      add('INSERT_CALL', { tool });
      const contract = TOOLS[tool] ? TOOLS[tool].args : [];
      const param = contract[1];
      if (param) for (const value of VALUE_POOL) add('INSERT_CALL_ARG', { tool, param, value });
    } else if (violation === 'wrong_value' || violation === 'wrong_output_type' || violation === 'exception' || violation === 'budget_exceeded') {
      // generic: any argument slot could be the culprit, or a call could be superfluous
      for (const { tool } of present) {
        const contract = TOOLS[tool] ? TOOLS[tool].args : [];
        for (const param of contract) {
          if (param === 'entries' || param === 'text') continue;
          for (const value of VALUE_POOL) add('SET_ARG', { tool, param, value });
        }
        add('REMOVE_CALL', { tool });
      }
      for (const field of FIELD_NAMES) add('FIELD_SET', { field });
    }
  }
  // de-duplicate by (kind + the fields that identify the edit)
  const seen = new Set();
  return edits.filter(e => {
    const key = `${e.kind}|${e.tool ?? ''}|${e.param ?? ''}|${e.value ?? ''}|${e.field ?? ''}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

/** Apply an edit to a program. */
export function applyEdit(code, edit) {
  try {
    if (edit.kind === 'SET_ARG') return setArg(code, edit.tool, edit.param, edit.value);
    if (edit.kind === 'INSERT_CALL') return insertCall(code, edit.tool);
    if (edit.kind === 'INSERT_CALL_ARG') return insertCallArg(code, edit.tool, edit.param, edit.value);
    if (edit.kind === 'REMOVE_CALL') return removeCall(code, edit.tool);
    if (edit.kind === 'SWAP_CALLS') return swapCalls(code, edit.toolA, edit.toolB);
    if (edit.kind === 'FIELD_SET') return fieldSet(code, edit.field);
    return null;
  } catch {
    return null;
  }
}

/** A stable, value-free identity of an edit — this is what a SKILL stores. */
export function editSignature(edit) {
  if (edit.kind === 'SET_ARG') return `SET_ARG:${edit.tool}:${edit.param}`;
  if (edit.kind === 'INSERT_CALL') return `INSERT_CALL:${edit.tool}`;
  if (edit.kind === 'INSERT_CALL_ARG') return `INSERT_CALL:${edit.tool}`;
  if (edit.kind === 'REMOVE_CALL') return `REMOVE_CALL:${edit.tool}`;
  if (edit.kind === 'SWAP_CALLS') return `SWAP_CALLS:${edit.toolA}:${edit.toolB}`;
  if (edit.kind === 'FIELD_SET') return 'FIELD_SET';
  return edit.kind;
}

export { VALUE_POOL };
