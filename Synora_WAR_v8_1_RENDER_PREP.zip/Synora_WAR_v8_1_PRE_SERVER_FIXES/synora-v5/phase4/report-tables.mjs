/**
 * Synora WAR v5 — PHASE 4: the report tables, generated FROM THE RAW RESULTS.
 *
 *   node synora-v5/phase4/report-tables.mjs --phase4=experiments/results-phase4.json
 *
 * No number in the Phase-4 report is typed by hand: every table below is printed by this
 * module from the raw JSON, and the test suite checks that the report contains them.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(HERE, '..', '..');

function parseArgs(argv) {
  const out = {};
  for (const raw of argv) {
    const m = /^--([^=]+)(?:=(.*))?$/.exec(raw);
    if (m) out[m[1]] = m[2] ?? 'true';
  }
  return out;
}

function median(values) {
  if (!values.length) return null;
  const v = [...values].sort((a, b) => a - b);
  const mid = v.length >> 1;
  return v.length % 2 ? v[mid] : (v[mid - 1] + v[mid]) / 2;
}

function fmt(value) {
  if (value === null || value === undefined) return '—';
  if (typeof value === 'number') return Number.isInteger(value) ? String(value) : value.toFixed(4);
  return String(value);
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const rawPath = args.phase4 || 'experiments/results-phase4.json';
  const full = path.isAbsolute(rawPath) ? rawPath : path.join(ROOT, rawPath);
  const raw = JSON.parse(fs.readFileSync(full, 'utf8'));
  const budgets = raw.config.budgets;
  const arms = ['base', 'notransfer', 'noise', 'cri'];
  const lines = [];
  const say = s => { lines.push(s); console.log(s); };

  say('# Phase 4 — the tables (generated from the raw results)');
  say('');
  say(`seeds: ${raw.config.seeds} · budgets: ${budgets.join(', ')} · tasks: A=${raw.config.tasksPerGroup.A} B=${raw.config.tasksPerGroup.B} C=${raw.config.tasksPerGroup.C}`);
  say('');

  /* ---------------- the headline table ---------------- */
  say('## 1. Success and cost (groups B + C)');
  say('');
  say('| budget | arm | solved | rate | median evals | B solved | C solved | hint hits | hint misses |');
  say('|---:|---|---:|---:|---:|---:|---:|---:|---:|');
  for (const budget of budgets) {
    for (const arm of arms) {
      const s = raw.summary[arm] && raw.summary[arm][budget];
      if (!s) continue;
      const b = s.groups.B || { solved: 0, runs: 0 };
      const c = s.groups.C || { solved: 0, runs: 0 };
      say(`| ${budget} | ${arm} | ${s.solved}/${s.runs} | ${(s.successRate * 100).toFixed(1)}% | ${fmt(s.medianEvaluationsOnSuccess)} | ${b.solved}/${b.runs} | ${c.solved}/${c.runs} | ${s.usefulInheritedHints} | ${s.wrongInheritedHints} |`);
    }
  }
  say('');

  /* ---------------- the paired comparisons ---------------- */
  say('## 2. The paired comparisons (the unit is (task, seed))');
  say('');
  say('| comparison | units | solved | base | both | only arm | only base | neither | McNemar p | Holm | Wilcoxon p | Holm | paired effect | CI95 | censored median diff |');
  say('|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|');
  for (const budget of budgets) {
    for (const arm of ['cri', 'noise', 'notransfer']) {
      for (const group of ['B', 'C']) {
        const c = raw.comparisons[`${arm}-vs-base@${budget}@${group}`];
        if (!c) continue;
        const ci = c.pairedBootstrap && c.pairedBootstrap.ci95 ? `[${c.pairedBootstrap.ci95[0]}, ${c.pairedBootstrap.ci95[1]}]` : '—';
        say(`| ${arm}-vs-base @${budget} @${group} | ${c.units} | ${c.solvedArm} | ${c.solvedBase} | ${c.bothSolved} | ${c.onlyArmSolved} | ${c.onlyBaseSolved} | ${c.neitherSolved} | ${fmt(c.pValueBinary)} | ${fmt(c.holmAdjustedPBinary)} | ${fmt(c.pValue)} | ${fmt(c.holmAdjustedP)} | ${fmt(c.pairedBootstrap && c.pairedBootstrap.point)} | ${ci} | ${fmt(c.censored && c.censored.medianDifference)} |`);
      }
    }
  }
  say('');

  /* ---------------- the per-task table of the held-out group ---------------- */
  say('## 3. The held-out group, per task (aggregated over the seeds)');
  say('');
  const maxBudget = Math.max(...budgets);
  say('| task | rule family | cri solved | base solved | noise | notransfer | cri median evals | base median evals |');
  say('|---|---|---:|---:|---:|---:|---:|---:|');
  // The rule family of a task: which inherited rule (if any) can apply to it.
  //   acquired   — the defective slot is one the acquisition session repaired with the
  //                DOMINANT rule, so the inherited hint is right;
  //   wrong      — the defective slot needs a DIFFERENT rule (a minority band, a unit the
  //                acquisition never used, a task-specific id), so the inherited hint is wrong;
  //   none       — the defective slot has no counterpart in the acquisition (a class, a rank).
  const RULE_FAMILY = {
    C1_settle_b2_num: 'acquired', C2_settle_b2_str: 'acquired', C3_settle_b2_rate: 'acquired',
    C4_largest_in_band2: 'acquired', C5_second_in_band2: 'acquired',
    C7_count_class_c: 'none',
    C6_settle_b3_num: 'wrong', C8_settle_b1_num: 'wrong', C9_settle_sar: 'wrong', C10_settle_wrongid: 'wrong',
  };
  const heldOut = raw.runs.filter(r => r.group === 'C');
  const taskIds = [...new Set(heldOut.map(r => r.taskId))].sort();
  for (const taskId of taskIds) {
    const cell = (arm) => {
      const rows = heldOut.filter(r => r.arm === arm && r.taskId === taskId);
      const ok = rows.filter(r => r.success);
      const ev = ok.length ? median(ok.map(r => r.evaluations)) : null;
      return { text: `${ok.length}/${rows.length}`, ev };
    };
    const cri = cell('cri'), base = cell('base'), noise = cell('noise'), nt = cell('notransfer');
    say(`| ${taskId} | ${RULE_FAMILY[taskId] || '—'} | ${cri.text} | ${base.text} | ${noise.text} | ${nt.text} | ${fmt(cri.ev)} | ${fmt(base.ev)} |`);
  }
  say('');

  /* ---------------- the rule-family breakdown ---------------- */
  say('## 3b. The held-out group, split by whether the inherited rule can apply');
  say('');
  say('| budget | family | cri solved | base solved | cri median evals | base median evals |');
  say('|---:|---|---:|---:|---:|---:|');
  for (const budget of budgets) {
    for (const family of ['acquired', 'wrong', 'none']) {
      const rows = (arm) => heldOut.filter(r => r.budget === budget && r.arm === arm && (RULE_FAMILY[r.taskId] || 'none') === family);
      const cri = rows('cri'), base = rows('base');
      if (!cri.length) continue;
      const okCri = cri.filter(r => r.success), okBase = base.filter(r => r.success);
      say(`| ${budget} | ${family} | ${okCri.length}/${cri.length} | ${okBase.length}/${base.length} | ${fmt(okCri.length ? median(okCri.map(r => r.evaluations)) : null)} | ${fmt(okBase.length ? median(okBase.map(r => r.evaluations)) : null)} |`);
    }
  }
  say('');

  /* ---------------- the memory accounting ---------------- */
  say('## 4. What the memory actually did');
  say('');
  for (const receipt of raw.acquisitionReceipts) {
    say(`- seed ${receipt.seed}: ${receipt.skills} skills, ${receipt.refutations} refutations, memory ${receipt.memorySha256.slice(0, 12)}…, ${receipt.elapsedMs} ms`);
    for (const s of receipt.skillTable || []) {
      if (!s.hint) continue;
      say(`  - \`${s.hint.key}\` → \`${JSON.stringify(s.hint.value)}\` (credit ${s.credit})`);
    }
  }
  say('');
  say('| arm | hints inherited | hits | misses | restored skills used |');
  say('|---|---:|---:|---:|---:|');
  for (const arm of arms) {
    const rows = raw.runs.filter(r => r.arm === arm);
    const hits = rows.reduce((a, r) => a + ((r.memoryStats && r.memoryStats.hintHits) || 0), 0);
    const misses = rows.reduce((a, r) => a + ((r.memoryStats && r.memoryStats.hintMisses) || 0), 0);
    const inherited = rows.reduce((a, r) => a + ((r.memoryStats && r.memoryStats.hintsInherited) || 0), 0);
    const used = rows.reduce((a, r) => a + ((r.memoryStats && r.memoryStats.restoredSkillsUsed) || 0), 0);
    say(`| ${arm} | ${inherited} | ${hits} | ${misses} | ${used} |`);
  }
  say('');

  /* ---------------- the controls ---------------- */
  say('## 5. The controls');
  say('');
  say('| seed | cross-process == in-process | acquisition pid | evaluation pid | memory sha256 |');
  say('|---:|---|---|---|---|');
  for (const c of raw.sessionControl) {
    say(`| ${c.seed} | ${c.identical ? 'IDENTICAL' : 'DIFFERENT'} | ${c.crossProcessPid} | ${c.inProcessPid} | \`${String(c.memoryFileSha256).slice(0, 12)}…\` |`);
  }
  say('');
  say('| seed | expected values found inside the memory file |');
  say('|---:|---:|');
  for (const s of raw.leakScans || []) say(`| ${s.seed} | ${s.answerHits} |`);
  say('');

  /* ---------------- the structural diversity ---------------- */
  say('## 6. The structural diversity of the held-out group');
  say('');
  say('| task | group | max similarity to the acquisition group | class | defect families |');
  say('|---|---|---:|---|---|');
  for (const [id, v] of Object.entries(raw.similarity.classes)) {
    say(`| ${id} | ${v.group} | ${v.maxSimInA} | ${v.class} | ${v.families.join(', ')} |`);
  }
  say('');

  if (args.out) {
    const outPath = path.isAbsolute(args.out) ? args.out : path.join(ROOT, args.out);
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    fs.writeFileSync(outPath, lines.join('\n') + '\n');
    console.log(`\nwritten: ${path.relative(ROOT, outPath)}`);
  }
}

main();
