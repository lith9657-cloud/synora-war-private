import { AdaptivePstEngine } from './adaptive-engine.mjs';

/** Reconstructed comparison arm: same per-hint counters, but aggregate misses across contexts. */
export class LegacyAdaptivePstEngine extends AdaptivePstEngine {
  hintFor(key) {
    const hint = super.hintForWithoutAdaptiveEvidence
      ? super.hintForWithoutAdaptiveEvidence(key)
      : this._baseHint(key);
    if (this.mode !== 'adaptive' || hint == null) return hint;
    if (this.budget >= 80) return null;
    const evidence = this.hintEvidence.get(this._hintId(key, hint));
    if (evidence && evidence.misses >= 2 && evidence.misses > evidence.hits) return null;
    return hint;
  }
  _baseHint(key) {
    // Call the base engine's implementation, bypassing AdaptivePstEngine.hintFor.
    return Object.getPrototypeOf(AdaptivePstEngine.prototype).hintFor.call(this, key);
  }
}
