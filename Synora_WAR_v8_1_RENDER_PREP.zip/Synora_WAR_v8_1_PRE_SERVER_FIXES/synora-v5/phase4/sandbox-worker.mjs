/**
 * Synora WAR v5 — PHASE 4: sandbox worker.
 *
 * A copy of the Phase-3 sandbox worker (synora-v5/pst/sandbox-worker.mjs) with ONE change: it
 * binds the PHASE-4 tool environment instead of the Phase-2 one. The execution semantics
 * (a worker thread, a tool trace, a timeout, no filesystem access) are byte-identical.
 *
 * Executes a candidate program with the tool environment bound, and returns the tool TRACE
 * plus the final output. Runs in a worker thread so an infinite loop can be terminated.
 */
import { parentPort } from 'node:worker_threads';
import { makeTools } from './environment.mjs';

for (const name of ['fetch', 'WebSocket', 'XMLHttpRequest']) {
  if (name in globalThis) {
    try { Object.defineProperty(globalThis, name, { value: undefined, configurable: true }); } catch { /* ignore */ }
  }
}

parentPort.on('message', message => {
  const trace = [];
  try {
    const tools = makeTools(trace);
    // eslint-disable-next-line no-new-func
    const fn = Function('input', ...Object.keys(tools), `${message.code}; return solution;`);
    const solution = fn(message.input, ...Object.values(tools));
    let value;
    try {
      const raw = solution(message.input);
      value = typeof raw === 'undefined' ? '__undefined__' : JSON.parse(JSON.stringify(raw));
    } catch (e) {
      parentPort.postMessage({ id: message.id, ok: false, error: String((e && e.message) || e), trace });
      return;
    }
    parentPort.postMessage({ id: message.id, ok: true, value, trace });
  } catch (e) {
    parentPort.postMessage({ id: message.id, ok: false, error: String((e && e.stack) || e), trace });
  }
});
