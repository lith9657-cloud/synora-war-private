/**
 * Synora WAR v5 — PHASE 4: the experiment orchestrator (cross-domain).
 *
 * Every arm runs in ITS OWN PROCESS. The memory only ever crosses a process boundary through
 * the file written by the acquisition session, so "the memory survived the session" is a
 * property of the file, not an accident of shared memory.
 *
 * Arms (the four the protocol asks for):
 *   cri        the persistent memory: session 1 acquires on A, writes the memory file, EXITS;
 *              a NEW process restores the file and works on B then C.
 *   base       NO persistent memory: no ledger at all (the baseline).
 *   noise      the memory file is restored, but the VALUE HINTS are randomised: the control
 *              for "useful knowledge" vs "any hint at all".
 *   notransfer the memory exists but the TRANSFER is blocked: the ledger is reset before every
 *              task, so nothing learned in one task is inherited by another.
 *
 * Control (not a headline arm):
 *   inprocess  the acquisition runs inside the evaluation process. It must produce the SAME
 *              results as the file-based session — that is what proves the file carries the
 *              whole memory.
 *
 * Budgets: 30 / 60 / 150 evaluations per task.
 *
 *   node synora-v5/phase4/experiments.mjs --seeds=5 --budgets=30,60,150 \
 *        --out=experiments/results-phase4.json
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { similarityReport, summariseArm, pairedUnits, compareArms } from './analysis.mjs';
import { holmBonferroni } from '../stats.mjs';
import { TASKS, byGroup } from './tasks.mjs';
import { EXPECTED_VALUES } from './secrets.mjs';
import { scanMemoryForAnswers } from '../phase3/memory.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(HERE, '..', '..');

const ARMS = ['cri', 'base', 'noise', 'notransfer'];

function parseArgs(argv) {
  const args = { seeds: 5, budgets: '30,60,150', generations: 200, out: 'experiments/results-phase4.json', raw: 'experiments/phase4' };
  for (const raw of argv) {
    const m = /^--([^=]+)(?:=(.*))?$/.exec(raw);
    if (!m) continue;
    const key = m[1];
    const value = m[2] ?? 'true';
    if (key in args) args[key] = (key === 'out' || key === 'raw' || key === 'budgets') ? value : Number(value);
  }
  return args;
}

function runNode(script, argv, label) {
  const result = spawnSync(process.execPath, [path.join(HERE, script), ...argv], {
    cwd: ROOT, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024,
  });
  if (result.status !== 0) {
    console.error(`--- ${label} failed (exit ${result.status}) ---\n${result.stderr}`);
    throw new Error(`${label} failed`);
  }
  return result.stdout;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const budgets = String(args.budgets).split(',').map(Number).filter(Boolean);
  const maxBudget = Math.max(...budgets);
  // The ACQUISITION budget is a design constant, not part of the measurement: the acquisition
  // session must be able to LEARN the rules, and every arm is then measured at the same
  // evaluation budget. It is generous on purpose (it is not the object of the experiment).
  const acquireBudget = Math.max(250, maxBudget);
  const rawDir = path.join(ROOT, args.raw);
  const memoryDir = path.join(rawDir, 'memory');
  fs.mkdirSync(memoryDir, { recursive: true });

  const runs = [];
  const acquisitionReceipts = [];
  const controlChecks = [];
  const leakScans = [];

  for (let seed = 1; seed <= args.seeds; seed++) {
    /* ---------- SESSION 1: acquisition (its own process) ---------- */
    const memoryFile = path.join(memoryDir, `acquire-seed${seed}.json`);
    const memoryFileRel = path.relative(ROOT, memoryFile);
    const acquireOut = runNode('acquire.mjs', [
      `--seed=${seed}`, `--budget=${acquireBudget}`, `--generations=${args.generations}`,
      `--out=${memoryFileRel}`,
    ], `acquire seed ${seed}`);
    const receipt = JSON.parse(acquireOut);
    acquisitionReceipts.push(receipt);

    // LEAK CHECK: the memory file must not contain any expected value of ANY task
    const hits = scanMemoryForAnswers(memoryFile, EXPECTED_VALUES);
    leakScans.push({ seed, file: memoryFileRel, answerHits: hits.length, hits });

    for (const budget of budgets) {
      for (const arm of ARMS) {
        const argv = [`--mode=${arm}`, `--seed=${seed}`, `--budget=${budget}`, `--generations=${args.generations}`, '--groups=B,C'];
        if (arm === 'cri' || arm === 'noise') argv.push(`--memory=${memoryFileRel}`);
        const outFile = path.join(rawDir, `eval-${arm}-seed${seed}-budget${budget}.json`);
        argv.push(`--out=${path.relative(ROOT, outFile)}`);
        runNode('evaluate.mjs', argv, `evaluate ${arm} seed ${seed} budget ${budget}`);
        const payload = JSON.parse(fs.readFileSync(outFile, 'utf8'));
        for (const r of payload.results) {
          runs.push({
            ...r, arm, budget, seed,
            elapsedMs: payload.elapsedMs,
            rssMb: payload.rssMb || 0,
            memoryFileBytes: payload.memoryFileBytes || null,
            memorySource: payload.memory.source,
            memorySkills: payload.memory.skills || 0,
          });
        }
      }
      /* ---------- the in-process control (the maximum budget only) ---------- */
      if (budget === maxBudget) {
        const argv = [`--mode=inprocess`, `--seed=${seed}`, `--budget=${budget}`, `--generations=${args.generations}`, '--groups=B,C', `--acquire-budget=${acquireBudget}`];
        const outFile = path.join(rawDir, `eval-inprocess-seed${seed}-budget${budget}.json`);
        argv.push(`--out=${path.relative(ROOT, outFile)}`);
        runNode('evaluate.mjs', argv, `evaluate inprocess seed ${seed}`);
        const payload = JSON.parse(fs.readFileSync(outFile, 'utf8'));
        const cross = JSON.parse(fs.readFileSync(path.join(rawDir, `eval-cri-seed${seed}-budget${budget}.json`), 'utf8'));
        const key = r => `${r.taskId}|${r.success}|${r.evaluations}|${r.champion.code}`;
        const a = payload.results.map(key).sort();
        const b = cross.results.map(key).sort();
        controlChecks.push({
          seed, budget,
          identical: JSON.stringify(a) === JSON.stringify(b),
          inProcessPid: payload.pid,
          crossProcessPid: cross.pid,
          memoryFileSha256: receipt.memory.sha256,
        });
        for (const r of payload.results) {
          runs.push({ ...r, arm: 'inprocess', budget, seed, elapsedMs: payload.elapsedMs, rssMb: payload.rssMb || 0, memorySource: payload.memory.source });
        }
      }
    }
    process.stdout.write(`seed ${seed}/${args.seeds} done\n`);
  }

  /* ---------------- aggregation ---------------- */
  const summary = {};
  for (const arm of [...ARMS, 'inprocess']) {
    summary[arm] = {};
    for (const budget of budgets) {
      const rows = runs.filter(r => r.arm === arm && r.budget === budget);
      if (!rows.length) continue;
      summary[arm][budget] = summariseArm(rows);
    }
  }

  /* ---------------- paired comparisons ---------------- */
  const comparisonList = [];
  for (const budget of budgets) {
    const base = runs.filter(r => r.arm === 'base' && r.budget === budget);
    for (const arm of ['cri', 'noise', 'notransfer']) {
      const other = runs.filter(r => r.arm === arm && r.budget === budget);
      for (const group of ['B', 'C']) {
        const units = pairedUnits(
          other.filter(r => r.group === group),
          base.filter(r => r.group === group),
        );
        const stats = compareArms(units, budget);
        comparisonList.push({
          arm, base: 'base', budget, group,
          ...stats,
          pValue: stats.wilcoxon.p,
          pValueBinary: stats.mcnemar.p,
        });
      }
    }
  }
  // MULTIPLICITY: two families (binary / continuous), each corrected with Holm-Bonferroni.
  const binaryAdj = holmBonferroni(comparisonList.map(c => ({ key: `${c.arm}-vs-base@${c.budget}@${c.group}`, p: c.pValueBinary })));
  const continuousAdj = holmBonferroni(comparisonList.map(c => ({ key: `${c.arm}-vs-base@${c.budget}@${c.group}`, p: c.pValue })));
  const binaryBy = new Map(binaryAdj.map(a => [a.key, a]));
  const continuousBy = new Map(continuousAdj.map(a => [a.key, a]));
  const comparisons = {};
  for (const c of comparisonList) {
    const key = `${c.arm}-vs-base@${c.budget}@${c.group}`;
    const bAdj = binaryBy.get(key);
    const cAdj = continuousBy.get(key);
    comparisons[key] = {
      ...c,
      holmAdjustedP: cAdj.pAdjusted, holmRank: cAdj.rank, familySize: cAdj.familySize,
      holmAdjustedPBinary: bAdj.pAdjusted, holmRankBinary: bAdj.rank, familySizeBinary: bAdj.familySize,
    };
  }

  const similarity = similarityReport();
  const crossStructure = Object.entries(similarity.classes).filter(([, v]) => v.class === 'cross_structure').map(([k]) => k);
  const crossStructureStats = {};
  for (const arm of [...ARMS]) {
    const rows = runs.filter(r => r.arm === arm && r.budget === maxBudget && crossStructure.includes(r.taskId));
    const ok = rows.filter(r => r.success);
    crossStructureStats[arm] = {
      tasks: crossStructure,
      runs: rows.length,
      solved: ok.length,
      successRate: rows.length ? Number((ok.length / rows.length).toFixed(4)) : null,
      medianEvaluationsOnSuccess: ok.length ? summariseArm(ok).medianEvaluationsOnSuccess : null,
    };
  }

  const payload = {
    generatedAt: new Date().toISOString(),
    config: {
      seeds: args.seeds, budgets, generations: args.generations,
      arms: ARMS,
      tasksPerGroup: { A: byGroup('A').length, B: byGroup('B').length, C: byGroup('C').length },
      environment: { node: process.version, cpus: (await import('node:os')).cpus().length, platform: process.platform },
    },
    acquisitionReceipts: acquisitionReceipts.map(r => ({
      seed: r.seed, pid: r.pid, memoryPath: r.memory.path, memorySha256: r.memory.sha256,
      skills: r.memory.skills, refutations: r.memory.refutations, prohibitions: r.memory.prohibitions,
      tasks: r.tasks, results: r.results, elapsedMs: r.elapsedMs,
      skillTable: r.skillTable,
    })),
    sessionControl: controlChecks,
    leakScans,
    similarity,
    crossStructure,
    crossStructureStats,
    summary,
    comparisons,
    runs,
  };
  const outPath = path.isAbsolute(args.out) ? args.out : path.join(ROOT, args.out);
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, JSON.stringify(payload, null, 2));

  /* ---------------- the flat CSV ---------------- */
  const csv = ['arm,budget,seed,taskId,group,success,score,evaluations,composed,violations,hintHits,hintMisses,restoredSkillsUsed,elapsedMs'];
  for (const r of runs) {
    const m = r.memoryStats || {};
    csv.push([
      r.arm, r.budget, r.seed, r.taskId, r.group, r.success ? 1 : 0, r.score, r.evaluations,
      r.solvedByComposition ? 1 : 0, (r.violations || []).join('|'),
      m.hintHits || 0, m.hintMisses || 0, m.restoredSkillsUsed || 0, r.elapsedMs || 0,
    ].join(','));
  }
  const csvPath = outPath.replace(/\.json$/, '.csv');
  fs.writeFileSync(csvPath, csv.join('\n') + '\n');

  console.log(`\nphase-4 experiment -> ${outPath}`);
  console.log(`flat results       -> ${csvPath}`);
  console.log(`\nbudget  arm            solved   rate    medEvals   B-med   C-med`);
  for (const budget of budgets) {
    for (const arm of ['base', 'notransfer', 'noise', 'cri', 'inprocess']) {
      const s = summary[arm] && summary[arm][budget];
      if (!s) continue;
      console.log(`${String(budget).padStart(5)}   ${arm.padEnd(14)} ${String(s.solved).padStart(3)}/${s.runs}   ${(s.successRate * 100).toFixed(1).padStart(6)}%   ${String(s.medianEvaluationsOnSuccess).padStart(8)}   ${String(s.groups.B && s.groups.B.medianEvaluationsOnSuccess).padStart(6)}   ${String(s.groups.C && s.groups.C.medianEvaluationsOnSuccess).padStart(6)}`);
    }
  }
  console.log('\ncross-process vs in-process control:', controlChecks.map(c => `${c.seed}:${c.identical ? 'IDENTICAL' : 'DIFFERENT'}`).join(' '));
  console.log('memory leak scans (expected values found in the memory file):', leakScans.map(s => `${s.seed}:${s.answerHits}`).join(' '));
}

main().catch(err => { console.error(err); process.exit(1); });
