/**
 * Synora WAR v5 — PHASE 4: the CRI engine over tool-use programs (CROSS-DOMAIN).
 *
 * A copy of the Phase-3 engine (synora-v5/phase3/engine.mjs). The SEARCH ALGORITHM, the CRI
 * ATTRIBUTION, the ledger interaction, the coverage/directed/composed structure and the
 * statistics are byte-identical — this file adds no capability. The only changes are:
 *   - the import of the tool contracts and the parameter pool (the Phase-4 environment),
 *   - the import of the task specifications (the Phase-4 tasks),
 *   - the noise arm's value pool (it must draw from the DOMAIN's pool, not Phase 2's),
 *   - the property names a trailing field access may carry (the Phase-4 records).
 *
 * A copy of the Phase-2 engine (Phase 2 stays untouched) with three additions:
 *
 *   1. MEMORY MODES
 *      'cri'   — the real memory: the learned repair shapes and their value hints.
 *      'base'  — no memory at all (the ablation).
 *      'noise' — the memory MECHANISM is exercised but the value hints are replaced by a
 *                 random value from the public pool. This is the control that separates
 *                 "useful knowledge" from "any hint at all".
 *   2. RESTORE ACCOUNTING — how many restored skills were actually applied, how many of the
 *      inherited hints turned out to be wrong, and how many were right.
 *   3. The extra operator of the Phase-3 library (INSERT_CALL_ARG) is understood by the
 *      family machinery.
 *
 * Same memory (the CRI ledger), same discipline (causal attribution, credible successes,
 * prohibitions), a different domain and a different, INDEPENDENT grader.
 *
 * What changes in this domain:
 *   - the fitness is a property score produced by the one-way grader (not a test count);
 *   - the SIGNATURE is the grader's violation category ('wrong_arg:sortBy:dir',
 *     'missing_tool:take', 'wrong_value', ...), which is task-independent and therefore
 *     transferable;
 *   - the SKILL is (violation category -> operator shape). The shape is learned; the operator's
 *     PARAMETER VALUE is only a hint that the engine re-verifies in every new context.
 *
 * Search structure (this is what makes composition possible):
 *   1. COVERAGE  — the parent's failures are grouped into FAMILIES (one per violation
 *      category). The engine tries the untried values of the first unfinished family. This is
 *      systematic, not random, so every family is exhausted before moving on.
 *   2. DIRECTED  — the ledger's verified skill for a family is tried first.
 *   3. COMPOSED  — two families are repaired in ONE child, using the learned value hints.
 *      This is the capability that single operators provably lack (see the exhaustive check).
 *
 * Modes:
 *   'base'  — no ledger: coverage + random composition only (the ablation).
 *   'cri'   — the ledger directs the search and supplies the value hints.
 */
import { Ledger } from '../ledger.mjs';
import { editsFor, applyEdit, editSignature, pipelineOf, VALUE_POOL } from './operators.mjs';
import { TOOLS, FIELD_NAMES } from './environment.mjs';
import { taskInput } from './tasks.mjs';

function makeRng(seed) {
  let state = (seed >>> 0) || 1;
  return function next() {
    state ^= state << 13; state >>>= 0;
    state ^= state >> 17;
    state ^= state << 5; state >>>= 0;
    return state / 0xffffffff;
  };
}

/**
 * The families of repairs implied by a program's violations (specific first, generic last).
 * A family = one repair SHAPE plus the set of values that shape may take.
 */
export function familiesFor(violations) {
  const families = [];
  for (const violation of violations) {
    if (violation.startsWith('wrong_arg:')) {
      const [, tool, param] = violation.split(':');
      families.push({ kind: 'SET_ARG', tool, param, values: VALUE_POOL, violation });
    } else if (violation.startsWith('missing_tool:')) {
      families.push({ kind: 'INSERT_CALL', tool: violation.split(':')[1], values: [null], violation });
    }
  }
  families.push({ kind: 'GENERIC', values: null, violation: 'wrong_value' });
  return families;
}

function familyKey(family) {
  if (family.kind === 'SET_ARG') return `SET_ARG:${family.tool}:${family.param}`;
  if (family.kind === 'INSERT_CALL') return `INSERT_CALL:${family.tool}`;
  if (family.kind === 'REMOVE_CALL') return `REMOVE_CALL:${family.tool}`;
  if (family.kind === 'FIELD_SET') return 'FIELD_SET';
  return 'GENERIC';
}

/** The concrete edits of a family (the generic family enumerates every slot and value). */
function familyEdits(family, code) {
  if (family.kind === 'SET_ARG') {
    return family.values.map(value => ({ kind: 'SET_ARG', tool: family.tool, param: family.param, value }));
  }
  if (family.kind === 'INSERT_CALL') return [{ kind: 'INSERT_CALL', tool: family.tool }];
  return [];
}

/** The repair family implied by a grader category. */
export function familyKeyForViolation(violation) {
  if (violation.startsWith('wrong_arg:')) {
    const [, tool, param] = violation.split(':');
    return `SET_ARG:${tool}:${param}`;
  }
  if (violation.startsWith('missing_tool:')) return `INSERT_CALL:${violation.split(':')[1]}`;
  return null;
}

function editFamilyKey(edit) {
  if (!edit) return null;
  if (edit.kind === 'SET_ARG') return `SET_ARG:${edit.tool}:${edit.param}`;
  if (edit.kind === 'INSERT_CALL') return `INSERT_CALL:${edit.tool}`;
  if (edit.kind === 'INSERT_CALL_ARG') return `INSERT_CALL:${edit.tool}`;
  if (edit.kind === 'REMOVE_CALL') return `REMOVE_CALL:${edit.tool}`;
  if (edit.kind === 'FIELD_SET') return 'FIELD_SET';
  return edit.kind;
}

function editValueKey(edit) {
  if (!edit) return 'none';
  if (edit.kind === 'SET_ARG') return `${edit.tool}:${edit.param}=${edit.value}`;
  if (edit.kind === 'FIELD_SET') return `field=${edit.field}`;
  if (edit.kind === 'REMOVE_CALL') return `remove=${edit.tool}`;
  if (edit.kind === 'INSERT_CALL') return `insert=${edit.tool}`;
  return edit.kind;
}

/** Decode a mixed-radix index into one option per participant. */
function decodeMixedRadix(index, radices) {
  const out = new Array(radices.length);
  let rest = index;
  for (let i = radices.length - 1; i >= 0; i--) {
    out[i] = rest % radices[i];
    rest = Math.floor(rest / radices[i]);
  }
  return out;
}

function buildEdit(family, value) {
  if (family.kind === 'SET_ARG') return { kind: 'SET_ARG', tool: family.tool, param: family.param, value };
  if (family.kind === 'INSERT_CALL') return { kind: 'INSERT_CALL', tool: family.tool };
  return null;
}

function genericEdits(code, presentTools) {
  const edits = [];
  for (const tool of presentTools) {
    const contract = TOOLS[tool] ? TOOLS[tool].args : [];
    for (const param of contract) {
      if (param === 'entries' || param === 'text') continue;
      for (const value of VALUE_POOL) edits.push({ kind: 'SET_ARG', tool, param, value });
    }
    edits.push({ kind: 'REMOVE_CALL', tool });
  }
  for (const field of FIELD_NAMES) edits.push({ kind: 'FIELD_SET', field });
  return edits;
}

/** Population ranking: fitness first, then fewer violations, then shorter code. */
function rank(a, b) {
  if (b.score !== a.score) return b.score - a.score;
  const va = a.evaluation && a.evaluation.violations ? a.evaluation.violations.length : 0;
  const vb = b.evaluation && b.evaluation.violations ? b.evaluation.violations.length : 0;
  if (va !== vb) return va - vb;
  return a.code.length - b.code.length;
}

export class PstEngine {
  constructor({
    grader,
    ledger = new Ledger(),
    mode = 'cri',
    seed = 1,
    budget = 150,
    generations = 60,
    epsilon = 0.2,
    populationSize = 8,
    log = () => {},
  } = {}) {
    this.grader = grader;
    this.ledger = ledger;
    this.mode = mode;
    this.seed = seed;
    this.budget = budget;
    this.generations = generations;
    this.epsilon = epsilon;
    this.populationSize = populationSize;
    this.log = log;
    this.covered = new Map();   // taskId -> Map(familyKey -> Set(valueKey))
    this.hints = new Map();     // familyKey -> value  (the ledger's advisory hint)
    this.chainCursors = new Map(); // taskId::chainKey -> the next combination to try
    this.stats = {
      restoredSkillsUsed: 0,   // skills that came from the restored memory and were applied
      directedProposals: 0,    // proposals produced from a stored skill
      hintHits: 0,             // an inherited hint removed the violation it was aimed at
      hintMisses: 0,           // an inherited hint did NOT remove that violation
      hintsInherited: 0,       // inherited hints that were tried at least once
    };
    let noiseState = ((this.seed * 2654435761) >>> 0) || 1;
    this._noiseRng = () => { noiseState ^= noiseState << 13; noiseState >>>= 0; noiseState ^= noiseState >> 17; noiseState ^= noiseState << 5; noiseState >>>= 0; return noiseState / 0xffffffff; };
  }

  get memoryEnabled() { return this.mode === 'cri' || this.mode === 'noise'; }

  /** Fisher-Yates shuffle of the family list, driven by the engine's rng. */
  shuffleFamilies(families) {
    for (let i = families.length - 1; i > 0; i--) {
      const j = Math.floor(this.rng() * (i + 1)) % (i + 1);
      const tmp = families[i]; families[i] = families[j]; families[j] = tmp;
    }
    return families;
  }

  coveredSet(taskId) {
    if (!this.covered.has(taskId)) this.covered.set(taskId, new Map());
    return this.covered.get(taskId);
  }

  markTried(taskId, key, valueKey) {
    const set = this.coveredSet(taskId);
    if (!set.has(key)) set.set(key, new Set());
    set.get(key).add(valueKey);
  }

  isTried(taskId, key, valueKey) {
    const set = this.coveredSet(taskId);
    return set.has(key) && set.get(key).has(valueKey);
  }

  /**
   * The learned value hint for a family (from the ledger's verified skills).
   * In the 'noise' mode the mechanism runs but the VALUE is random: the shape knowledge is
   * kept, the value knowledge is destroyed. If the noise arm performs like the real arm, the
   * benefit came from the shapes only; if it performs like the base arm, the values matter.
   */
  hintFor(key) {
    if (this.mode === 'noise') {
      if (!this._noiseHints) this._noiseHints = new Map();
      if (!this._noiseHints.has(key)) {
        // the DOMAIN's pool (the Phase-3 engine hard-coded the Phase-2 pool here)
        const pool = VALUE_POOL;
        const idx = Math.floor(this._noiseRng() * pool.length) % pool.length;
        this._noiseHints.set(key, pool[idx]);
      }
      return this._noiseHints.get(key);
    }
    if (this.memoryEnabled) {
      // Never resolve conflicting hints by insertion order. The current task context
      // does not yet provide a validated discriminator for choosing between values, so
      // abstain when more than one distinct verified value exists. The search then falls
      // back to systematic coverage and the grader validates every candidate.
      const values = new Set();
      for (const skill of this.ledger.skills.values()) {
        if (skill.verified !== false && skill.hint && skill.hint.key === key) {
          values.add(JSON.stringify(skill.hint.value));
        }
      }
      if (values.size === 1) return JSON.parse([...values][0]);
      if (values.size > 1) return null;
    }
    return this.hints.get(key) ?? null;
  }

  noteHint(key, value) {
    this.hints.set(key, value);
  }

  /* ------------------------------------------------------------- proposal */

  /** The candidate children for a program, ordered by priority. */
  propose(parent, taskId, presentTools) {
    const violations = parent.evaluation.violations;
    const families = familiesFor(violations);
    // STOCHASTICITY: the order in which the failure families are attacked is drawn from the
    // engine's rng. Without this the whole search was deterministic and every "seed" produced
    // byte-identical results, which made the reported dispersion and confidence intervals
    // meaningless (audited in 07-FINAL-AUDIT-AND-REPRODUCTION.md).
    if (this.rng) this.shuffleFamilies(families);
    const proposals = [];

    // 1. per family: the learned value hint first, then the systematic coverage of values
    for (const family of families) {
      const key = familyKey(family);
      if (this.memoryEnabled && family.violation && this.ledger.isProhibited(taskId, family.violation, key, this.currentGen || 0)) continue;
      const hint = this.hintFor(key, family.violation);
      if (hint !== null && hint !== undefined) this.stats.hintsInherited++;
      if (family.kind === 'GENERIC') {
        // the generic family enumerates every slot of the program: one proposal per edit shape
        for (const edit of genericEdits(parent.code, presentTools)) {
          const editKey = `GENERIC:${editSignature(edit)}`;
          const valueKey = edit.kind === 'SET_ARG' ? String(edit.value) : 'none';
          if (this.isTried(taskId, editKey, valueKey)) continue;
          const code = applyEdit(parent.code, edit);
          if (!code) continue;
          proposals.push({ code, signature: editSignature(edit), edit, source: 'coverage', familyKey: editKey, valueKey });
          break;
        }
        continue;
      }
      // the candidates of this family: the learned hint first, then the systematic coverage
      const candidates = family.kind === 'INSERT_CALL'
        ? this.insertCandidates(family, hint)
        : (hint !== null && hint !== undefined
          ? [{ value: hint, edit: buildEdit(family, hint) }, ...family.values.map(v => ({ value: v, edit: buildEdit(family, v) }))]
          : family.values.map(v => ({ value: v, edit: buildEdit(family, v) })));
      for (const candidate of candidates) {
        const value = candidate.value;
        const valueKey = value === null ? 'none' : String(value);
        if (this.isTried(taskId, key, valueKey)) continue;
        const edit = candidate.edit;
        if (!edit) continue;
        const code = applyEdit(parent.code, edit);
        if (!code) continue;
        if (hint !== null && hint !== undefined && value === hint) this.stats.directedProposals++;
        proposals.push({
          code, signature: key, edit,
          source: (hint !== null && hint !== undefined && value === hint) ? 'directed' : 'coverage',
          familyKey: key, valueKey,
        });
        break;
      }
    }

    // 2. COMPOSED — repair several families in one child, using the learned hints
    const composed = this.compose(parent, taskId, families, presentTools);
    if (composed) proposals.push(composed);

    // on a STRICT task a single repair cannot be seen in the fitness, so the composed
    // proposals go first: a composed repair is the only way to reach the goal
    if (this.strictTask && this.preferComposed) {
      proposals.sort((a, b) => (a.source === 'composed' ? -1 : 0) - (b.source === 'composed' ? -1 : 0));
    }

    return proposals;
  }

  /**
   * The candidates of a MISSING-CALL family: the bare insertion plus the same insertion with a
   * value in the tool's first argument slot (Phase-3 only — the Phase-2 library could not do
   * the second one, which is why three Phase-3 tasks were unsolvable at first).
   */
  insertCandidates(family, hint) {
    const tool = family.tool;
    const contract = TOOLS[tool] ? TOOLS[tool].args : [];
    const param = contract[1];
    const out = [{ value: null, edit: { kind: 'INSERT_CALL', tool } }];
    if (!param) return out;
    const values = hint !== null && hint !== undefined
      ? [hint, ...VALUE_POOL.filter(v => v !== hint)]
      : VALUE_POOL;
    for (const value of values) out.push({ value, edit: { kind: 'INSERT_CALL_ARG', tool, param, value } });
    return out;
  }

  editsForShape(shape, hint) {
    const parts = shape.split(':');
    if (parts[0] === 'SET_ARG') {
      const values = hint && hint.value !== undefined ? [hint.value, ...VALUE_POOL.filter(v => v !== hint.value)] : VALUE_POOL;
      return values.map(value => ({ kind: 'SET_ARG', tool: parts[1], param: parts[2], value }));
    }
    if (parts[0] === 'INSERT_CALL') {
      const tool = parts[1];
      const contract = TOOLS[tool] ? TOOLS[tool].args : [];
      const param = contract[1];
      const plain = [{ kind: 'INSERT_CALL', tool }];
      if (!param) return plain;
      const values = hint && hint.value !== undefined ? [hint.value, ...VALUE_POOL.filter(v => v !== hint.value)] : VALUE_POOL;
      return plain.concat(values.map(value => ({ kind: 'INSERT_CALL_ARG', tool, param, value })));
    }
    if (parts[0] === 'REMOVE_CALL') return [{ kind: 'REMOVE_CALL', tool: parts[1] }];
    if (parts[0] === 'FIELD_SET') return FIELD_NAMES.map(field => ({ kind: 'FIELD_SET', field }));
    return [];
  }

  /**
   * COMPOSED REPAIR — the capability test.
   *
   * A chain = an ordered list of PARTICIPANTS (one per failure family). Each participant
   * contributes one edit. The engine enumerates the PRODUCT of the participants' candidate
   * edits with a deterministic cursor, so the search is systematic rather than random.
   *
   * The learned VALUE HINT is placed FIRST in each participant's candidate list. That is the
   * whole point of the memory: the *shape* of a repair is task-independent, and the value that
   * repaired that shape in an earlier task is tried first in the next one.
   */
  compose(parent, taskId, families, presentTools) {
    const specific = families.filter(f => f.kind !== 'GENERIC');
    const generic = families.find(f => f.kind === 'GENERIC');
    const participants = [];
    for (const family of specific) {
      const key = familyKey(family);
      const hint = this.hintFor(key, family.violation);
      const edits = this.editsForShape(key, hint !== null && hint !== undefined ? { value: hint } : null);
      if (!edits.length) continue;
      participants.push({ key, edits });
    }
    if (participants.length < 2) return null;

    // the generic family can join a chain as a participant (it carries FIELD_SET / REMOVE_CALL)
    const genericEditsList = generic ? genericEdits(parent.code, presentTools) : [];

    const chains = [];
    const permute = (items, len) => {
      if (len === 1) return [items];
      const out = [];
      for (let i = 0; i < items.length; i++) {
        const rest = [...items.slice(0, i), ...items.slice(i + 1)];
        for (const tail of permute(rest, len - 1)) out.push([items[i], ...tail]);
      }
      return out;
    };
    for (const len of [3, 2]) {
      if (specific.length >= len) {
        for (const combo of permute(specific, len)) chains.push(combo.map(f => ({ key: familyKey(f), edits: this.editsForShape(familyKey(f), this.hintOrNull(familyKey(f))) })));
      }
    }
    if (genericEditsList.length && specific.length >= 1) {
      for (const family of specific) {
        chains.push([
          { key: familyKey(family), edits: this.editsForShape(familyKey(family), this.hintOrNull(familyKey(family))) },
          { key: 'GENERIC', edits: genericEditsList },
        ]);
      }
    }
    if (!chains.length) return null;

    for (const chain of chains) {
      if (chain.some(p => !p.edits.length)) continue;
      const chainKey = chain.map(p => p.key).join('+');
      // the cursor is bound to the CURRENT candidate lists: when a hint changes, the ordering
      // of the product changes too, so the cursor must restart (otherwise the correct
      // combination could be skipped forever)
      const orderSignature = chain.map(p => (p.edits[0] ? editValueKey(p.edits[0]) : '-')).join('|');
      const cursorKey = `${taskId}::${chainKey}::${orderSignature}`;
      const cursor = this.chainCursors.get(cursorKey) ?? 0;
      const total = chain.reduce((a, p) => a * p.edits.length, 1);
      for (let step = 0; step < total; step++) {
        const index = cursor + step;
        const choices = decodeMixedRadix(index, chain.map(p => p.edits.length));
        const edits = choices.map((choice, i) => chain[i].edits[choice]);
        let code = parent.code;
        let ok = true;
        for (const edit of edits) {
          const next = applyEdit(code, edit);
          if (!next) { ok = false; break; }
          code = next;
        }
        if (!ok) continue;
        this.chainCursors.set(cursorKey, index + 1);
        return {
          code,
          signature: chainKey,
          edit: edits[edits.length - 1],
          edits,
          source: 'composed',
          familyKey: chainKey,
          valueKey: chainKey + '|' + edits.map(e => editValueKey(e)).join('|'),
        };
      }
    }
    return null;
  }

  hintOrNull(key) {
    const hint = this.hintFor(key);
    return hint === null || hint === undefined ? null : { value: hint };
  }

  /* ---------------------------------------------------------- attribution */

  attribute(parent, child, task, gen, events) {
    if (!this.memoryEnabled) return;
    const parentViolations = new Set(parent.evaluation.violations);
    const childViolations = new Set(child.evaluation.violations);

    for (const violation of parentViolations) {
      if (childViolations.has(violation)) continue;
      if (!child.signature) continue;
      const family = familyKeyForViolation(violation);
      // an inherited hint that removed the violation it was aimed at: a HIT
      if (child.source === 'directed') {
        this.stats.hintHits++;
        this.stats.restoredSkillsUsed++;
      }
      const applied = (child.edits || []).find(e => e && editFamilyKey(e) === family);
      const hint = applied && applied.kind === 'SET_ARG'
        ? { key: `SET_ARG:${applied.tool}:${applied.param}`, value: applied.value }
        : (applied && applied.kind === 'INSERT_CALL_ARG'
          ? { key: `INSERT_CALL:${applied.tool}`, value: applied.value }
          : null);
      this.ledger.noteSuccess({
        taskId: task.id, signature: violation, transformId: child.signature, gen,
        witnesses: [], hint,
      });
      if (hint) this.noteHint(hint.key, hint.value);
      events.push({ type: 'repair', gen, taskId: task.id, signature: violation, operator: child.signature, hint });
    }

    for (const violation of childViolations) {
      if (parentViolations.has(violation)) continue;
      if (!child.signature) continue;
      // a directed proposal that did not remove the violation it was aimed at: a MISS
      if (child.source === 'directed') this.stats.hintMisses++;
      this.ledger.noteAttributableFailure({
        taskId: task.id, signature: violation, transformId: child.signature, gen, message: '',
      });
      events.push({ type: 'failure', gen, taskId: task.id, signature: violation, operator: child.signature });
    }
  }

  /* --------------------------------------------------------------- runner */

  async runTask(task) {
    const rng = makeRng((this.seed ^ hash(task.id)) >>> 0);
    this.rng = rng;                 // the family order now consumes it -> seeds differ
    this.strictTask = !!task.strict;
    const events = [];
    const input = taskInput(task);
    let evaluations = 0;

    const seedGrade = await this.grader.grade(task.seed, task, input);
    evaluations++;
    const seed = {
      id: `${task.id}#0`, parentId: null, gen: 0, code: task.seed, signature: null, source: 'seed',
      taskId: task.id, lineageOps: [], evaluation: seedGrade.public, score: seedGrade.public.score,
      edit: null,
    };
    let population = [seed];
    let champion = seed;
    let solved = false;
    const history = [];

    for (let gen = 1; gen <= this.generations && evaluations < this.budget && !solved; gen++) {
      this.currentGen = gen;
      // on a strict task a single repair is invisible in the fitness: alternate between
      // LEARNING (one repair at a time, which reveals which slot was fixed) and EXPLOITING
      // (a composed repair, which is the only way to reach the goal)
      this.preferComposed = this.strictTask ? (gen % 2 === 0) : false;
      const children = [];
      // The champion is the most-repaired program, so on a strict task it has too few
      // remaining defects to compose. The SEED stays in the parent set on purpose: a composed
      // repair must start from a program that still carries ALL the defects.
      const parents = [...population].sort(rank).slice(0, 3);
      if (!parents.includes(seed)) parents.push(seed);
      for (const parent of parents) {
        if (evaluations >= this.budget) break;
        const presentTools = [...new Set(pipelineOf(parent.code).map(p => p.tool))];
        const proposals = this.propose(parent, task.id, presentTools);
        if (!proposals.length) continue;
        const proposal = proposals[0];
        if (proposal.familyKey && proposal.valueKey) this.markTried(task.id, proposal.familyKey, proposal.valueKey);
        const evaluation = await this.grader.grade(proposal.code, task, input);
        evaluations++;
        const child = {
          id: `${task.id}#${gen}.${children.length}`, parentId: parent.id, gen,
          code: proposal.code, signature: proposal.signature, source: proposal.source,
          taskId: task.id, lineageOps: [...(parent.lineageOps || []), proposal.signature],
          evaluation: evaluation.public, score: evaluation.public.score, edit: proposal.edit || null,
          edits: proposal.edits || (proposal.edit ? [proposal.edit] : []),
        };
        this.attribute(parent, child, task, gen, events);
        children.push(child);
      }

      const pool = [...population, ...children].sort(rank);
      const seen = new Set();
      population = [];
      for (const organism of pool) {
        if (seen.has(organism.code)) continue;
        seen.add(organism.code);
        population.push(organism);
        if (population.length >= this.populationSize) break;
      }
      if (!population.includes(seed)) population[population.length - 1] = seed;
      champion = population[0];
      solved = champion.score >= 1;
      history.push({
        gen, evaluations, score: Number(champion.score.toFixed(3)),
        violations: champion.evaluation.violations.length,
        population: population.length,
        skills: this.ledger.skills.size,
      });
    }

    const final = await this.grader.grade(champion.code, task, input);
    evaluations++;
    const composed = (champion.lineageOps || []).some(op => String(op).includes('+'));

    return {
      taskId: task.id,
      set: task.set,
      family: task.family,
      success: final.private.full,
      score: final.public.score,
      evaluations,
      champion: {
        code: champion.code, signature: champion.signature, lineageOps: champion.lineageOps,
        source: champion.source, edits: champion.lineageOps,
      },
      solvedByComposition: composed && final.private.full,
      violations: final.public.violations,
      events,
      history,
      expected: final.private.expected,
      memoryStats: { ...this.stats },
    };
  }
}

function hash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
