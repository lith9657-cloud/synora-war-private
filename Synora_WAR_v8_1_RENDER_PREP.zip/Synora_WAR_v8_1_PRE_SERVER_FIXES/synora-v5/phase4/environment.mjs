/**
 * Synora WAR v5 — PHASE 4: the CROSS-DOMAIN environment.
 *
 * A SECOND, structurally different experimental domain. It is NOT a file-repair domain.
 *
 * WHAT THE DOMAIN IS
 * ------------------
 * A freight company settles shipments with a TARIFF TABLE (a set of rules). A rule is a band:
 * a low bound, a high bound and a factor. A shipment has a class, and the class has a
 * multiplier. The settlement of a shipment is:
 *
 *     settlement = amount x bandFactor(amount) x classMultiplier(class)
 *
 * A rule therefore depends on TWO facts (the band bounds AND the class multiplier) — the
 * organism has to COMPOSE them, not just look one up.
 *
 * WHY THIS IS STRUCTURALLY DIFFERENT FROM PHASE 3
 * ----------------------------------------------
 *   Phase 3 (PST): a workspace of FILES; the organisms filter, sort, count and join file
 *                   entries; the answer is a string built from file names.
 *   Phase 4 (here): a knowledge base of RULES and CASES; the organisms must RECALL a rule
 *                   (its bounds), look a class multiplier up, and COMBINE both into a
 *                   numeric settlement; some tasks aggregate over a rule-selected subset;
 *                   some tasks must select the largest/smallest case of a rule-selected
 *                   subset before settling it.
 *   The data structures (records with typed fields, a band table, a multiplier table) and the
 *   operations (band matching, multiplication, aggregation over a rule-selected subset) are
 *   disjoint from the file operations of Phase 3.
 *
 * WHAT IS PUBLIC AND WHAT IS HIDDEN
 * ---------------------------------
 * PUBLIC: the tariff table, the class multipliers, the case list, the tool contracts, the
 *         parameter pool, the goal of each task, the seed program.
 * HIDDEN: the expected settlement of each task (./secrets.mjs — imported by the grader only).
 *
 * The KEY POINT of the domain: the rule bounds are NOT readable by a program. The organism can
 * only call the tools with LITERAL arguments, so to apply the band [500,1499) it must *know*
 * that band and *write* its bounds into the program. A program cannot look the band up in the
 * table. Therefore, a rule that was learned in one session has to be RECALLED (as a literal)
 * in a later session — which is exactly what the persistent memory is for.
 *
 * THE PARAMETER POOL AND ITS ORDER
 * --------------------------------
 * The pool is the DOMAIN's parameter space (every real shipment id, every real band bound,
 * every real unit / rate / class / count / sort direction) — not an invented handicap.
 *
 * Its ORDER matters for how expensive a blind search is, so it must not be chosen to favour
 * either arm. It is therefore a FIXED PSEUDO-RANDOM PERMUTATION (a documented Fisher-Yates
 * shuffle with a documented seed), not a hand-written order. The seed can be changed with
 * SYNORA_PHASE4_POOL_SEED to run the ORDER-SENSITIVITY check reported in the Phase-4 report;
 * the default is the value used for the headline numbers.
 */
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/** PUBLIC tariff table: the bands and their factors. */
export const BANDS = [
  { low: 0, high: 499, factor: 1 },
  { low: 500, high: 1499, factor: 2 },
  { low: 1500, high: 4000, factor: 3 },
];

/** PUBLIC class multipliers. */
export const CLASS_MULT = { A: 1, B: 2, C: 3 };

/** PUBLIC case list. */
export const CASES = [
  { id: 'S-01', cls: 'A', amount: 320 },
  { id: 'S-02', cls: 'B', amount: 780 },
  { id: 'S-03', cls: 'C', amount: 640 },
  { id: 'S-04', cls: 'B', amount: 2200 },
  { id: 'S-05', cls: 'A', amount: 950 },
  { id: 'S-06', cls: 'C', amount: 1400 },
  { id: 'S-07', cls: 'B', amount: 640 },
  { id: 'S-08', cls: 'A', amount: 120 },
  { id: 'S-09', cls: 'C', amount: 1800 },
  { id: 'S-10', cls: 'B', amount: 1500 },
  { id: 'S-11', cls: 'A', amount: 760 },
  { id: 'S-12', cls: 'C', amount: 250 },
  { id: 'S-13', cls: 'B', amount: 890 },
  { id: 'S-14', cls: 'A', amount: 1100 },
  { id: 'S-15', cls: 'C', amount: 500 },
  { id: 'S-16', cls: 'B', amount: 1300 },
  { id: 'S-17', cls: 'A', amount: 350 },
  { id: 'S-18', cls: 'C', amount: 1250 },
  { id: 'S-19', cls: 'B', amount: 1100 },
  { id: 'S-20', cls: 'A', amount: 1900 },
];

/**
 * Tool contracts. `args` names the argument slots in order; the FIRST slot is the piped one
 * when it is named 'entries' or 'text' (the same convention as the Phase-2/3 environments, so
 * the operators and the grader of Phase 3 work unchanged).
 */
export const TOOLS = {
  listCases: { args: [], ret: 'entries', piped: false },
  caseOf: { args: ['id'], ret: 'entry', piped: false },
  classOf: { args: ['entries'], ret: 'string' },
  bandOf: { args: ['entries', 'low', 'high'], ret: 'entry' },
  multOf: { args: ['entries'], ret: 'entry' },
  settle: { args: ['entries'], ret: 'number' },
  totalOf: { args: ['entries'], ret: 'number' },
  countOf: { args: ['entries'], ret: 'number' },
  filterBand: { args: ['entries', 'low', 'high'], ret: 'entries' },
  filterClass: { args: ['entries', 'class'], ret: 'string' },
  sortByAmount: { args: ['entries', 'dir'], ret: 'entries' },
  headOf: { args: ['entries'], ret: 'entry' },
  nthOf: { args: ['entries', 'n'], ret: 'entry' },
  formatMoney: { args: ['text', 'unit'], ret: 'string' },
  applyRate: { args: ['text', 'rate'], ret: 'number' },
};

function bandFactor(low, high) {
  const band = BANDS.find(b => b.low === low && b.high === high);
  return band ? band.factor : null;
}

function inBand(entry, low, high) {
  return entry.amount >= low && entry.amount <= high;
}

/** Implementations, bound inside the sandbox worker. */
export function makeTools(trace) {
  const t = (name, fn) => (...args) => {
    if (trace) trace.push({ tool: name, args: args.map(a => (typeof a === 'object' ? JSON.parse(JSON.stringify(a)) : a)) });
    return fn(...args);
  };
  return {
    listCases: t('listCases', () => CASES.map(c => ({ ...c }))),
    caseOf: t('caseOf', (id) => {
      const found = CASES.find(c => c.id === id);
      return found ? { ...found } : null;
    }),
    classOf: t('classOf', (entry) => (entry && entry.cls) || null),
    bandOf: t('bandOf', (entry, low, high) => {
      if (!entry) return null;
      return { ...entry, bandLow: low, bandHigh: high, factor: bandFactor(low, high) };
    }),
    multOf: t('multOf', (entry) => {
      if (!entry) return null;
      const mult = CLASS_MULT[entry.cls];
      return { ...entry, mult: mult === undefined ? null : mult };
    }),
    settle: t('settle', (entry) => {
      if (!entry || entry.factor === null || entry.mult === null || entry.mult === undefined) return null;
      return entry.amount * entry.factor * entry.mult;
    }),
    totalOf: t('totalOf', (entries) => (entries || []).reduce((a, e) => a + e.amount, 0)),
    countOf: t('countOf', (entries) => (entries || []).length),
    filterBand: t('filterBand', (entries, low, high) => (entries || []).filter(e => inBand(e, low, high))),
    filterClass: t('filterClass', (entries, cls) => (entries || []).filter(e => e.cls === cls)),
    sortByAmount: t('sortByAmount', (entries, dir) => {
      const list = [...(entries || [])];
      list.sort((x, y) => (dir === 'desc' ? y.amount - x.amount : x.amount - y.amount));
      return list;
    }),
    headOf: t('headOf', (entries) => (entries && entries.length ? { ...entries[0] } : null)),
    nthOf: t('nthOf', (entries, n) => {
      if (!entries || !entries.length) return null;
      const index = Math.max(0, Math.min(entries.length - 1, (Number(n) || 1) - 1));
      return { ...entries[index] };
    }),
    formatMoney: t('formatMoney', (number, unit) => `${number} ${unit}`),
    applyRate: t('applyRate', (number, rate) => (typeof number === 'number' ? number * rate : null)),
  };
}

/** The DOMAIN's parameter space, in the order the domain description lists the tables. */
const DOMAIN_PARAMETERS = [
  // the band bounds of the tariff table
  0, 500, 1500, 499, 1499, 4000,
  // the units
  'USD', 'EUR', 'SAR',
  // the handling rates
  0.9, 0.75, 1.25,
  // the classes
  'A', 'B', 'C',
  // the counts
  1, 2, 3,
  // the sort direction
  'asc', 'desc',
  // the shipment ids
  ...CASES.map(c => c.id),
];

/** The seed of the FIXED pool permutation (documented; override for the sensitivity check). */
export const POOL_SEED = Number(process.env.SYNORA_PHASE4_POOL_SEED || 20241025);

function shuffle(values, seed) {
  const out = [...values];
  let state = (seed >>> 0) || 1;
  const next = () => {
    state ^= state << 13; state >>>= 0;
    state ^= state >> 17;
    state ^= state << 5; state >>>= 0;
    return state / 0xffffffff;
  };
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(next() * (i + 1)) % (i + 1);
    const tmp = out[i]; out[i] = out[j]; out[j] = tmp;
  }
  return out;
}

/**
 * The PUBLIC parameter pool: every value a solver may legitimately write into an argument
 * slot. Its SIZE is the search space a blind arm has to sweep; its ORDER is a fixed
 * pseudo-random permutation so that neither arm is favoured by a hand-written ordering.
 */
export const VALUE_POOL = shuffle(DOMAIN_PARAMETERS, POOL_SEED);

export const TOOL_NAMES = Object.keys(TOOLS);

/** The property names a trailing field access may carry in this domain. */
export const FIELD_NAMES = ['id', 'cls', 'amount', 'factor', 'mult'];

/** The position of a value in the pool (used by the report to explain the search cost). */
export function poolPosition(value) {
  return VALUE_POOL.findIndex(v => v === value);
}
