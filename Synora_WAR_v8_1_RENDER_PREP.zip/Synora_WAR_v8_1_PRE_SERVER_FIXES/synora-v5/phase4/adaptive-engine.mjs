import { PstEngine } from './engine.mjs';

/** Experimental adaptive policy with per-hint evidence (separate from global counters). */
export class AdaptivePstEngine extends PstEngine {
  constructor(options = {}) {
    super(options);
    // hintId -> { hits, misses, contexts: Map<context,{hits,misses}> }
    this.hintEvidence = new Map();
    this._lastHintByKey = new Map();
    this._seenOutcomeEvents = new Set();
  }

  get memoryEnabled() { return this.mode === 'adaptive' || super.memoryEnabled; }

  _hintId(key, value) { return `${key}::${JSON.stringify(value)}`; }

  _evidence(key, value) {
    const id = this._hintId(key, value);
    if (!this.hintEvidence.has(id)) this.hintEvidence.set(id, { key, value, hits: 0, misses: 0, contexts: new Map() });
    return this.hintEvidence.get(id);
  }

  /** Record outcome for the exact hint and the violation family/context that was targeted. */
  recordHintOutcome({ key, value, context = 'unknown', success, eventId = null }) {
    if (key == null || value === undefined || typeof success !== 'boolean') return;
    if (eventId != null) {
      const eventKey = String(eventId);
      if (this._seenOutcomeEvents.has(eventKey)) return;
      this._seenOutcomeEvents.add(eventKey);
    }
    const item = this._evidence(key, value);
    const field = success ? 'hits' : 'misses';
    item[field]++;
    if (!item.contexts.has(context)) item.contexts.set(context, { hits: 0, misses: 0 });
    item.contexts.get(context)[field]++;
  }

  hintFor(key, context = null) {
    const hint = super.hintFor(key);
    if (this.mode !== 'adaptive' || hint == null) return hint;
    // High-budget abstention remains a conservative benchmarked policy, not learned confidence.
    if (this.budget >= 80) return null;
    const evidence = this.hintEvidence.get(this._hintId(key, hint));
    // When the caller knows the active violation, use only evidence from that context.
    // An omitted context retains conservative legacy aggregate behavior for diagnostics/API users.
    const scoped = evidence && context != null ? evidence.contexts.get(String(context)) : evidence;
    const hits = scoped ? scoped.hits : 0;
    const misses = scoped ? scoped.misses : 0;
    // Require repeated, context-local negative evidence; unknown contexts do not inherit misses.
    if (scoped && misses >= 2 && misses > hits) return null;
    this._lastHintByKey.set(key, hint);
    return hint;
  }

  attribute(parent, child, task, gen, events) {
    if (this.mode === 'adaptive' && child?.source === 'directed') {
      const edits = child.edits || [];
      for (const edit of edits) {
        if (!edit) continue;
        let key = null;
        if (edit.kind === 'SET_ARG') key = `SET_ARG:${edit.tool}:${edit.param}`;
        else if (edit.kind === 'INSERT_CALL_ARG') key = `INSERT_CALL:${edit.tool}`;
        if (!key) continue;
        const value = edit.value;
        const before = new Set(parent?.evaluation?.violations || []);
        const after = new Set(child?.evaluation?.violations || []);
        // Attribute only against a violation that disappeared or appeared in this transition.
        const eventBase = `${task?.id ?? 'task'}|${gen ?? 'gen'}|${child?.signature ?? child?.code ?? ''}|${key}|${JSON.stringify(value)}`;
        for (const violation of before) {
          if (!after.has(violation)) this.recordHintOutcome({ key, value, context: String(violation), success: true, eventId: `${eventBase}|hit|${violation}` });
        }
        for (const violation of after) {
          if (!before.has(violation)) this.recordHintOutcome({ key, value, context: String(violation), success: false, eventId: `${eventBase}|miss|${violation}` });
        }
      }
    }
    return super.attribute(parent, child, task, gen, events);
  }
}
