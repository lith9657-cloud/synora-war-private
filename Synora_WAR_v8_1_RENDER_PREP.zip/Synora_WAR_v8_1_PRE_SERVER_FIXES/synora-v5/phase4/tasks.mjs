/**
 * Synora WAR v5 — PHASE 4: the CROSS-DOMAIN task specifications.
 *
 * THREE GROUPS, with a hard separation:
 *   A — ACQUISITION: the system meets them so that it can acquire the rules.
 *   B — GENERALISATION: new structures and new shipments.
 *   C — FINAL HELD-OUT: never used to design, tune, or debug anything. Its answers are not
 *       visible to the solver during the search (only the one-way grader sees them).
 *
 * WHAT IS PUBLIC HERE: the goal, the tools, the tariff table, the parameters that appear in
 *                      the goal, the budget of tool calls, the scoring rule, the seed program.
 * WHAT IS NOT PUBLIC:  the expected settlement (it lives in ./secrets.mjs, grader-only).
 *
 * The seed programs are PARTIALLY WRONG on purpose: each one carries exactly the defects the
 * task is meant to exercise, so the grader's categories point at real slots.
 *
 * THE DESIGN RULES THAT MATTER FOR THE MEASUREMENT
 * -------------------------------------------------
 *  1. The DOMINANT rule (the band [500,1499)) is the one the acquisition group ends on, so
 *     the memory carries it into the evaluation sessions. The MINORITY bands ([0,499) and
 *     [1500,4000]) appear in the held-out group on purpose: the inherited hint is WRONG
 *     there, and the cost of that wrongness is measured, not hidden.
 *  2. Every task uses a shipment that its own group did not use before, so no answer can be
 *     reused across groups.
 *  3. Strict tasks (all-or-nothing) exist because they are the only place where a COMPOSED
 *     repair can be reached; the rest are hill-climbable so that the COST of a solution is
 *     measurable.
 *  4. No task can be solved by memorising an answer: the goal asks for a settlement that
 *     depends on the shipment's amount, its band and its class.
 */

export const GROUPS = { A: 'acquisition', B: 'generalisation', C: 'final_heldout' };

export const TASKS = [
  /* ================================================================ A — acquisition */
  {
    id: 'A1_settle_b2_strict', group: 'A', strict: true, maxCalls: 7, valueType: 'number',
    goal: 'احسب قيمة تسوية الشحنة S-11',
    goalEn: 'the settlement value of shipment S-11',
    required: ['caseOf', 'bandOf', 'multOf', 'settle'],
    seed: "function solution(input){return settle(multOf(bandOf(caseOf('S-11'),0,499)))}",
    note: 'both bounds are wrong, so a composed repair is required (the dominant band)',
  },
  {
    id: 'A2_settle_b2_num', group: 'A', strict: false, maxCalls: 7, valueType: 'number',
    goal: 'احسب قيمة تسوية الشحنة S-02',
    goalEn: 'the settlement value of shipment S-02',
    required: ['caseOf', 'bandOf', 'multOf', 'settle'],
    seed: "function solution(input){return settle(multOf(bandOf(caseOf('S-02'),0,1499)))}",
    note: 'the dominant band: the lower bound is wrong',
  },
  {
    id: 'A3_settle_b2_str', group: 'A', strict: false, maxCalls: 8, valueType: 'string',
    goal: 'احسب قيمة تسوية الشحنة S-05 بالدولار',
    goalEn: 'the settlement value of shipment S-05, in USD',
    required: ['caseOf', 'bandOf', 'multOf', 'settle', 'formatMoney'],
    seed: "function solution(input){return formatMoney(settle(multOf(bandOf(caseOf('S-05'),500,499))),'EUR')}",
    note: 'the upper bound AND the unit are wrong',
  },
  {
    id: 'A4_count_band2', group: 'A', strict: false, maxCalls: 6, valueType: 'number',
    goal: 'كم شحنة يقع مقدارها بين 500 و1499؟',
    goalEn: 'how many shipments fall in the band [500,1499]',
    required: ['listCases', 'filterBand', 'countOf'],
    seed: "function solution(input){return countOf(filterBand(listCases(),0,1499))}",
    note: 'the lower bound of the filter is wrong',
  },
  {
    id: 'A5_total_class_b', group: 'A', strict: false, maxCalls: 7, valueType: 'number',
    goal: 'ما مجموع مبالغ الشحنات من فئة B؟',
    goalEn: 'the total amount of the shipments of class B',
    required: ['listCases', 'filterClass', 'totalOf'],
    seed: "function solution(input){return totalOf(listCases())}",
    note: 'the class filter step is MISSING, and it needs a class literal',
  },
  {
    id: 'A6_settle_rate', group: 'A', strict: false, maxCalls: 9, valueType: 'number',
    goal: 'احسب تسوية الشحنة S-03 ثم طبّق نسبة 0.9',
    goalEn: 'the settlement of shipment S-03, then apply the rate 0.9',
    required: ['caseOf', 'bandOf', 'multOf', 'settle', 'applyRate'],
    seed: "function solution(input){return applyRate(settle(multOf(bandOf(caseOf('S-03'),500,1499))),0.75)}",
    note: 'the handling rate is wrong',
  },
  {
    id: 'A7_settle_wrongid', group: 'A', strict: false, maxCalls: 7, valueType: 'number',
    goal: 'احسب قيمة تسوية الشحنة S-07',
    goalEn: 'the settlement value of shipment S-07',
    required: ['caseOf', 'bandOf', 'multOf', 'settle'],
    seed: "function solution(input){return settle(multOf(bandOf(caseOf('S-01'),500,1499)))}",
    note: 'the shipment id is wrong (a copy-paste defect): the hint learned here is task-specific',
  },
  {
    id: 'A8_total_band2', group: 'A', strict: false, maxCalls: 6, valueType: 'number',
    goal: 'ما مجموع مبالغ الشحنات التي بين 500 و1499؟',
    goalEn: 'the total amount of the shipments in the band [500,1499]',
    required: ['listCases', 'filterBand', 'totalOf'],
    seed: "function solution(input){return totalOf(filterBand(listCases(),0,1499))}",
    note: 'the dominant band again, and the LAST acquisition task: the memory ends holding it',
  },

  /* ================================================================ B — generalisation */
  {
    id: 'B1_settle_b2_num', group: 'B', strict: false, maxCalls: 7, valueType: 'number',
    goal: 'احسب قيمة تسوية الشحنة S-13',
    goalEn: 'the settlement value of shipment S-13',
    required: ['caseOf', 'bandOf', 'multOf', 'settle'],
    seed: "function solution(input){return settle(multOf(bandOf(caseOf('S-13'),0,1499)))}",
    note: 'new shipment, dominant band: the learned lower bound should transfer',
  },
  {
    id: 'B2_settle_b2_str', group: 'B', strict: false, maxCalls: 8, valueType: 'string',
    goal: 'احسب قيمة تسوية الشحنة S-14 بالدولار',
    goalEn: 'the settlement value of shipment S-14, in USD',
    required: ['caseOf', 'bandOf', 'multOf', 'settle', 'formatMoney'],
    seed: "function solution(input){return formatMoney(settle(multOf(bandOf(caseOf('S-14'),500,499))),'USD')}",
    note: 'new shipment, dominant band: the learned upper bound should transfer',
  },
  {
    id: 'B3_class_of', group: 'B', strict: false, maxCalls: 5, valueType: 'string',
    goal: 'ما فئة الشحنة S-10؟',
    goalEn: 'the class of shipment S-10',
    required: ['caseOf', 'classOf'],
    seed: "function solution(input){return classOf(caseOf('S-01'))}",
    note: 'NEW STRUCTURE; uses S-10, disjoint from acquisition and held-out shipment IDs; the inherited id hint is WRONG here (harm case)',
  },
  {
    id: 'B4_settle_b2_rate', group: 'B', strict: false, maxCalls: 9, valueType: 'number',
    goal: 'احسب تسوية الشحنة S-16 ثم طبّق نسبة 0.9',
    goalEn: 'the settlement of shipment S-16, then apply the rate 0.9',
    required: ['caseOf', 'bandOf', 'multOf', 'settle', 'applyRate'],
    seed: "function solution(input){return applyRate(settle(multOf(bandOf(caseOf('S-16'),0,1499))),0.75)}",
    note: 'the lower bound AND the rate are wrong',
  },
  {
    id: 'B5_count_class_a', group: 'B', strict: false, maxCalls: 6, valueType: 'number',
    goal: 'كم شحنة من فئة A؟',
    goalEn: 'how many shipments are of class A',
    required: ['listCases', 'filterClass', 'countOf'],
    seed: "function solution(input){return countOf(filterClass(listCases(),'B'))}",
    note: 'NEW STRUCTURE (count over a class); the class hint of A5 was an INSERT hint, so it does NOT apply to this SET slot',
  },
  {
    id: 'B6_settle_b1_num', group: 'B', strict: false, maxCalls: 7, valueType: 'number',
    goal: 'احسب قيمة تسوية الشحنة S-17',
    goalEn: 'the settlement value of shipment S-17',
    required: ['caseOf', 'bandOf', 'multOf', 'settle'],
    seed: "function solution(input){return settle(multOf(bandOf(caseOf('S-17'),500,1499)))}",
    note: 'the MINORITY band: the inherited hint is wrong here',
  },
  {
    id: 'B7_settle_b3_num', group: 'B', strict: false, maxCalls: 7, valueType: 'number',
    goal: 'احسب قيمة تسوية الشحنة S-20',
    goalEn: 'the settlement value of shipment S-20',
    required: ['caseOf', 'bandOf', 'multOf', 'settle'],
    seed: "function solution(input){return settle(multOf(bandOf(caseOf('S-20'),0,1499)))}",
    note: 'the other MINORITY band',
  },
  {
    id: 'B8_total_band1', group: 'B', strict: false, maxCalls: 6, valueType: 'number',
    goal: 'ما مجموع مبالغ الشحنات التي أقل من 500؟',
    goalEn: 'the total amount of the shipments below 500',
    required: ['listCases', 'filterBand', 'totalOf'],
    seed: "function solution(input){return totalOf(filterBand(listCases(),0,1499))}",
    note: 'the upper bound of a MINORITY band is wrong',
  },

  /* ================================================================ C — final held-out */
  {
    id: 'C1_settle_b2_num', group: 'C', strict: false, maxCalls: 7, valueType: 'number',
    goal: 'احسب قيمة تسوية الشحنة S-15',
    goalEn: 'the settlement value of shipment S-15',
    required: ['caseOf', 'bandOf', 'multOf', 'settle'],
    seed: "function solution(input){return settle(multOf(bandOf(caseOf('S-15'),0,1499)))}",
    note: 'new shipment, dominant band: the core transfer case',
  },
  {
    id: 'C2_settle_b2_str', group: 'C', strict: false, maxCalls: 8, valueType: 'string',
    goal: 'احسب قيمة تسوية الشحنة S-18 بالدولار',
    goalEn: 'the settlement value of shipment S-18, in USD',
    required: ['caseOf', 'bandOf', 'multOf', 'settle', 'formatMoney'],
    seed: "function solution(input){return formatMoney(settle(multOf(bandOf(caseOf('S-18'),500,499))),'USD')}",
    note: 'new shipment, dominant band: the core transfer case',
  },
  {
    id: 'C3_settle_b2_rate', group: 'C', strict: false, maxCalls: 9, valueType: 'number',
    goal: 'احسب تسوية الشحنة S-19 ثم طبّق نسبة 0.9',
    goalEn: 'the settlement of shipment S-19, then apply the rate 0.9',
    required: ['caseOf', 'bandOf', 'multOf', 'settle', 'applyRate'],
    seed: "function solution(input){return applyRate(settle(multOf(bandOf(caseOf('S-19'),0,1499))),0.75)}",
    note: 'the lower bound AND the rate are wrong',
  },
  {
    id: 'C4_largest_in_band2', group: 'C', strict: false, maxCalls: 10, valueType: 'number',
    goal: 'احسب قيمة تسوية أكبر شحنة بين 500 و1499',
    goalEn: 'the settlement of the largest shipment in the band [500,1499]',
    required: ['listCases', 'filterBand', 'sortByAmount', 'headOf', 'bandOf', 'multOf', 'settle'],
    seed: "function solution(input){return settle(multOf(bandOf(headOf(sortByAmount(filterBand(listCases(),0,1499),'desc')),500,1499)))}",
    note: 'NEW STRUCTURE (seven stages): select the rule subset, order it, take one, then settle it',
  },
  {
    id: 'C5_second_in_band2', group: 'C', strict: true, maxCalls: 11, valueType: 'number',
    goal: 'احسب قيمة تسوية ثاني أكبر شحنة بين 500 و1499',
    goalEn: 'the settlement of the second largest shipment in the band [500,1499]',
    required: ['listCases', 'filterBand', 'sortByAmount', 'nthOf', 'bandOf', 'multOf', 'settle'],
    seed: "function solution(input){return settle(multOf(bandOf(nthOf(sortByAmount(filterBand(listCases(),0,1499),'desc'),1),500,1499)))}",
    note: 'NEW STRUCTURE + two defects: the band bound and the rank',
  },
  {
    id: 'C6_settle_b3_num', group: 'C', strict: false, maxCalls: 7, valueType: 'number',
    goal: 'احسب قيمة تسوية الشحنة S-09',
    goalEn: 'the settlement value of shipment S-09',
    required: ['caseOf', 'bandOf', 'multOf', 'settle'],
    seed: "function solution(input){return settle(multOf(bandOf(caseOf('S-09'),0,1499)))}",
    note: 'the MINORITY band: the inherited hint is wrong here',
  },
  {
    id: 'C7_count_class_c', group: 'C', strict: false, maxCalls: 6, valueType: 'number',
    goal: 'كم شحنة من فئة C؟',
    goalEn: 'how many shipments are of class C',
    required: ['listCases', 'filterClass', 'countOf'],
    seed: "function solution(input){return countOf(filterClass(listCases(),'A'))}",
    note: 'the class slot has no transferable hint (the shape differs from A5)',
  },
  {
    id: 'C8_settle_b1_num', group: 'C', strict: false, maxCalls: 7, valueType: 'number',
    goal: 'احسب قيمة تسوية الشحنة S-12',
    goalEn: 'the settlement value of shipment S-12',
    required: ['caseOf', 'bandOf', 'multOf', 'settle'],
    seed: "function solution(input){return settle(multOf(bandOf(caseOf('S-12'),500,1499)))}",
    note: 'the MINORITY band: the inherited hint is wrong here',
  },
  {
    id: 'C9_settle_sar', group: 'C', strict: false, maxCalls: 9, valueType: 'string',
    goal: 'احسب قيمة تسوية الشحنة S-04 بالريال السعودي',
    goalEn: 'the settlement value of shipment S-04, in SAR',
    required: ['caseOf', 'bandOf', 'multOf', 'settle', 'formatMoney'],
    seed: "function solution(input){return formatMoney(settle(multOf(bandOf(caseOf('S-04'),0,1499))),'USD')}",
    note: 'the MINORITY band AND a unit that the acquisition never used: three wrong slots',
  },
  {
    id: 'C10_settle_wrongid', group: 'C', strict: false, maxCalls: 7, valueType: 'number',
    goal: 'احسب قيمة تسوية الشحنة S-08',
    goalEn: 'the settlement value of shipment S-08',
    required: ['caseOf', 'bandOf', 'multOf', 'settle'],
    seed: "function solution(input){return settle(multOf(bandOf(caseOf('S-02'),500,1499)))}",
    note: 'the id is wrong AND the band is the minority band: the inherited hints are all wrong here',
  },
];

export const TASK_IDS = TASKS.map(t => t.id);
export const byId = id => TASKS.find(t => t.id === id);
export const byGroup = group => TASKS.filter(t => t.group === group);
export const groupOf = id => (byId(id) || {}).group || null;

/** The runtime input handed to `solution(input)` (public). Every task of this domain is
 *  parameterless: the shipment is named inside the program, not passed in. */
export function taskInput(task) {
  return null;
}

/**
 * The structural fingerprint of a task, used ONLY by the analysis (never by the solver):
 * the pipeline shape, the number of stages, and whether the task is strict.
 */
export function structureOf(task) {
  return {
    id: task.id,
    group: task.group,
    tools: [...task.required].sort(),
    stages: task.required.length,
    strict: !!task.strict,
    valueType: task.valueType,
  };
}
