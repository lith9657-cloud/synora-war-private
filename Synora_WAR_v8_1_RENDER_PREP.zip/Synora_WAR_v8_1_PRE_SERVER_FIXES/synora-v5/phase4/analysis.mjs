/**
 * Synora WAR v5 — PHASE 4: offline analysis (cross-domain).
 *
 * Everything in this module runs AFTER the experiment and never touches the solver.
 *
 * It provides:
 *   1. the ANALYTIC defect families of a task (reference program vs. seed program) and the
 *      structural similarity between tasks — the same measures Phase 3 used, so that the two
 *      domains can be compared on the same scale,
 *   2. the aggregation of the raw per-run results into the reported metrics.
 *
 * The aggregation and the paired tests are IMPORTED UNCHANGED from the Phase-3 analysis
 * module (synora-v5/phase3/analysis.mjs), so the numbers of this phase and the numbers of
 * Phase 3 are produced by the same code. The Phase-3 module's own imports of the Phase-3
 * tasks/secrets are harmless here: this module is a MEASUREMENT INSTRUMENT, it never runs
 * the solver.
 */
import { TOOLS } from './environment.mjs';
import { findCalls } from './operators.mjs';
import { planFor } from './secrets.mjs';
import { TASKS, byId } from './tasks.mjs';

export { pairedUnits, compareArms, summariseArm, median, quantile } from '../phase3/analysis.mjs';

/** Build the reference program of a task from its private plan (analysis side only). */
export function referenceProgram(taskId) {
  const plan = planFor(taskId);
  if (!plan) return null;
  let expr = 'input';
  for (const call of plan.calls) {
    const [name, ...args] = call;
    const contract = TOOLS[name].args;
    const parts = args.map(a => JSON.stringify(a));
    if (contract[0] === 'entries' || contract[0] === 'text') parts.unshift(expr);
    expr = `${name}(${parts.join(', ')})`;
  }
  return `function solution(input){return ${expr}}`;
}

function literalOf(text) {
  const t = String(text).trim();
  if (/^'[^']*'$/.test(t)) return t.slice(1, -1);
  if (/^"[^"]*"$/.test(t)) return t.slice(1, -1);
  if (/^-?\d+(\.\d+)?$/.test(t)) return Number(t);
  return undefined;
}

/** The calls of a program, per tool, with their literal arguments. */
export function callsOf(code) {
  const map = new Map();
  for (const tool of Object.keys(TOOLS)) {
    for (const call of findCalls(code, tool)) {
      const args = call.args.map(a => literalOf(a.text));
      map.set(tool, { tool, args, count: map.has(tool) ? map.get(tool).count + 1 : 1 });
    }
  }
  return map;
}

/** The trailing property access of a program, if any. */
function fieldOf(code) {
  const m = /\)\.[A-Za-z_$][\w$]*/.exec(code);
  return m ? m[1] : null;
}

/**
 * The analytic defect families of a task: what is structurally wrong with the seed compared
 * with the reference program. This is a property of the TASK DESIGN (used to measure how
 * similar two tasks are), not something the solver is told.
 */
export function defectFamilies(taskId) {
  const task = byId(taskId);
  const reference = referenceProgram(taskId);
  if (!task || !reference) return [];
  const refCalls = callsOf(reference);
  const seedCalls = callsOf(task.seed);
  const families = [];
  for (const [tool, call] of refCalls) {
    if (!seedCalls.has(tool)) { families.push(`MISSING_CALL:${tool}`); continue; }
    const contract = TOOLS[tool].args;
    const seedCall = seedCalls.get(tool);
    for (let i = 1; i < contract.length; i++) {
      const param = contract[i];
      const refValue = call.args[i];
      const seedValue = seedCall.args[i];
      if (refValue === undefined) continue;
      if (seedValue === undefined) { families.push(`WRONG_ARG:${tool}:${param}`); continue; }
      if (refValue !== seedValue) families.push(`WRONG_ARG:${tool}:${param}`);
    }
  }
  for (const [tool] of seedCalls) {
    if (!refCalls.has(tool)) families.push(`EXTRA_CALL:${tool}`);
  }
  const refField = fieldOf(reference);
  const seedField = fieldOf(task.seed);
  if ((refField || null) !== (seedField || null)) families.push('WRONG_FIELD');
  return [...new Set(families)].sort();
}

function jaccard(a, b) {
  const A = new Set(a), B = new Set(b);
  if (!A.size && !B.size) return 1;
  let inter = 0;
  for (const x of A) if (B.has(x)) inter++;
  return inter / (A.size + B.size - inter);
}

/** Structural similarity between two tasks, in [0,1] (the Phase-3 formula, unchanged). */
export function similarity(a, b) {
  const fa = defectFamilies(a), fb = defectFamilies(b);
  const ta = byId(a), tb = byId(b);
  const toolsA = ta ? ta.required : [], toolsB = tb ? tb.required : [];
  return 0.6 * jaccard(fa, fb) + 0.4 * jaccard(toolsA, toolsB);
}

/** The similarity matrix + the per-task maximum similarity to the acquisition group. */
export function similarityReport() {
  const ids = TASKS.map(t => t.id);
  const matrix = {};
  for (const a of ids) {
    matrix[a] = {};
    for (const b of ids) matrix[a][b] = a === b ? 1 : Number(similarity(a, b).toFixed(3));
  }
  const maxSimInA = {};
  for (const id of ids) {
    const group = byId(id).group;
    if (group === 'A') { maxSimInA[id] = 1; continue; }
    const others = TASKS.filter(t => t.group === 'A').map(t => t.id);
    maxSimInA[id] = Number(Math.max(...others.map(o => matrix[id][o])).toFixed(3));
  }
  const classes = {};
  for (const id of ids) {
    const value = maxSimInA[id];
    const cls = value >= 0.95 ? 'clone_of_A' : value >= 0.75 ? 'near_A' : 'cross_structure';
    classes[id] = { group: byId(id).group, maxSimInA: value, class: cls, families: defectFamilies(id) };
  }
  return { matrix, maxSimInA, classes };
}
