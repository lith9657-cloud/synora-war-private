/**
 * Synora WAR v5 — PHASE 4: SESSION 2 — the evaluation session (cross-domain).
 *
 * A copy of the Phase-3 evaluation session with the four Phase-4 arms:
 *   --mode=cri         the persistent memory: the file written by the acquisition session is
 *                      restored and its value hints direct the search,
 *   --mode=base        NO persistent memory: no ledger at all (the baseline),
 *   --mode=noise       the memory file is restored but its VALUE HINTS are replaced by random
 *                      values from the domain's pool: the control for "useful knowledge" vs
 *                      "any hint at all",
 *   --mode=notransfer  the memory exists but the TRANSFER is blocked: the ledger is reset
 *                      before every task, so the skills learned inside a task are used inside
 *                      that task only (within-task learning, no cross-task inheritance),
 *   --mode=inprocess   the control: the acquisition runs inside this process and nothing is
 *                      written or read from a file. It must produce the same results as
 *                      --mode=cri (same seed, same budget, same engine).
 *
 * A FRESH PROCESS. It may obtain the memory in exactly one of these ways:
 *   --mode=cri        load the memory file written by session 1 (persistent memory),
 *   --mode=nocross    start with an empty ledger for every task (within-task learning only),
 *   --mode=base       no ledger at all,
 *   --mode=noise      load the memory file, but the value hints are randomised (the control),
 *   --mode=inprocess  run the acquisition INSIDE this process and then evaluate — the control
 *                     that proves the file-based memory carries exactly the same information as
 *                     the in-memory one (the two must produce identical results).
 *
 *   node synora-v5/phase3/evaluate.mjs --mode=cri --seed=1 --budget=250 \
 *        --memory=experiments/memory/acquire-seed1.json --groups=B,C \
 *        --out=experiments/phase3/eval-cri-seed1.json
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Ledger } from '../ledger.mjs';
import { Grader } from './grader.mjs';
import { PstEngine } from './engine.mjs';
import { AdaptivePstEngine } from './adaptive-engine.mjs';
import { LegacyAdaptivePstEngine } from './adaptive-legacy-engine.mjs';
import { byGroup, TASKS } from './tasks.mjs';
import { loadMemory } from '../phase3/memory.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));

function parseArgs(argv) {
  const args = { mode: 'cri', seed: 1, budget: 250, generations: 80, groups: 'B,C', out: 'experiments/phase3/eval.json', memory: null, acquireBudget: 250 };
  for (const raw of argv) {
    const m = /^--([^=]+)(?:=(.*))?$/.exec(raw);
    if (!m) continue;
    const key = m[1];
    const value = m[2] ?? 'true';
    if (key === 'groups') { args.groups = value; continue; }
    if (key === 'memory') { args.memory = value; continue; }
    if (key === 'mode') { args.mode = value; continue; }
    if (key === 'out') { args.out = value; continue; }
    if (key === 'acquire-budget') { args.acquireBudget = Number(value); continue; }
    if (key in args) args[key] = Number(value);
  }
  return args;
}

function hash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const grader = new Grader({ size: 2, timeoutMs: 700 });
  await grader.init();
  const started = Date.now();

  const groups = String(args.groups).split(',').map(g => g.trim()).filter(Boolean);
  const tasks = groups.flatMap(g => byGroup(g));
  if (!tasks.length) throw new Error(`no tasks for groups ${args.groups}`);

  let shared = null;
  let memoryInfo = { source: 'none' };

  if (args.mode === 'inprocess') {
    // CONTROL: the acquisition runs inside this process, the memory never leaves the heap.
    shared = new Ledger();
    for (const task of byGroup('A')) {
      // the in-process acquisition always uses the FULL acquisition budget, so that this
      // control is comparable with the file-based session at every evaluation budget
      const engine = new PstEngine({ grader, ledger: shared, mode: 'cri', seed: args.seed * 977 + hash(task.id), budget: args.acquireBudget, generations: args.generations });
      await engine.runTask(task);
    }
    memoryInfo = { source: 'in-process acquisition (no file)', skills: shared.skills.size };
  } else if (args.mode === 'cri' || args.mode === 'noise' || args.mode === 'adaptive') {
    if (!args.memory) throw new Error('--memory is required for this mode');
    const filePath = path.isAbsolute(args.memory) ? args.memory : path.join(HERE, '..', '..', args.memory);
    const loaded = loadMemory(filePath);
    shared = loaded.ledger;
    memoryInfo = {
      source: 'restored from file',
      path: path.relative(path.join(HERE, '..', '..'), filePath),
      fileSha256: loaded.fileSha256,
      payloadSha256: loaded.payloadSha256,
      skills: loaded.skills,
      refutations: loaded.refutations,
      createdAt: loaded.envelope.createdAt,
      writtenByPid: loaded.envelope.session ? loaded.envelope.session.pid : null,
    };
  }

  const runs = [];
  for (const task of tasks) {
    // 'notransfer': the memory is present but the knowledge may NOT cross the task boundary
    const ledger = args.mode === 'notransfer' ? new Ledger() : (shared || new Ledger());
    const Engine = args.mode === 'adaptive' ? AdaptivePstEngine : (args.mode === 'adaptive-legacy' ? LegacyAdaptivePstEngine : PstEngine);
    const engine = new Engine({
      grader, ledger,
      mode: args.mode === 'noise' ? 'noise' : (args.mode === 'base' ? 'base' : ((args.mode === 'adaptive' || args.mode === 'adaptive-legacy') ? 'adaptive' : 'cri')),
      seed: args.seed * 977 + hash(task.id),
      budget: args.budget, generations: args.generations,
    });
    const result = await engine.runTask(task);
    result.group = task.group;
    result.seed = args.seed;
    result.arm = args.mode;
    result.elapsedMs = 0;
    runs.push(result);
  }

  const payload = {
    session: 'evaluate',
    pid: process.pid,
    mode: args.mode,
    seed: args.seed,
    budget: args.budget,
    groups,
    memory: memoryInfo,
    rssMb: Math.round(process.memoryUsage().rss / (1024 * 1024)),
    memoryFileBytes: memoryInfo && memoryInfo.path && fs.existsSync(memoryInfo.path)
      ? fs.statSync(memoryInfo.path).size : null,
    tasks: tasks.map(t => t.id),
    results: runs.map(r => ({
      taskId: r.taskId, group: r.group, success: r.success, score: r.score, evaluations: r.evaluations,
      violations: r.violations, composed: r.solvedByComposition,
      champion: r.champion, memoryStats: r.memoryStats, history: r.history,
    })),
    elapsedMs: Date.now() - started,
  };
  const outPath = path.isAbsolute(args.out) ? args.out : path.join(HERE, '..', '..', args.out);
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, JSON.stringify(payload, null, 2));
  console.log(JSON.stringify({
    pid: payload.pid, mode: payload.mode, seed: payload.seed, budget: payload.budget,
    memory: memoryInfo,
    rssMb: Math.round(process.memoryUsage().rss / (1024 * 1024)),
    memoryFileBytes: memoryInfo && memoryInfo.path && fs.existsSync(memoryInfo.path)
      ? fs.statSync(memoryInfo.path).size : null,
    solved: payload.results.filter(r => r.success).length,
    total: payload.results.length,
    out: outPath,
  }, null, 2));
  await grader.close();
}

main().catch(err => { console.error(err); process.exit(1); });
