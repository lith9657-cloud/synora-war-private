/**
 * Synora WAR v5 — PHASE 4: the PRIVATE answer key.
 *
 * This file is imported by the GRADER ONLY. It is never imported by a solver-side module
 * (the environment, the operators, the engine, the task specifications) — the test
 * suite checks that statically.
 *
 * A plan is the reference PIPELINE of a task: the sequence of tool calls, with the literal
 * arguments the reference program uses. The grader executes the plan to obtain the expected
 * value and then compares it with the candidate's output. The solver never sees the plan,
 * the expected value, or the difference between them.
 *
 * The plan format is the Phase-2/3 format: a list of [tool, ...literalArgs]. The value of the
 * previous step is threaded into the first slot when that slot is the piped one ('entries'
 * or 'text' in the tool contract).
 */
import { BANDS, CLASS_MULT, CASES } from './environment.mjs';

const band = (low, high) => BANDS.find(b => b.low === low && b.high === high).factor;

function settlementOf(caseId, low, high) {
  const c = CASES.find(x => x.id === caseId);
  return c.amount * band(low, high) * CLASS_MULT[c.cls];
}

function totalOfBand(low, high) {
  return CASES.filter(c => c.amount >= low && c.amount <= high).reduce((a, c) => a + c.amount, 0);
}

function totalOfClass(cls) {
  return CASES.filter(c => c.cls === cls).reduce((a, c) => a + c.amount, 0);
}

function countOfBand(low, high) {
  return CASES.filter(c => c.amount >= low && c.amount <= high).length;
}

function countOfClass(cls) {
  return CASES.filter(c => c.cls === cls).length;
}

function orderedBand(low, high, dir, n) {
  const list = CASES.filter(c => c.amount >= low && c.amount <= high)
    .sort((x, y) => (dir === 'desc' ? y.amount - x.amount : x.amount - y.amount));
  return list[n - 1];
}

/** The reference plan of every task, keyed by task id. */
export const PLANS = {
  /* ---------------- A — acquisition ---------------- */
  A1_settle_b2_strict: { calls: [['caseOf', 'S-11'], ['bandOf', 500, 1499], ['multOf'], ['settle']] },
  A2_settle_b2_num: { calls: [['caseOf', 'S-02'], ['bandOf', 500, 1499], ['multOf'], ['settle']] },
  A3_settle_b2_str: { calls: [['caseOf', 'S-05'], ['bandOf', 500, 1499], ['multOf'], ['settle'], ['formatMoney', 'USD']] },
  A4_count_band2: { calls: [['listCases'], ['filterBand', 500, 1499], ['countOf']] },
  A5_total_class_b: { calls: [['listCases'], ['filterClass', 'B'], ['totalOf']] },
  A6_settle_rate: { calls: [['caseOf', 'S-03'], ['bandOf', 500, 1499], ['multOf'], ['settle'], ['applyRate', 0.9]] },
  A7_settle_wrongid: { calls: [['caseOf', 'S-07'], ['bandOf', 500, 1499], ['multOf'], ['settle']] },
  A8_total_band2: { calls: [['listCases'], ['filterBand', 500, 1499], ['totalOf']] },

  /* ---------------- B — generalisation ---------------- */
  B1_settle_b2_num: { calls: [['caseOf', 'S-13'], ['bandOf', 500, 1499], ['multOf'], ['settle']] },
  B2_settle_b2_str: { calls: [['caseOf', 'S-14'], ['bandOf', 500, 1499], ['multOf'], ['settle'], ['formatMoney', 'USD']] },
  B3_class_of: { calls: [['caseOf', 'S-10'], ['classOf']] },
  B4_settle_b2_rate: { calls: [['caseOf', 'S-16'], ['bandOf', 500, 1499], ['multOf'], ['settle'], ['applyRate', 0.9]] },
  B5_count_class_a: { calls: [['listCases'], ['filterClass', 'A'], ['countOf']] },
  B6_settle_b1_num: { calls: [['caseOf', 'S-17'], ['bandOf', 0, 499], ['multOf'], ['settle']] },
  B7_settle_b3_num: { calls: [['caseOf', 'S-20'], ['bandOf', 1500, 4000], ['multOf'], ['settle']] },
  B8_total_band1: { calls: [['listCases'], ['filterBand', 0, 499], ['totalOf']] },

  /* ---------------- C — final held-out ---------------- */
  C1_settle_b2_num: { calls: [['caseOf', 'S-15'], ['bandOf', 500, 1499], ['multOf'], ['settle']] },
  C2_settle_b2_str: { calls: [['caseOf', 'S-18'], ['bandOf', 500, 1499], ['multOf'], ['settle'], ['formatMoney', 'USD']] },
  C3_settle_b2_rate: { calls: [['caseOf', 'S-19'], ['bandOf', 500, 1499], ['multOf'], ['settle'], ['applyRate', 0.9]] },
  C4_largest_in_band2: { calls: [['listCases'], ['filterBand', 500, 1499], ['sortByAmount', 'desc'], ['headOf'], ['bandOf', 500, 1499], ['multOf'], ['settle']] },
  C5_second_in_band2: { calls: [['listCases'], ['filterBand', 500, 1499], ['sortByAmount', 'desc'], ['nthOf', 2], ['bandOf', 500, 1499], ['multOf'], ['settle']] },
  C6_settle_b3_num: { calls: [['caseOf', 'S-09'], ['bandOf', 1500, 4000], ['multOf'], ['settle']] },
  C7_count_class_c: { calls: [['listCases'], ['filterClass', 'C'], ['countOf']] },
  C8_settle_b1_num: { calls: [['caseOf', 'S-12'], ['bandOf', 0, 499], ['multOf'], ['settle']] },
  C9_settle_sar: { calls: [['caseOf', 'S-04'], ['bandOf', 1500, 4000], ['multOf'], ['settle'], ['formatMoney', 'SAR']] },
  C10_settle_wrongid: { calls: [['caseOf', 'S-08'], ['bandOf', 0, 499], ['multOf'], ['settle']] },
};

export function planFor(taskId) {
  return PLANS[taskId] || null;
}

/**
 * The expected VALUES, computed independently of the plan execution (a cross-check of the
 * answer key against the domain's arithmetic). Used by the test suite, never by the grader.
 */
export const EXPECTED = {
  A1_settle_b2_strict: settlementOf('S-11', 500, 1499),
  A2_settle_b2_num: settlementOf('S-02', 500, 1499),
  A3_settle_b2_str: `${settlementOf('S-05', 500, 1499)} USD`,
  A4_count_band2: countOfBand(500, 1499),
  A5_total_class_b: totalOfClass('B'),
  A6_settle_rate: settlementOf('S-03', 500, 1499) * 0.9,
  A7_settle_wrongid: settlementOf('S-07', 500, 1499),
  A8_total_band2: totalOfBand(500, 1499),
  B1_settle_b2_num: settlementOf('S-13', 500, 1499),
  B2_settle_b2_str: `${settlementOf('S-14', 500, 1499)} USD`,
  B3_class_of: CASES.find(c => c.id === 'S-10').cls,
  B4_settle_b2_rate: settlementOf('S-16', 500, 1499) * 0.9,
  B5_count_class_a: countOfClass('A'),
  B6_settle_b1_num: settlementOf('S-17', 0, 499),
  B7_settle_b3_num: settlementOf('S-20', 1500, 4000),
  B8_total_band1: totalOfBand(0, 499),
  C1_settle_b2_num: settlementOf('S-15', 500, 1499),
  C2_settle_b2_str: `${settlementOf('S-18', 500, 1499)} USD`,
  C3_settle_b2_rate: settlementOf('S-19', 500, 1499) * 0.9,
  C4_largest_in_band2: settlementOf('S-06', 500, 1499),
  C5_second_in_band2: settlementOf('S-16', 500, 1499),
  C6_settle_b3_num: settlementOf('S-09', 1500, 4000),
  C7_count_class_c: countOfClass('C'),
  C8_settle_b1_num: settlementOf('S-12', 0, 499),
  C9_settle_sar: `${settlementOf('S-04', 1500, 4000)} SAR`,
  C10_settle_wrongid: settlementOf('S-08', 0, 499),
};

export const EXPECTED_VALUES = Object.values(EXPECTED);
