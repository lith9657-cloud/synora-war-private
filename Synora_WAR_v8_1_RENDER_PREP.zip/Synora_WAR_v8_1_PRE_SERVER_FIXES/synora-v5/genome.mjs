/**
 * Synora WAR v5 — Genome: representation, failure signatures, and the repair operator library.
 *
 * ARTIFACT CONTRACT (unchanged from v4 on purpose): an organism is a single JavaScript source
 * string `function solution(a){...}`. Keeping the artifact identical is what allows the v4
 * engine to run on the very same benchmark as a baseline.
 *
 * WHAT IS NEW HERE:
 *  - A *signature* algebra over failures (numbers, exceptions, mismatches). Signatures are
 *    task-independent, so knowledge can travel between tasks.
 *  - A *semantic repair operator library*: generic, task-agnostic transformations of the source
 *    (remove an off-by-one decrement, install a null guard using the value the failing test
 *    asked for, extend a character class with Arabic letters, ...).
 *  - The operators are a FIXED SUBSTRATE (like an instruction set). What the system *learns*
 *    is the mapping failure-signature -> operator, plus which witnesses exist. That boundary is
 *    stated explicitly: the engine cannot invent new primitives, only compose and prioritise them.
 */

/* ------------------------------------------------------------------ tokenizer */

const TOKEN_RE = /(\/\/[^\n]*|\/\*[\s\S]*?\*\/)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')|(`(?:[^`\\]|\\.)*`)|(\b\d+(?:\.\d+)?\b)|([A-Za-z_$][\w$]*)|(<=|>=|===|!==|&&|\|\||[-+*/%<>=!?:.,;()[\]{}])/g;

/** Tokenise JS source. Comments and strings are kept as single tokens (never split). */
export function tokenize(code) {
  const tokens = [];
  let m;
  TOKEN_RE.lastIndex = 0;
  while ((m = TOKEN_RE.exec(code)) !== null) {
    const [value, comment, str, tpl, num, ident, punct] = m;
    let type = 'punct';
    if (comment) type = 'comment';
    else if (str) type = 'string';
    else if (tpl) type = 'template';
    else if (num) type = 'number';
    else if (ident) type = 'ident';
    else if (punct) type = 'punct';
    tokens.push({ type, value, start: m.index, end: m.index + value.length });
  }
  return tokens;
}

/** Cheap structural sanity check used to reject malformed edits. */
export function isBalanced(code) {
  const tokens = tokenize(code).filter(t => t.type !== 'comment');
  const stack = [];
  const pairs = { ')': '(', ']': '[', '}': '{' };
  for (const t of tokens) {
    if (t.value === '(' || t.value === '[' || t.value === '{') stack.push(t.value);
    else if (pairs[t.value]) {
      if (stack.pop() !== pairs[t.value]) return false;
    }
  }
  return stack.length === 0;
}

/* ------------------------------------------------------- failure signatures */

/**
 * Extract the expected literal from a failure message such as
 *   `Expected 3, got 2`  /  `Expected "hi", got "x"`  /  `Expected "", got undefined`
 * The literal is returned verbatim so it can be pasted into generated code.
 */
export function expectedLiteral(message) {
  const m = /Expected\s+([^\s,]+(?:\s*,\s*[^,]*?)?),\s*got\s+/i.exec(String(message || ''));
  if (!m) return null;
  let lit = m[1].trim();
  if (lit.endsWith(',') || lit.endsWith('.')) lit = lit.slice(0, -1);
  // cut at the first comma that separates the expected literal from extra prose
  if (lit.includes(',')) lit = lit.slice(0, lit.indexOf(',')).trim();
  if (!/^(".*"|'.*'|-?\d+(?:\.\d+)?|true|false|null|undefined)$/.test(lit)) {
    // keep only simple literals; otherwise fall back to a quoted string of the raw text
    return null;
  }
  return lit;
}

/**
 * Extract the demanded value from the TEST SOURCE itself, not only from the runtime message.
 * This matters: when the candidate throws, the assertion never executes and the runtime message
 * carries no "Expected ..." at all — yet the test source still states what was demanded.
 * A repairer that cannot read that value cannot install a correct guard.
 */
export function expectedFromTestSource(testSource) {
  const src = String(testSource || '');
  const patterns = [
    /!==\s*("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|-?\d+(?:\.\d+)?|true|false|null|undefined)/,
    /!=\s*("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|-?\d+(?:\.\d+)?|true|false|null|undefined)/,
    /===\s*("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|-?\d+(?:\.\d+)?|true|false|null|undefined)/,
    /==\s*("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|-?\d+(?:\.\d+)?|true|false|null|undefined)/,
  ];
  for (const pattern of patterns) {
    const m = pattern.exec(src);
    if (m) return m[1];
  }
  return null;
}

/**
 * Signature algebra. Signatures must be (a) derivable from a failure alone, (b) task independent,
 * so that a lesson learned on one task can be applied on another.
 *
 *   below_by_1 | below | above | negated | equal_type | threw:<Class> | mismatch
 */
export function signatureOf(failure) {
  const message = String((failure && failure.error) || '');
  const exp = expectedLiteral(message);
  const gotMatch = /,\s*got\s+([^\s]+)/i.exec(message);
  const gotRaw = gotMatch ? gotMatch[1] : null;
  const num = v => (v !== null && /^-?\d+(?:\.\d+)?$/.test(v) ? Number(v) : null);
  const e = num(exp), g = num(gotRaw);
  if (e !== null && g !== null) {
    if (g === e - 1) return 'below_by_1';
    if (g === -e && e !== 0) return 'negated';
    if (g < e) return 'below';
    if (g > e) return 'above';
    return 'equal_but_wrong';
  }
  const threw = /\b(TypeError|RangeError|ReferenceError|SyntaxError|URIError)\b/.exec(message);
  if (threw) return `threw:${threw[1]}`;
  if (exp !== null) {
    if (/^['\"]/.test(exp) || (gotRaw && /^['\"]/.test(gotRaw))) return 'string_mismatch';
    return 'type_mismatch';
  }
  return 'mismatch';
}

/** Human-readable relation used by the report. */
export function signatureLabel(sig) {
  return {
    below_by_1: 'value too small by exactly one (classic off-by-one)',
    below: 'value too small',
    above: 'value too large',
    negated: 'sign flipped',
    equal_but_wrong: 'right magnitude, wrong value',
    type_mismatch: 'wrong type',
    string_mismatch: 'string content differs',
    mismatch: 'generic mismatch',
  }[sig] || (sig.startsWith('threw:') ? `threw ${sig.slice(6)}` : sig);
}

/* ------------------------------------------------------ repair operator library */

const ARABIC_VOWELS = 'اويوأإآؤئ';

/**
 * Insert a guard statement right after the function's opening brace AND after any guards that
 * are already there. Order matters: a null guard must precede a length guard, otherwise the
 * length guard throws on null. This is what makes two-operator compositions work.
 */
export function insertGuard(code, guard) {
  const open = code.indexOf('{');
  if (open < 0) return null;
  let cursor = open + 1;
  const guardRe = /^\s*if\([^)]*\)\s*return[^;]*;/;
  for (let i = 0; i < 8; i++) {
    const rest = code.slice(cursor);
    const m = guardRe.exec(rest);
    if (!m) break;
    cursor += m[0].length;
  }
  return code.slice(0, cursor) + guard + code.slice(cursor);
}


const retExpr = code => {
  const m = /return\s+([^;}]+)/.exec(code);
  return m ? m[1].trim() : null;
};

/**
 * Every operator is generic: it must not mention a task, a file, or a variable name other than
 * the conventional parameter `a`. `applies` decides relevance; `apply` performs the edit.
 */
export const TRANSFORMS = [
  {
    id: 'LOOP_BOUND_REMOVE_MINUS_ONE',
    label: 'drop the `-1` from an array length bound',
    applies: code => /<\s*[A-Za-z_$][\w$.]*\.length\s*-\s*1/.test(code),
    apply: code => code.replace(/(<\s*[A-Za-z_$][\w$.]*\.length)\s*-\s*1/g, '$1'),
  },
  {
    id: 'LOOP_BOUND_INCREMENT',
    label: 'increment a numeric upper bound by one',
    applies: code => /[<>]=?\s*\d+/.test(code),
    apply: code => code.replace(/([<>]=?\s*)(\d+)\b/g, (_, op, n) => `${op}${Number(n) + 1}`),
  },
  {
    id: 'LOOP_BOUND_DECREMENT',
    label: 'decrement a numeric lower bound by one',
    applies: code => /[>]=?\s*\d+/.test(code),
    apply: code => code.replace(/([>]=?\s*)(\d+)\b/g, (_, op, n) => `${op}${Number(n) - 1}`),
  },
  {
    id: 'ADD_NULL_GUARD',
    label: 'guard a null/undefined input with the value the test demanded',
    applies: (code, ctx) => (ctx.expected !== null && ctx.expected !== undefined) && !/a\s*==\s*null/.test(code),
    apply: (code, ctx) => insertGuard(code, `if(a==null)return ${ctx.expected};`),
  },
  {
    id: 'ADD_TYPE_GUARD',
    label: 'guard a wrong input type with the value the test demanded',
    applies: (code, ctx) => (ctx.expected !== null && ctx.expected !== undefined) && /typeof/.test(code) === false && /\.[a-zA-Z]+\(|\[0\]|String\(|\.length/.test(code),
    apply: (code, ctx) => insertGuard(code, `if(typeof a==='undefined')return ${ctx.expected};`),
  },
  {
    id: 'USE_ABS',
    label: 'take the absolute value of the result',
    applies: (code, ctx) => ctx.signature === 'negated' && /return\s+[^;}]+/.test(code),
    apply: code => code.replace(/return\s+([^;}]+)/, (_, expr) => `return Math.abs(${expr.trim()})`),
  },
  {
    id: 'EXTEND_CHARCLASS_ARABIC',
    label: 'extend a character class with Arabic letters',
    // handles both `'chars'.includes(x)` (literal as receiver) and `.includes('chars')`
    applies: code => /(['"])[^'"]*\1\s*\.includes\s*\(|\.includes\(\s*(['"])[^'"]*\2\s*\)/.test(code) && !code.includes(ARABIC_VOWELS),
    apply: code => code
      .replace(/(['"])([^'"]*)\1(\s*\.includes\s*\()/g, (m, q, body, tail) => `${q}${body}${ARABIC_VOWELS}${q}${tail}`)
      .replace(/(\.includes\(\s*)(['"])([^'"]*)\2/g, (m, head, q, body) => `${head}${q}${body}${ARABIC_VOWELS}${q}`),
  },
  {
    id: 'TRIM_WHITESPACE_CLASS',
    label: 'trim all whitespace, not only spaces',
    applies: code => /\/\^\s*\+\|\s*\+\$\//.test(code),
    apply: code => code.replace(/\/\^\s*\+\|\s*\+\$\//g, '/^\\s+|\\s+$/'),
  },
  {
    id: 'STRIP_EDGE_DASHES',
    label: 'strip leading/trailing dashes from the result',
    applies: code => /return\s+[^;}]+/.test(code) && !/\^-\+/.test(code) && /['\"]-[^'\"]*['\"]|replace\(|split\(/.test(code),
    apply: code => code.replace(/return\s+([^;}]+)/, (_, expr) => `return String(${expr.trim()}).replace(/^-+|-+$/g,'')`),
  },
  {
    id: 'NUMERIC_SORT',
    label: 'sort numerically instead of lexicographically',
    applies: code => /\.sort\(\s*\)/.test(code),
    apply: code => code.replace(/\.sort\(\s*\)/g, '.sort((x,y)=>x-y)'),
  },
  {
    id: 'WRAP_TRY_CATCH',
    label: 'wrap the body in try/catch and return the demanded value',
    applies: (code, ctx) => (ctx.expected !== null && ctx.expected !== undefined) && !/try\{/.test(code),
    apply: (code, ctx) => code.replace(/\{([\s\S]*)\}\s*$/, `{try{$1}catch(e){return ${ctx.expected};}}`),
  },
  {
    id: 'INVERT_COMPARISON',
    label: 'flip a comparison direction',
    applies: code => /[^=!<>](<=?|>=?)[^=]/.test(code) && !/=>|===|!==/.test(code.replace(/[=!]{2}/g, '')),
    apply: code => code.replace(/<=|[<>]=|[<>]/g, m => ({ '<': '>', '>': '<', '<=': '>=', '>=': '<=' })[m]),
  },
  {
    id: 'STRICT_TO_LOOSE',
    label: 'relax a strict equality',
    applies: code => code.includes('==='),
    apply: code => code.replace(/===/g, '=='),
  },
  {
    id: 'ADD_EMPTY_CHECK',
    label: 'handle an empty collection with the demanded value',
    applies: (code, ctx) => (ctx.expected !== null && ctx.expected !== undefined) && (/\.length/.test(code) || /\[\s*0\s*\]/.test(code)),
    apply: (code, ctx) => insertGuard(code, `if(a.length===0)return ${ctx.expected};`),
  },
  {
    id: 'RETRACT_GUARD',
    label: 'remove an inserted guard that over-fits the test',
    applies: code => /\{if\([^)]*\)return[^;]*;/.test(code),
    apply: code => code.replace(/\{if\([^)]*\)return[^;]*;/, '{'),
  },
  {
    id: 'LITERAL_PERTURB',
    label: 'nudge a numeric literal by one',
    applies: code => /\d/.test(code),
    apply: code => code.replace(/\b(\d+)\b/, (_, n) => String(Number(n) + 1)),
  },
  {
    id: 'SWAP_STRING_LITERALS',
    label: 'swap two string literals',
    applies: code => (code.match(/'[^']*'/g) || []).length >= 2,
    apply: code => {
      const lits = code.match(/'[^']*'/g);
      let i = 0;
      return code.replace(/'[^']*'/g, () => {
        const pick = lits[(i + 1) % lits.length];
        i++;
        return pick;
      });
    },
  },
];

export const TRANSFORM_BY_ID = new Map(TRANSFORMS.map(t => [t.id, t]));

/** Context handed to an operator: the failure that motivated the edit plus the demanded value. */
export function transformContext(failure, killer) {
  const message = String((failure && failure.error) || '');
  const fromMessage = expectedLiteral(message);
  const fromSource = killer && killer.test ? expectedFromTestSource(killer.test) : null;
  return {
    signature: failure ? signatureOf(failure) : 'mismatch',
    // the demanded value: prefer what the runtime message said, fall back to the test source
    expected: fromMessage !== null ? fromMessage : fromSource,
    expectedFromSource: fromSource,
    message,
  };
}

/**
 * Apply one operator. Returns null when the operator does not apply, when it produces no
 * change, or when the result is not balanced — invalid edits never enter the population.
 */
export function applyTransform(transformId, code, ctx) {
  const transform = TRANSFORM_BY_ID.get(transformId);
  if (!transform) return null;
  try {
    if (!transform.applies(code, ctx)) return null;
    const next = transform.apply(code, ctx);
    if (typeof next !== 'string' || next === code) return null;
    if (!isBalanced(next)) return null;
    return next;
  } catch {
    return null;
  }
}

/** All operators that are applicable right now, with their contexts. */
export function applicableTransforms(code, ctx) {
  const out = [];
  for (const transform of TRANSFORMS) {
    let ok = false;
    try { ok = transform.applies(code, ctx); } catch { ok = false; }
    if (!ok) continue;
    const result = applyTransform(transform.id, code, ctx);
    if (result) out.push({ id: transform.id, code: result, label: transform.label });
  }
  return out;
}
