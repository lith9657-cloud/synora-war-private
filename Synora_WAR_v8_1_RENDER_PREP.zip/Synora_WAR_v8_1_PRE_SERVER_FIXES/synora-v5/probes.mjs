/**
 * Synora WAR v5 — Input-space mutators used by the BREAKER and SKEPTIC families.
 *
 * These are generic transformations of an input value; they never look at the task, the code or
 * the oracle. Their job is to walk the *edge* of the input domain, where real bugs live.
 */

export function mutateInput(input, rand) {
  const kind = Array.isArray(input) ? 'array'
    : typeof input === 'string' ? 'string'
      : typeof input === 'number' ? 'number'
        : input === null ? 'null' : typeof input;

  const pick = arr => arr[Math.floor(rand() * arr.length) % arr.length];

  if (kind === 'array') {
    const opts = [
      [], input.length ? [input[0]] : [], input.length ? [...input, input[0]] : [],
      input.length ? [...input].reverse() : [], input.length ? [...input, null] : [],
      input.length ? [...input].slice(0, Math.max(0, input.length - 1)) : [],
      input.length ? input.map(x => (typeof x === 'number' ? x + 1 : x)) : [],
      input.length ? input.map(x => (typeof x === 'number' ? x - 1 : x)) : [],
    ];
    return pick(opts);
  }
  if (kind === 'string') {
    const opts = [
      '', ' ' + input, input + ' ', input.toUpperCase(), input + '!',
      input + '؟', input.replace(/\s+/g, ' '), input.slice(0, Math.max(0, input.length - 1)),
      input + input,
    ];
    return pick(opts);
  }
  if (kind === 'number') {
    const opts = [0, 1, -1, input + 1, input - 1, input * 2, NaN, Infinity, -Infinity];
    return pick(opts);
  }
  if (kind === 'null') {
    return pick([0, '', [], {}, undefined, false]);
  }
  return pick([null, undefined, 0, '', [], {}]);
}

/** A deterministic PRNG so every run is reproducible from its seed. */
export function makeRng(seed) {
  let state = (seed >>> 0) || 1;
  return function next() {
    state ^= state << 13; state >>>= 0;
    state ^= state >> 17;
    state ^= state << 5; state >>>= 0;
    return state / 0xffffffff;
  };
}
