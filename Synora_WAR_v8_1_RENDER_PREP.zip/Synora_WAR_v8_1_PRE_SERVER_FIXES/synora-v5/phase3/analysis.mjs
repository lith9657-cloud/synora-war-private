/**
 * Synora WAR v5 — PHASE 3: offline analysis.
 *
 * Everything in this module runs AFTER the experiment and never touches the solver. It is
 * allowed to read the answer key, because it is a measurement instrument, not part of the
 * search loop.
 *
 * It provides:
 *   1. the ANALYTIC defect families of a task (reference program vs. seed program),
 *   2. the structural similarity between tasks, and the "cross-structure" subsets,
 *   3. the aggregation of the raw per-run results into the reported metrics.
 */
import { TOOLS } from '../pst/environment.mjs';
import { findCalls } from './operators.mjs';
import { planFor } from './secrets.mjs';
import { TASKS, byId } from './tasks.mjs';
import { pairedBootstrap, wilcoxonSignedRank, mcnemarExact, holmBonferroni } from '../stats.mjs';

/** Build the reference program of a task from its private plan (analysis side only). */
export function referenceProgram(taskId) {
  const plan = planFor(taskId);
  if (!plan) return null;
  let expr = 'input';
  for (const call of plan.calls) {
    const [name, ...args] = call;
    const contract = TOOLS[name].args;
    const parts = args.map(a => JSON.stringify(a));
    if (contract[0] === 'entries' || contract[0] === 'text') parts.unshift(expr);
    expr = `${name}(${parts.join(', ')})`;
  }
  if (plan.field === 'length') expr += '.length';
  else if (plan.field) expr += `.${plan.field}`;
  return `function solution(input){return ${expr}}`;
}

function literalOf(text) {
  const t = String(text).trim();
  if (/^'[^']*'$/.test(t)) return t.slice(1, -1);
  if (/^"[^"]*"$/.test(t)) return t.slice(1, -1);
  if (/^-?\d+(\.\d+)?$/.test(t)) return Number(t);
  return undefined;
}

/** The calls of a program, per tool, with their literal arguments. */
export function callsOf(code) {
  const map = new Map();
  for (const tool of Object.keys(TOOLS)) {
    for (const call of findCalls(code, tool)) {
      const args = call.args.map(a => literalOf(a.text));
      map.set(tool, { tool, args, count: map.has(tool) ? map.get(tool).count + 1 : 1 });
    }
  }
  return map;
}

function fieldOf(code) {
  const m = /\)\.([A-Za-z_$][\w$]*)/.exec(code);
  return m ? m[1] : null;
}

/**
 * The analytic defect families of a task: what is structurally wrong with the seed compared
 * with the reference program. This is a property of the TASK DESIGN (used to measure how
 * similar two tasks are), not something the solver is told.
 */
export function defectFamilies(taskId) {
  const task = byId(taskId);
  const reference = referenceProgram(taskId);
  if (!task || !reference) return [];
  const refCalls = callsOf(reference);
  const seedCalls = callsOf(task.seed);
  const families = [];
  for (const [tool, call] of refCalls) {
    if (!seedCalls.has(tool)) { families.push(`MISSING_CALL:${tool}`); continue; }
    const contract = TOOLS[tool].args;
    const seedCall = seedCalls.get(tool);
    for (let i = 1; i < contract.length; i++) {
      const param = contract[i];
      const refValue = call.args[i];
      const seedValue = seedCall.args[i];
      if (refValue === undefined) continue;
      if (seedValue === undefined) { families.push(`WRONG_ARG:${tool}:${param}`); continue; }
      if (refValue !== seedValue) families.push(`WRONG_ARG:${tool}:${param}`);
    }
  }
  for (const [tool] of seedCalls) {
    if (!refCalls.has(tool)) families.push(`EXTRA_CALL:${tool}`);
  }
  const refField = fieldOf(reference);
  const seedField = fieldOf(task.seed);
  if ((refField || null) !== (seedField || null)) families.push('WRONG_FIELD');
  return [...new Set(families)].sort();
}

function jaccard(a, b) {
  const A = new Set(a), B = new Set(b);
  if (!A.size && !B.size) return 1;
  let inter = 0;
  for (const x of A) if (B.has(x)) inter++;
  return inter / (A.size + B.size - inter);
}

/** Structural similarity between two tasks, in [0,1]. */
export function similarity(a, b) {
  const fa = defectFamilies(a), fb = defectFamilies(b);
  const ta = byId(a), tb = byId(b);
  const toolsA = ta ? ta.required : [], toolsB = tb ? tb.required : [];
  return 0.6 * jaccard(fa, fb) + 0.4 * jaccard(toolsA, toolsB);
}

/** The similarity matrix + the per-task maximum similarity to the acquisition group. */
export function similarityReport() {
  const ids = TASKS.map(t => t.id);
  const matrix = {};
  for (const a of ids) {
    matrix[a] = {};
    for (const b of ids) matrix[a][b] = a === b ? 1 : Number(similarity(a, b).toFixed(3));
  }
  const maxSimInA = {};
  for (const id of ids) {
    const group = byId(id).group;
    if (group === 'A') { maxSimInA[id] = 1; continue; }
    const others = TASKS.filter(t => t.group === 'A').map(t => t.id);
    maxSimInA[id] = Number(Math.max(...others.map(o => matrix[id][o])).toFixed(3));
  }
  const classes = {};
  for (const id of ids) {
    const value = maxSimInA[id];
    const cls = value >= 0.95 ? 'clone_of_A' : value >= 0.75 ? 'near_A' : 'cross_structure';
    classes[id] = { group: byId(id).group, maxSimInA: value, class: cls, families: defectFamilies(id) };
  }
  return { matrix, maxSimInA, classes };
}

/* ------------------------------------------------------------------ aggregation */

export function median(values) {
  if (!values.length) return null;
  const v = [...values].sort((a, b) => a - b);
  const mid = v.length >> 1;
  return v.length % 2 ? v[mid] : (v[mid - 1] + v[mid]) / 2;
}

export function quantile(values, q) {
  if (!values.length) return null;
  const v = [...values].sort((a, b) => a - b);
  const pos = (v.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  return v[base + 1] !== undefined ? v[base] + rest * (v[base + 1] - v[base]) : v[base];
}

/**
 * DEPRECATED — kept only so that old result files still load. The unpaired bootstrap was
 * wrong for this design (it resampled the arms independently); use
 * synora-v5/stats.mjs `pairedBootstrap` with PAIRED units instead.
 */
export function bootstrapMedianDiff(a, b, iterations = 4000, seed = 12345) {
  const pairs = a.map((value, index) => ({ arm: value, base: b[index], unit: index }))
    .filter(p => p.arm !== undefined && p.base !== undefined);
  return pairedBootstrap(pairs, { iterations, seed });
}

/**
 * Build the paired units of an arm-vs-arm comparison from the raw runs.
 * The unit is (taskId, seed): the same task with the same random seed in both arms.
 */
export function pairedUnits(runsA, runsB) {
  const key = r => `${r.taskId}#${r.seed}`;
  const mapB = new Map(runsB.map(r => [key(r), r]));
  const units = [];
  for (const a of runsA) {
    const b = mapB.get(key(a));
    if (!b) continue;
    units.push({
      unit: key(a), taskId: a.taskId, seed: a.seed, group: a.group,
      armSolved: !!a.success, baseSolved: !!b.success,
      arm: a.success ? a.evaluations : null,
      base: b.success ? b.evaluations : null,
    });
  }
  return units;
}

/** The full statistical report of one arm-vs-arm comparison. */
export function compareArms(units, budget = null) {
  const both = units.filter(u => u.armSolved && u.baseSolved);
  const onlyArm = units.filter(u => u.armSolved && !u.baseSolved);
  const onlyBase = units.filter(u => !u.armSolved && u.baseSolved);
  const neither = units.filter(u => !u.armSolved && !u.baseSolved);
  const diffs = both.map(u => u.arm - u.base);
  return {
    units: units.length,
    solvedArm: units.filter(u => u.armSolved).length,
    solvedBase: units.filter(u => u.baseSolved).length,
    bothSolved: both.length,
    onlyArmSolved: onlyArm.length,
    onlyBaseSolved: onlyBase.length,
    neitherSolved: neither.length,
    medianArm: median(both.map(u => u.arm)),
    medianBase: median(both.map(u => u.base)),
    pairedBootstrap: pairedBootstrap(both.map(u => ({ arm: u.arm, base: u.base, unit: u.unit }))),
    wilcoxon: wilcoxonSignedRank(diffs),
    mcnemar: mcnemarExact(units.map(u => ({ arm: u.armSolved, base: u.baseSolved }))),
    // A CONSERVATIVE VIEW: a failure counts as the full budget (censoring). This keeps the
    // failures inside the efficiency comparison instead of dropping them.
    censored: budget ? {
      medianArm: median(units.map(u => (u.armSolved ? u.arm : budget))),
      medianBase: median(units.map(u => (u.baseSolved ? u.base : budget))),
      medianDifference: median(units.map(u => (u.armSolved ? u.arm : budget))) - median(units.map(u => (u.baseSolved ? u.base : budget))),
    } : null,
  };
}

export function summariseArm(runs) {
  const solved = runs.filter(r => r.success);
  const evals = solved.map(r => r.evaluations);
  const groups = {};
  for (const group of ['A', 'B', 'C']) {
    const rows = runs.filter(r => r.group === group);
    if (!rows.length) continue;
    const ok = rows.filter(r => r.success);
    groups[group] = {
      runs: rows.length,
      solved: ok.length,
      successRate: Number((ok.length / rows.length).toFixed(4)),
      medianEvaluationsOnSuccess: median(ok.map(r => r.evaluations)),
      q25: quantile(ok.map(r => r.evaluations), 0.25),
      q75: quantile(ok.map(r => r.evaluations), 0.75),
      composed: ok.filter(r => r.solvedByComposition).length,
      failed: rows.filter(r => !r.success).map(r => r.taskId),
    };
  }
  const wrongHints = runs.reduce((a, r) => a + ((r.memoryStats && r.memoryStats.hintMisses) || 0), 0);
  const goodHints = runs.reduce((a, r) => a + ((r.memoryStats && r.memoryStats.hintHits) || 0), 0);
  const restoredUsed = runs.reduce((a, r) => a + ((r.memoryStats && r.memoryStats.restoredSkillsUsed) || 0), 0);
  return {
    runs: runs.length,
    solved: solved.length,
    successRate: Number((solved.length / runs.length).toFixed(4)),
    meanScore: Number((runs.reduce((a, r) => a + r.score, 0) / runs.length).toFixed(4)),
    medianEvaluationsOnSuccess: median(evals),
    q25: quantile(evals, 0.25),
    q75: quantile(evals, 0.75),
    groups,
    composedSuccesses: solved.filter(r => r.solvedByComposition).length,
    wrongInheritedHints: wrongHints,
    usefulInheritedHints: goodHints,
    restoredSkillsUsed: restoredUsed,
    totalEvaluations: runs.reduce((a, r) => a + r.evaluations, 0),
    totalElapsedMs: runs.reduce((a, r) => a + (r.elapsedMs || 0), 0),
    maxRssMb: runs.reduce((a, r) => Math.max(a, r.rssMb || 0), 0),
  };
}
