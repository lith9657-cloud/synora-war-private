/**
 * Synora WAR v5 — PHASE 3: the long-term memory layer.
 *
 * The point of this module is to make the memory SURVIVE the process that produced it.
 * The ledger already knows how to serialise itself (Ledger.toJSON / Ledger.fromJSON); what is
 * missing is a documented, integrity-checked FILE FORMAT and the proof that what comes back
 * is exactly what was saved.
 *
 * File format (JSON, version 1):
 * {
 *   "format":   "synora-cri-memory/1",
 *   "createdAt": ISO timestamp,
 *   "session":  { "pid": ..., "seed": ..., "acquisitionTasks": [...], "budget": ... },
 *   "integrity": { "sha256": "<hash of the ledger payload>" },
 *   "ledger":   { ...Ledger.toJSON() ... }
 * }
 *
 * The integrity hash covers the ledger payload, so a corrupted or hand-edited memory file is
 * detected on load instead of silently poisoning the search.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { Ledger } from '../ledger.mjs';

export const MEMORY_FORMAT = 'synora-cri-memory/1';

function canonical(value) {
  return JSON.stringify(value, Object.keys(value || {}).sort());
}

export function hashLedger(ledgerPayload) {
  return crypto.createHash('sha256').update(JSON.stringify(ledgerPayload)).digest('hex');
}

/** Serialise a ledger into the documented memory envelope. */
export function buildMemoryFile(ledger, meta = {}) {
  const payload = ledger.toJSON();
  return {
    format: MEMORY_FORMAT,
    createdAt: new Date().toISOString(),
    session: {
      pid: process.pid,
      seed: meta.seed ?? null,
      acquisitionTasks: meta.acquisitionTasks || [],
      budget: meta.budget ?? null,
      engine: meta.engine || 'phase3',
    },
    integrity: { sha256: hashLedger(payload) },
    ledger: payload,
  };
}

/** Write the memory file. Returns the path and the hash that was written. */
export function saveMemory(ledger, filePath, meta = {}) {
  const envelope = buildMemoryFile(ledger, meta);
  fs.mkdirSync(path.dirname(path.resolve(filePath)), { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(envelope, null, 2), 'utf8');
  return { path: filePath, sha256: envelope.integrity.sha256, skills: envelope.ledger.skills.length };
}

/**
 * Load the memory file.
 * Throws when the format is unknown or the integrity check fails — a silent partial load
 * would be indistinguishable from "the memory did not help".
 */
export function loadMemory(filePath) {
  const raw = fs.readFileSync(filePath, 'utf8');
  const envelope = JSON.parse(raw);
  if (!envelope || envelope.format !== MEMORY_FORMAT) {
    throw new Error(`unknown memory format: ${envelope && envelope.format}`);
  }
  const expected = envelope.integrity && envelope.integrity.sha256;
  const actual = hashLedger(envelope.ledger);
  if (expected && expected !== actual) {
    throw new Error(`memory integrity check failed for ${filePath}: ${expected} != ${actual}`);
  }
  const ledger = Ledger.fromJSON(envelope.ledger);
  return {
    ledger,
    envelope,
    fileSha256: crypto.createHash('sha256').update(raw).digest('hex'),
    payloadSha256: actual,
    skills: envelope.ledger.skills.length,
    refutations: envelope.ledger.refutations.length,
  };
}

/**
 * A guard used by the tests and by the experiment: the memory file must not contain any
 * expected value of any task. It looks for the *values*, not for the task ids.
 */
export function scanMemoryForAnswers(filePath, expectedValues) {
  const raw = fs.readFileSync(filePath, 'utf8');
  const hits = [];
  for (const value of expectedValues) {
    if (value === null || value === undefined) continue;
    if (typeof value === 'object') {
      for (const part of Object.values(value)) {
        if (typeof part === 'string' && part.length >= 2 && raw.includes(part)) hits.push({ value: part });
      }
      continue;
    }
    if (typeof value === 'string' && value.length >= 2 && raw.includes(value)) hits.push({ value });
  }
  return hits;
}
