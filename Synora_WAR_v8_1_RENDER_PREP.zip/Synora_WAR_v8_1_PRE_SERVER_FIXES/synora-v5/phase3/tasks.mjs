/**
 * Synora WAR v5 — PHASE 3: long-term memory & generalisation.
 *
 * THE PUBLIC TASK SPECIFICATIONS.
 *
 * Three groups, with a hard separation:
 *   A — ACQUISITION: the system meets them so that it can acquire repair skills.
 *   B — GENERALISATION: new structures; the skills learned in A may apply.
 *   C — FINAL HELD-OUT: never used to design, tune, or debug anything. Its answers are not
 *       visible to the solver during the search (only the one-way grader sees them).
 *
 * What is PUBLIC here: the goal, the tools, the parameters that appear in the goal, the
 * budget of tool calls, the scoring rule (strict = all-or-nothing), and the seed program.
 * What is NOT public: the expected output (it lives in ./secrets.mjs, grader-only).
 *
 * The seed programs are PARTIALLY WRONG on purpose: each one carries exactly the defects the
 * task is meant to exercise, so the grader's categories point at real slots.
 */

export const GROUPS = { A: 'acquisition', B: 'generalisation', C: 'final_heldout' };

export const TASKS = [
  /* ================================================================ A — acquisition */
  {
    id: 'A1_names3_txt', group: 'A', strict: true, maxCalls: 8, valueType: 'string',
    goal: 'اعرض أسماء أكبر ثلاثة ملفات من نوع txt مفصولة بفواصل',
    goalEn: 'names of the three largest txt files, comma separated',
    required: ['listDir', 'filterByExt', 'sortBy', 'take', 'joinNames'],
    seed: "function solution(input){return joinNames(take(sortBy(filterByExt(listDir(),'txt'),'size','asc'),2),'-')}",
    note: 'three coordinated defects: sort direction, how many, separator',
  },
  {
    id: 'A2_ext_sum_csv', group: 'A', strict: false, maxCalls: 6, valueType: 'number',
    goal: 'ما مجموع أحجام ملفات csv بالبايت؟',
    goalEn: 'sum of the sizes of the csv files',
    required: ['listDir', 'filterByExt', 'sumSize'],
    seed: "function solution(input){return sumSize(filterByExt(listDir(),'txt'))}",
    note: 'wrong extension',
  },
  {
    id: 'A3_md_count', group: 'A', strict: true, maxCalls: 6, valueType: 'number',
    goal: 'كم ملفاً من نوع md؟',
    goalEn: 'how many md files',
    required: ['listDir', 'filterByExt', 'countByExt'],
    seed: "function solution(input){return countByExt(filterByExt(listDir(),'csv')).csv}",
    note: 'wrong extension AND wrong field of the count object',
  },
  {
    id: 'A4_min_count_100', group: 'A', strict: false, maxCalls: 5, valueType: 'number',
    goal: 'كم ملفاً حجمه لا يقل عن 100 بايت؟',
    goalEn: 'how many files are at least 100 bytes',
    required: ['listDir', 'filterByMinSize'],
    seed: 'function solution(input){return filterByMinSize(listDir(),1000).length}',
    note: 'wrong threshold',
  },
  {
    id: 'A5_clean_text', group: 'A', strict: false, maxCalls: 4, valueType: 'string',
    goal: 'نظّف النص: احذف المسافات الزائدة وحوّل الأرقام إلى أرقام عربية',
    goalEn: 'clean the text: collapse spaces, arabic digits',
    required: ['normalizeSpaces', 'toArabicDigits'],
    seed: 'function solution(input){return toArabicDigits(input)}',
    note: 'the space-normalisation step is missing',
  },
  {
    id: 'A6_sort_by_name', group: 'A', strict: false, maxCalls: 6, valueType: 'string',
    goal: 'اعرض أسماء كل الملفات مرتبة أبجدياً مفصولة بشرطة',
    goalEn: 'all file names, alphabetical, dash separated',
    required: ['listDir', 'sortBy', 'joinNames'],
    seed: "function solution(input){return joinNames(sortBy(listDir(),'size','asc'),'-')}",
    note: 'sorts by size instead of by name',
  },
  {
    id: 'A7_count_all_types', group: 'A', strict: false, maxCalls: 6, valueType: 'object',
    goal: 'عدّ الملفات حسب نوعها: كم ملفاً من كل نوع',
    goalEn: 'count the files per type',
    required: ['listDir', 'countByExt'],
    seed: "function solution(input){return countByExt(filterByExt(listDir(),'txt'))}",
    note: 'counts one type instead of all of them',
  },

  /* ================================================================ B — generalisation */
  {
    id: 'B1_two_filter_names', group: 'B', strict: true, maxCalls: 9, valueType: 'string',
    goal: 'اعرض أسماء أكبر ملفين csv من حجم لا يقل عن 100 بايت، مفصولة بفواصل',
    goalEn: 'names of the two largest csv files of at least 100 bytes, comma separated',
    required: ['listDir', 'filterByExt', 'filterByMinSize', 'sortBy', 'take', 'joinNames'],
    seed: "function solution(input){return joinNames(take(sortBy(filterByMinSize(filterByExt(listDir(),'txt'),100),'size','desc'),3),'-')}",
    note: 'NEW STRUCTURE (five stages). Defects: extension, how many, separator',
  },
  {
    id: 'B2_field_only', group: 'B', strict: true, maxCalls: 6, valueType: 'number',
    goal: 'كم ملفاً من نوع txt في المجلد؟',
    goalEn: 'how many txt files',
    required: ['listDir', 'countByExt'],
    seed: 'function solution(input){return countByExt(listDir()).md}',
    note: 'only the field of the count object is wrong',
  },
  {
    id: 'B3_missing_filter', group: 'B', strict: true, maxCalls: 6, valueType: 'string',
    goal: 'اعرض أسماء ملفات txt مرتبة بالحجم تنازلياً مفصولة بشرطة',
    goalEn: 'txt file names, size descending, dash separated',
    required: ['listDir', 'filterByExt', 'sortBy', 'joinNames'],
    seed: "function solution(input){return joinNames(sortBy(listDir(),'size','desc'),'-')}",
    note: 'NEW STRUCTURE: the filtering step is missing from the middle of the pipeline',
  },
  {
    id: 'B4_threshold_sort_name', group: 'B', strict: true, maxCalls: 7, valueType: 'string',
    goal: 'اعرض أسماء الملفات التي حجمها لا يقل عن 50 بايت، مرتبة أبجدياً، بشرطة',
    goalEn: 'names of files of at least 50 bytes, alphabetical, dash separated',
    required: ['listDir', 'filterByMinSize', 'sortBy', 'joinNames'],
    seed: "function solution(input){return joinNames(sortBy(filterByMinSize(listDir(),100),'size','asc'),'-')}",
    note: 'NEW COMBINATION: threshold and sort key',
  },
  {
    id: 'B5_extra_take_sum', group: 'B', strict: false, maxCalls: 7, valueType: 'number',
    goal: 'ما مجموع أحجام ملفات txt بالبايت؟',
    goalEn: 'sum of the sizes of the txt files',
    required: ['listDir', 'filterByExt', 'sumSize'],
    seed: "function solution(input){return sumSize(take(filterByExt(listDir(),'txt'),2))}",
    note: 'NEW STRUCTURE: a superfluous take() truncates the sum',
  },
  {
    id: 'B6_md_largest_one', group: 'B', strict: true, maxCalls: 8, valueType: 'string',
    goal: 'اعرض اسم أكبر ملف md مفصولاً بشرطة',
    goalEn: 'the name of the largest md file, dash separated',
    required: ['listDir', 'filterByExt', 'sortBy', 'take', 'joinNames'],
    seed: "function solution(input){return joinNames(take(sortBy(filterByExt(listDir(),'csv'),'size','asc'),1),'-')}",
    note: 'NEW COMBINATION: extension and sort direction',
  },

  /* ================================================================ C — final held-out */
  {
    id: 'C1_two_filter_one', group: 'C', strict: true, maxCalls: 9, valueType: 'string',
    goal: 'اعرض اسم أكبر ملف txt حجمه لا يقل عن 50 بايت، مفصولاً بفاصلة عربية',
    goalEn: 'the name of the largest txt file of at least 50 bytes, arabic comma separated',
    required: ['listDir', 'filterByExt', 'filterByMinSize', 'sortBy', 'take', 'joinNames'],
    seed: "function solution(input){return joinNames(take(sortBy(filterByMinSize(filterByExt(listDir(),'txt'),100),'size','asc'),2),', ')}",
    note: 'NEW STRUCTURE (five stages) + a separator never used in A',
  },
  {
    id: 'C2_missing_filter_sum', group: 'C', strict: true, maxCalls: 6, valueType: 'number',
    goal: 'ما مجموع أحجام ملفات md؟',
    goalEn: 'sum of the sizes of the md files',
    required: ['listDir', 'filterByExt', 'sumSize'],
    seed: 'function solution(input){return sumSize(listDir())}',
    note: 'NEW STRUCTURE: a whole filtering step is missing',
  },
  {
    id: 'C3_missing_threshold_sum', group: 'C', strict: true, maxCalls: 7, valueType: 'number',
    goal: 'ما مجموع أحجام ملفات txt التي حجمها لا يقل عن 100 بايت؟',
    goalEn: 'sum of the sizes of the txt files of at least 100 bytes',
    required: ['listDir', 'filterByExt', 'filterByMinSize', 'sumSize'],
    seed: "function solution(input){return sumSize(filterByExt(listDir(),'txt'))}",
    note: 'NEW STRUCTURE: a threshold step is missing from a numeric pipeline',
  },
  {
    id: 'C4_sort_size_desc_names', group: 'C', strict: true, maxCalls: 6, valueType: 'string',
    goal: 'اعرض أسماء كل الملفات مرتبة بالحجم تنازلياً مفصولة بفاصلة عربية',
    goalEn: 'all file names by size descending, arabic comma separated',
    required: ['listDir', 'sortBy', 'joinNames'],
    seed: "function solution(input){return joinNames(sortBy(listDir(),'name','asc'),'-')}",
    note: 'NEW STRUCTURE: no filter and no take at all',
  },
  {
    id: 'C5_two_filter_names3', group: 'C', strict: true, maxCalls: 9, valueType: 'string',
    goal: 'اعرض أسماء ثلاثة ملفات txt حجمها لا يقل عن 50 بايت، مرتبة أبجدياً، بشرطة',
    goalEn: 'names of three txt files of at least 50 bytes, alphabetical, dash separated',
    required: ['listDir', 'filterByExt', 'filterByMinSize', 'sortBy', 'take', 'joinNames'],
    seed: "function solution(input){return joinNames(take(sortBy(filterByMinSize(filterByExt(listDir(),'csv'),1000),'size','desc'),3),'-')}",
    note: 'NEW STRUCTURE (five stages) with a different combination of defects',
  },
  {
    id: 'C6_txt_two_names', group: 'C', strict: true, maxCalls: 8, valueType: 'string',
    goal: 'اعرض أسماء أكبر ملفين txt مفصولة بفاصلة عربية',
    goalEn: 'the names of the two largest txt files, arabic comma separated',
    required: ['listDir', 'filterByExt', 'sortBy', 'take', 'joinNames'],
    seed: "function solution(input){return joinNames(take(sortBy(filterByExt(listDir(),'txt'),'size','asc'),2),'-')}",
    note: 'NEW COMBINATION: direction and separator only',
  },
];

export const TASK_IDS = TASKS.map(t => t.id);
export const byId = id => TASKS.find(t => t.id === id);
export const byGroup = group => TASKS.filter(t => t.group === group);
export const groupOf = id => (byId(id) || {}).group || null;

/** The runtime input handed to `solution(input)` (public). */
export function taskInput(task) {
  if (task.id === 'A5_clean_text') return 'العدد  450 ريال';
  return null;
}

/**
 * The structural fingerprint of a task, used ONLY by the analysis (never by the solver):
 * the pipeline shape, the number of stages, and whether the task is strict.
 */
export function structureOf(task) {
  return {
    id: task.id,
    group: task.group,
    tools: [...task.required].sort(),
    stages: task.required.length,
    strict: !!task.strict,
    valueType: task.valueType,
  };
}
