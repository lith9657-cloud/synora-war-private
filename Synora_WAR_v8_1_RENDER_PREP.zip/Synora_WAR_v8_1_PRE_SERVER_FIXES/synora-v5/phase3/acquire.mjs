/**
 * Synora WAR v5 — PHASE 3: SESSION 1 — the acquisition session.
 *
 * This program:
 *   1. meets the acquisition group A and lets the CRI engine learn repair skills,
 *   2. writes the learned memory to a FILE (the documented format of ./memory.mjs),
 *   3. prints a receipt (pid, file, sha256, skill count) and EXITS.
 *
 * Nothing of this session survives except the file. The evaluation session is a different
 * process that can only see that file.
 *
 *   node synora-v5/phase3/acquire.mjs --seed=1 --budget=250 \
 *        --out=experiments/memory/acquire-seed1.json
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Ledger } from '../ledger.mjs';
import { Grader } from './grader.mjs';
import { PstEngine } from './engine.mjs';
import { byGroup, taskInput } from './tasks.mjs';
import { saveMemory, hashLedger } from './memory.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));

function parseArgs(argv) {
  const args = { seed: 1, budget: 250, generations: 80, out: 'experiments/memory/acquire.json' };
  for (const raw of argv) {
    const m = /^--([^=]+)(?:=(.*))?$/.exec(raw);
    if (!m) continue;
    const key = m[1];
    const value = m[2] ?? 'true';
    if (key in args) args[key] = (key === 'out') ? value : Number(value);
  }
  return args;
}

function hash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const grader = new Grader({ size: 2, timeoutMs: 700 });
  await grader.init();
  const ledger = new Ledger();
  const acquisition = byGroup('A');
  const started = Date.now();

  const runs = [];
  for (const task of acquisition) {
    const engine = new PstEngine({
      grader, ledger, mode: 'cri',
      seed: args.seed * 977 + hash(task.id),
      budget: args.budget, generations: args.generations,
    });
    const result = await engine.runTask(task);
    result.group = 'A';
    result.seed = args.seed;
    runs.push(result);
  }

  const outPath = path.isAbsolute(args.out) ? args.out : path.join(HERE, '..', '..', args.out);
  const outRel = path.relative(path.join(HERE, '..', '..'), outPath);
  const saved = saveMemory(ledger, outPath, {
    seed: args.seed,
    acquisitionTasks: acquisition.map(t => t.id),
    budget: args.budget,
    engine: 'phase3-acquire',
  });

  const receipt = {
    session: 'acquire',
    pid: process.pid,
    seed: args.seed,
    budget: args.budget,
    tasks: acquisition.map(t => t.id),
    results: runs.map(r => ({
      taskId: r.taskId, success: r.success, score: r.score, evaluations: r.evaluations,
      violations: r.violations, composed: r.solvedByComposition,
    })),
    memory: {
      path: outRel,
      sha256: saved.sha256,
      ledgerPayloadSha256: hashLedger(ledger.toJSON()),
      skills: saved.skills,
      refutations: ledger.refutations.size,
      prohibitions: ledger.prohibitions.size,
    },
    skillTable: [...ledger.skills.values()].map(s => ({
      signature: s.signature, transformId: s.transformId, credit: s.credit, hint: s.hint || null,
    })),
    elapsedMs: Date.now() - started,
  };
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(path.join(path.dirname(outPath), `acquire-receipt-seed${args.seed}.json`), JSON.stringify(receipt, null, 2));
  console.log(JSON.stringify(receipt, null, 2));
  await grader.close();
}

main().catch(err => { console.error(err); process.exit(1); });
