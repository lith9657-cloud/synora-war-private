/**
 * Synora WAR v5 — report table generator.
 *
 * Every table in the Phase-2 / Phase-3 reports is produced by this script FROM THE RAW RESULT
 * FILES. Nothing is typed by hand, so the reports cannot drift away from the data.
 *
 *   node synora-v5/phase3/report-tables.mjs --phase3=experiments/results-phase3.json \
 *        --phase2=experiments/results-pst.json --phase1=experiments/results-v5.json
 *
 * It prints Markdown; the audit test (tests/audit.test.mjs) re-runs it and compares the
 * numbers with the ones in the report files.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { median } from '../stats.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(HERE, '..', '..');

const read = p => JSON.parse(fs.readFileSync(path.isAbsolute(p) ? p : path.join(ROOT, p), 'utf8'));

function fmt(x, digits = 1) {
  if (x === null || x === undefined) return '—';
  if (typeof x === 'number') return Number.isInteger(x) ? String(x) : x.toFixed(digits);
  return String(x);
}

/* ------------------------------------------------------------------ Phase 3 */
export function phase3Tables(data) {
  const out = {};
  const budgets = data.config.budgets;
  const arms = ['base', 'nocross', 'noise', 'cri'];

  out.successByBudget = [
    '| ميزانية | base | nocross | noise | **cri** |',
    '|---|---|---|---|---|',
  ];
  for (const b of budgets) {
    const cells = arms.map(a => {
      const rows = data.runs.filter(r => r.budget === b && r.arm === a);
      const ok = rows.filter(r => r.success).length;
      return `${ok}/${rows.length} (${(ok / rows.length * 100).toFixed(1)}%)`;
    });
    out.successByBudget.push(`| ${b} | ${cells.join(' | ')} |`);
  }

  out.successByGroup = [
    '| ميزانية | ذراع | المجموعة B | المجموعة C | الكل |',
    '|---|---|---|---|---|',
  ];
  for (const b of budgets) {
    for (const a of arms) {
      const rows = data.runs.filter(r => r.budget === b && r.arm === a);
      const rate = g => {
        const sub = rows.filter(r => r.group === g);
        return sub.length ? `${sub.filter(r => r.success).length}/${sub.length}` : '—';
      };
      const ok = rows.filter(r => r.success).length;
      out.successByGroup.push(`| ${b} | ${a} | ${rate('B')} | ${rate('C')} | ${ok}/${rows.length} |`);
    }
  }

  out.medianEvals = [
    '| ذراع | B وسيط | C وسيط | الكل وسيط | مجموع التقييمات |',
    '|---|---|---|---|---|',
  ];
  for (const b of budgets) {
    for (const a of arms) {
      const rows = data.runs.filter(r => r.budget === b && r.arm === a);
      const med = g => {
        const sub = rows.filter(r => r.group === g && r.success).map(r => r.evaluations);
        return median(sub);
      };
      const all = rows.filter(r => r.success).map(r => r.evaluations);
      out.medianEvals.push(`| ${b} | ${a} | ${fmt(med('B'))} | ${fmt(med('C'))} | ${fmt(median(all))} | ${rows.reduce((x, r) => x + r.evaluations, 0)} |`);
    }
  }

  out.inference = [
    '| الميزانية | المجموعة | الذراع | نجاح الذراع | نجاح base | المتخالف (b/c) | McNemar p | Holm | Wilcoxon p | Holm | أثر مزدوج (وسيط) | CI95 |',
    '|---|---|---|---|---|---|---|---|---|---|---|---|',
  ];
  for (const b of budgets) {
    for (const g of ['B', 'C']) {
      for (const a of ['cri', 'nocross', 'noise']) {
        const c = data.comparisons[`${a}-vs-base@${b}@${g}`];
        if (!c) continue;
        const pb = c.pairedBootstrap;
        out.inference.push(`| ${b} | ${g} | ${a} | ${c.solvedArm}/30 | ${c.solvedBase}/30 | ${c.mcnemar.b}/${c.mcnemar.c} | ${fmt(c.pValueBinary, 4)} | ${fmt(c.holmAdjustedPBinary, 4)} | ${fmt(c.pValue, 6)} | ${fmt(c.holmAdjustedP, 6)} | ${fmt(pb.point)} | [${pb.ci95.join(', ')}] |`);
      }
    }
  }

  out.perTask = [
    '| المهمة | المجموعة | base | nocross | noise | **cri** |',
    '|---|---|---|---|---|---|',
  ];
  const tasks = [...new Set(data.runs.map(r => r.taskId))].sort();
  for (const t of tasks) {
    const cells = arms.map(a => {
      const rows = data.runs.filter(r => r.budget === 250 && r.arm === a && r.taskId === t);
      const ok = rows.filter(r => r.success).map(r => r.evaluations);
      return ok.length ? `${median(ok)} (${ok.length}/5)` : `— (${ok.length}/5)`;
    });
    const group = data.runs.find(r => r.taskId === t).group;
    out.perTask.push(`| ${t} | ${group} | ${cells.join(' | ')} |`);
  }

  out.failures = ['| ميزانية | ذراع | إخفاقات |', '|---|---|---|'];
  for (const b of budgets) {
    for (const a of arms) {
      const f = data.runs.filter(r => r.budget === b && r.arm === a && !r.success)
        .map(r => `${r.taskId}#${r.seed}`);
      out.failures.push(`| ${b} | ${a} | ${f.length ? f.join('، ') : 'لا شيء'} |`);
    }
  }

  out.hints = ['| ذراع | تلميحات موروثة | إصابات | إخفاقات | مهارات مستعادة مستخدمة |', '|---|---|---|---|---|'];
  for (const a of arms) {
    const rows = data.runs.filter(r => r.budget === 250 && r.arm === a);
    const sum = k => rows.reduce((x, r) => x + (r.memoryStats[k] || 0), 0);
    out.hints.push(`| ${a} | ${sum('hintsInherited')} | ${sum('hintHits')} | ${sum('hintMisses')} | ${sum('restoredSkillsUsed')} |`);
  }

  out.similarity = ['| المهمة | المجموعة | أقرب تشابه مع A | الصنف | عائلات العيوب |', '|---|---|---|---|---|'];
  for (const [id, v] of Object.entries(data.similarity.classes)) {
    out.similarity.push(`| ${id} | ${v.group} | ${v.maxSimInA} | ${v.class} | ${v.families.join('، ')} |`);
  }

  out.resources = ['| ذراع | مجموع التقييمات | ذروة RSS | حجم ملف الذاكرة |', '|---|---|---|---|'];
  for (const a of arms) {
    const rows = data.runs.filter(r => r.budget === 250 && r.arm === a);
    out.resources.push(`| ${a} | ${rows.reduce((x, r) => x + r.evaluations, 0)} | ${Math.max(...rows.map(r => r.rssMb))}MB | ${rows[0].memoryFileBytes || '—'} |`);
  }

  out.sessionControl = ['| البذرة | عملية الاكتساب | عملية التقييم | متطابق | بصمة الذاكرة |', '|---|---|---|---|---|'];
  const receipts = new Map(data.acquisitionReceipts.map(r => [r.seed, r]));
  for (const c of data.sessionControl) {
    const rec = receipts.get(c.seed);
    out.sessionControl.push(`| ${c.seed} | PID ${rec.pid} | PID ${c.crossProcessPid} | ${c.identical ? 'نعم' : 'لا'} | ${c.memoryFileSha256.slice(0, 12)} |`);
  }

  return out;
}

/* ------------------------------------------------------------------ Phase 2 */
export function phase2Tables(data) {
  const out = {};
  const arms = ['base', 'cri', 'cri-notransfer'];
  out.summary = ['| الذراع | نجاح | وسيط التقييمات | متوسط الدرجة | حلول مُركَّبة |', '|---|---|---|---|---|'];
  for (const arm of arms) {
    const row = data.summary[arm];
    if (!row) continue;
    out.summary.push(`| ${arm} | ${row.solved}/${row.runs} (${(row.successRate * 100).toFixed(1)}%) | ${row.medianEvaluationsOnSuccess} | ${row.meanScore} | ${row.composedSuccesses} |`);
  }
  out.sweep = ['| ميزانية | base | cri | cri-notransfer |', '|---|---|---|---|'];
  for (const row of data.sweep || []) {
    out.sweep.push(`| ${row.budget} | ${(row.arms.base.successRate * 100).toFixed(1)}% | ${(row.arms.cri.successRate * 100).toFixed(1)}% | ${(row.arms['cri-notransfer'].successRate * 100).toFixed(1)}% |`);
  }
  out.paired = ['| المقارنة | وحدات | نجاح الذراع | نجاح base | متخالف b/c | McNemar p | أثر مزدوج | CI95 | Wilcoxon p |', '|---|---|---|---|---|---|---|---|---|'];
  for (const [key, v] of Object.entries(data.paired || {})) {
    const pb = v.pairedBootstrap;
    out.paired.push(`| ${key} | ${v.units} | ${v.solvedArm} | ${v.solvedBase} | ${v.mcnemar.b}/${v.mcnemar.c} | ${v.mcnemar.p} | ${pb.point} | [${pb.ci95.join(', ')}] | ${v.wilcoxon.p} |`);
  }
  out.perTask = ['| المهمة | base | cri | cri-notransfer |', '|---|---|---|---|'];
  const tasks = [...new Set(data.results.map(r => r.taskId))].sort();
  for (const t of tasks) {
    const cells = arms.map(a => {
      const ok = data.results.filter(r => r.arm === a && r.taskId === t && r.success).map(r => r.evaluations);
      return ok.length ? `${median(ok)} (${ok.length}/5)` : `— (0/5)`;
    });
    out.perTask.push(`| ${t} | ${cells.join(' | ')} |`);
  }
  out.singleOperator = ['| المهمة | قابلة بمشغّل واحد | أفضل نتيجة بمشغّل واحد |', '|---|---|---|'];
  for (const [id, row] of Object.entries(data.exhaustive || {})) {
    out.singleOperator.push(`| ${id} | ${row.solvableByOneOperator ? 'نعم' : '**لا**'} | ${row.bestSingleScore} |`);
  }
  return out;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const args = {};
  for (const raw of process.argv.slice(2)) {
    const m = /^--([^=]+)(?:=(.*))?$/.exec(raw);
    if (m) args[m[1]] = m[2] === undefined ? true : m[2];
  }
  if (args.phase3) {
    const tables = phase3Tables(read(args.phase3));
    for (const [name, rows] of Object.entries(tables)) {
      console.log(`\n### ${name}\n${rows.join('\n')}`);
    }
  }
  if (args.phase2) {
    const tables = phase2Tables(read(args.phase2));
    for (const [name, rows] of Object.entries(tables)) {
      console.log(`\n### ${name}\n${rows.join('\n')}`);
    }
  }
}
