/**
 * Synora WAR v5 — PHASE 3: the experiment orchestrator.
 *
 * Every arm runs in ITS OWN PROCESS. The memory only ever crosses a process boundary through
 * the file written by the acquisition session, so "the memory survived the session" is a
 * property of the file, not an accident of shared memory.
 *
 * Arms
 *   cri        persistent memory: session 1 acquires on A, writes the memory file, EXITS;
 *              a NEW process restores the file and works on B then C.
 *   nocross    the same engine, but the ledger is reset before every task: the skills learned
 *              inside a task are used inside that task and then deleted.
 *   base       no ledger at all.
 *   noise      the memory file is restored, but the value hints are randomised: the control for
 *              "useful knowledge" vs "any hint at all".
 *   inprocess  the acquisition runs inside the evaluation process: the control that proves the
 *              file-based memory carries exactly the same information as the in-memory one.
 *
 * Budgets: 10 / 30 / 60 / 250 evaluations per task.
 *
 *   node synora-v5/phase3/experiments.mjs --seeds=5 --budgets=10,30,60,250 \
 *        --out=experiments/results-phase3.json
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { similarityReport, summariseArm, median, pairedUnits, compareArms } from './analysis.mjs';
import { holmBonferroni } from '../stats.mjs';
import { TASKS, byGroup } from './tasks.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(HERE, '..', '..');

function parseArgs(argv) {
  const args = { seeds: 5, budgets: '10,30,60,250', generations: 80, out: 'experiments/results-phase3.json', raw: 'experiments/phase3' };
  for (const raw of argv) {
    const m = /^--([^=]+)(?:=(.*))?$/.exec(raw);
    if (!m) continue;
    const key = m[1];
    const value = m[2] ?? 'true';
    if (key in args) args[key] = (key === 'out' || key === 'raw' || key === 'budgets') ? value : Number(value);
  }
  return args;
}

function runNode(script, argv, label) {
  const result = spawnSync(process.execPath, [path.join(HERE, script), ...argv], {
    cwd: ROOT, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024,
  });
  if (result.status !== 0) {
    console.error(`--- ${label} failed (exit ${result.status}) ---\n${result.stderr}`);
    throw new Error(`${label} failed`);
  }
  return result.stdout;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const budgets = String(args.budgets).split(',').map(Number).filter(Boolean);
  const rawDir = path.join(ROOT, args.raw);
  const memoryDir = path.join(rawDir, 'memory');
  fs.mkdirSync(memoryDir, { recursive: true });

  const runs = [];
  const acquisitionReceipts = [];
  const controlChecks = [];

  for (let seed = 1; seed <= args.seeds; seed++) {
    /* ---------- SESSION 1: acquisition (its own process) ---------- */
    const memoryFile = path.join(memoryDir, `acquire-seed${seed}.json`);
    const memoryFileRel = path.relative(ROOT, memoryFile);
    const acquireOut = runNode('acquire.mjs', [
      `--seed=${seed}`, `--budget=${Math.max(...budgets)}`, `--generations=${args.generations}`,
      `--out=${memoryFileRel}`,
    ], `acquire seed ${seed}`);
    const receipt = JSON.parse(acquireOut);
    acquisitionReceipts.push(receipt);

    for (const budget of budgets) {
      for (const arm of ['cri', 'nocross', 'base', 'noise', 'inprocess']) {
        const argv = [`--mode=${arm}`, `--seed=${seed}`, `--budget=${budget}`, `--generations=${args.generations}`, '--groups=B,C'];
        if (arm === 'cri' || arm === 'noise') argv.push(`--memory=${memoryFileRel}`);
        if (arm === 'inprocess') argv.push(`--acquire-budget=${Math.max(...budgets)}`);
        const outFile = path.join(rawDir, `eval-${arm}-seed${seed}-budget${budget}.json`);
        const outFileRel = path.relative(ROOT, outFile);
        argv.push(`--out=${outFileRel}`);
        runNode('evaluate.mjs', argv, `evaluate ${arm} seed ${seed} budget ${budget}`);
        const payload = JSON.parse(fs.readFileSync(outFile, 'utf8'));
        for (const r of payload.results) {
          runs.push({
            ...r, arm, budget, seed,
            elapsedMs: payload.elapsedMs,
            rssMb: payload.rssMb || 0,
            memoryFileBytes: payload.memoryFileBytes || null,
            memorySource: payload.memory.source,
            memorySkills: payload.memory.skills || 0,
          });
        }
        if (arm === 'inprocess' && budget === Math.max(...budgets)) {
          // the control: the same session, run inside one process, must be identical to the
          // file-based session (same seeds, same budget, same engine)
          const crossFile = path.join(rawDir, `eval-cri-seed${seed}-budget${budget}.json`);
          const cross = JSON.parse(fs.readFileSync(crossFile, 'utf8'));
          const key = r => `${r.taskId}|${r.success}|${r.evaluations}|${r.champion.code}`;
          const a = payload.results.map(key).sort();
          const b = cross.results.map(key).sort();
          controlChecks.push({
            seed, budget,
            identical: JSON.stringify(a) === JSON.stringify(b),
            inProcessPid: payload.pid,
            crossProcessPid: cross.pid,
            memoryFileSha256: receipt.memory.sha256,
          });
        }
      }
    }
    process.stdout.write(`seed ${seed}/${args.seeds} done\n`);
  }

  /* ---------------- aggregation ---------------- */
  const summary = {};
  for (const arm of ['cri', 'nocross', 'base', 'noise', 'inprocess']) {
    const mine = runs.filter(r => r.arm === arm);
    summary[arm] = {};
    for (const budget of budgets) {
      const rows = mine.filter(r => r.budget === budget);
      summary[arm][budget] = summariseArm(rows);
    }
  }

  // PAIRED comparisons. The resampling / test unit is (taskId, seed) — the same task with the
  // same seed in both arms. Failures are NOT dropped silently: they are counted, they enter
  // McNemar's test, and they also enter a censored view where a failure costs the full budget.
  const comparisonList = [];
  for (const budget of budgets) {
    const base = runs.filter(r => r.arm === 'base' && r.budget === budget);
    for (const arm of ['cri', 'nocross', 'noise']) {
      const other = runs.filter(r => r.arm === arm && r.budget === budget);
      for (const group of ['B', 'C']) {
        const units = pairedUnits(
          other.filter(r => r.group === group),
          base.filter(r => r.group === group),
        );
        const stats = compareArms(units, budget);
        comparisonList.push({
          arm, base: 'base', budget, group,
          ...stats,
          pValue: stats.wilcoxon.p,
          // McNemar is the test of the paired BINARY outcome (success); the Wilcoxon test is
          // the paired test of the efficiency difference among the pairs both arms solved.
          pValueBinary: stats.mcnemar.p,
        });
      }
    }
  }
  // MULTIPLICITY: two separate families, each corrected with Holm-Bonferroni:
  //   (a) the BINARY family  -> McNemar's exact test on the paired success outcome
  //   (b) the CONTINUOUS family -> Wilcoxon signed-rank on the paired efficiency difference
  // Each family holds 3 arms x 2 groups x 4 budgets = 24 comparisons.
  const binaryAdj = holmBonferroni(comparisonList.map(c => ({
    key: `${c.arm}-vs-base@${c.budget}@${c.group}`, p: c.pValueBinary,
  })));
  const continuousAdj = holmBonferroni(comparisonList.map(c => ({
    key: `${c.arm}-vs-base@${c.budget}@${c.group}`, p: c.pValue,
  })));
  const binaryBy = new Map(binaryAdj.map(a => [a.key, a]));
  const continuousBy = new Map(continuousAdj.map(a => [a.key, a]));
  const comparisons = {};
  for (const c of comparisonList) {
    const key = `${c.arm}-vs-base@${c.budget}@${c.group}`;
    const bAdj = binaryBy.get(key);
    const cAdj = continuousBy.get(key);
    comparisons[key] = {
      ...c,
      holmAdjustedP: cAdj.pAdjusted, holmRank: cAdj.rank, familySize: cAdj.familySize,
      holmAdjustedPBinary: bAdj.pAdjusted, holmRankBinary: bAdj.rank, familySizeBinary: bAdj.familySize,
    };
  }

  const similarity = similarityReport();
  const crossStructure = Object.entries(similarity.classes).filter(([, v]) => v.class === 'cross_structure').map(([k]) => k);
  const crossStructureStats = {};
  for (const arm of ['cri', 'nocross', 'base', 'noise']) {
    const budget = Math.max(...budgets);
    const rows = runs.filter(r => r.arm === arm && r.budget === budget && crossStructure.includes(r.taskId));
    const ok = rows.filter(r => r.success);
    crossStructureStats[arm] = {
      tasks: crossStructure,
      runs: rows.length,
      solved: ok.length,
      successRate: Number((ok.length / rows.length).toFixed(4)),
      medianEvaluationsOnSuccess: median(ok.map(r => r.evaluations)),
    };
  }

  const payload = {
    generatedAt: new Date().toISOString(),
    config: {
      seeds: args.seeds, budgets, generations: args.generations,
      tasksPerGroup: { A: byGroup('A').length, B: byGroup('B').length, C: byGroup('C').length },
      environment: { node: process.version, cpus: (await import('node:os')).cpus().length, platform: process.platform },
    },
    acquisitionReceipts: acquisitionReceipts.map(r => ({
      seed: r.seed, pid: r.pid, memoryPath: r.memory.path, memorySha256: r.memory.sha256,
      skills: r.memory.skills, refutations: r.memory.refutations, prohibitions: r.memory.prohibitions,
      tasks: r.tasks, results: r.results, elapsedMs: r.elapsedMs,
    })),
    sessionControl: controlChecks,
    similarity,
    crossStructure,
    crossStructureStats,
    summary,
    comparisons,
    runs,
  };
  const outPath = path.isAbsolute(args.out) ? args.out : path.join(ROOT, args.out);
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, JSON.stringify(payload, null, 2));

  console.log(`\nphase-3 experiment -> ${outPath}`);
  console.log(`\nbudget  arm            solved   rate    medEvals   B-med   C-med`);
  for (const budget of budgets) {
    for (const arm of ['base', 'nocross', 'noise', 'cri', 'inprocess']) {
      const s = summary[arm][budget];
      if (!s) continue;
      console.log(`${String(budget).padStart(5)}   ${arm.padEnd(14)} ${String(s.solved).padStart(3)}/${s.runs}   ${(s.successRate * 100).toFixed(1).padStart(6)}%   ${String(s.medianEvaluationsOnSuccess).padStart(8)}   ${String(s.groups.B && s.groups.B.medianEvaluationsOnSuccess).padStart(6)}   ${String(s.groups.C && s.groups.C.medianEvaluationsOnSuccess).padStart(6)}`);
    }
  }
  console.log('\ncross-process vs in-process control:', controlChecks.map(c => `${c.seed}:${c.identical ? 'IDENTICAL' : 'DIFFERENT'}`).join(' '));
}

main().catch(err => { console.error(err); process.exit(1); });
