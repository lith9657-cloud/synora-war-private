/**
 * Synora WAR v5 — PHASE 3: THE ANSWER KEY (grader-private).
 *
 * Imported ONLY by ./grader.mjs. The engine, the operators and the memory layer never import
 * it; tests/phase3.test.mjs asserts that, and also asserts that a saved memory file contains
 * none of the expected values of ANY group (including the held-out C group).
 *
 * A plan is the sequence of tool invocations that a correct solution performs; the grader
 * EXECUTES the plan to obtain the expected value and compares.
 */
export const PLANS = {
  /* A — acquisition */
  A1_names3_txt: { calls: [['listDir'], ['filterByExt', 'txt'], ['sortBy', 'size', 'desc'], ['take', 3], ['joinNames', ', ']] },
  A2_ext_sum_csv: { calls: [['listDir'], ['filterByExt', 'csv'], ['sumSize']] },
  A3_md_count: { calls: [['listDir'], ['filterByExt', 'md'], ['countByExt']], field: 'md' },
  A4_min_count_100: { calls: [['listDir'], ['filterByMinSize', 100]], field: 'length' },
  A5_clean_text: { calls: [['normalizeSpaces'], ['toArabicDigits']] },
  A6_sort_by_name: { calls: [['listDir'], ['sortBy', 'name', 'asc'], ['joinNames', '-']] },
  A7_count_all_types: { calls: [['listDir'], ['countByExt']] },

  /* B — generalisation */
  B1_two_filter_names: { calls: [['listDir'], ['filterByExt', 'csv'], ['filterByMinSize', 100], ['sortBy', 'size', 'desc'], ['take', 2], ['joinNames', ', ']] },
  B2_field_only: { calls: [['listDir'], ['countByExt']], field: 'txt' },
  B3_missing_filter: { calls: [['listDir'], ['filterByExt', 'txt'], ['sortBy', 'size', 'desc'], ['joinNames', '-']] },
  B4_threshold_sort_name: { calls: [['listDir'], ['filterByMinSize', 50], ['sortBy', 'name', 'asc'], ['joinNames', '-']] },
  B5_extra_take_sum: { calls: [['listDir'], ['filterByExt', 'txt'], ['sumSize']] },
  B6_md_largest_one: { calls: [['listDir'], ['filterByExt', 'md'], ['sortBy', 'size', 'desc'], ['take', 1], ['joinNames', '-']] },

  /* C — final held-out */
  C1_two_filter_one: { calls: [['listDir'], ['filterByExt', 'txt'], ['filterByMinSize', 50], ['sortBy', 'size', 'desc'], ['take', 1], ['joinNames', '، ']] },
  C2_missing_filter_sum: { calls: [['listDir'], ['filterByExt', 'md'], ['sumSize']] },
  C3_missing_threshold_sum: { calls: [['listDir'], ['filterByExt', 'txt'], ['filterByMinSize', 100], ['sumSize']] },
  C4_sort_size_desc_names: { calls: [['listDir'], ['sortBy', 'size', 'desc'], ['joinNames', '، ']] },
  C5_two_filter_names3: { calls: [['listDir'], ['filterByExt', 'txt'], ['filterByMinSize', 50], ['sortBy', 'name', 'asc'], ['take', 3], ['joinNames', '-']] },
  C6_txt_two_names: { calls: [['listDir'], ['filterByExt', 'txt'], ['sortBy', 'size', 'desc'], ['take', 2], ['joinNames', '، ']] },
};

export const planFor = taskId => PLANS[taskId];
