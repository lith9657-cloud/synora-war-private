/**
 * Synora WAR v5 — v4 baseline harness.
 *
 * Runs the UNMODIFIED v4 engine (`synora-evo-farm-v4.mjs`) on exactly the same benchmark tasks,
 * with exactly the same killers, and the same evaluation budget as the v5 arms.
 *
 * How it stays honest:
 *  - The v4 source is copied verbatim into a temp directory; the ONLY edit is the `TRIBES`
 *    whitelist, so that it accepts the benchmark task ids as tribe names. The algorithm
 *    (mutation, evaluation, promotion, graveyard) is untouched.
 *  - The tasks are laid out in the exact directory structure v4 expects:
 *    `tribes/<id>/teacher.js` (the buggy seed) and `tribes/<id>/killers_<id>.jsonl`.
 *  - The final teacher is scored by the SAME v5 judge, on the SAME train/validation killers and
 *    the SAME holdout inputs, so the final exam is identical for both engines.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { Judge } from './judge.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const V4_SOURCE = path.join(HERE, '..', 'synora-evo-farm-v4.mjs');

export function runV4Baseline(tasks, { budget = 800, workdir = null, quiet = true } = {}) {
  const root = workdir || fs.mkdtempSync(path.join(os.tmpdir(), 'synora-v4-baseline-'));
  fs.mkdirSync(root, { recursive: true });

  // 1. copy v4 verbatim, widening only the tribe whitelist
  const source = fs.readFileSync(V4_SOURCE, 'utf8');
  const tribeIds = tasks.map(t => t.id);
  const patched = source.replace(
    /const TRIBES = \[[^\]]*\];/,
    `const TRIBES = ${JSON.stringify(tribeIds)};`,
  );
  if (patched === source) throw new Error('Could not patch the v4 tribe whitelist');
  const enginePath = path.join(root, 'synora-evo-farm-v4.mjs');
  fs.writeFileSync(enginePath, patched, 'utf8');

  // 2. lay the tasks out the way v4 expects
  for (const task of tasks) {
    const dir = path.join(root, 'tribes', task.id);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'teacher.js'), task.buggy + '\n', 'utf8');
    const killers = [...task.train, ...task.validation].map(k => JSON.stringify(k)).join('\n') + '\n';
    fs.writeFileSync(path.join(dir, `killers_${task.id}.jsonl`), killers, 'utf8');
  }

  // 3. run v4 repeatedly (each `--once` run evaluates ~20 candidates) until the budget is spent
  const results = [];
  for (const task of tasks) {
    const runs = [];
    let evaluations = 0;
    let attempt = 0;
    while (evaluations < budget && attempt < 200) {
      attempt++;
      const proc = spawnSync(process.execPath, [enginePath, `--tribe=${task.id}`, '--with-teacher', '--once'], {
        cwd: root, encoding: 'utf8', timeout: 120000,
        env: { ...process.env, SYNORA_TIMEOUT_MS: process.env.SYNORA_TIMEOUT_MS || '500' },
      });
      if (proc.status !== 0) break;
      let summary;
      try { summary = JSON.parse(proc.stdout); } catch { break; }
      evaluations += summary.evaluated || 0;
      runs.push({ evaluated: summary.evaluated, teacherPromoted: summary.teacherPromoted, ark: summary.ark });
      if (!quiet) console.log(`  v4 ${task.id} run ${attempt}: evaluated=${summary.evaluated} promoted=${summary.teacherPromoted}`);
    }
    const teacher = fs.readFileSync(path.join(root, 'tribes', task.id, 'teacher.js'), 'utf8').trim();
    results.push({ taskId: task.id, teacher, evaluations, runs });
  }
  return { root, results };
}

/** Score the v4 champions with the v5 judge (identical final exam for every engine). */
export async function scoreV4Champions(v4Results, tasks, judge) {
  const out = [];
  for (const entry of v4Results.results) {
    const task = tasks.find(t => t.id === entry.taskId);
    const killers = await judge.runKillers(entry.teacher, [...task.train, ...task.validation]);
    const holdout = await judge.differential(entry.teacher, task.reference, task.holdout);
    const success = killers.passed === killers.total && holdout.length === 0;
    out.push({
      taskId: entry.taskId,
      success,
      evaluations: entry.evaluations,
      train: `${killers.passed}/${killers.total}`,
      holdoutFailures: holdout.length,
      code: entry.teacher,
      runs: entry.runs.length,
    });
  }
  return out;
}

export async function runBaseline(tasks, { budget = 800 } = {}) {
  const v4 = runV4Baseline(tasks, { budget });
  const judge = new Judge({ size: 2, timeoutMs: 500 });
  await judge.init();
  const scored = await scoreV4Champions(v4, tasks, judge);
  await judge.close();
  const success = scored.filter(r => r.success).length;
  return {
    arm: 'v4-baseline',
    summary: {
      tasks: tasks.length,
      success,
      successRate: success / tasks.length,
      totalEvaluations: scored.reduce((a, r) => a + r.evaluations, 0),
      medianEvaluations: scored.map(r => r.evaluations).sort((a, b) => a - b)[Math.floor(scored.length / 2)] || 0,
    },
    results: scored,
  };
}
