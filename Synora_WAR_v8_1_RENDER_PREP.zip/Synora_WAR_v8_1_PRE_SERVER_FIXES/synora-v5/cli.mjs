/**
 * Synora WAR v5 — command line runner.
 *
 *   node synora-v5/cli.mjs --mode=full --set=all --seed=7 --budget=400 --out=results.json
 *   node synora-v5/cli.mjs --mode=random --set=B --bank=ledger.json --out=cold.json
 *
 * Flags
 *   --mode=full|random   full = CRI memory active; random = identical operators, no memory
 *   --set=A|B|all        which task set to run
 *   --tasks=id,id        explicit task ids
 *   --seed=N             deterministic seed (every run is reproducible)
 *   --budget=N           candidate evaluations per task
 *   --generations=N      maximum generations per task
 *   --bank=path          load a ledger (warm start / transfer experiment)
 *   --out=path           write results as JSON
 *   --save-ledger=path   write the resulting ledger as JSON
 *   --quiet              suppress per-generation logs
 */
import fs from 'node:fs';
import path from 'node:path';
import { Judge } from './judge.mjs';
import { Ledger } from './ledger.mjs';
import { Engine } from './engine.mjs';
import { TASKS, byId } from './tasks.mjs';

export function parseArgs(argv) {
  const args = {};
  for (const raw of argv) {
    const m = /^--([^=]+)(?:=(.*))?$/.exec(raw);
    if (!m) continue;
    args[m[1]] = m[2] === undefined ? true : m[2];
  }
  return args;
}

export function selectTasks(args) {
  if (args.tasks) return String(args.tasks).split(',').map(s => s.trim()).filter(Boolean).map(id => byId(id)).filter(Boolean);
  if (args.set === 'A') return TASKS.filter(t => t.set === 'A');
  if (args.set === 'B') return TASKS.filter(t => t.set === 'B');
  return TASKS;
}

/** Aggregate metrics computed identically for every arm, from the raw event log. */
export function summarise(results) {
  const total = results.length;
  const success = results.filter(r => r.success).length;
  const certified = results.filter(r => r.certified).length;
  const evals = results.map(r => r.evaluations).sort((a, b) => a - b);
  const median = evals.length ? evals[Math.floor(evals.length / 2)] : 0;
  let failureEvents = 0, attributable = 0, attributableRepeats = 0, witnessViolations = 0;
  for (const r of results) {
    const seen = new Set();
    for (const event of r.events) {
      if (event.type === 'witness_violation') { witnessViolations++; continue; }
      if (event.type !== 'failure') continue;
      failureEvents++;
      if (!event.attributable) continue;           // inherited failures are not "new mistakes"
      attributable++;
      // a mistake the engine had already been taught about, repeated in a later generation
      if (seen.has(event.signature)) attributableRepeats++;
      seen.add(event.signature);
    }
  }
  return {
    tasks: total,
    success,
    certified,
    successRate: total ? success / total : 0,
    medianEvaluations: median,
    totalEvaluations: results.reduce((a, r) => a + r.evaluations, 0),
    totalOracleQueries: results.reduce((a, r) => a + r.oracleQueries, 0),
    failureEvents,
    attributableFailures: attributable,
    attributableRepeats,
    // rate at which the engine repeats a mistake that was already documented for that task
    recurrenceRate: attributable ? attributableRepeats / attributable : null,
    // rate at which a candidate violates an inherited witness (a documented counterexample)
    witnessViolations,
    witnessViolationRate: results.reduce((a, r) => a + r.evaluations, 0) ? witnessViolations / results.reduce((a, r) => a + r.evaluations, 0) : 0,
    attributableFailureRate: failureEvents ? attributable / failureEvents : 0,
  };
}

export async function run(args = {}) {
  const mode = args.mode || 'full';
  const seed = Number(args.seed ?? 1);
  const budget = Number(args.budget ?? 800);
  const generations = Number(args.generations ?? 120);
  const oracleBudget = Number(args['oracle-budget'] ?? 200);
  const distractorCount = Number(args.distractors ?? 0);

  const ledger = args.bank && fs.existsSync(args.bank)
    ? Ledger.fromJSON(JSON.parse(fs.readFileSync(args.bank, 'utf8')))
    : new Ledger();

  const judge = new Judge({ size: 2, timeoutMs: 500 });
  await judge.init();
  const engine = new Engine({
    judge, ledger, mode, seed, budget, generations, oracleBudget, distractorCount,
    log: args.quiet ? () => {} : (e) => {
      if (process.env.SYNORA_VERBOSE) console.error(`  [${mode}] ${e.task} gen${e.gen} evals=${e.evaluations} score=${e.score}`);
    },
  });

  const tasks = selectTasks(args);
  const results = [];
  for (const task of tasks) {
    const result = await engine.runTask(task);
    results.push(result);
    const mark = result.success ? 'PASS' : 'fail';
    console.log(`${mark} ${task.id.padEnd(24)} evals=${String(result.evaluations).padStart(4)} oracle=${String(result.oracleQueries).padStart(3)} ` +
      `train=${result.champion.train.passed}/${result.champion.train.total} val=${result.champion.validation.passed}/${result.champion.validation.total} ` +
      `wit=${result.champion.witnesses.passed}/${result.champion.witnesses.total} code=${JSON.stringify(result.champion.code).slice(0, 74)}`);
  }
  await judge.close();

  const summary = summarise(results);
  console.log('\nSUMMARY ' + JSON.stringify({ mode, seed, budget, generations, ...summary }));

  if (args.out) {
    fs.mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
    fs.writeFileSync(args.out, JSON.stringify({ args: { mode, seed, budget, generations }, summary, results }, null, 2) + '\n', 'utf8');
    console.log(`wrote ${args.out}`);
  }
  if (args['save-ledger']) {
    fs.mkdirSync(path.dirname(path.resolve(args['save-ledger'])), { recursive: true });
    fs.writeFileSync(args['save-ledger'], JSON.stringify(ledger.toJSON(), null, 2) + '\n', 'utf8');
    console.log(`wrote ${args['save-ledger']}`);
  }
  return { summary, results, ledger };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  run(parseArgs(process.argv.slice(2))).catch(error => {
    console.error(error && error.stack || error);
    process.exitCode = 1;
  });
}
