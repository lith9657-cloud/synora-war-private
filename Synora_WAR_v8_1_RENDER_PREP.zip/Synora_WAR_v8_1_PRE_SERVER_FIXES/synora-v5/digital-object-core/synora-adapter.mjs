import { createHash } from 'node:crypto';

const stable = value => {
  if (Array.isArray(value)) return `[${value.map(stable).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${stable(value[k])}`).join(',')}}`;
  return JSON.stringify(value);
};
const digest = value => createHash('sha256').update(stable(value)).digest('hex');

/**
 * Explicit, opt-in bridge from a Synora PST/CRI-compatible engine result to Digital Object Core.
 * It wraps the public runTask(task) boundary only; it does not alter the search algorithm, ledger,
 * scoring, or CRI persistence. Each runId/taskId pair is an idempotency key. Reusing that key for
 * a different result is surfaced as a conflict by DigitalObjectCore rather than overwritten.
 */
export class DigitalObjectSynoraAdapter {
  constructor(core, { runId, mode = 'cri', seed = 1, budget = 150 } = {}) {
    if (!core || typeof core.addFact !== 'function') throw new TypeError('a DigitalObjectCore instance is required');
    if (typeof runId !== 'string' || !runId.trim()) throw new TypeError('runId is required for idempotent integration');
    if (typeof mode !== 'string' || !mode.trim() || !Number.isFinite(seed) || !Number.isFinite(budget) || budget < 1) throw new TypeError('invalid run metadata');
    this.core = core; this.runId = runId; this.mode = mode; this.seed = seed; this.budget = budget;
    this.attached = null;
  }

  recordTaskResult(result) {
    if (!result || typeof result.taskId !== 'string' || !result.taskId.trim() || typeof result.success !== 'boolean' || !Number.isFinite(result.score) || !Number.isInteger(result.evaluations)) throw new TypeError('engine result is missing required public result fields');
    const publicResult = {
      runId: this.runId, taskId: result.taskId, success: result.success, score: result.score,
      evaluations: result.evaluations, violations: Array.isArray(result.violations) ? result.violations.map(String) : [],
      championSignature: result.champion?.signature ?? null, mode: this.mode, seed: this.seed, budget: this.budget,
    };
    const eventId = `synora-result:${digest({ runId: this.runId, taskId: result.taskId }).slice(0, 40)}`;
    const fact = this.core.addFact({
      subject: result.taskId, predicate: 'synora.pst-result', object: stable(publicResult),
      source: 'synora-cri-adapter', status: 'accepted', confidence: result.success ? 1 : Math.max(0, Math.min(1, result.score)),
      evidence: [{ kind: 'engine-result', runId: this.runId, mode: this.mode, seed: this.seed, budget: this.budget, digest: digest(publicResult) }],
    }, eventId);
    return { eventId, duplicate: fact.duplicate === true, factId: fact.id, taskId: result.taskId };
  }

  attach(engine) {
    if (!engine || typeof engine.runTask !== 'function') throw new TypeError('engine must expose runTask(task)');
    if (this.attached) throw new Error('adapter is already attached to an engine');
    const original = engine.runTask;
    const adapter = this;
    async function wrappedRunTask(task, ...args) {
      const result = await original.call(this, task, ...args);
      try {
        const recording = adapter.recordTaskResult(result);
        return { ...result, digitalObjectRecording: { ok: true, ...recording } };
      } catch (error) {
        // The engine has already completed. Preserve its result and expose the recording
        // failure explicitly so callers can inspect/retry instead of losing the result.
        const message = String(error?.message ?? error);
        return { ...result, digitalObjectRecording: { ok: false, retryable: !message.includes('event id conflict'), error: { name: error?.name ?? 'Error', message } } };
      }
    }
    engine.runTask = wrappedRunTask;
    this.attached = { engine, original, wrappedRunTask };
    return engine;
  }

  detach() {
    if (!this.attached) return false;
    const { engine, original, wrappedRunTask } = this.attached;
    if (engine.runTask === wrappedRunTask) engine.runTask = original;
    this.attached = null;
    return true;
  }
}
