import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const SCHEMA_VERSION = 3;
const clone = value => value === undefined ? undefined : JSON.parse(JSON.stringify(value));
const stable = value => {
  if (Array.isArray(value)) return `[${value.map(stable).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${stable(value[k])}`).join(',')}}`;
  return JSON.stringify(value);
};
const hash = value => crypto.createHash('sha256').update(stable(value)).digest('hex');
const validId = id => typeof id === 'string' && id.trim().length > 0 && id.length <= 200;
const scalar = x => x === null || ['string', 'number', 'boolean'].includes(typeof x) && (typeof x !== 'number' || Number.isFinite(x));
const tripleKey = f => `${f.subject}\u0000${f.predicate}\u0000${stable(f.object)}`;
const factKey = f => `${tripleKey(f)}\u0000${f.source}`;
const validProperties = p => p && typeof p === 'object' && !Array.isArray(p) && Object.entries(p).every(([k,v]) => validId(k) && scalar(v));
const validPremise = p => !!p && typeof p === 'object' && !Array.isArray(p) && validId(p.predicate) && (p.subject === undefined || validId(p.subject)) && (p.object === undefined || scalar(p.object));
const validConclusion = c => !!c && typeof c === 'object' && validId(c.predicate) && validId(c.subjectFrom) && (c.objectValueFrom === undefined || ['premise.subject', 'premise.object'].includes(c.objectValueFrom)) && (c.objectValueFrom !== undefined || scalar(c.objectValue));
const pairKey = f => `${f.subject}\u0000${f.predicate}`;

export class DigitalObjectCore {
  constructor({ maxInferenceRounds = 32, maxDerivedFacts = 10000, functionalPredicates = [] } = {}) {
    if (!Number.isInteger(maxInferenceRounds) || maxInferenceRounds < 1 || maxInferenceRounds > 1000) throw new TypeError('maxInferenceRounds must be an integer in [1,1000]');
    if (!Number.isInteger(maxDerivedFacts) || maxDerivedFacts < 1) throw new TypeError('maxDerivedFacts must be a positive integer');
    if (!Array.isArray(functionalPredicates) || !functionalPredicates.every(validId)) throw new TypeError('functionalPredicates must be an array of predicate IDs');
    this.maxInferenceRounds = maxInferenceRounds; this.maxDerivedFacts = maxDerivedFacts; this.functionalPredicates = new Set(functionalPredicates);
    this.objects = new Map(); this.facts = new Map(); this.rules = new Map(); this.relations = new Map();
    this.events = new Map(); this.evidence = new Map(); this.experience = new Map(); this.sequence = 0;
  }

  // Event identity is checked before any state mutation. Same ID + same request is a no-op;
  // same ID + different request is an explicit conflict, never silent deduplication.
  #prepare(type, request, eventId) {
    const id = eventId ?? `auto:${this.sequence + 1}:${hash({ type, request }).slice(0, 24)}`;
    if (!validId(id)) throw new TypeError('event id must be a non-empty string');
    const prior = this.events.get(id);
    if (prior) {
      if (prior.type !== type || stable(prior.request) !== stable(request)) throw new Error(`event id conflict: ${id}`);
      return { duplicate: true, id, prior };
    }
    return { duplicate: false, id, type, request: clone(request) };
  }
  #commit(prepared, payload = {}) {
    if (prepared.duplicate) return prepared.prior;
    const event = { id: prepared.id, type: prepared.type, request: prepared.request, payload: clone(payload), sequence: ++this.sequence };
    this.events.set(event.id, event); return event;
  }
  #duplicateResult(value) { return { ...clone(value), duplicate: true }; }

  createObject({ id = crypto.randomUUID(), type = 'entity', properties = {}, state = 'active' } = {}, eventId) {
    if (!validId(id) || !validId(type) || !validId(state) || !validProperties(properties)) throw new TypeError('invalid object id, type, state, or properties');
    const request = { id, type, properties: clone(properties), state };
    const event = this.#prepare('object.created', request, eventId);
    if (event.duplicate) return this.#duplicateResult(this.objects.get(id));
    if (this.objects.has(id)) throw new Error(`object already exists: ${id}`);
    const obj = { ...request, createdAtSequence: this.sequence + 1 };
    this.objects.set(id, obj); this.#commit(event, { objectId: id }); return clone(obj);
  }
  getObject(id) { const x = this.objects.get(id); return x ? clone(x) : null; }

  transition(id, nextState, { allowedFrom, eventId, reason = 'explicit operation' } = {}) {
    if (!validId(id) || !validId(nextState) || !validId(reason)) throw new TypeError('invalid transition request');
    if (allowedFrom !== undefined && (!Array.isArray(allowedFrom) || !allowedFrom.every(validId))) throw new TypeError('allowedFrom must be an array of state IDs');
    const request = { id, nextState, allowedFrom: allowedFrom ? [...allowedFrom].sort() : null, reason };
    const event = this.#prepare('object.state.changed', request, eventId);
    const obj = this.objects.get(id); if (!obj) throw new Error(`unknown object: ${id}`);
    if (event.duplicate) return this.#duplicateResult(obj);
    if (allowedFrom && !allowedFrom.includes(obj.state)) throw new Error(`transition rejected: ${obj.state} -> ${nextState}`);
    const before = obj.state; obj.state = nextState;
    this.#commit(event, { before, after: nextState }); return clone(obj);
  }

  addRelation({ id = crypto.randomUUID(), from, to, type, properties = {} }, eventId) {
    if (!validId(id) || !validId(from) || !validId(to) || !validId(type) || !validProperties(properties)) throw new TypeError('relation id, endpoints, type, or properties are invalid');
    const request = { id, from, to, type, properties: clone(properties) };
    const event = this.#prepare('relation.created', request, eventId);
    if (event.duplicate) return this.#duplicateResult(this.relations.get(id));
    if (!this.objects.has(from) || !this.objects.has(to)) throw new Error(`relation references unknown object: ${from} -> ${to}`);
    if (this.relations.has(id)) throw new Error(`relation already exists: ${id}`);
    this.relations.set(id, request); this.#commit(event, { relationId: id }); return clone(request);
  }

  addFact({ subject, predicate, object, source = 'user', kind = 'direct', status = 'accepted', confidence = 1, evidence = [] }, eventId) {
    if (!validId(subject) || !validId(predicate) || !scalar(object) || !validId(source)) throw new TypeError('invalid fact');
    if (!['accepted', 'rejected', 'contested'].includes(status)) throw new TypeError('invalid fact status');
    if (!['direct', 'retrieved', 'hypothesis'].includes(kind)) throw new TypeError('invalid fact kind');
    if (typeof confidence !== 'number' || !Number.isFinite(confidence) || confidence < 0 || confidence > 1 || !Array.isArray(evidence)) throw new TypeError('invalid fact confidence or evidence');
    const request = { subject, predicate, object, source, kind, status, confidence, evidence: clone(evidence) };
    const event = this.#prepare('fact.upserted', request, eventId);
    const key = factKey(request); const prior = this.facts.get(key);
    if (event.duplicate) return this.#duplicateResult(prior);
    // A semantically identical fact from a new event is a no-op, but its event ID is
    // still committed. Otherwise that ID could later be reused with a different payload.
    if (prior && stable({ subject: prior.subject, predicate: prior.predicate, object: prior.object, source: prior.source, kind: prior.kind ?? 'direct', status: prior.status, confidence: prior.confidence, evidence: prior.evidence }) === stable(request)) {
      this.#commit(event, { factId: prior.id, noOp: true });
      return this.#duplicateResult(prior);
    }
    const fact = { id: `fact:${hash({ subject, predicate, object, source }).slice(0, 24)}`, ...request, derived: false };
    this.facts.set(key, fact); this.evidence.set(fact.id, clone(evidence)); this.#commit(event, { factId: fact.id, previousStatus: prior?.status ?? null }); return clone(fact);
  }

  removeFact({ id, subject, predicate, object, source = 'user' }, eventId) {
    const request = { id: id ?? null, subject: subject ?? null, predicate: predicate ?? null, objectProvided: object !== undefined, object: object ?? null, source };
    if (!validId(source) || id !== undefined && !validId(id) || subject !== undefined && !validId(subject) || predicate !== undefined && !validId(predicate)) throw new TypeError('invalid fact removal selector');
    const event = this.#prepare('fact.removed', request, eventId);
    if (event.duplicate) return { duplicate: true, removed: event.prior.payload.factId ?? null };
    let foundKey = null, found = null;
    for (const [k,f] of this.facts) {
      if ((id === undefined || f.id === id) && (subject === undefined || f.subject === subject) && (predicate === undefined || f.predicate === predicate) && (object === undefined || stable(f.object) === stable(object)) && f.source === source) { foundKey = k; found = f; break; }
    }
    if (!found) throw new Error('fact not found for removal');
    this.facts.delete(foundKey); this.evidence.delete(found.id); this.#commit(event, { factId: found.id }); return { removed: found.id, duplicate: false };
  }

  addRule({ id = crypto.randomUUID(), premise, conclusion, confidence = 1, enabled = true, source = 'user' }, eventId) {
    const premiseList = Array.isArray(premise) ? premise : [premise];
    if (!validId(id) || premiseList.length < 1 || !premiseList.every(validPremise) || !validConclusion(conclusion) || !validId(source)) throw new TypeError('invalid rule shape');
    if (typeof confidence !== 'number' || !Number.isFinite(confidence) || confidence < 0 || confidence > 1 || typeof enabled !== 'boolean') throw new TypeError('invalid rule confidence or enabled state');
    const request = { id, premise: clone(premise), conclusion: clone(conclusion), confidence, enabled, source };
    const event = this.#prepare('rule.added', request, eventId);
    if (event.duplicate) return this.#duplicateResult(this.rules.get(id));
    if (this.rules.has(id)) throw new Error(`rule already exists: ${id}`);
    const rule = { ...request, successes: 0, failures: 0 };
    this.rules.set(id, rule); this.#commit(event, { ruleId: id }); return clone(rule);
  }

  setRuleEnabled(id, enabled, eventId) {
    if (!validId(id) || typeof enabled !== 'boolean') throw new TypeError('rule ID and boolean enabled are required');
    const request = { id, enabled }; const event = this.#prepare('rule.enabled.changed', request, eventId);
    const rule = this.rules.get(id); if (!rule) throw new Error(`unknown rule: ${id}`);
    if (event.duplicate) return this.#duplicateResult(rule);
    rule.enabled = enabled; this.#commit(event, { ruleId: id, enabled }); return clone(rule);
  }

  infer({ maxRounds = this.maxInferenceRounds } = {}) {
    if (!Number.isInteger(maxRounds) || maxRounds < 1 || maxRounds > this.maxInferenceRounds) throw new TypeError('invalid inference round limit');
    const groups = new Map();
    for (const f of this.facts.values()) { const k = tripleKey(f); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(f); }
    const byPair = new Map();
    for (const f of this.facts.values()) { const k = pairKey(f); if (!byPair.has(k)) byPair.set(k, []); byPair.get(k).push(f); }
    // A proposition with rejected/contested evidence or multiple accepted values is
    // unresolved. Neither alternative may serve as a premise until reconciled.
    const blockedTriples = new Set();
    const blockedPairs = new Set();
    for (const [triple, group] of groups) if (group.some(f => f.kind !== 'hypothesis' && f.status !== 'accepted')) blockedTriples.add(triple);
    for (const [k, list] of byPair) {
      const acceptedValues = new Set(list.filter(f => f.status === 'accepted' && f.kind !== 'hypothesis').map(f => stable(f.object)));
      const predicate = list[0]?.predicate;
      // Predicates are multi-valued by default (e.g. Socrates is-a human and mortal).
      // Only explicitly functional predicates treat multiple values as a contradiction.
      if (this.functionalPredicates.has(predicate) && acceptedValues.size > 1) {
        blockedPairs.add(k);
        for (const f of list) blockedTriples.add(tripleKey(f));
      }
    }
    const known = new Map();
    for (const group of groups.values()) {
      const f = group[0];
      const usable = group.find(x => x.status === 'accepted' && x.kind !== 'hypothesis');
      if (usable && !blockedTriples.has(tripleKey(f)) && !blockedPairs.has(pairKey(f))) known.set(tripleKey(f), clone(usable));
    }
    const trace = []; const derivedConflicts = []; let rounds = 0, changed = true;
    const matches = (f, pattern) => f.predicate === pattern.predicate && (pattern.subject === undefined || f.subject === pattern.subject) && (pattern.object === undefined || stable(f.object) === stable(pattern.object));
    while (changed && rounds < maxRounds) {
      changed = false; rounds++;
      for (const rule of this.rules.values()) {
        if (!rule.enabled) continue;
        const patterns = Array.isArray(rule.premise) ? rule.premise : [rule.premise];
        const candidatesBySubject = new Map();
        for (const p of known.values()) {
          if (!matches(p, patterns[0])) continue;
          if (!candidatesBySubject.has(p.subject)) candidatesBySubject.set(p.subject, []);
          candidatesBySubject.get(p.subject).push([p]);
        }
        for (const [subjectKey, firstMatches] of candidatesBySubject) {
          let combinations = firstMatches;
          for (let i = 1; i < patterns.length; i++) {
            const options = [...known.values()].filter(f => f.subject === subjectKey && matches(f, patterns[i]));
            combinations = combinations.flatMap(combo => options.map(f => [...combo, f]));
            if (combinations.length > this.maxDerivedFacts) throw new Error('inference combination limit exceeded');
            if (!combinations.length) break;
          }
          for (const combo of combinations) {
            const p = combo[0];
            const subject = rule.conclusion.subjectFrom === 'premise.subject' ? p.subject : rule.conclusion.subjectFrom === 'premise.object' ? p.object : rule.conclusion.subjectFrom;
            const object = rule.conclusion.objectValueFrom === 'premise.subject' ? p.subject : rule.conclusion.objectValueFrom === 'premise.object' ? p.object : rule.conclusion.objectValue;
            if (typeof subject !== 'string') continue;
            const key = `${subject}\u0000${rule.conclusion.predicate}\u0000${stable(object)}`;
            if (known.has(key) || blockedTriples.has(key) || blockedPairs.has(`${subject}\u0000${rule.conclusion.predicate}`)) continue;
            const targetPair = `${subject}\u0000${rule.conclusion.predicate}`;
            const conflictingFacts = this.functionalPredicates.has(rule.conclusion.predicate) ? [...known.values()].filter(f => f.subject === subject && f.predicate === rule.conclusion.predicate && stable(f.object) !== stable(object)) : [];
            if (conflictingFacts.length) {
              blockedPairs.add(targetPair);
              derivedConflicts.push({ subject, predicate: rule.conclusion.predicate, attemptedObject: object, existingFactIds: conflictingFacts.map(f => f.id), ruleId: rule.id, policy: 'functional predicate conflict blocks all derived alternatives' });
              // Remove existing derived alternatives and every downstream conclusion that
              // depends on them; otherwise a contradiction would leave stale descendants.
              const removed = new Set(conflictingFacts.filter(f => f.derived).map(f => f.id));
              for (const f of conflictingFacts.filter(f => f.derived)) known.delete(tripleKey(f));
              let pruned = true;
              while (pruned) {
                pruned = false;
                for (const f of [...known.values()]) if (f.derived && f.premiseFactIds?.some(id => removed.has(id))) {
                  known.delete(tripleKey(f)); removed.add(f.id); pruned = true;
                }
              }
              changed = true;
              continue;
            }
            const derivedCount = [...known.values()].filter(f => f.derived).length;
            if (derivedCount >= this.maxDerivedFacts) throw new Error('inference fact limit exceeded');
            const premiseFactIds = combo.map(f => f.id);
            const fact = { id: `derived:${hash({ rule: rule.id, premises: premiseFactIds, subject, predicate: rule.conclusion.predicate, object }).slice(0,24)}`, subject, predicate: rule.conclusion.predicate, object, source: 'inference', kind: 'inference', status: 'accepted', confidence: Math.min(rule.confidence, ...combo.map(f => f.confidence)), evidence: [{ kind: 'inference', ruleId: rule.id, premiseFactIds, premiseSources: combo.map(f => f.source) }], derived: true, ruleId: rule.id, premiseFactIds };
            known.set(key, fact); trace.push({ fact: clone(fact), ruleId: rule.id, premiseFactId: premiseFactIds[0], premiseFactIds }); changed = true;
          }
        }
      }
    }
    const exhausted = changed && rounds >= maxRounds;
    const facts = [...known.values()];
    const conflicts = [...this.#conflicts([...this.facts.values(), ...facts.filter(f => f.derived)]), ...derivedConflicts];
    const finalDerivedIds = new Set(facts.filter(f => f.derived).map(f => f.id));
    return { facts: facts.map(clone), derived: trace.filter(t => finalDerivedIds.has(t.fact.id)).map(clone), hypotheses: [...this.facts.values()].filter(f => f.kind === 'hypothesis').map(clone), rounds, exhausted, conflicts };
  }

  #conflicts(facts) {
    const groups = new Map();
    for (const f of facts.filter(x => x.kind !== 'hypothesis')) { const k = `${f.subject}\u0000${f.predicate}`; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(f); }
    return [...groups.values()].filter(g => new Set(g.map(f => stable(f.object))).size > 1 || g.some(f => f.status !== 'accepted')).map(g => ({ subject: g[0].subject, predicate: g[0].predicate, factIds: g.map(f => f.id), policy: 'retain alternatives; conflicting/non-accepted evidence blocks inference for the proposition' }));
  }

  recordOutcome({ ruleId, eventId, success, context = 'default', notes = '' }) {
    if (!validId(ruleId) || typeof success !== 'boolean' || !validId(context) || typeof notes !== 'string') throw new TypeError('outcome needs ruleId, boolean success, context, and string notes');
    const request = { ruleId, success, context, notes }; const event = this.#prepare('rule.outcome', request, eventId);
    const rule = this.rules.get(ruleId); if (!rule) throw new Error(`unknown rule: ${ruleId}`);
    if (event.duplicate) return { duplicate: true, rule: clone(rule) };
    const key = `${ruleId}\u0000${context}`; const stat = clone(this.experience.get(key) ?? { ruleId, context, successes: 0, failures: 0, events: [] });
    if (success) { stat.successes++; rule.successes++; } else { stat.failures++; rule.failures++; }
    stat.events.push(event.id); const total = rule.successes + rule.failures;
    const confidence = total ? rule.successes / total : rule.confidence;
    // All in-memory changes are applied together only after validation and event-ID preflight.
    rule.confidence = confidence; this.experience.set(key, stat);
    this.#commit(event, { ruleId, confidence, successes: rule.successes, failures: rule.failures });
    return { duplicate: false, rule: clone(rule), experience: clone(stat) };
  }

  snapshot() {
    return { schemaVersion: SCHEMA_VERSION, objects: [...this.objects.values()], facts: [...this.facts.values()], rules: [...this.rules.values()], relations: [...this.relations.values()], events: [...this.events.values()], evidence: [...this.evidence.entries()], experience: [...this.experience.entries()], sequence: this.sequence, config: { maxInferenceRounds: this.maxInferenceRounds, maxDerivedFacts: this.maxDerivedFacts, functionalPredicates: [...this.functionalPredicates].sort() } };
  }
  save(filePath) {
    const data = this.snapshot(); const envelope = { payload: data, sha256: hash(data) };
    const target = path.resolve(filePath); fs.mkdirSync(path.dirname(target), { recursive: true });
    const tmp = `${target}.tmp-${process.pid}-${crypto.randomBytes(6).toString('hex')}`;
    const lockPath = `${target}.lock`;
    let lockFd; let ownsLock = false;
    try {
      try {
        lockFd = fs.openSync(lockPath, 'wx', 0o600); ownsLock = true;
      } catch (error) {
        if (error.code === 'EEXIST') {
          // Recover only clearly stale locks. A live PID is treated as an active writer.
          let stale = false;
          try {
            const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
            if (Number.isInteger(lock.pid) && lock.pid > 0) {
              try { process.kill(lock.pid, 0); } catch (probe) { if (probe.code === 'ESRCH') stale = true; }
            } else stale = Date.now() - fs.statSync(lockPath).mtimeMs > 10 * 60 * 1000;
          } catch {
            try { stale = Date.now() - fs.statSync(lockPath).mtimeMs > 10 * 60 * 1000; } catch {}
          }
          if (stale) {
            try { fs.unlinkSync(lockPath); } catch {}
            lockFd = fs.openSync(lockPath, 'wx', 0o600); ownsLock = true;
          } else throw new Error('persistence writer lock is already held; concurrent save refused');
        } else throw error;
      }
      fs.writeFileSync(lockFd, JSON.stringify({ pid: process.pid, startedAt: new Date().toISOString() }));
      fs.fsyncSync(lockFd); fs.closeSync(lockFd); lockFd = undefined;
    } catch (e) {
      if (lockFd !== undefined) try { fs.closeSync(lockFd); } catch {}
      if (ownsLock) try { fs.unlinkSync(lockPath); } catch {}
      throw new Error(`digital object persistence write failed: ${e.message}`);
    }

    let fd; let backupTmp;
    try {
      // Never rotate an invalid existing target over a potentially good backup. A valid
      // previous snapshot is copied to .bak before the atomic replacement.
      if (fs.existsSync(target)) {
        let prior;
        try { prior = JSON.parse(fs.readFileSync(target, 'utf8')); } catch { throw new Error('existing target is invalid; refusing to replace it'); }
        if (!prior?.payload || ![2, SCHEMA_VERSION].includes(prior.payload.schemaVersion) || prior.sha256 !== hash(prior.payload)) throw new Error('existing target is invalid; refusing to replace it');
        backupTmp = `${target}.bak.tmp-${process.pid}-${crypto.randomBytes(6).toString('hex')}`;
        fs.copyFileSync(target, backupTmp, fs.constants.COPYFILE_EXCL);
        const bfd = fs.openSync(backupTmp, 'r'); try { fs.fsyncSync(bfd); } finally { fs.closeSync(bfd); }
        fs.renameSync(backupTmp, `${target}.bak`); backupTmp = undefined;
      }
      fd = fs.openSync(tmp, 'wx', 0o600); fs.writeFileSync(fd, JSON.stringify(envelope, null, 2)); fs.fsyncSync(fd); fs.closeSync(fd); fd = undefined;
      fs.renameSync(tmp, target);
      try { const dirfd = fs.openSync(path.dirname(target), 'r'); try { fs.fsyncSync(dirfd); } finally { fs.closeSync(dirfd); } } catch { /* directory fsync is not supported on every platform */ }
    } catch (e) {
      if (fd !== undefined) try { fs.closeSync(fd); } catch {}
      try { fs.unlinkSync(tmp); } catch {}
      if (backupTmp) try { fs.unlinkSync(backupTmp); } catch {}
      throw new Error(`digital object persistence write failed: ${e.message}`);
    } finally {
      try { fs.unlinkSync(lockPath); } catch {}
    }
    return { path: target, sha256: envelope.sha256 };
  }

  static load(filePath) {
    let envelope;
    try { envelope = JSON.parse(fs.readFileSync(filePath, 'utf8')); } catch (e) { throw new Error(`digital object persistence read/parse failed: ${e.message}`); }
    const storedVersion = envelope?.payload?.schemaVersion;
    if (!envelope?.payload || ![2, SCHEMA_VERSION].includes(storedVersion) || typeof envelope.sha256 !== 'string') throw new Error(`digital object persistence schema/version invalid (supported ${SCHEMA_VERSION} and migratable v2)`);
    if (hash(envelope.payload) !== envelope.sha256) throw new Error('digital object persistence integrity check failed');
    const p = clone(envelope.payload);
    if (storedVersion === 2) {
      // Additive, deterministic migration: v2 facts were source facts without an explicit kind.
      p.schemaVersion = SCHEMA_VERSION;
      p.config ??= {};
      p.config.functionalPredicates ??= [];
      p.facts = p.facts.map(f => ({ ...f, kind: f.kind ?? 'direct' }));
      p.events = p.events.map(e => {
        if (e.type === 'fact.upserted') return { ...e, request: { ...e.request, kind: e.request.kind ?? 'direct' } };
        if (e.type === 'fact.removed') return { ...e, request: { ...e.request, objectProvided: e.request.object !== null } };
        return e;
      });
    }
    for (const name of ['objects','facts','rules','relations','events','evidence','experience']) if (!Array.isArray(p[name])) throw new Error(`invalid persisted ${name} collection`);
    if (!Number.isSafeInteger(p.sequence) || p.sequence < 0) throw new Error('invalid persisted event sequence');
    const core = new DigitalObjectCore(p.config ?? {});
    for (const o of p.objects) {
      if (!validId(o.id) || !validId(o.type) || !validId(o.state) || !validProperties(o.properties) || core.objects.has(o.id)) throw new Error('invalid/duplicate persisted object');
      core.objects.set(o.id, clone(o));
    }
    for (const r of p.relations) {
      if (!validId(r.id) || !validId(r.type) || !core.objects.has(r.from) || !core.objects.has(r.to) || !validProperties(r.properties) || core.relations.has(r.id)) throw new Error('invalid persisted relation reference');
      core.relations.set(r.id, clone(r));
    }
    for (const f of p.facts) {
      if (!validId(f.id) || !validId(f.subject) || !validId(f.predicate) || !scalar(f.object) || !validId(f.source) || !['direct','retrieved','hypothesis'].includes(f.kind) || !['accepted','rejected','contested'].includes(f.status) || typeof f.confidence !== 'number' || f.confidence < 0 || f.confidence > 1 || !Array.isArray(f.evidence) || f.derived !== false) throw new Error('invalid persisted fact');
      const k = factKey(f); if (core.facts.has(k)) throw new Error('duplicate persisted fact'); core.facts.set(k, clone(f));
    }
    for (const r of p.rules) {
      if (!validId(r.id) || !(Array.isArray(r.premise) ? r.premise.length > 0 && r.premise.every(validPremise) : validPremise(r.premise)) || !validConclusion(r.conclusion) || typeof r.enabled !== 'boolean' || typeof r.confidence !== 'number' || r.confidence < 0 || r.confidence > 1 || !Number.isInteger(r.successes) || !Number.isInteger(r.failures) || core.rules.has(r.id)) throw new Error('invalid/duplicate persisted rule');
      core.rules.set(r.id, clone(r));
    }
    let maxSequence = 0; const eventSequences = new Set();
    for (const e of p.events) {
      if (!validId(e.id) || !validId(e.type) || !Number.isSafeInteger(e.sequence) || e.sequence < 1 || !e.request || typeof e.request !== 'object' || Array.isArray(e.request) || core.events.has(e.id) || eventSequences.has(e.sequence)) throw new Error('invalid/duplicate persisted event');
      core.events.set(e.id, clone(e)); eventSequences.add(e.sequence); maxSequence = Math.max(maxSequence, e.sequence);
    }
    if (maxSequence !== p.sequence || p.events.length !== p.sequence || [...eventSequences].some(n => n < 1 || n > p.sequence)) throw new Error('persisted event sequence/history is inconsistent');
    core.evidence = new Map(p.evidence); core.experience = new Map(p.experience); core.sequence = p.sequence;
    for (const [key, value] of core.experience) if (typeof key !== 'string' || !value || !validId(value.ruleId) || !validId(value.context) || !Number.isInteger(value.successes) || !Number.isInteger(value.failures) || !Array.isArray(value.events) || !core.rules.has(value.ruleId)) throw new Error('invalid persisted experience');
    return core;
  }
}
export { SCHEMA_VERSION };
