# Digital Object Core (experimental)

This module adds an isolated, dependency-free first digital-object layer at
`synora-v5/digital-object-core/index.mjs`. It does not replace CRI, Adaptive V2,
the legacy adaptive engine, the evolutionary engine, or any existing memory format.

## Minimal usage

```js
import { DigitalObjectCore } from './synora-v5/digital-object-core/index.mjs';
const core = new DigitalObjectCore();
core.createObject({ id: 'Socrates', type: 'person', properties: { name: 'Socrates' } });
core.addFact({ subject: 'Socrates', predicate: 'is-a', object: 'human', source: 'premise-A' });
core.addRule({
  id: 'human-mortal',
  premise: { predicate: 'is-a', object: 'human' },
  conclusion: { subjectFrom: 'premise.subject', predicate: 'is-a', objectValue: 'mortal' }
});
const result = core.infer();
console.log(result.facts.filter(f => f.derived), result.derived); // derived fact and proof trace
core.save('./digital-objects.json');
// In a later process: const restored = DigitalObjectCore.load('./digital-objects.json');
```

## Semantics and limits

- Objects have explicit IDs, types, scalar typed properties, and a state string. `transition`
  can enforce an allow-list of source states.
- Relations have explicit IDs and endpoints; both endpoints must exist.
- Facts distinguish source facts (`derived:false`) from inference results (`derived:true`).
  A fact has source kind (`direct`, `retrieved`, `hypothesis`), status (`accepted`, `rejected`, `contested`), confidence, and evidence. Hypotheses are returned separately and never act as premises by themselves.
  Only accepted direct/retrieved facts participate in inference. A rejected/contested source for the same triple blocks that triple. Predicates are multi-valued by default; configure `functionalPredicates` when distinct values for a predicate must be treated as contradictory. Hypotheses are kept separate from accepted evidence. Callers must explicitly reconcile/retract conflicting records.
- Rules are explicit bounded pattern rules with one or more conjunctive premises matched against the same subject. Supported bindings in the conclusion refer to the first premise via `premise.subject`
  and `premise.object`; conclusions can use a constant object value. This is a deliberately
  small first-order pattern, not a complete logic language or a natural-language reasoner.
- Inference uses a finite known-fact set, round limit, and derived-fact cap. It terminates on
  cycles by deduplicating facts. The returned trace names the rule and every premise fact ID for each
  derivation.
- `recordOutcome` records contextual success/failure, deduplicates caller-provided event IDs,
  and updates rule confidence to the observed success fraction. This is bounded evidence-based
  rule scoring, not general learning, autonomous skill discovery, or model training.
- Persistence stores objects, facts, rules, relations, event history, evidence, experience,
  sequence, and schema version in a SHA-256 integrity envelope. Schema v2 migrates deterministically
  to v3; unknown schemas are rejected. Writes use a temporary file, fsync, an exclusive writer lock, and atomic rename,
  while a verified previous target is retained as `.bak`. A stale lock from a crashed process is
  reclaimed only when its PID is confirmed absent or the malformed lock is over ten minutes old. A corrupted target is not overwritten. This is corruption detection, not cryptographic authentication against an
  attacker who can rewrite both payload and digest. The module uses its own file; CRI storage
  is untouched.
- `infer()` rebuilds results from current accepted facts and enabled rules rather than saving
  derived facts as source truths. Persisted derived results are therefore reconstructed after
  restart.
- `synora-adapter.mjs` provides an opt-in bridge at the public `runTask(task)` boundary used by the CRI/PST engine and its Adaptive V2 subclass. It records a public task-result fact under a caller-supplied `runId`; it does not change proposal/search behavior, ledger state, scoring, or CRI persistence. Reusing the same runId/taskId with changed output is a visible event conflict. The adapter is tested against real `PstEngine` and `AdaptivePstEngine` instances. It is intentionally not attached by default.

## Verification

Run `npm run test:digital-objects` for the focused tests or `npm test` for the full existing and
new suite. The cross-process test uses a child Node.js process to save and a separate process
to restore and re-infer.

## Research limitations

This is a deterministic symbolic prototype. Passing synthetic tests demonstrates only the
specific behaviors tested; it does not establish broad generalization, intelligence, superiority
to Llama 2, or a globally novel architecture.
