# Digital Object Core — final engineering audit

## Scope and preserved baseline

The original CRI ledger, CRI/PST search implementation, Adaptive V2 implementation, Adaptive Legacy implementation, and their persistent-memory formats remain unchanged. The digital-object subsystem is still opt-in and independently testable. `synora-adapter.mjs` bridges the public `runTask(task)` result boundary without modifying engine search logic.

## Repairs made in final closure

- Event IDs are preflighted before state mutation. Replaying an identical request is idempotent; reusing an ID with different content raises an explicit conflict.
- Object creation, state transition, relation creation, fact updates/removals, rule creation/enablement, and rule outcomes use a prepare-then-commit pattern; validation failures do not append success events.
- Facts are source-scoped and tagged `direct`, `retrieved`, or `hypothesis`; hypotheses do not enter inference. A rejected or contested record for the same triple blocks it. Predicates are multi-valued by default; an explicit `functionalPredicates` list opts into single-valued conflict blocking. `removeFact()` retracts a source record. Derived conclusions are rebuilt from current eligible premises, so retracted support does not leave stale conclusions.
- Rule chaining and conjunctive multi-premise rules are supported; proof links retain all premise IDs. Cycles deduplicate; round, combination, and derived-fact limits are enforced.
- Persistence schema is version 3 and validates collection shapes, IDs, references, fact/rule shapes, event sequence, checksum, truncation, and schema version. A verified v2 snapshot migrates deterministically; unsupported schemas are rejected. Save uses an exclusive writer lock, a temporary file, fsync, rename, cleanup on failure, and a verified `.bak` of the prior target; corrupt targets are not overwritten. Stale locks are reclaimed conservatively.
- Added an explicit opt-in engine-result adapter tested with the actual `PstEngine` and `AdaptivePstEngine` classes. CRI/Adaptive policy and memory formats are not modified.

## Semantics and limitations

The rule language is a bounded conjunctive pattern matcher whose premises must share a subject; conclusion bindings refer to the first premise. It is not a general first-order theorem prover. Contradictory/non-accepted evidence is handled conservatively; predicates are only treated as single-valued when explicitly configured, and there is no general truth-maintenance network or non-monotonic logic. Outcome-based confidence is a small empirical rule score, not general learning. SHA-256 detects accidental corruption but is not authentication against an attacker able to rewrite the payload and digest.

The adapter records a task-result fact from the engine's public result fields and does not feed digital-object conclusions back into CRI or Adaptive V2 search. This is an audited one-way integration boundary, not a claim that the core has become the engine's learning mechanism.

No comparison against Llama 2 and no new generalization benchmark were run. The existing CRI/Adaptive experiment results remain the existing project results, not evidence of digital-object superiority.
