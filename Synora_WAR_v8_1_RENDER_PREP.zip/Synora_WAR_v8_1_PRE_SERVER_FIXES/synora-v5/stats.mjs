/**
 * Synora WAR v5 — shared statistics for the paired experimental designs.
 *
 * WHY THIS FILE EXISTS (audit finding): the earlier analysis used an UNPAIRED bootstrap —
 * it resampled the two arms independently. The experiment IS paired (the same task and the
 * same seed run in every arm), so the correct resampling unit is the PAIR, not the arm. The
 * unpaired version understated the variance and produced intervals that were too narrow.
 *
 * Everything here works on PAIRED UNITS: one observation = (taskId, seed).
 *
 *   pairedBootstrap      — resamples the pairs (task, seed) with replacement.
 *   mcnemarExact         — the exact test for a paired BINARY outcome (solved / not solved).
 *   wilcoxonSignedRank   — the paired test for a continuous paired difference.
 *   holmBonferroni       — the multiplicity correction for a family of comparisons.
 */

export function median(values) {
  if (!values.length) return null;
  const v = [...values].sort((a, b) => a - b);
  const mid = v.length >> 1;
  return v.length % 2 ? v[mid] : (v[mid - 1] + v[mid]) / 2;
}

export function quantile(values, q) {
  if (!values.length) return null;
  const v = [...values].sort((a, b) => a - b);
  const pos = (v.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  return v[base + 1] !== undefined ? v[base] + rest * (v[base + 1] - v[base]) : v[base];
}

function makeRng(seed) {
  let state = (seed >>> 0) || 1;
  return function next() {
    state ^= state << 13; state >>>= 0;
    state ^= state >> 17;
    state ^= state << 5; state >>>= 0;
    return state / 0xffffffff;
  };
}

/**
 * PAIRED bootstrap.
 *
 * `pairs` = [{ arm: number|null, base: number|null, unit: 'taskId#seed' }]
 * A null on either side means "that arm did not reach a solution" — such a pair is EXCLUDED
 * from the efficiency statistics (and reported separately by the caller), because a failure
 * has no "evaluations to success".
 *
 * Returns the interval of the median of the paired differences AND of the difference of the
 * per-arm medians, both computed by resampling the PAIRS.
 */
export function pairedBootstrap(pairs, { iterations = 4000, seed = 12345 } = {}) {
  const usable = pairs.filter(p => p.arm !== null && p.base !== null && Number.isFinite(p.arm) && Number.isFinite(p.base));
  const diffs = usable.map(p => p.arm - p.base);
  if (usable.length < 3) {
    return { n: usable.length, point: null, ci95: null, pointMedianDiff: null, ci95MedianDiff: null, iterations: 0 };
  }
  const rng = makeRng(seed);
  const stats = [];
  for (let i = 0; i < iterations; i++) {
    const arm = [];
    const base = [];
    const diff = [];
    for (let k = 0; k < usable.length; k++) {
      const pick = usable[Math.floor(rng() * usable.length)];
      arm.push(pick.arm); base.push(pick.base); diff.push(pick.arm - pick.base);
    }
    stats.push({ medDiff: median(diff), medArm: median(arm), medBase: median(base) });
  }
  const medDiffs = stats.map(s => s.medDiff);
  const medArm = stats.map(s => s.medArm);
  const medBase = stats.map(s => s.medBase);
  const diffOfMedians = stats.map((s, i) => s.medArm - s.medBase);
  return {
    n: usable.length,
    point: Number(median(diffs).toFixed(3)),                 // the paired effect size
    ci95: [Number(quantile(medDiffs, 0.025).toFixed(3)), Number(quantile(medDiffs, 0.975).toFixed(3))],
    pointMedianDiff: Number((median(usable.map(p => p.arm)) - median(usable.map(p => p.base))).toFixed(3)),
    ci95MedianDiff: [Number(quantile(diffOfMedians, 0.025).toFixed(3)), Number(quantile(diffOfMedians, 0.975).toFixed(3))],
    iterations,
  };
}

/**
 * McNemar's EXACT test on the paired binary outcome.
 * `pairs` = [{ arm: boolean, base: boolean }]  (solved / not solved)
 * Only the discordant pairs carry information.
 */
export function mcnemarExact(pairs) {
  let b = 0;   // arm solved, base did not
  let c = 0;   // base solved, arm did not
  for (const p of pairs) {
    if (p.arm && !p.base) b++;
    else if (!p.arm && p.base) c++;
  }
  const n = b + c;
  if (n === 0) return { b, c, n, p: 1, method: 'exact binomial (no discordant pairs)' };
  const k = Math.min(b, c);
  // two-sided exact binomial p under H0: p(binomial) = 0.5
  let tail = 0;
  for (let i = 0; i <= k; i++) {
    tail += binomial(n, i);
  }
  const p = Math.min(1, 2 * tail / Math.pow(2, n));
  return { b, c, n, p: Number(p.toFixed(6)), method: 'exact binomial' };
}

function binomial(n, k) {
  let r = 1;
  for (let i = 0; i < k; i++) r = r * (n - i) / (i + 1);
  return r;
}

/** Wilcoxon signed-rank test on the paired differences (normal approximation for n > 25). */
export function wilcoxonSignedRank(diffs) {
  const nonZero = diffs.filter(d => d !== 0);
  const n = nonZero.length;
  if (n === 0) return { n: 0, W: 0, p: 1, method: 'no non-zero differences' };
  const abs = nonZero.map(d => Math.abs(d));
  const order = abs.map((a, i) => ({ a, i })).sort((x, y) => x.a - y.a);
  const ranks = new Array(n).fill(0);
  let i = 0;
  while (i < n) {
    let j = i;
    while (j + 1 < n && order[j + 1].a === order[i].a) j++;
    const avgRank = (i + j) / 2 + 1;
    for (let k = i; k <= j; k++) ranks[order[k].i] = avgRank;
    i = j + 1;
  }
  let wPlus = 0;
  nonZero.forEach((d, idx) => { if (d > 0) wPlus += ranks[idx]; });
  const w = Math.min(wPlus, n * (n + 1) / 2 - wPlus);
  let p;
  if (n <= 25) {
    // exact distribution of the signed-rank statistic
    const counts = new Map();
    for (let mask = 0; mask < (1 << n); mask++) {
      let s = 0;
      for (let k = 0; k < n; k++) if (mask & (1 << k)) s += ranks[k];
      const wv = Math.min(s, n * (n + 1) / 2 - s);
      const key = Math.round(wv * 2) / 2;
      counts.set(key, (counts.get(key) || 0) + 1);
    }
    const total = 1 << n;
    let tail = 0;
    for (const [k, c] of counts) if (k <= w + 1e-9) tail += c;
    // the MIN statistic already covers both tails: P(W <= w_obs), not twice that
    p = Math.min(1, tail / total);
  } else {
    const mu = n * (n + 1) / 4;
    const sigma = Math.sqrt(n * (n + 1) * (2 * n + 1) / 24);
    const z = (w - mu) / sigma;
    p = Math.min(1, 2 * (1 - normalCdf(Math.abs(z))));
  }
  return { n, W: Number(w.toFixed(3)), p: Number(p.toFixed(6)), method: n <= 25 ? 'exact' : 'normal approximation' };
}

function normalCdf(x) {
  // Abramowitz & Stegun 7.1.26
  const t = 1 / (1 + 0.2316419 * x);
  const d = 0.3989422804014327 * Math.exp(-x * x / 2);
  const p = d * t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
  return p;
}

/** Holm-Bonferroni step-down correction over a family of p-values. */
export function holmBonferroni(entries) {
  const sorted = [...entries].sort((a, b) => a.p - b.p);
  const m = sorted.length;
  const out = [];
  let prev = 0;
  sorted.forEach((entry, index) => {
    const adjusted = Math.min(1, Math.max(prev, (m - index) * entry.p));
    prev = adjusted;
    out.push({ ...entry, pAdjusted: Number(adjusted.toFixed(6)), rank: index + 1, familySize: m });
  });
  return out;
}
