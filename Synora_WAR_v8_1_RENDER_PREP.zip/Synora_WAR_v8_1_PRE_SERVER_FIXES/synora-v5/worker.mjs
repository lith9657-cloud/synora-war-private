/**
 * Synora WAR v5 — sandboxed evaluator worker.
 *
 * Runs in a worker_thread; the parent may terminate it on timeout, which kills runaway code
 * (infinite loops) — the same guarantee v4 got from SIGKILL, but with a reusable pool so we do
 * not pay a process fork per candidate.
 *
 * SECURITY NOTE (honest): this is a *timeout sandbox*, not a security sandbox. The worker has
 * no DOM, but `Function` inside a worker thread still exposes most of Node's globals. We
 * therefore disable network access inside the worker and never execute untrusted third-party
 * code here — only code produced by our own evolutionary operators.
 */
import { parentPort } from 'node:worker_threads';

// Hard-disable outbound network from inside the sandbox.
for (const name of ['fetch', 'WebSocket', 'XMLHttpRequest']) {
  if (name in globalThis) {
    try { Object.defineProperty(globalThis, name, { value: undefined, configurable: true }); } catch { /* ignore */ }
  }
}
if (globalThis.navigator) {
  try { Object.defineProperty(globalThis.navigator, 'sendBeacon', { value: undefined, configurable: true }); } catch { /* ignore */ }
}

const MAX_STRING = 20000;

function load(code) {
  // Same construction v4 uses; kept identical on purpose so both engines share the artifact contract.
  const fn = Function(`${code}; return solution;`);
  return fn();
}

function safe(v) {
  try {
    if (v === undefined) return { ok: true, value: '__undefined__' };
    const s = JSON.stringify(v);
    if (s === undefined) return { ok: true, value: '__undefined__' };
    return { ok: true, value: s.length > MAX_STRING ? s.slice(0, MAX_STRING) : s };
  } catch (e) {
    return { ok: false, value: '__unserializable__', error: String(e) };
  }
}

function runKillers(code, killers) {
  const failures = [];
  let passed = 0;
  let solution;
  try {
    solution = load(code);
  } catch (e) {
    return { passed: 0, total: killers.length, failures: killers.map(k => ({ name: k.name || 'load', error: String(e && e.stack || e), split: k.split || 'train' })), loadError: String(e) };
  }
  for (const killer of killers) {
    try {
      const input = Object.hasOwn(killer, 'input') ? killer.input : undefined;
      if (killer.type === 'js_test' && typeof killer.test === 'string') {
        Function('solution', 'input', killer.test)(solution, input);
      } else {
        throw new Error(`Unsupported killer schema: ${killer.type || killer.name}`);
      }
      passed++;
    } catch (e) {
      failures.push({ name: killer.name || 'unknown', error: String((e && e.stack) || e), split: killer.split || 'train' });
    }
  }
  return { passed, total: killers.length, failures, loadError: null };
}

function probe(code, inputs) {
  let solution;
  try {
    solution = load(code);
  } catch (e) {
    return { results: inputs.map(() => ({ ok: false, error: String(e) })) };
  }
  const results = inputs.map(input => {
    try {
      const value = solution(input);
      return safe(value);
    } catch (e) {
      return { ok: false, error: String((e && e.message) || e) };
    }
  });
  return { results };
}

parentPort.on('message', message => {
  try {
    if (message.kind === 'killers') parentPort.postMessage({ id: message.id, result: runKillers(message.code, message.killers) });
    else if (message.kind === 'probe') parentPort.postMessage({ id: message.id, result: probe(message.code, message.inputs) });
    else parentPort.postMessage({ id: message.id, error: 'unknown message kind' });
  } catch (e) {
    parentPort.postMessage({ id: message.id, error: String((e && e.stack) || e) });
  }
});
