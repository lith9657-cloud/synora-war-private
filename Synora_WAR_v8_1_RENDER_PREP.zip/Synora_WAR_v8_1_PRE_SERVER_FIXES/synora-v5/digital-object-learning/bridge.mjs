import { DigitalObjectCore } from '../digital-object-core/index.mjs';

export const learnerObjectIdFor = learnerId => `digital-learner:${learnerId}`;
export const skillObjectIdFor = skillId => `digital-skill:${skillId}`;

/**
 * Register an accepted learned skill in the existing DigitalObjectCore. Skill code and
 * the learning ledger remain in the learner store; this bridge exposes identity,
 * provenance, status and ownership as inspectable digital objects and facts.
 */
export function syncSkillToCore(core, learner, skill) {
  if (!(core instanceof DigitalObjectCore)) throw new TypeError('core must be a DigitalObjectCore instance');
  if (!learner || typeof learner.id !== 'string' || !skill || typeof skill.id !== 'string') throw new TypeError('learner and skill are required');
  if (skill.status !== 'accepted') return { changed: false, skipped: true, reason: 'only accepted skills are registered' };
  const before = core.sequence;
  const ownerId = learnerObjectIdFor(learner.id), objectId = skillObjectIdFor(skill.id);
  if (!core.getObject(ownerId)) core.createObject({ id: ownerId, type: 'digital-learning-agent', properties: { learnerId: learner.id, learnerVersion: learner.version }, state: 'active' }, `stage4:learner:${learner.id}:created`);
  const desiredState = skill.active === false ? 'superseded' : 'active';
  const existing = core.getObject(objectId);
  if (!existing) {
    core.createObject({ id: objectId, type: 'digital-skill', properties: {
      skillId: skill.id, skillKind: skill.kind, skillVersion: skill.version,
      skillStatus: skill.status, source: String(skill.provenance?.source ?? 'unknown'),
      modulus: skill.params?.modulus ?? skill.steps?.[0]?.params?.modulus ?? 0
    }, state: desiredState }, `stage4:skill:${skill.id}:created`);
  } else if (existing.state !== desiredState) {
    core.transition(objectId, desiredState, { allowedFrom: [existing.state], reason: 'learning ledger active-state synchronization', eventId: `stage4:skill:${skill.id}:state:${desiredState}:v${skill.version}` });
  }
  const relationId = `owns:${learner.id}:${skill.id}`;
  core.addRelation({ id: relationId, from: ownerId, to: objectId, type: 'owns-skill', properties: { skillVersion: skill.version } }, `stage4:skill:${skill.id}:ownership`);
  const facts = [
    ['skill-kind', skill.kind], ['skill-status', skill.status],
    ['skill-source', String(skill.provenance?.source ?? 'unknown')], ['skill-version', skill.version],
    ...(Number.isInteger(skill.params?.modulus) ? [['skill-modulus', skill.params.modulus]] : [])
  ];
  for (const [predicate, value] of facts) core.addFact({ subject: objectId, predicate, object: value, source: 'digital-object-learning', kind: 'direct', status: 'accepted', confidence: 1, evidence: [String(skill.provenance?.trainingDigest ?? skill.id)] }, `stage4:skill:${skill.id}:fact:${predicate}`);
  return { changed: core.sequence !== before, skipped: false, ownerObjectId: ownerId, skillObjectId: objectId, relationId, eventSequence: core.sequence };
}

export function syncAllSkillsToCore(core, learner) {
  const results = [];
  for (const skill of learner.skills.values()) if (skill.status === 'accepted') results.push(syncSkillToCore(core, learner, skill));
  return { changed: results.some(r => r.changed), results, registered: results.filter(r => !r.skipped).length };
}

export function inspectSkillInCore(core, skillId) {
  const id = skillObjectIdFor(skillId);
  return core.getObject(id);
}
