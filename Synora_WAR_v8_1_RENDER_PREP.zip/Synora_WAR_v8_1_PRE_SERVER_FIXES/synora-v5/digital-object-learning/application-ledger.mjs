import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export const APPLICATION_LEDGER_SCHEMA_VERSION = 1;
const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
const canonical = value => {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;
  return JSON.stringify(value);
};
const clone = value => JSON.parse(JSON.stringify(value));

function inputSummary(input) {
  const raw = input === undefined ? '"[undefined]"' : canonical(input);
  const digest = sha256(raw);
  if (Array.isArray(input)) return input.length <= 32 ? { shape: 'array', length: input.length, values: clone(input), sha256: digest } : { shape: 'array', length: input.length, sha256: digest };
  if (typeof input === 'number' || typeof input === 'string' || typeof input === 'boolean' || input === null) return { shape: input === null ? 'null' : typeof input, value: input, sha256: digest };
  return { shape: typeof input, sha256: digest };
}

export class SkillApplicationLedger {
  constructor({ filePath } = {}) {
    if (typeof filePath !== 'string' || !filePath.trim()) throw new TypeError('application ledger filePath is required');
    this.filePath = path.resolve(filePath);
    this.events = new Map();
    if (fs.existsSync(this.filePath)) this.#load();
  }

  #payload() { return { schemaVersion: APPLICATION_LEDGER_SCHEMA_VERSION, events: [...this.events.values()].map(clone) }; }

  #load() {
    let envelope;
    try { envelope = JSON.parse(fs.readFileSync(this.filePath, 'utf8')); }
    catch (error) { throw new Error(`application ledger read/parse failed: ${error.message}`); }
    if (!envelope || typeof envelope !== 'object' || !envelope.payload || typeof envelope.sha256 !== 'string') throw new Error('application ledger integrity envelope is missing');
    const digest = sha256(canonical(envelope.payload));
    if (digest !== envelope.sha256) throw new Error('application ledger integrity check failed');
    const payload = envelope.payload;
    if (payload.schemaVersion !== APPLICATION_LEDGER_SCHEMA_VERSION || !Array.isArray(payload.events)) throw new Error('application ledger schema is unsupported');
    for (const event of payload.events) {
      if (!event || typeof event.eventId !== 'string' || !event.eventId || typeof event.requestDigest !== 'string' || this.events.has(event.eventId)) throw new Error('application ledger contains invalid or duplicate events');
      this.events.set(event.eventId, clone(event));
    }
  }

  get(eventId) { const event = this.events.get(eventId); return event ? clone(event) : null; }

  record({ eventId = crypto.randomUUID(), skillId = null, skillVersion = null, operation = 'apply', input, status, executed = false, executionSuccess = false, reason = null, result = null, source = 'dialogue', requestFingerprint = null } = {}) {
    if (typeof eventId !== 'string' || !eventId.trim() || eventId.length > 200) throw new TypeError('eventId must be a non-empty string up to 200 characters');
    if (!['apply', 'route', 'abstain'].includes(operation)) throw new TypeError('invalid application operation');
    if (!['executed', 'abstained', 'error'].includes(status)) throw new TypeError('invalid application status');
    if (typeof executed !== 'boolean' || typeof executionSuccess !== 'boolean') throw new TypeError('execution flags must be boolean');
    const safeInput = inputSummary(input);
    if (requestFingerprint !== null && typeof requestFingerprint !== 'string') throw new TypeError('requestFingerprint must be a string or null');
    const requestDigest = sha256(canonical({ skillId, skillVersion, operation, input: safeInput.sha256, source, requestFingerprint: requestFingerprint === null ? null : sha256(requestFingerprint) }));
    const prior = this.events.get(eventId);
    if (prior) {
      if (prior.requestDigest !== requestDigest) throw new Error('application event ID conflict: same eventId used for a different request');
      return { duplicate: true, event: clone(prior) };
    }
    const event = {
      eventId, timestamp: new Date().toISOString(), skillId, skillVersion,
      operation, input: safeInput, status, executed, executionSuccess,
      objectiveCorrectness: 'not-assessed', reason: reason == null ? null : String(reason).slice(0, 500),
      result: result === null ? null : clone(result), source, requestDigest
    };
    this.events.set(eventId, event);
    try { this.#save(); }
    catch (error) { this.events.delete(eventId); throw new Error(`application ledger persistence failed: ${error.message}`); }
    return { duplicate: false, event: clone(event) };
  }

  #save() {
    const payload = this.#payload();
    const envelope = { payload, sha256: sha256(canonical(payload)) };
    const directory = path.dirname(this.filePath);
    fs.mkdirSync(directory, { recursive: true });
    const temporary = `${this.filePath}.${process.pid}.${crypto.randomUUID()}.tmp`;
    let fd;
    try {
      fd = fs.openSync(temporary, 'wx', 0o600);
      fs.writeFileSync(fd, JSON.stringify(envelope, null, 2) + '\n');
      fs.fsyncSync(fd); fs.closeSync(fd); fd = undefined;
      fs.renameSync(temporary, this.filePath);
      try { const dirFd = fs.openSync(directory, 'r'); try { fs.fsyncSync(dirFd); } finally { fs.closeSync(dirFd); } } catch { /* directory fsync is not supported on every platform */ }
    } finally {
      if (fd !== undefined) fs.closeSync(fd);
      if (fs.existsSync(temporary)) fs.unlinkSync(temporary);
    }
  }

  list() { return [...this.events.values()].map(clone); }
}
