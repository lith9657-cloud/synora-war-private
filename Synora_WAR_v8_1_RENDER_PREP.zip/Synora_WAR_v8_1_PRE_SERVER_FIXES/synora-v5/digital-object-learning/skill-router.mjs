import { inspectSkillInCore } from './bridge.mjs';

const escapeRegExp = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const actionPattern = /\b(?:apply|use|run|execute)\b|طبّق|طبق|استخدم|نفّذ|نفذ|شغّل|شغل/i;

function parseExplicitInput(text) {
  const array = text.match(/(?:\bto\b|\binput\s*[:=]?|\bwith\s+input\b|على|بمدخل|المدخلات?\s*[:=]?)\s*\[\s*(-?\d+(?:\s*,\s*-?\d+)*)?\s*\]/i);
  if (array) {
    if (!array[1]) return { ok: true, input: [] };
    const values = array[1].split(',').map(x => Number(x.trim()));
    if (values.some(n => !Number.isSafeInteger(n))) return { ok: false, reason: 'invalid-array-input' };
    return { ok: true, input: values };
  }
  const scalar = text.match(/(?:\bto\b|\binput\s*[:=]?|\bwith\s+input\b|على|بمدخل|المدخلات?\s*[:=]?)\s*(-?\d+)\s*$/i);
  if (scalar) {
    const value = Number(scalar[1]);
    if (!Number.isSafeInteger(value)) return { ok: false, reason: 'invalid-scalar-input' };
    return { ok: true, input: value };
  }
  return { ok: false, reason: 'explicit-input-required' };
}

function registeredActive(skill, learner, core) {
  if (!skill || skill.status !== 'accepted' || skill.active === false) return { ok: false, reason: 'skill-not-accepted-or-active' };
  const object = core ? inspectSkillInCore(core, skill.id) : null;
  if (!object || object.state !== 'active' || object.type !== 'digital-skill' || object.properties?.skillId !== skill.id || object.properties?.skillStatus !== 'accepted') {
    return { ok: false, reason: 'skill-not-registered-active-in-digital-object-core' };
  }
  if (!learner.skills.has(skill.id)) return { ok: false, reason: 'skill-not-present-in-learner' };
  return { ok: true, object };
}

export function routeExplicitSkillRequest(text, { learner, core } = {}) {
  if (typeof text !== 'string' || !actionPattern.test(text) || !learner || !core) return { matched: false };
  const allSkills = [...learner.skills.values()];
  // Match whole skill IDs/names only; no fuzzy or substring guessing.
  const matches = [];
  for (const skill of allSkills) {
    for (const label of new Set([skill.id, skill.name].filter(x => typeof x === 'string' && x.trim()))) {
      const re = new RegExp(`(^|[^\\p{L}\\p{N}_-])${escapeRegExp(label)}(?=$|[^\\p{L}\\p{N}_-])`, 'iu');
      if (re.test(text)) { matches.push(skill); break; }
    }
  }
  const unique = [...new Map(matches.map(s => [s.id, s])).values()];
  if (!unique.length) return { matched: false };
  if (unique.length !== 1) return { matched: true, ok: false, reason: 'ambiguous-skill-name', candidateSkillIds: unique.map(s => s.id), selectedSkillId: null };
  const skill = unique[0];
  const availability = registeredActive(skill, learner, core);
  if (!availability.ok) return { matched: true, ok: false, reason: availability.reason, selectedSkillId: skill.id, skillVersion: skill.version, input: null };
  const parsed = parseExplicitInput(text);
  if (!parsed.ok) return { matched: true, ok: false, reason: parsed.reason, selectedSkillId: skill.id, skillVersion: skill.version, input: null };
  // Validate the input against the skill's declared DSL/domain before invoking it.
  const m = skill.params?.modulus ?? skill.steps?.[0]?.params?.modulus;
  const input = parsed.input;
  const validScalar = Number.isSafeInteger(input) && input >= 0 && input < m;
  const validArray = Array.isArray(input) && input.length <= 1000 && input.every(n => Number.isSafeInteger(n) && n >= 0 && n < m);
  if (!(validScalar || validArray)) return { matched: true, ok: false, reason: 'input-outside-skill-domain', selectedSkillId: skill.id, skillVersion: skill.version, input };
  return { matched: true, ok: true, skill, input, selectedSkillId: skill.id, skillVersion: skill.version, reason: 'exact-active-skill-name-or-id-and-explicit-supported-input', coreObjectId: availability.object.id };
}
