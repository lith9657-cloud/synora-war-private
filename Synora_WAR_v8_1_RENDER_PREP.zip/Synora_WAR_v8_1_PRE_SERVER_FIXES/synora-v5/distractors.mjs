/**
 * Synora WAR v5 — DISTRACTOR OPERATORS (benchmark stress knob, not part of the mechanism).
 *
 * The honest finding of the first experiment was that with only ~18 semantic operators the
 * search space is small enough that *systematic coverage alone* solves every task, so the
 * memory could not show an efficiency gain. That is a property of the benchmark, not of the
 * method — and it is exactly the regime a real system would never be in.
 *
 * Distractors are generic, syntactically safe edits that are usually irrelevant to the bug
 * (renaming, re-quoting, adding no-ops). They enlarge the operator space without adding any
 * repair capability, so a blind search must try more of them before it reaches the useful one.
 *
 * `--distractors=N` pads the operator pool with N of them. The number is reported with every
 * result so the reader always knows which regime a number was measured in.
 */

export const DISTRACTORS = [
  {
    id: 'D_RENAME_PARAM',
    label: 'rename the parameter',
    applies: code => /\ba\b/.test(code),
    apply: code => code.replace(/\ba\b/g, 'z'),
  },
  {
    id: 'D_ADD_NOOP',
    label: 'insert a no-op statement',
    applies: code => /\{/.test(code),
    apply: code => code.replace(/\{/, '{let __n=0;'),
  },
  {
    id: 'D_DOUBLE_QUOTES',
    label: 're-quote a string literal',
    applies: code => /'[^']*'/.test(code),
    apply: code => code.replace(/'([^']*)'/g, '"$1"'),
  },
  {
    id: 'D_APPEND_COMMENT',
    label: 'append a comment',
    applies: code => /\{/.test(code),
    apply: code => code.replace(/\{/, '{/*x*/'),
  },
  {
    id: 'D_REORDER_STMT',
    label: 'duplicate the first statement',
    applies: code => /\{[^}]*;/.test(code),
    apply: code => code.replace(/\{([^;]*);/, '{$1;$1;'),
  },
  {
    id: 'D_WRAP_PARENS',
    label: 'wrap the result in parentheses',
    applies: code => /return\s+[^;}]+/.test(code),
    apply: code => code.replace(/return\s+([^;}]+)/, 'return ($1)'),
  },
  {
    id: 'D_ADD_SEMICOLON',
    label: 'add a redundant semicolon',
    applies: code => /\}/.test(code),
    apply: code => code.replace(/\}/, ';}'),
  },
  {
    id: 'D_SWAP_CONST',
    label: 'swap two numeric literals',
    applies: code => (code.match(/\b\d+\b/g) || []).length >= 2,
    apply: code => {
      const nums = code.match(/\b\d+\b/g);
      let i = 0;
      return code.replace(/\b\d+\b/g, m => { const pick = nums[(i + 1) % nums.length]; i++; return pick; });
    },
  },
  {
    id: 'D_STRIP_SPACES',
    label: 'reformat whitespace',
    applies: code => /,\s/.test(code),
    apply: code => code.replace(/,\s/g, ','),
  },
  {
    id: 'D_ADD_EMPTY_CATCH',
    label: 'attach an empty catch',
    applies: code => /\{/.test(code),
    apply: code => code.replace(/\}$/, '}catch(e){}'),
  },
  {
    id: 'D_NEGATE_CONST',
    label: 'negate the first numeric literal',
    applies: code => /-\d/.test(code) || /\b\d+\b/.test(code),
    apply: code => code.replace(/\b(\d+)\b/, '-$1'),
  },
  {
    id: 'D_REORDER_ARGS',
    label: 'reorder two call arguments',
    applies: code => /\w+\([^)]*,[^)]*\)/.test(code),
    apply: code => code.replace(/\w+\(([^,()]+),([^,()]+)\)/, (m, a, b) => m.replace(a + ',' + b, b + ',' + a)),
  },
  {
    id: 'D_DROP_SEMICOLON',
    label: 'drop a semicolon',
    applies: code => /;/.test(code),
    apply: code => code.replace(/;/, ''),
  },
  {
    id: 'D_EXTRA_PAREN',
    label: 'add a redundant parenthesis',
    applies: code => /return\s/.test(code),
    apply: code => code.replace(/return\s+/, 'return ((').replace(/;?\s*\}$/, '));}'),
  },
  {
    id: 'D_SWAP_KEYWORDS',
    label: 'swap const and let',
    applies: code => /\bconst\b/.test(code),
    apply: code => code.replace(/\bconst\b/, 'let'),
  },
  {
    id: 'D_DUPLICATE_EXPR',
    label: 'duplicate an expression inside a comparison',
    applies: code => /===|!==/.test(code),
    apply: code => code.replace(/===|!==/, m => m),
  },
];
