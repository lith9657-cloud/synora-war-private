/** Independent workforce scheduling domain: assigns workers to shifts under availability and coverage constraints. */
export function scheduleShifts({ workers, shifts }) {
  if (!Array.isArray(workers) || !Array.isArray(shifts)) throw new TypeError('workers and shifts must be arrays');
  const workerIds = new Set();
  for (const w of workers) {
    if (!w || w.id == null) throw new TypeError('every worker needs an id');
    if (workerIds.has(w.id)) throw new TypeError(`duplicate worker id: ${w.id}`);
    workerIds.add(w.id);
    if (w.maxShifts != null && (!Number.isInteger(w.maxShifts) || w.maxShifts < 0)) throw new TypeError(`maxShifts for ${w.id} must be a non-negative integer`);
  }
  const shiftIds = new Set();
  for (const s of shifts) {
    if (!s || s.id == null) throw new TypeError('every shift needs an id');
    if (shiftIds.has(s.id)) throw new TypeError(`duplicate shift id: ${s.id}`);
    shiftIds.add(s.id);
  }
  const remaining = new Map(workers.map(w => [w.id, Number(w.maxShifts ?? Infinity)]));
  const assigned = [], unfilled = [];
  const eligibleFor = shift => workers.filter(w => (w.availableShifts || []).includes(shift.id)
    && (shift.requiredSkills || []).every(skill => (w.skills || []).includes(skill))
    && (remaining.get(w.id) ?? 0) > 0);
  // Assign the most constrained shifts first to avoid consuming a worker needed by a harder-to-fill shift.
  const ordered = [...shifts].sort((a,b) => eligibleFor(a).length - eligibleFor(b).length
    || (b.requiredSkills?.length || 0) - (a.requiredSkills?.length || 0)
    || String(a.id).localeCompare(String(b.id)));
  for (const shift of ordered) {
    const eligible = eligibleFor(shift).sort((a,b) => (remaining.get(b.id)-remaining.get(a.id)) || String(a.id).localeCompare(String(b.id)));
    if (!eligible.length) { unfilled.push(shift.id); continue; }
    const worker = eligible[0]; assigned.push({ shiftId: shift.id, workerId: worker.id });
    remaining.set(worker.id, remaining.get(worker.id)-1);
  }
  return { assigned, unfilled, coverage: shifts.length ? (shifts.length-unfilled.length)/shifts.length : 1 };
}
