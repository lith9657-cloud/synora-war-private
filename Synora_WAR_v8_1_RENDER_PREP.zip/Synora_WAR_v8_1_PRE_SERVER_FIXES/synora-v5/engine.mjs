/**
 * Synora WAR v5 — Engine.
 *
 * Families (real populations with different jobs, not labels):
 *
 *  PATCHER    — the main population. Proposes a child by applying ONE repair operator to its
 *               parent's source. In `full` mode the operator is chosen by the ledger (signature
 *               -> operator credit); in `random` mode it is chosen uniformly among applicable
 *               operators. This single switch is the ablation that isolates the contribution of
 *               the memory from the contribution of the operator library.
 *  BREAKER    — proposes inputs at the edge of the input domain and asks the judge whether the
 *               champion disagrees with the trusted oracle. Disagreements become WITNESSES.
 *  SKEPTIC    — the evaluation family. When a candidate claims to pass everything, the skeptic
 *               fires a battery of near-miss inputs at it. A survivor that fails the battery is
 *               demoted (it was overfitting) and the killing input is filed as a witness.
 *  SYNTHESIZER— takes an operator that earned credit elsewhere and re-applies it to a region the
 *               parent has never touched. This is how a skill travels between tasks.
 *
 * Evaluation budget is metered per task; oracle queries are metered separately, because the
 * oracle is the most expensive thing in the system (it is a trusted reference implementation).
 */
import { applyTransform, applicableTransforms, signatureOf, transformContext, expectedLiteral } from './genome.mjs';
import { mutateInput, makeRng } from './probes.mjs';
import { DISTRACTORS } from './distractors.mjs';

/**
 * EDGE-DOMAIN BATTERY.
 * Hard-coded guards (`if(a==null)return <demanded value>`) hide exactly where a mutation-based
 * search never looks: on inputs that the task's own probes never contain. Every organism that
 * claims success is therefore fired at with type-edge inputs (null, undefined, empty, zero, ...).
 * The judge silently drops the ones outside the oracle's domain, so the battery is safe to use
 * for every task.
 */
const EDGE_DOMAIN_INPUTS = [null, undefined, '', 0, [], {}, NaN, ' ', '\t'];

const hashString = s => {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
};

/** Turn an inherited witness into a killer record so the same evaluator can run it. */
function witnessToKiller(witness) {
  const expectedLiteralText = JSON.stringify(witness.expected);
  return {
    type: 'js_test',
    name: `witness:${witness.id}`,
    input: witness.input,
    split: 'witness',
    test: `const r=JSON.stringify(solution(input)); if(r!==${expectedLiteralText}) throw new Error("Expected "+${expectedLiteralText}+", got "+r);`,
  };
}

export class Engine {
  constructor({
    judge,
    ledger,
    mode = 'full',            // 'full' | 'random'
    seed = 1,
    budget = 400,             // candidate evaluations per task
    generations = 120,
    epsilon = 0.25,           // exploration probability
    populationSize = 6,
    oracleBudget = 200,       // differential queries per task
    maxCodeBytes = 512,
    distractorCount = 0,
    log = () => {},
  } = {}) {
    this.judge = judge;
    this.ledger = ledger;
    this.mode = mode;
    this.seed = seed;
    this.budget = budget;
    this.generations = generations;
    this.epsilon = epsilon;
    this.populationSize = populationSize;
    this.oracleBudget = oracleBudget;
    this.maxCodeBytes = maxCodeBytes;
    this.distractorCount = distractorCount;
    this.log = log;
    this.cursors = new Map();
    this.compose = false;
  }

  get memoryEnabled() { return this.mode === 'full'; }

  /* ------------------------------------------------------------- evaluation */

  /**
   * Evaluate a candidate.
   * IMPORTANT (anti-leak): train failures are returned WITH details (that is the information a
   * developer gets from a failing test). Validation failures are returned as COUNTS ONLY, and
   * holdout inputs are never touched here.
   */
  async evaluate(code, task) {
    const train = await this.judge.runKillers(code, task.train);
    const validationRaw = await this.judge.runKillers(code, task.validation);
    const validation = { passed: validationRaw.passed, total: validationRaw.total };
    // Witnesses are always evaluated, even when memory is disabled: this keeps the
    // "repeated documented error" metric identical for every arm of the experiment.
    const witnessKillers = this.ledger.witnessesFor(task.id).map(witnessToKiller);
    const witnessRaw = witnessKillers.length ? await this.judge.runKillers(code, witnessKillers) : { passed: 0, total: 0, failures: [] };
    const killerByName = new Map([...task.train, ...task.validation].map(k => [k.name, k]));
    return {
      train: {
        passed: train.passed,
        total: train.total,
        // train failures keep the killer's source: that is the information a developer reads
        // from a failing test, and it is what tells us which value the test demanded.
        failures: train.failures.map(f => ({ name: f.name, error: f.error, killer: killerByName.get(f.name) || null })),
      },
      validation,
      witnesses: {
        passed: witnessRaw.passed,
        total: witnessRaw.total,
        violations: witnessRaw.failures.map(f => f.name),
      },
      timedOut: Boolean(train.timedOut),
    };
  }

  score(evaluation) {
    const base = 3 * evaluation.train.passed + 2 * evaluation.validation.passed;
    if (!this.memoryEnabled) return base;
    return base + 4 * evaluation.witnesses.passed - 8 * evaluation.witnesses.violations.length;
  }

  passesEverything(evaluation) {
    return evaluation.train.passed === evaluation.train.total
      && evaluation.validation.passed === evaluation.validation.total
      && evaluation.witnesses.violations.length === 0;
  }

  /* -------------------------------------------------------------- proposal */

  /** The most informative failure is the one whose test tells us what value was demanded. */
  mostInformativeFailure(organism) {
    const failures = organism.evaluation.train.failures;
    if (!failures.length) return null;
    const withValue = failures.find(f => {
      const ctx = transformContext(f, f.killer);
      return ctx.expected !== null;
    });
    return withValue || failures[0];
  }

  proposeChild(parent, task, rng) {
    const parentFailure = this.mostInformativeFailure(parent);
    const ctx = parentFailure
      ? transformContext(parentFailure, parentFailure.killer)
      : { signature: 'mismatch', expected: null, message: '' };

    const directed = [];
    if (this.memoryEnabled && parentFailure) {
      const ranked = this.ledger.rankedOperatorsFor(ctx.signature, { taskId: task.id });
      for (const candidate of ranked) {
        if (this.ledger.isProhibited(task.id, ctx.signature, candidate.transformId, this.currentGen)) continue;
        const next = applyTransform(candidate.transformId, parent.code, ctx);
        if (next && next !== parent.code) directed.push({ code: next, transformId: candidate.transformId, source: 'directed' });
      }
    }

    const randomPool = applicableTransforms(parent.code, ctx)
      .filter(c => !directed.some(d => d.code === c.code));
    // DISTRACTORS: pad the operator space with generic edits that rarely repair anything.
    // They make the blind-search baseline pay for its coverage, which is the regime a real
    // operator library lives in. They are counted in every report.
    if (this.distractorCount > 0) {
      const offset = Math.floor(rng() * DISTRACTORS.length) % DISTRACTORS.length;
      for (let i = 0; i < DISTRACTORS.length && randomPool.length < this.distractorCount + 4; i++) {
        const d = DISTRACTORS[(offset + i) % DISTRACTORS.length];
        let ok = false;
        try { ok = d.applies(parent.code); } catch { ok = false; }
        if (!ok) continue;
        let next = null;
        try { next = d.apply(parent.code); } catch { next = null; }
        if (!next || next === parent.code) continue;
        if (randomPool.some(c => c.code === next)) continue;
        randomPool.push({ id: d.id, code: next, label: d.label });
      }
    }
    // Systematic operator coverage: a rotating cursor guarantees every applicable operator is
    // tried before any is repeated. Pure uniform sampling wastes budget on unlucky draws.
    let explored = [];
    if (randomPool.length) {
      // NOTE: the cursor is per PARENT, not per task. With a per-task cursor and a population
      // size equal to the operator-pool size, every generation re-picks the same operator
      // (index aliasing) and the search silently stalls.
      const key = `${task.id}|${parent.id}`;
      const cursor = this.cursors.get(key) ?? 0;
      const offset = Math.floor(rng() * randomPool.length) % randomPool.length;
      const index = (cursor + offset) % randomPool.length;
      const picked = randomPool[index];
      this.cursors.set(key, (cursor + 1) % randomPool.length);
      explored = [{ code: picked.code, transformId: picked.id, source: 'random' }];
    }

    const pool = [...directed, ...explored];
    if (!pool.length) return null;
    const preferDirected = directed.length && rng() > this.epsilon;
    const chosen = preferDirected ? directed[0] : (explored[0] || directed[0]);

    // COMPOSITION: a second operator applied on top of the first. Some repairs genuinely need
    // two steps (e.g. a null guard AND an empty-input guard), and no single operator can
    // express that. The composed operator id is what the ledger learns, so a *combination*
    // can become a reusable skill.
    if (this.compose && chosen) {
      const first = chosen;
      const after = applicableTransforms(first.code, ctx).filter(c => c.id !== first.transformId);
      if (after.length) {
        const second = after[Math.floor(rng() * after.length) % after.length];
        const composed = { code: second.code, transformId: `${first.transformId}+${second.id}`, source: 'composed' };
        if (Buffer.byteLength(composed.code, 'utf8') <= this.maxCodeBytes) return composed;
      }
    }

    if (Buffer.byteLength(chosen.code, 'utf8') > this.maxCodeBytes) return null;
    return { code: chosen.code, transformId: chosen.transformId, source: chosen.source };
  }

  /* ------------------------------------------------------------ attribution */

  /**
   * Causal attribution by intervention: a failure counts as caused by the child's mutation only
   * when the PARENT PASSED the very same killer. If the parent failed it too, the failure is
   * inherited, not caused, and we must not learn a false lesson from it.
   */
  async attribute(parent, child, task, gen, events, taskSignature) {
    const parentFailedNames = new Set(parent.evaluation.train.failures.map(f => f.name));
    const parentFailure = parent.evaluation.train.failures[0] || null;
    for (const failure of child.evaluation.train.failures) {
      const signature = signatureOf(failure);
      const attributable = !parentFailedNames.has(failure.name);
      events.push({ type: 'failure', gen, taskId: task.id, signature, transformId: child.transformId, attributable });
      if (attributable && this.memoryEnabled && child.transformId) {
        this.ledger.noteAttributableFailure({
          taskId: task.id, signature, transformId: child.transformId, gen, message: failure.error,
        });
        // the operator was applied in the parent's context: record the miss against THAT
        // context too, so a skill that fails here stops being preferred here.
        const parentSignature = parentFailure ? signatureOf(parentFailure) : null;
        if (parentSignature && parentSignature !== signature) {
          this.ledger.noteOperatorMiss({
            taskId: task.id, signature: parentSignature, transformId: child.transformId, gen,
          });
        }
      }
    }
    const childPassedNames = new Set(child.evaluation.train.failures.map(f => f.name));
    // A pass is only CREDIBLE if the child also respects every inherited witness. Without this
    // gate the ledger happily learns coincidental fixes: bumping a constant can make one
    // failing assertion pass by luck, and that operator then inherits the credit and is
    // transferred to other tasks as if it were a real repair.
    const credible = child.evaluation.witnesses.violations.length === 0;
    for (const fixed of parent.evaluation.train.failures) {
      if (childPassedNames.has(fixed.name)) continue;
      const raw = signatureOf(fixed);
      // The context signature can be uninformative (a timeout says nothing about the defect).
      // The stable identifier of the defect is the seed's own signature: credit the fix there.
      const signature = (raw === 'mismatch' && taskSignature) ? taskSignature : raw;
      events.push({ type: 'repair', gen, taskId: task.id, signature, transformId: child.transformId, credible });
      if (this.memoryEnabled && child.transformId && credible) {
        this.ledger.noteSuccess({
          taskId: task.id, signature, transformId: child.transformId, gen,
          witnesses: this.ledger.witnessesFor(task.id).map(w => w.id),
        });
        if (taskSignature && taskSignature !== signature) {
          this.ledger.noteSuccess({
            taskId: task.id, signature: taskSignature, transformId: child.transformId, gen,
            witnesses: this.ledger.witnessesFor(task.id).map(w => w.id),
          });
        }
      }
    }

    // COMPOSITION DECOMPOSITION. A combination may repair a task even when neither part does
    // alone, but a combination is a poor unit of inheritance: it rarely transfers. So we ask
    // the intervention question again — does one component alone repair the same killer? — and
    // if it does, that component is credited as the transferable unit.
    if (this.memoryEnabled && credible && child.transformId && child.transformId.includes('+')) {
      const parts = child.transformId.split('+');
      const ctx = parentFailure ? transformContext(parentFailure, parentFailure.killer) : { signature: taskSignature, expected: null, message: '' };
      for (const part of parts) {
        // The transferable unit is "this operator repairs this task from the seed", not
        // "it repairs this particular descendant". We therefore apply it to the SEED.
        const probe = applyTransform(part, task.buggy, ctx);
        if (!probe) continue;
        const probeEvaluation = await this.evaluate(probe, task);
        if (probeEvaluation.train.passed !== probeEvaluation.train.total) continue;
        if (probeEvaluation.witnesses.violations.length) continue;
        const sig = taskSignature || signatureOf(parentFailure || { error: '' });
        this.ledger.noteSuccess({
          taskId: task.id, signature: sig, transformId: part, gen,
          witnesses: this.ledger.witnessesFor(task.id).map(w => w.id),
        });
        events.push({ type: 'component_credit', gen, taskId: task.id, signature: sig, transformId: part });
      }
    }
  }

  /* ---------------------------------------------------------------- families */

  /** BREAKER: probe the edge of the input domain for disagreements with the oracle. */
  async breaker(task, champion, rng, count = 4) {
    if (!this.memoryEnabled) return { witnesses: 0, queries: 0 };
    const base = [...task.probes];
    const queries = [];
    for (let i = 0; i < count; i++) {
      const seedInput = base[Math.floor(rng() * base.length) % base.length];
      queries.push(mutateInput(seedInput, rng));
    }
    // one edge-domain probe per breaker round
    queries.push(EDGE_DOMAIN_INPUTS[Math.floor(rng() * EDGE_DOMAIN_INPUTS.length) % EDGE_DOMAIN_INPUTS.length]);
    const mismatches = await this.judge.differential(champion.code, task.reference, queries);
    let created = 0;
    for (const mismatch of mismatches) {
      const witness = this.ledger.addWitness({
        taskId: task.id,
        input: mismatch.input,
        expected: mismatch.expected,
        actual: mismatch.actual,
        signature: 'witness',
        origin: 'breaker',
        gen: this.currentGen,
      });
      if (witness) created++;
    }
    return { witnesses: created, queries: queries.length };
  }

  /** SKEPTIC: near-miss battery against a candidate that claims to pass everything. */
  async skeptic(task, candidate, rng) {
    if (!this.memoryEnabled) return { passed: true, demoted: false };
    const inputs = [];
    for (const probe of task.probes) inputs.push(mutateInput(probe, rng));
    inputs.push(...EDGE_DOMAIN_INPUTS);
    const mismatches = await this.judge.differential(candidate.code, task.reference, inputs);
    if (!mismatches.length) return { passed: true, demoted: false };
    for (const mismatch of mismatches) {
      this.ledger.addWitness({
        taskId: task.id, input: mismatch.input, expected: mismatch.expected, actual: mismatch.actual,
        signature: 'witness', origin: 'skeptic', gen: this.currentGen,
      });
    }
    return { passed: false, demoted: true, kills: mismatches.length };
  }

  /* ------------------------------------------------------------- main loop */

  async runTask(task) {
    const rng = makeRng((this.seed ^ hashString(task.id)) >>> 0);
    const events = [];
    let evaluations = 0;
    let oracleQueries = 0;
    this.currentGen = 0;

    const seedEvaluation = await this.evaluate(task.buggy, task);
    evaluations++;
    // The canonical signature of this task's defect: the most informative signature the seed
    // produces. It is the stable key under which a repair is learned and transferred.
    const seedFailure = this.mostInformativeFailure({ evaluation: seedEvaluation });
    const taskSignature = seedFailure ? signatureOf(seedFailure) : null;
    const seedOrganism = {
      id: `${task.id}#0`, parentId: null, gen: 0, code: task.buggy, transformId: null, source: 'seed',
      lineageOps: [],
      evaluation: seedEvaluation, score: this.score(seedEvaluation),
    };
    let population = [seedOrganism];
    let champion = seedOrganism;
    let certified = false;
    let firstCertifiedAt = null;
    const history = [];

    for (let gen = 1; gen <= this.generations && evaluations < this.budget && !certified; gen++) {
      this.currentGen = gen;
      const breakerResult = await this.breaker(task, champion, rng, 4);
      oracleQueries += breakerResult.queries;

      const children = [];
      for (const parent of population) {
        if (evaluations >= this.budget) break;
        this.compose = (children.length % 2 === 1);
        const proposal = this.proposeChild(parent, task, rng);
        if (!proposal) continue;
        const evaluation = await this.evaluate(proposal.code, task);
        evaluations++;
        for (const violation of evaluation.witnesses.violations) {
        events.push({ type: 'witness_violation', gen, taskId: task.id, witness: violation, transformId: proposal.transformId });
      }
      const child = {
          id: `${task.id}#${gen}.${children.length}`, parentId: parent.id, gen,
          code: proposal.code, transformId: proposal.transformId, source: proposal.source,
          lineageOps: [...(parent.lineageOps || []), proposal.transformId],
          evaluation, score: this.score(evaluation),
        };
        await this.attribute(parent, child, task, gen, events, taskSignature);
        children.push(child);
      }

      const pool = [...population, ...children];
      pool.sort((a, b) => (b.score - a.score) || (a.code.length - b.code.length));
      const seen = new Set();
      const nextPopulation = [];
      const lineageBest = new Map();
      for (const organism of pool) {
        if (seen.has(organism.code)) continue;
        seen.add(organism.code);
        const lineage = (organism.lineageOps || []).slice(0, 2).join('>');
        if (!lineageBest.has(lineage)) {
          lineageBest.set(lineage, organism);
          nextPopulation.push(organism);
        }
      }
      population = nextPopulation.sort((a, b) => (b.score - a.score) || (a.code.length - b.code.length)).slice(0, this.populationSize);
      champion = population[0];

      if (this.passesEverything(champion.evaluation)) {
        const verdict = await this.skeptic(task, champion, rng);
        oracleQueries += task.probes.length;
        if (verdict.passed) {
          certified = true;
          firstCertifiedAt = evaluations;
        } else {
          // overfitting detected: re-score with the new witness and demote
          const refreshed = await this.evaluate(champion.code, task);
          evaluations++;
          champion.evaluation = refreshed;
          champion.score = this.score(refreshed);
          population.sort((a, b) => (b.score - a.score) || (a.code.length - b.code.length));
          champion = population[0];
        }
      }

      history.push({
        gen, evaluations, oracleQueries,
        championScore: champion.score,
        championPasses: `${champion.evaluation.train.passed}/${champion.evaluation.train.total}`,
        validation: `${champion.evaluation.validation.passed}/${champion.evaluation.validation.total}`,
        witnesses: `${champion.evaluation.witnesses.passed}/${champion.evaluation.witnesses.total}`,
        population: population.length,
        skills: this.ledger.skills.size,
        witnessesTotal: this.ledger.witnesses.size,
      });
      this.ledger.prune({ gen });
      this.log({ task: task.id, gen, evaluations, score: champion.score });
    }

    // Final exam: holdout inputs were never used during evolution.
    const holdoutMismatches = await this.judge.differential(champion.code, task.reference, task.holdout);
    oracleQueries += task.holdout.length;
    const success = this.passesEverything(champion.evaluation) && holdoutMismatches.length === 0;

    const witnessViolationEvents = events.filter(e => e.type === 'witness_violation').length;
    return {
      taskId: task.id,
      set: task.set,
      bugClass: task.bugClass,
      success,
      certified,
      evaluations,
      oracleQueries,
      firstCertifiedAt,
      champion: {
        code: champion.code,
        transformId: champion.transformId,
        score: champion.score,
        train: champion.evaluation.train,
        validation: champion.evaluation.validation,
        witnesses: champion.evaluation.witnesses,
      },
      holdoutFailures: holdoutMismatches.map(m => ({ input: m.input, expected: m.expected, actual: m.actual })),
      witnessViolationEvents,
      events,
      history,
    };
  }
}
