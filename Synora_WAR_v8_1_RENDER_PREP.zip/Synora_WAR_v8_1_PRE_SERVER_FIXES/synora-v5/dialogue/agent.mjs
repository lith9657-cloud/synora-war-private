import { parseRequest } from './index.mjs';
import { generateSolution } from '../solution-engine/index.mjs';
import { createDefaultToolRegistry } from '../tools/registry.mjs';
import { inspectSkillInCore } from '../digital-object-learning/bridge.mjs';
import { routeExplicitSkillRequest } from '../digital-object-learning/skill-router.mjs';
import crypto from 'node:crypto';

export async function handleDialogue(text, { history = [], tools = createDefaultToolRegistry(), learner = null, core = null, skillId = null, skillInput = undefined, applicationLedger = null, eventId = null, source = 'dialogue' } = {}) {
  const request = parseRequest(text, { history });
  const trace = [{ stage: 'parse-request', intent: request.intent, action: request.action, confidence: request.confidence }];
  if (request.followUp) trace.push({ stage: 'context-resolution', source: request.evidence.contextResolution, intent: request.intent });
  const attemptId = typeof eventId === 'string' && eventId.trim() ? eventId : crypto.randomUUID();
  const recordAttempt = (details) => {
    if (!applicationLedger) return { persisted: false, eventId: attemptId };
    return applicationLedger.record({ eventId: attemptId, source, ...details });
  };
  const responseForAttempt = (skill, input, applied, reason = null) => {
    let persisted;
    try {
      persisted = recordAttempt({
        skillId: skill?.id ?? null, skillVersion: skill?.version ?? null,
        operation: applied?.ok ? 'apply' : 'abstain', input,
        status: applied?.ok ? 'executed' : (applied?.error ? 'error' : 'abstained'),
        executed: Boolean(applied?.executed), executionSuccess: Boolean(applied?.ok),
        reason: reason ?? applied?.reason ?? null,
        result: applied?.ok ? applied.output : null, requestFingerprint: text
      });
    } catch (error) {
      const conflict = /application event ID conflict/.test(error.message);
      return { ok: false, request, answer: conflict ? 'This idempotency key was already used for a different request.' : 'Skill result was not reported as successful because the application evidence could not be persisted.', error: { kind: conflict ? 'idempotency-key-conflict' : 'application-ledger-persistence-failed', message: error.message }, trace: [...trace, { stage: 'skill-application-ledger', ok: false, reason: error.message }] };
    }
    if (persisted?.duplicate) {
      const old = persisted.event;
      return { ok: old.executionSuccess, request, answer: old.executionSuccess ? `Previously recorded application ${old.eventId}: ${JSON.stringify(old.result)}` : `Previously recorded non-success: ${old.reason ?? old.status}`, skillResult: { ok: old.executionSuccess, output: old.result, reason: old.reason }, trace: [...trace, { stage: 'skill-application-ledger', ok: true, duplicate: true, eventId: old.eventId }], application: { eventId: old.eventId, duplicate: true, status: old.status, objectiveCorrectness: old.objectiveCorrectness } };
    }
    return null;
  };
  if (skillId !== null) {
    const skill = learner?.skills?.get(skillId) ?? null;
    if (!learner || typeof skillId !== 'string' || skillInput === undefined || !core) {
      const applied = { ok: false, executed: false, reason: 'known-skill-input-and-digital-object-core-required' };
      const failure = responseForAttempt(skill, skillInput, applied, applied.reason);
      if (failure) return failure;
      return { ok: false, request, answer: 'A known active skill, explicit input, and DigitalObjectCore registration are required.', trace, error: { kind: 'invalid-skill-invocation' } };
    }
    const object = inspectSkillInCore(core, skillId);
    if (!skill || skill.status !== 'accepted' || skill.active === false || !object || object.state !== 'active' || object.type !== 'digital-skill' || object.properties?.skillId !== skillId || object.properties?.skillStatus !== 'accepted') {
      const applied = { ok: false, executed: false, reason: 'skill-not-registered-active-in-digital-object-core' };
      const failure = responseForAttempt(skill, skillInput, applied, applied.reason);
      if (failure) return failure;
      return { ok: false, request, answer: 'The skill is not accepted, active, and registered in DigitalObjectCore.', trace, error: { kind: applied.reason } };
    }
    const applied = learner.apply(skillId, skillInput);
    applied.executed = Boolean(applied.ok);
    trace.push({ stage: 'digital-skill-application', skillId, skillVersion: skill.version, coreVerified: true, ok: applied.ok, reason: applied.reason ?? null });
    const failure = responseForAttempt(skill, skillInput, applied);
    if (failure) return failure;
    return { ok: applied.ok, request, answer: applied.ok ? `Applied skill ${skillId}: ${JSON.stringify(applied.output)}` : `Skill not applied: ${applied.reason ?? 'unavailable'}`, skillResult: applied, trace, verification: { engineReportedSuccess: applied.ok, objectiveCorrectness: 'not-assessed', provenance: applied.provenance ?? null }, application: { eventId: attemptId, status: applied.ok ? 'executed' : 'abstained', objectiveCorrectness: 'not-assessed' } };
  }
  if (learner && core) {
    const routed = routeExplicitSkillRequest(text, { learner, core });
    if (routed.matched) {
      trace.push({ stage: 'digital-skill-routing', selectedSkillId: routed.selectedSkillId ?? null, candidateSkillIds: routed.candidateSkillIds ?? [], reason: routed.reason, input: routed.input ?? null, ok: Boolean(routed.ok) });
      const skill = routed.selectedSkillId ? learner.skills.get(routed.selectedSkillId) ?? null : null;
      if (!routed.ok) {
        const failed = { ok: false, executed: false, reason: routed.reason };
        const failure = responseForAttempt(skill, routed.input, failed, routed.reason);
        if (failure) return failure;
        return { ok: false, request, answer: `Skill request not executed: ${routed.reason}.`, trace, abstention: { reason: routed.reason, candidateSkillIds: routed.candidateSkillIds ?? [] }, application: { eventId: attemptId, status: 'abstained', objectiveCorrectness: 'not-assessed' } };
      }
      const applied = learner.apply(routed.selectedSkillId, routed.input);
      applied.executed = Boolean(applied.ok);
      trace.push({ stage: 'digital-skill-application', skillId: routed.selectedSkillId, skillVersion: routed.skillVersion, coreVerified: true, ok: applied.ok, reason: applied.reason ?? null });
      const failure = responseForAttempt(routed.skill, routed.input, applied);
      if (failure) return failure;
      return { ok: applied.ok, request, answer: applied.ok ? `Applied skill ${routed.skill.name} (${routed.selectedSkillId}) to ${JSON.stringify(routed.input)}: ${JSON.stringify(applied.output)}` : `Skill not applied: ${applied.reason ?? 'unavailable'}`, skillResult: applied, trace, skillSelection: { skillId: routed.selectedSkillId, name: routed.skill.name, version: routed.skillVersion, reason: routed.reason, input: routed.input }, verification: { engineReportedSuccess: applied.ok, objectiveCorrectness: 'not-assessed', provenance: applied.provenance ?? null }, application: { eventId: attemptId, status: applied.ok ? 'executed' : 'abstained', objectiveCorrectness: 'not-assessed' } };
    }
  }
  if (request.intent === 'greeting') return { ok: true, request, answer: request.language === 'ar' ? 'مرحبًا! أستطيع حاليًا الحساب الأساسي وإنشاء واختبار قوالب برمجية محددة. اذكر المهمة بوضوح.' : 'Hello! I currently support basic arithmetic and a small set of generated-and-tested code templates. Describe the task you want to solve.', trace, evidence: ['bounded-rule-dialogue-v1'] };
  if (request.intent === 'calculate' && request.entities.arithmetic?.valid) {
    const a = request.entities.arithmetic;
    const toolResult = await tools.call('calculator.basic', { left: Number(a.expression.split(' ')[0]), operator: a.expression.split(' ')[1], right: Number(a.expression.split(' ')[2]) });
    trace.push({ stage: 'tool-selection', selectedTool: 'calculator.basic', reason: 'request intent is arithmetic' });
    trace.push({ stage: 'tool-result-validation', ok: toolResult.ok });
    if (!toolResult.ok) return { ok: false, request, answer: 'I could not verify the calculation input.', trace, toolResult };
    const agrees = Object.is(toolResult.output.value, a.value);
    return { ok: agrees, request, answer: `${a.expression} = ${toolResult.output.value}`, trace, toolResult, verification: { parserToolAgreement: agrees } };
  }
  if (request.intent === 'code.unsupported') return { ok: false, request, answer: request.language === 'ar' ? 'المهمة البرمجية المطلوبة خارج النطاق المدعوم حاليًا. لم أنفذ شيفرة غير معروفة.' : 'The requested programming task is outside the currently supported scope. I did not execute unknown code.', trace, abstention: { reason: 'unsupported-code-task', requiredInfo: request.slots.missing ?? [] } };
  if (request.intent.startsWith('code.')) {
    const solution = generateSolution(request);
    trace.push({ stage: 'solution-generation', templateId: solution.generated?.templateId ?? null, status: solution.status });
    if (!solution.ok) return { ok: false, request, answer: request.language === 'ar' ? 'هذه المهمة خارج القوالب البرمجية التي تم التحقق منها. لم أنشئ ادعاءً بحلها.' : 'This task is outside the verified code templates. I will not claim to have solved it.', solution, trace };
    return { ok: true, request, answer: request.language === 'ar' ? `أنشأت قالبًا برمجيًا ${solution.generated.templateId} واجتاز ${solution.verification.testsPassed}/${solution.verification.testsTotal} اختبارات داخلية.` : `Generated ${solution.generated.templateId}; it passed ${solution.verification.testsPassed}/${solution.verification.testsTotal} internal tests.`, solution, trace, verification: solution.verification };
  }
  if (request.intent === 'skill.learn-affine') return { ok: false, request, answer: request.language === 'ar' ? 'أستطيع استقراء قاعدة تحويل حسابية محدودة إذا قدمت معامل modulus ومثالين على الأقل من المدخلات والمخرجات، مع أمثلة تحقق منفصلة.' : 'I can induce a bounded affine-mod rule if you provide a modulus, at least two input/output examples, and separate validation examples.', trace, requiredSchema: { modulus: 'integer 2..97', training: [{ id: 'train-1', input: 1, output: 3 }, { id: 'train-2', input: 2, output: 5 }], development: [{ id: 'dev-1', input: 3, output: 0 }, { id: 'dev-2', input: 4, output: 2 }] } };
  if (request.intent === 'explain') return { ok: true, request, answer: request.language === 'ar' ? 'أستطيع شرح المكونات الموجودة في المشروع إذا حددت المكون. فهمي الحالي يعتمد على قواعد لغوية محدودة وليس فهمًا عامًا.' : 'I can explain a project component if you name it. My current language handling is based on bounded rules, not general understanding.', trace, evidence: ['bounded-scope-response'] };
  return { ok: false, request, answer: request.language === 'ar' ? 'لم أستطع تحديد مهمة مدعومة بثقة كافية. أعد صياغة الطلب وحدد المدخلات والنتيجة المطلوبة.' : 'I could not identify a supported task with enough confidence. Please specify the inputs and desired output.', trace, abstention: { reason: 'unsupported-or-ambiguous-intent', confidence: request.confidence } };
}
