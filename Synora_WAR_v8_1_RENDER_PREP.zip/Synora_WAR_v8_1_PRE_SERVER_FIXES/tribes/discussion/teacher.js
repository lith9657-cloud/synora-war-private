function solution(a){return {question:"هدف؟",answer:"مساعدة",next_step:"ابدأ"}}
