function solution(a){return {text:String(a),language:"en"}}
