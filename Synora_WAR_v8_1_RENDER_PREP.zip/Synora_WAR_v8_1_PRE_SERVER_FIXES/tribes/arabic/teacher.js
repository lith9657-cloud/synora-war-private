function solution(a){return {text:String(a),language:"ar"}}
