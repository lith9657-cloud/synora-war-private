function solution(a){return typeof a==='number'?a*2:'error'}
