function solution(a){return {hook:a,pain:a,cta:a}}
