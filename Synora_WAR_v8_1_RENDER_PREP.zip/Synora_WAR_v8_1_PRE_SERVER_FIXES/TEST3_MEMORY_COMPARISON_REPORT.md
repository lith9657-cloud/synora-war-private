# Synora WAR v6 — Test 3: memory impact comparison

## Method
- Reanalyzed the packaged Phase-4 paired benchmark across 5 seeds, 4 arms, 5 budgets, and 90 evaluation units per arm/budget.
- Compared CRI memory, cold baseline, noise memory, and no-transfer control.
- Ran the complete Node test files after the analysis.

## Results
| Budget | Cold baseline | CRI memory | Noise memory | No transfer | CRI vs baseline |
|---:|---:|---:|---:|---:|---:|
| 10 | 0/90 (0.0%) | 26/90 (28.9%) | 3/90 | 0/90 | +26 tasks |
| 20 | 15/90 (16.7%) | 31/90 (34.4%) | 15/90 | 16/90 | +16 tasks |
| 40 | 40/90 (44.4%) | 48/90 (53.3%) | 37/90 | 40/90 | +8 tasks |
| 80 | 76/90 (84.4%) | 71/90 (78.9%) | 70/90 | 76/90 | -5 tasks |
| 150 | 83/90 (92.2%) | 78/90 (86.7%) | 81/90 | 84/90 | -5 tasks |

## Defect identified and mitigation
The comparison shows CRI is helpful at small budgets but can trail the cold baseline at larger budgets. This is a real transfer-calibration issue, not a test-suite failure. The v6 package therefore keeps the conservative SafeTransferLedger opt-in and does not silently replace the audited legacy ledger. Its policy requires two distinct successful task IDs before cross-task transfer and blocks a transfer after a target-task miss. Four focused regression tests verify these gates.

## Verification
- `tests/audit.test.mjs`: 23 passed
- `tests/phase3.test.mjs`: 20 passed
- `tests/phase4.test.mjs`: 32 passed
- `tests/pst.test.mjs`: 19 passed
- `tests/v5.test.mjs`: 15 checks passed
- `tests/safe-transfer-ledger.test.mjs`: 4 passed
- `tests/third-domain.test.mjs`: 6 passed

All executed test files exited successfully. Existing benchmark results were analyzed as packaged; this report does not claim a new Phase-4 benchmark run.
