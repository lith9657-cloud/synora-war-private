# Synora WAR v6 — Adaptive memory policy (experimental)

## What changed
- Added `synora-v5/phase4/adaptive-engine.mjs`, an experimental subclass that leaves the audited legacy Phase-4 engine unchanged.
- Added `--mode=adaptive` to the evaluation runner. It restores the same memory artifact as CRI.
- At budgets >= 80, adaptive mode abstains from transferred value hints and relies on systematic search while retaining the ledger for within-task evidence/refutations.
- At lower budgets, it stops using hints after at least two directed misses when misses outnumber hits.
- Updated the package manifest for the changed runner and new module.

## Verification
- Adaptive policy unit checks: 2 passed.
- `tests/self-test.mjs`: 11 checks passed.
- `tests/v5.test.mjs`: 15 checks passed.
- `tests/pst.test.mjs`: 19 passed.
- `tests/phase3.test.mjs`: 20 passed.
- `tests/audit.test.mjs`: 23 passed.
- `tests/phase4.test.mjs`: 32 passed.
- `tests/safe-transfer-ledger.test.mjs`: 4 passed.
- `tests/third-domain.test.mjs`: 6 passed.
- Smoke runs using the existing seed-1 acquisition memory and groups B,C completed: budget 80 solved 14/18 tasks; budget 150 solved 16/18 tasks.

## Important limitation
These smoke runs are not a full paired multi-seed benchmark and cannot establish that the regression is fixed. The policy is experimental and is not the default mode. Compare `adaptive` against `cri`, `base`, `noise`, and `notransfer` over the same seeds and budgets before promoting it. The existing packaged benchmark evidence has not been overwritten.
