# Synora WAR V8.1 — Pre-server fixes report

## Status

**Acceptance status: PASS for the scoped acceptance criteria in this task.** This release is a bounded prototype, not a general-purpose language model or production deployment.

## Baseline protection

- Original archive: `Synora_WAR_v8_EVOLUTIONARY_LEARNING_STAGE4.zip`
- SHA-256 measured before work: `b0300e0d10726065b3867f0e192f8e3842a98c4f437f6ecbcde19efdf00e206f`
- Original archive was not modified; all edits were made in an extracted work copy.
- Node.js used: `v22.16.0`; project engine requirement remains Node.js `>=20`.
- All 32 files in `audit/immutable-baseline.json` still match their recorded SHA-256 hashes. A separate direct comparison against the extracted original V8 also found zero hash changes across 12 protected source files (DigitalObjectCore, CRI engine, and Adaptive V2 engine files).
- `synora-v5/digital-object-core/index.mjs`, CRI engine files, and Adaptive V2 engine files were not modified. The existing DigitalObjectCore implementation is reused as-is.

## Changes implemented

1. Added `synora-v5/digital-object-learning/skill-router.mjs`.
   - Recognizes a bounded explicit action (apply/use/run/execute and supported Arabic equivalents).
   - Matches whole skill names or IDs only; it does not use fuzzy matching.
   - Requires exactly one candidate, accepted status, active learner state, and an active matching `digital-skill` registration in DigitalObjectCore.
   - Extracts only an explicit integer or bracketed integer array; rejects missing/ambiguous input, out-of-domain values, arbitrary expressions, and unsupported shapes.
   - The trace includes selected skill ID/version, selection reason, input, core-registration check, and actual result.

2. Added `synora-v5/digital-object-learning/application-ledger.mjs`.
   - Stores a separate checksummed JSON ledger with unique event IDs, timestamps, skill ID/version, operation, safe input summary, execution/abstention/error status, reason, result, source, and request digest.
   - Uses a temporary file, `fsync`, and atomic rename. A failed write is surfaced as an error; the dialogue path does not claim a successful persisted application.
   - Rejects corrupted data and conflicting reuse of an event ID; identical requests are idempotent.
   - Records `objectiveCorrectness: "not-assessed"` to distinguish successful execution from independently verified truth.
   - For arrays longer than 32 values, stores length and digest rather than the full input.

3. Updated `synora-v5/dialogue/agent.mjs`.
   - Preserves the existing explicit `skillId` path, but now requires accepted/active state and a matching active DigitalObjectCore registration.
   - Automatically routes explicit named-skill requests when the caller omits `skillId` and `skillInput`.
   - Records successful and unsuccessful named-skill attempts when a ledger is configured.
   - A ledger persistence failure prevents a success response; idempotency-key conflicts are surfaced distinctly.

4. Updated `synora-v5/api/server.mjs`.
   - Wires the application ledger into the dialogue and direct apply endpoints.
   - Adds `SYNORA_SKILL_APPLICATION_LEDGER` to configure the ledger file; default is `data/digital-skill-applications.json`.
   - Supports `eventId` in the JSON request or `Idempotency-Key` header.
   - Validates the accepted learner skill and exact active DigitalObjectCore registration before direct application.
   - Adds functional `GET /v1/skills` (the prior method gate made this advertised GET route unreachable).
   - Keeps local-only default binding and existing size/rate/token protections.

5. Expanded the reviewed code-template set from three to five with non-mutating reverse-array and ascending numeric-sort templates. The dialogue parser recognizes explicit English and Arabic requests for those operations; each template has positive, empty-input, and invalid-element tests. This exposed a real verification bug: generated array results were compared with `Object.is`, which compares array identity rather than elements. The trusted-template test harness now performs elementwise array equality while retaining strict `Object.is` for scalar values. These remain finite verified templates, not open-ended code synthesis.

6. Added `tests/stage4/skill-routing.test.mjs` with tests for exact routing, novel input, ambiguity, inactive/unregistered skills, invalid domain/input, event deduplication/conflicts, checksummed cross-process ledger recovery, actual HTTP API calls, actual Node process restart, and refusal to execute arbitrary JavaScript.

7. Fixed the pre-existing Stage 4 API test fixture to put its application ledger in the temporary test directory. An extracted-package run exposed that the test had written to `data/digital-skill-applications.json` inside the source tree, invalidating the package manifest. The test is now isolated and the generated runtime file is excluded from the deliverable.

8. Updated `package.json`, `audit/package-manifest.json`, the runbook, README, and change log.

## Test evidence

Final verification on the exact source package:

- `npm test` — exit code **0**, all legacy suites and the expanded Stage 4 suite passed.
- `npm run test:stage4` — exit code **0**, **25/25** Stage 4 tests passed.
- A separate Node.js server process learned a skill through HTTP, applied it without `skillId`/`skillInput` by naming the skill in text, and recorded one event. After terminating that process and starting a new Node.js process against the same files, the skill was restored and the event count remained one. Repeating the identical request with the same `Idempotency-Key` returned the prior result without adding a second event.
- The application ledger was loaded in a separate Node process; checksum corruption was rejected.
- Arbitrary user-supplied JavaScript is not passed to `eval`, `Function`, `vm`, or a shell. The skill router only calls the existing constrained affine/composition DSL.
- Initial failures were retained in `reports/v8.1-pre-server-fixes/`: one test fixture mutated the cloned skill returned by induction rather than the learner's stored skill; one test initially used POST to exercise the documented GET skills route; the first full suite after source edits detected a stale package manifest; the first reverse/sort template run exposed array-reference comparison in the verifier, which was corrected with elementwise checks; and the first extracted-package run exposed that an older API test polluted the package root with runtime ledger state. The fixture was corrected without weakening assertions, the GET route was made functional, the test store was isolated, and the manifest was regenerated. All final runs passed.

See `reports/v8.1-pre-server-fixes/` for captured logs. The archive SHA-256 is supplied in the separate `.sha256` sidecar to avoid a self-referential hash inside the ZIP.

## Modified files

- `package.json`
- `synora-v5/api/server.mjs`
- `synora-v5/dialogue/agent.mjs`
- `synora-v5/dialogue/index.mjs`
- `synora-v5/solution-engine/index.mjs`
- `synora-v5/digital-object-learning/application-ledger.mjs` (new)
- `synora-v5/digital-object-learning/skill-router.mjs` (new)
- `tests/stage4/skill-routing.test.mjs` (new)
- `tests/stage4/stage4.test.mjs` (reverse/sort parser and template tests; API test path isolation; no assertion removed or relaxed)
- `audit/package-manifest.json` (regenerated)
- `SYNORA_WAR_V8_STAGE4_RUNBOOK.md`
- `README.md`
- `docs/CHANGE-LOG.md`
- `docs/V8_1_PRE_SERVER_FIXES_REPORT.md` (new)
- `reports/v8.1-pre-server-fixes/*` (test and provenance logs)

## Remaining limits (not release blockers for this scoped task)

- Skill routing is deliberately exact-name/ID and explicit-input based; it is not general natural-language understanding.
- Skill learning remains limited to the existing affine modular DSL and compositions supported by the learner.
- Objective correctness is not inferred from successful execution; it remains `not-assessed` unless an independent evaluator is supplied.
- The application ledger is a local single-writer JSON store, not a distributed transactional database. Back it up with the learner/core stores.
- The API is not production-ready for public exposure; no claim is made about TLS termination, production authentication, multi-tenant isolation, or hardened hostile-code sandboxing. Do not bind it publicly just because a token is set.
- No comparison with Llama 2, general self-improvement claim, or energy-efficiency claim is made.
