# سجل التغييرات — Synora WAR v5

كل تغيير على الشيفرة أو التقارير، مع سببته ودليله. النسخة الأصلية قبل التدقيق محفوظة في
`audit/pre-audit-code-snapshot.tar.gz` + `audit/pre-audit-manifest.json` (بصمات SHA-256 لكل ملف).

## قبل التدقيق (المراحل 1–3 كما سُلّمت)

| # | التغيير | السبب |
|---|---|---|
| 1 | `synora-v5/ledger.mjs`: أضيف `hint` للمهارة | المرحلة 2/3: القيمة التي نجحت لكل شكل إصلاح (مُرشَّحة للـhint) |
| 2 | `synora-v5/phase3/*` (مجلد جديد) | المرحلة 3: ذاكرة دائمة + مجموعات A/B/C + 5 أذرع |
| 3 | `synora-v5/phase3/operators.mjs`: مشغّل `INSERT_CALL_ARG` | **مضبوط بالقياس**: ثلاث مهام بخطوة ناقصة كانت مستحيلة الحل بدونه |
| 4 | `docs/REPORT-PST.md`, `docs/06-REPORT-LONG-TERM-MEMORY.md` | تقارير المرحلتين 2 و3 |

## أثناء التدقيق (ما في هذا التقرير)

| # | التغيير | السبب | الدليل |
|---|---|---|---|
| 5 | `synora-v5/pst/engine.mjs` + `synora-v5/phase3/engine.mjs`: **خلط Fisher–Yates على ترتيب عائلات الأعطاب** داخل `propose()` | البحث كان **حتمياً** (ينشئ `rng` ولا يستدعيه) ⇒ «5 بذور» = 5 تكرارات لتجربة واحدة ⇒ كل تباين/فاصل ثقة مشتقّ من البذور كان بلا معنى | `tests/audit.test.mjs` + إعادة التشغيل: البذور صارت تُنتج نتائج مختلفة (في `docs/07-FINAL-AUDIT-AND-REPRODUCTION.md` §2.1) |
| 6 | `synora-v5/stats.mjs` (جديد): bootstrap **مزدوج** + McNemar exact + Wilcoxon + Holm | التحليل القديم كان يعيدSampling الذراعين مستقلّتين (غير مزدوج) رغم أن التصميم مزدوج | `tests/audit.test.mjs` (حالة معروفة: فرق ثابت ⇒ فترة انحدار) |
| 7 | `synora-v5/phase3/analysis.mjs`: `pairedUnits()` + `compareArms()` +_failures صريحة + منظور `_censored` | فصل النجاح (وصفي) عن الاستدلال، وعدم حذف الإخفاقات من تحليل الكفاءة | `docs/07-...` §3 |
| 8 | `synora-v5/phase3/experiments.mjs`: عائلتا Holm منفصلتان (ثنائي/متصل) + حساب الوحدات المزدوجة | تصحيح المقارنات المتعددة | `docs/07-...` §3 |
| 9 | `synora-v5/pst/experiments.mjs`: إضافة `paired` إلى المخرجات | نفس المنطق للمرحلة 2 | `docs/REPORT-PST.md` §6 |
| 10 | `synora-v5/phase3/report-tables.mjs` (جديد): توليد كل الجداول من الخام | منع انفصال التقارير عن البيانات | `tests/audit.test.mjs` (اتساق الخام↔التقرير) |
| 11 | `docs/REPORT-PST.md`: **تصحيح الاستنتاجات** (نسبة النجاح من 83.3% إلى 65.0%، والوسيط من 12.0 إلى 15) | كانت ناتجة عن بذور متطابقة | `docs/07-...` §2.1 |
| 12 | `docs/06-REPORT-LONG-TERM-MEMORY.md`: **تصحيح كل الأرقام** بعد الإصلاح + إحصاء مزدوج | نفس السبب | `docs/07-...` §2.1 |
| 13 | `tests/audit.test.mjs` (جديد): 16 فحصاً للسلامة والاتساق | شرط القبول | — |
| 14 | `scripts/build-manifest.mjs` (جديد) + `audit/package-manifest.json` | التحقق بايت-ببايت من الحزمة | — |
| 15 | `scripts/reproduce-phase3.sh`: إضافة suite التدقيق + ذكر تقرير 07 | إعادة إنتاج شاملة | — |
| 16 | `tests/audit.test.mjs`: الفحص 21 يصبح 23 (المهمة المجهولة + مسارات Phase3) | تغطية الفجوات التي كشفها التدقيق | — |
| 17 | `docs/07-FINAL-AUDIT-AND-REPRODUCTION.md` (جديد) | التقرير النهائي للتدقيق | — |
| 18 | `README.md`: العنوان المُصحَّح/report 07/suite التدقيق | شفافية | — |
| 19 | `TEST_REPORT.txt`: إضافة نتائج التدقيق النهائي | سجل حيّ | — |

> ملاحظة: `TEST_REPORT.txt` و`audit/immutable-baseline.json` و`audit/package-manifest.json` ملفات حيّة
> (سجلّات تتغيّر مع كل إصدار) ⇒ هي **خارج** قائمة الملفات المحمية بالبصمات، لكن **داخل** البيان.
> البصمة في `audit/package-manifest.json` تُبنى **بعد** كل تعديل ⇒ فحص الحزمة يتحقّق منها ✓.

## ما لم يتغيّر

- نواة v4 (`synora-evo-farm-v4.mjs`, `convert-skill.js`, `tests/self-test.mjs`, `tribes/`) ✓
- نواة v5 (`synora-v5/{tasks,judge,worker,genome,engine,cli,experiments,baseline-v4,llm-compare,distractors,report,resources}.mjs`) ✓
- `synora-v5/pst/{environment,operators,tasks,secrets,grader,sandbox-worker,old-library-check}.mjs` ✓

---

## Phase 4 — the cross-domain transfer experiment (added 2026-10-25)

| # | Change | Why | Evidence |
|---:|---|---|---|
| 20 | **NEW** `synora-v5/phase4/` — a second experimental domain (tariff settlement: 14 tools, 20 shipments, a 3-band tariff table, class multipliers) | Phase 3 could not answer "does the memory transfer to a *different* domain?" — its domain was the same file-repair family | `docs/08-REPORT-PHASE4-CROSS-DOMAIN.md` §1 |
| 21 | **NEW** `synora-v5/phase4/{engine,operators,grader,sandbox-worker}.mjs` — a **port** of the Phase-3 files (4/2/2/0 code lines changed, every change documented) | The engine imports its tool contracts from the environment, so a new domain needs a port; **no capability was added** | the diff in report 08 §2.2 + `tests/phase4.test.mjs` |
| 22 | **NEW** `synora-v5/phase4/{tasks,secrets,analysis,acquire,evaluate,experiments,report-tables}.mjs` — 26 tasks in three groups (A=8, B=8, C=10 held out), a grader-only answer key, the four protocol arms (`cri`/`base`/`noise`/`notransfer`) plus the `inprocess` control | The protocol asks for exactly these four arms and this data separation | `experiments/results-phase4.json` |
| 23 | **NEW** `tests/phase4.test.mjs` — 29 checks (no answer leaks, the grader's validity, the budget's enforcement, the memory round-trip and tamper rejection, the group separation, the seeds really changing the behaviour, the session boundary, the untouched core) | The protocol asks for anti-cheating tests | `node tests/phase4.test.mjs` → 29/29 |
| 24 | **NEW** `scripts/core-hashes.mjs`, `audit/phase4-core-hashes-{before,after}.json` | The proof that the core engine was not modified | combined SHA-256 identical: `98bad072e5ff…` |
| 25 | **NEW** `scripts/reproduce-phase4.sh`, `scripts/phase4-order-sensitivity.sh` | One script to reproduce everything; the acquisition-order control | `docs/09-PHASE4-PROTOCOL-DEVIATIONS.md` §5 |
| 26 | **NEW** `docs/08-REPORT-PHASE4-CROSS-DOMAIN.md`, `docs/09-PHASE4-PROTOCOL-DEVIATIONS.md` | The deliverable report and the deviation log | — |
| 27 | The Phase-4 **parameter pool** is a fixed pseudo-random permutation (`POOL_SEED = 20241025`), overridable with `SYNORA_PHASE4_POOL_SEED` | The order of the pool decides the cost of a blind search; it must not be hand-written to favour an arm | the pool-order sensitivity run (`SYNORA_PHASE4_POOL_SEED=777`) keeps the direction |
| 28 | The Phase-4 **acquisition group is homogeneous** (every task teaches the dominant rule) and can be run in reverse (`--reverse=1`) | The ledger returns the FIRST skill whose hint matches, so the inherited rule depends on the acquisition order | `scripts/phase4-order-sensitivity.sh` → identical results forward and reverse |

**Nothing in `synora-v5/{engine,genome,judge,worker,ledger,stats}.mjs`, in `synora-v5/phase3/`,
in `synora-v5/pst/`, or in the four existing test suites was modified** — verified by the SHA-256
list of 27 files taken before and after the experiment.


## 2026-10-25 — Independent audit corrections

- Fixed Phase-4 task `B3_class_of` to use shipment `S-10` instead of reusing `S-19` from held-out task `C3_settle_b2_rate`. Updated the independent answer key accordingly.
- Added an automated assertion that actual shipment IDs in the answer plans are disjoint across acquisition, generalisation, and held-out groups.
- Made `scripts/reproduce-phase4.sh` restore the packaged Phase-4 result files on exit, failure, or interruption, preventing a reproduction attempt from silently invalidating the shipped package manifest.
- Marked the Phase-4 report's previous statistics as historical/pre-correction. The full corrected study must finish before new statistical claims are made.

## 2026-10-26 — Adaptive Memory context validation and packaging

| Change | Reason | Evidence |
|---|---|---|
| `synora-v5/phase4/adaptive-engine.mjs`: optional context-aware hint decision, malformed-record guard, event-ID deduplication | Previously context outcomes were stored but ignored by `hintFor`; repeated misses in one context could suppress a hint in another | `tests/adaptive-engine.test.mjs` 16/16; `reports/ADAPTIVE_MEMORY_CONTEXT_REPORT.md` |
| `synora-v5/phase4/engine.mjs`: pass active violation to hint lookup in proposal/composition | The policy must know which context is being addressed | `tests/phase4.test.mjs` 32/32 |
| `synora-v5/phase4/adaptive-legacy-engine.mjs` and evaluation mode | Preserve a controlled reconstruction of the old aggregate-miss rule for matched comparison | `experiments/adaptive-final/low-budget-raw.json` |
| `scripts/run-adaptive-final-study.mjs`, `experiments/adaptive-final/`, `reports/ADAPTIVE_MEMORY_*` | Reproducible low-budget and new-seed comparison with raw outputs | reports list exact protocols and limitations |
| `package.json` | Provide one documented full-suite command and experiment shortcuts | `npm test` |

Decision: V2 fixes context-local decision behavior but did not outperform CRI on the tested end-to-end success metric. It remains experimental; no superiority claim is made.


## 2026-10-26 — Digital Object Core final closure

| Change | Root cause | Repair / evidence |
|---|---|---|
| `synora-v5/digital-object-core/index.mjs` — event preflight, conflict detection, idempotent operations, source-scoped facts, explicit retraction, stricter persistence validation, schema v2 | Earlier event handling checked duplicates after mutation and silently treated reused IDs as duplicates even when content differed; premise retraction and persisted shape validation were incomplete | `tests/digital-object-core.test.mjs` covers replay across operation types, conflicting replay, no partial success events, premise retraction, cross-process persistence and malformed files |
| `synora-v5/digital-object-core/synora-adapter.mjs` (new) | The prior core had no tested bridge to a real Synora engine result boundary | Opt-in wrapper around `runTask(task)` tested with real `PstEngine` and `AdaptivePstEngine`; search logic and CRI memory are not changed |
| `tests/digital-object-core.test.mjs` — expanded from 6 to 11 tests | Previous tests missed changed-payload event collisions, failed-operation atomicity, chained derivations/retraction, save failure, and actual engine integration | `npm run test:digital-objects`; full suite rerun from extracted final archive |
| `synora-v5/digital-object-core/{README.md,ENGINEERING-REPORT.md}`, `README.md` | Documentation described retraction and integration as future/unsupported despite the final closure implementation | Updated semantics, opt-in integration boundary, reproduction and research limits |
| `DIGITAL_OBJECT_CORE_FINAL_AUDIT.md` and `audit/package-manifest.json` | Final package needs a reproducible closeout record and package-level integrity manifest | Archive hash recorded in report after final archive creation; manifest generated after all other files were finalized |


## 2026-10-26 — V7 engineering stage 1: Digital Object Core hardening

| File | Change / root cause | Regression evidence |
|---|---|---|
| `synora-v5/digital-object-core/index.mjs` | Schema v3 adds fact kind (`direct`/`retrieved`/`hypothesis`), deterministic v2 migration including event request normalization, conjunctive same-subject premises, configurable functional predicates, and event-history consistency checks. Semantic duplicate fact operations now commit their event IDs as no-op events, preventing later reuse of those IDs with changed payloads. | `tests/digital-object-core.test.mjs`: v2 migration replay, hypothesis exclusion, multi-premise proof lineage, duplicate event and conflict cases. |
| `synora-v5/digital-object-core/index.mjs` persistence | Existing verified snapshots are backed up to `.bak` before atomic replacement; corrupt/incompatible targets are refused instead of overwritten, and an exclusive lock rejects concurrent writers. | Backup recovery and corrupted-target regression test; cross-process save/load test. |
| `synora-v5/digital-object-core/synora-adapter.mjs` | A recording exception after engine completion no longer discards the engine result; an explicit `digitalObjectRecording.ok=false` result is returned and can be retried. | Real `PstEngine` run with injected one-shot recording failure and successful retry. |
| `tests/digital-object-core.test.mjs` | Expanded acceptance suite from 11 to 18 tests, including schema migration, backup protection, retrieved/hypothesis evidence, multi-premise rules, and adapter failure/retry. | `npm run test:digital-objects`. |
| `synora-v5/digital-object-core/{README.md,ENGINEERING-REPORT.md}`, root `README.md` | Documentation corrected to match schema v3, premise semantics, evidence kinds, backups, and adapter failure behavior. | Full suite plus package manifest audit. |

## 2026-10-26 — V7 experiment stage 2: Digital Object Core value measurement

| File / area | Change / issue | Evidence |
|---|---|---|
| `scripts/stage2/` and `experiments/stage2/` | Added a reproducible, seeded symbolic core benchmark and matched CRI / Adaptive V2 integration arms, including cold, persisted native-memory, core-only, native-plus-core, and matched no-rule cross-process controls | 60 core/control rows, 108 engine rows, `paired-ablation.csv` with 36 matched rows |
| `scripts/stage2/engine-worker.mjs`, `scripts/stage2/native-memory.mjs` | Corrected generation-budget propagation and fresh-process restoration of both native hint maps and the ledger; added explicit core fallback counters and verified-hint export | `tests/stage2-experiment.test.mjs`; final run metadata records 20 generations |
| `scripts/stage2/run-stage2-experiments.mjs` | Added matched counterfactual rows, a no-rule cross-process control, separate paired CSV/JSON, and explicit exclusions for invalid exploratory runs | 36 paired rows; 60 core/control rows; zero runner exceptions; unsuccessful Adaptive V2 task outcomes remain in raw rows |
| `experiments/stage2/archive/pre-fix-run/` | Retained the initial exploratory run with an explicit invalid-for-primary-inference notice instead of deleting it | Earlier run used 60 generations contrary to config and lacked the post-restart native-memory arm |
| `tests/stage2-experiment.test.mjs`, `package.json` | Added automated checks for split separation, answer-key separation, persisted native memory, declared budgets, fresh-process arms, matched cold transfer control, and core hit-vs-outcome distinction | Stage 2 tests: 8/8; full `npm test` rerun before release |
| `SYNORA_WAR_V7_STAGE2_EXPERIMENT_REPORT.md` and this report copy | Documented positive and negative findings and the interface-based exclusion of CRI/Adaptive V2 from symbolic QA tasks | Result: keep core experimental; narrow CRI evaluation-count reduction only; no Adaptive V2 hits and no success-rate change |


## Stage 3 final audit harness correction (2026-10-26)

- `tests/self-test.mjs` copies only runtime fixtures (`synora-evo-farm-v4.mjs`, `convert-skill.js`, `synora-sleep.jsonl`, and `tribes/`) into disposable integration scenarios. This avoids recursively copying historical experiment artifacts into each test scenario; runtime assertions are unchanged.
- Updated `tests/phase4.test.mjs` and `tests/audit.test.mjs` so historical immutability snapshots continue to protect engine and prior-phase source files while explicitly excluding the documented test-harness-only refactor. The original snapshots are preserved for provenance.

## 2026-10-26 — Stage 4: bounded dialogue, code templates, skill learning and API

- Added `synora-v5/dialogue/` for bounded Arabic/English intent parsing, explicit follow-up resolution, structured request evidence, and abstention on unsupported tasks.
- Added `synora-v5/solution-engine/` with three reviewed JavaScript templates (sum, max, factorial), positive/negative tests, numeric-boundary checks, and no arbitrary user-source execution.
- Added `synora-v5/tools/registry.mjs` with capability descriptions and a validated calculator tool.
- Added `synora-v5/api/server.mjs` and a client example: local-only default bind, request size/history limits, optional bearer token, basic rate limiting, persistent skill learning/application routes.
- Added `synora-v5/digital-object-learning/` as a bounded rule-induction layer using the existing digital object core as a conceptual neighbor, not a replacement. Corrected a duplicate assignment in accepted-mutation history.
- Added a held-out Stage 4 experiment with separate solver task data and evaluator answer key, raw JSON/CSV, retained pilot results, and tests for a fresh Node.js process, corruption rejection, mutation rollback, HTTP integration, and benchmark separation.
- No CRI or Adaptive V2 engine source was changed. The new API/learning/dialogue components are additive and opt-in.
- Limits: the parser is lexical, code generation is template selection rather than open-ended synthesis, the learner is limited to affine modular arithmetic, and the API is not production-hardened.

## 2026-10-27 — V8.1 pre-server skill routing and application ledger

| File | Change / root cause | Evidence |
|---|---|---|
| `synora-v5/digital-object-learning/skill-router.mjs` (new) | Adds exact name/ID routing for explicit Arabic/English apply requests; validates input shape/domain and requires accepted, active skill state plus matching active DigitalObjectCore registration. Ambiguous and unsupported requests abstain. | `tests/stage4/skill-routing.test.mjs` covers novel values, ambiguity, inactive/unregistered skills, domain rejection and no arbitrary source execution. |
| `synora-v5/digital-object-learning/application-ledger.mjs` (new) | Adds a separate checksummed, atomic, idempotent application ledger with event identity, version, safe input summary, result, failure reason and `objectiveCorrectness: not-assessed`. | Corruption detection, long-input round-trip, conflicting event ID, deduplication, and independent Node process reload tests. |
| `synora-v5/dialogue/agent.mjs` | Integrates named-skill routing and records success/abstention. A failed ledger write cannot be reported as successful persistence. | Real HTTP tests and actual Node process restart test. |
| `synora-v5/api/server.mjs` | Wires ledger persistence, `Idempotency-Key`, stricter registration checks and the previously unreachable advertised `GET /v1/skills` route. | `npm run test:stage4`; process terminated/restarted with skill and ledger restored. |
| `tests/stage4/skill-routing.test.mjs`, `tests/stage4/stage4.test.mjs`, `package.json`, `audit/package-manifest.json` | Adds focused acceptance tests, runs all Stage 4 test files from the standard commands, isolates API test persistence in temporary directories, and regenerates package hashes. | Stage 4 suite 25/25; full `npm test` exit code 0; extracted-archive test confirms no generated runtime state mutates the manifest. |

No changes were made to the original `DigitalObjectCore`, CRI, or Adaptive V2 engine source. The original V8 ZIP was retained unchanged.


### V8.1 code-generation scope expansion (2026-10-27)

- Expanded the fixed reviewed JavaScript template library from three to five: added reverse-array and ascending numeric-sort templates, each with normal, empty, and invalid-element cases.
- Fixed the trusted template verifier to compare array outputs element-by-element rather than using `Object.is` on array references; tests caught the defect immediately, and no expected results were changed.
- Added explicit Arabic/English intent rules and regression checks. This increases supported operations but does not claim general natural-language understanding or open-ended program synthesis.
