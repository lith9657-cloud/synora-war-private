# V8.1 pre-server fixes — change log

| File | Change | Reason / verification |
|---|---|---|
| `synora-v5/digital-object-learning/skill-router.mjs` | New explicit name/ID router, input parser, domain validation and active DigitalObjectCore registration check | Automated exact-match, ambiguity, inactive, unregistered, unsupported-input and novel-value tests |
| `synora-v5/digital-object-learning/application-ledger.mjs` | New checksummed, atomic, idempotent application ledger | Same-event deduplication/conflict checks, tamper rejection, and reload from separate Node process |
| `synora-v5/dialogue/agent.mjs` | Named-skill application path and trace; fail closed on missing core registration or ledger persistence errors | HTTP integration and end-to-end dialogue tests |
| `synora-v5/api/server.mjs` | Persistent ledger wiring, idempotency key support, stricter skill registration checks, working `GET /v1/skills` | Real HTTP requests and process-restart test |
| `synora-v5/dialogue/index.mjs`, `synora-v5/solution-engine/index.mjs` | Expanded reviewed code templates from three to five with reverse-array and ascending numeric sort; added English/Arabic explicit request rules | Parser and generated-template tests include normal, empty, and invalid input cases; no arbitrary user code is run |
| `tests/stage4/skill-routing.test.mjs` | Nine focused regression/integration tests including real-process restart | Stage 4 suite increased from 15 to 25 passing tests |
| `package.json` | Include all Stage 4 test files in `npm test` and `npm run test:stage4` | Full test suite passes |
| `audit/package-manifest.json` | Regenerated after all package changes | Full audit suite confirms every listed file hash |
| `SYNORA_WAR_V8_STAGE4_RUNBOOK.md`, `README.md`, `docs/CHANGE-LOG.md` | Updated routes, ledger path, idempotency behavior, limitations and history | Documentation now matches implementation |

## Render deployment preparation (separate deployment copy)
- Added `npm start` for the Stage 4 HTTP service.
- API port now falls back to Render's `PORT` environment variable when `SYNORA_API_PORT` is not set.
- Added a starter `render.yaml` with health check, Singapore region, and token secret placeholder. Its `/tmp` storage paths are ephemeral on Render free instances.
- IMPORTANT: this free-plan template is for a smoke test only; learned skills and application history can be lost on restart/redeploy. Before real use, configure paid persistent storage or an external durable datastore.
- Set a strong random `SYNORA_API_TOKEN` (at least 24 characters) in Render environment variables before deploy. Never commit the token.
