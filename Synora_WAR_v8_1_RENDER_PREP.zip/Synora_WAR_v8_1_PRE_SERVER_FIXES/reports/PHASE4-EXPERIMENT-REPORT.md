# Synora WAR V8 Stage 4 — experiment report

## Scope and protocol

The final symbolic benchmark is version 2, generated after the initial pilot surfaced an abstention-reporting defect. The pilot `tasks-pilot-v1.json`, `answer-key-pilot-v1.json`, `results-pilot-v1.json`, and `results-pilot-v1.csv` are retained as exploratory artifacts and are not the final-test evidence. The final set uses five new task IDs and moduli 23, 29, 31, 37, and 41; the training inputs are scalar values `[1,3,5,8]`, development inputs are `[0,2]`, and the held-out evaluation applies the acquired rule to arrays containing unseen values. The solver view contains no final outputs or affine parameters. The separate answer key is used by the evaluator only; solver modules do not import it.

The three labels 17, 43, and 101 control deterministic rotations of training-example order, development-example order, and final-case order. They are **order-sensitivity repetitions**, not independent randomly sampled datasets and not independent statistical replicates. There are five underlying symbolic task designs and three final array cases per task. Thus 45 rows per arm represent 15 task/case combinations repeated under three input orders, not 45 independent problem families.

## Arms

- A — cold baseline with no acquired rule; abstains rather than guessing.
- B — exact example retrieval; it can answer only if every array element has an exact training example.
- C — bounded affine-mod skill induction with development validation.
- D — the same induction plus a deliberately worse mutation proposal, evaluated under a regression gate.
- E — a separate smoke benchmark for dialogue/tool/template behavior; it is not pooled with symbolic rows.

## Results

| Arm | Rows | Correct task outcomes | Wrong answers | Abstentions | Interpretation |
|---|---:|---:|---:|---:|---|
| A cold baseline | 45 | 0/45 | 0 | 45 | No skill means no supported answer; conservative abstention |
| B exact retrieval | 45 | 0/45 | 0 | 45 | Memorized scalar examples do not cover unseen array values |
| C induced skill | 45 | 45/45 | 0 | 0 | Learned rule generalized to held-out values in this bounded DSL |
| D gated evolution | 45 | 45/45 | 0 | 0 | Same task performance as C; 15/15 deliberately worse mutations rejected and original skill preserved |
| E dialogue/tool/template smoke cases | 4 | 4/4 | 0 | 1 correct abstention | Three calculation/code examples succeeded; unsupported broad code request abstained correctly |

The E arm contains four deliberately small cases: one Arabic calculation, one sum-array code request, one factorial code request, and one unsupported broad code request. Each generated template also runs its own positive and negative cases. The internal tests are not a general code-generation benchmark.

## What this establishes

The result demonstrates that the bounded affine learner can infer a compact rule from a small set of scalar examples and apply it to unseen values grouped as arrays, while exact-example retrieval cannot solve those held-out inputs. The mutation gate rejects a deliberately worse candidate without losing the previously accepted skill. The API has a passing real HTTP round-trip for chat, skill induction, persistence, and skill application. Persistent storage was loaded in a separate Node.js process during the unit test.

## What this does not establish

- It does not establish general natural-language understanding, open-domain reasoning, or arbitrary code synthesis.
- It does not establish general autonomous self-improvement: the one tested mutation was intentionally harmful and correctly rejected; no beneficial mutation was discovered in this study.
- It does not establish broad statistical generalization: there are five hand-designed task families, and the three seed labels only permute order.
- It does not compare against Llama 2 or any other LLM.
- It does not establish energy or memory efficiency against a fair external baseline.
- The answer key is packaged for reproducibility but is evaluator-only by convention; this is not a cryptographic benchmark secrecy system.

## Reproduction

From the project root with Node.js 20 or newer:

```sh
npm run test:stage4
npm run study:stage4
```

The runner rewrites `experiments/stage4/results.json` and `results.csv` with fresh results. The JSON includes task/key hashes and source hashes. The generation timestamp is expected to differ between runs; measured row outcomes should remain the same.
