# Adaptive Memory — New-seed generalization check

## Protocol

Fresh seeds 11, 13 and 17 were not used in the low-budget seed-1-to-5 comparison. For each seed, a new acquisition memory was produced on group A (budget 250, 200 generations), then Base, CRI, reconstructed Adaptive legacy and Adaptive V2 were evaluated on the same B/C tasks at budgets 20 and 40, 200 generations. Each cell contains 18 tasks. Raw task-level data and the memory files are included under `experiments/adaptive-final/generalization/`.

## Results

| Budget | Policy | Successes / tasks | Rate | Per-seed successes |
|---:|---|---:|---:|---|
| 20 | Base | 11/54 | 20.4% | 5, 3, 3 |
| 20 | CRI | 19/54 | 35.2% | 8, 5, 6 |
| 20 | Adaptive legacy | 11/54 | 20.4% | 5, 3, 3 |
| 20 | Adaptive V2 | 19/54 | 35.2% | 8, 5, 6 |
| 40 | Base | 25/54 | 46.3% | 8, 9, 8 |
| 40 | CRI | 32/54 | 59.3% | 11, 10, 11 |
| 40 | Adaptive legacy | 25/54 | 46.3% | 8, 9, 8 |
| 40 | Adaptive V2 | 32/54 | 59.3% | 11, 10, 11 |

## Interpretation and limits

- New seeds reproduce the same qualitative pattern: CRI/V2 outperform Base descriptively in these cells, while V2 exactly matches CRI and does not beat the aggregate-miss legacy arm on task success.
- This is **seed generalization only**, not an independent new-task generalization test: the task identities in groups B/C are unchanged. The acquisition memories are newly generated for each seed, but the evaluation task suite remains the same.
- Only three new seeds and 18 tasks per seed were used. Do not describe this as proof of broad generalization or universal superiority.
- The context-specific unit tests provide behavioral evidence for the decision-rule fix; the aggregate success metric does not yet show a downstream benefit.

Raw results: `generalization-raw.json`, `generalization-summary.json`, `generalization-summary.csv`; each run also has an individual JSON file.
