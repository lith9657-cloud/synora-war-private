# Adaptive Memory V2 — Context and leakage validation

## Change made

`AdaptivePstEngine.hintFor(key, context)` now evaluates negative evidence only for the active violation context when the caller supplies one. Phase-4 `propose()` and `compose()` pass `family.violation` into hint lookup. The abstention threshold remains conservative: at least two misses in that context and misses greater than hits. A context with no evidence does not inherit another context's misses. Calls that omit context retain aggregate behavior for compatibility.

Outcome records reject malformed inputs. Optional event IDs are deduplicated, and attribution derives deterministic event IDs from task, generation, child signature/code, hint key/value and changed violation. Evidence remains separated by exact hint key/value and violation context.

## Deterministic cases

`tests/adaptive-engine.test.mjs` now covers: helpful context remains usable; harmful context abstains after repeated misses; cross-context contamination is prevented; unknown contexts do not inherit misses; contradictory evidence within one context abstains only when misses dominate; duplicate event IDs are counted once; malformed/empty records are ignored; unverified hints and mode isolation remain enforced. Result: **16/16 passed**.

## Leakage and determinism

- The policy only receives outcomes recorded from already-evaluated parent/child transitions; no grader answer key is imported by the adaptive engine.
- Attribution compares violations before and after the child transition. Future outcomes are not available at the point of proposal; context evidence updates in `attribute()` after evaluation.
- Re-running the same fixed-seed scenario is deterministic under the existing engine RNG and deterministic event keys.
- The persistent memory format stores CRI ledger data, not `hintEvidence`; therefore the new per-context outcome evidence is currently session-local. This is an important limitation: V2 does not persist learned context-local hit/miss statistics across acquisition/evaluation processes.

## Verdict

The context-isolation defect in the in-process decision rule is fixed and covered by regression tests. The end-to-end benchmark does not show an overall success-rate improvement over CRI: V2 matches CRI at budgets 10, 20 and 40 on the tested seed cells. Keep V2 experimental; do not claim superiority.
