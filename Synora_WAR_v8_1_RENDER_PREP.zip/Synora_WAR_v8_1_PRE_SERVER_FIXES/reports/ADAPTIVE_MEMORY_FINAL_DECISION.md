# Synora WAR — Final Adaptive Memory Validation

**Decision: retain Adaptive V2 as experimental; do not promote it as superior to CRI or the previous adaptive rule.**

## What changed

1. The V2 decision path now accepts the active violation context from Phase-4 proposal and composition logic.
2. Repeated negative evidence is scoped to the exact hint key/value and active context; unrelated contexts no longer suppress a useful hint.
3. Malformed outcome records are ignored, and optional event IDs prevent duplicate attribution from incrementing counters twice.
4. Added deterministic regression cases, a reproducible low-budget experiment runner, new-seed evaluation outputs, summaries, and this report set.
5. Added `package.json` commands and refreshed the package SHA-256 manifest.

## Evidence

- Low-budget comparison: 5 seeds × 18 tasks × 3 budgets × 4 arms = 1,080 task evaluations. At budgets 10/20/40, Adaptive V2 achieved 25/90, 30/90 and 50/90 successes. CRI achieved exactly the same counts and per-seed outcomes. The reconstructed legacy adaptive arm achieved 0/90, 16/90 and 41/90.
- New-seed check: seeds 11/13/17, 18 B/C tasks each, budgets 20/40. Adaptive V2 and CRI tie at 19/54 and 32/54; the reconstructed legacy arm ties Base at 11/54 and 25/54.
- Context tests: 16/16 pass, including cross-context isolation, same-context conflicting evidence, empty/malformed input and duplicate event IDs.
- Existing project suites were rerun after the implementation change; the final recorded run is in `reports/TEST_EXECUTION_REPORT.md`.

## Critical limitations

- The new-seed test reuses the existing B/C task identities; it tests seed variation, not transfer to a genuinely new task distribution.
- The context hit/miss evidence is session-local and is not currently serialized in the CRI memory file. The experiment therefore does not show a persistent, cross-session gain from V2's context evidence.
- The aggregate success-rate benchmark shows no downstream improvement for V2 over CRI. Context correctness is demonstrated at the unit/decision-rule level only.
- The `adaptive-legacy` arm reconstructs the old aggregate abstention rule from the pre-change implementation, rather than invoking a separately preserved historical binary.

## Final policy recommendation

Keep CRI as the demonstrated baseline. Keep Adaptive V2 available for further experimentation because its context-isolation behavior is better specified and tested, but do not call it more effective until (a) context evidence persistence is intentionally designed and validated, and (b) an untouched task suite demonstrates a repeatable improvement without unacceptable regressions.
