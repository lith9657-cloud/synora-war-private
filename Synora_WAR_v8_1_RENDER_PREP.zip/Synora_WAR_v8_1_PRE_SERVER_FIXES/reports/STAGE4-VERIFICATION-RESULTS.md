# Stage 4 verification summary

This file records the successful pre-release source-tree run. The release is also extracted and tested independently; its final raw logs are supplied beside the ZIP so they can refer to the exact final archive without creating a self-referential ZIP digest.

## Baseline

- Reference V7 archive SHA-256: `8d6e326c94346813ddb280af2b52255b68dc7931ef63371ed397cfed5e2a1476` (matched before modification).
- Clean baseline extraction: `npm test` exited 0; 172 checks/subtests passed, 0 failed.

## Stage 4 source tree

- Node.js: v22.16.0.
- `npm test`: exit 0; 187 checks/subtests passed, 0 failed. This is the sum of inherited test groups and the new Stage 4 group; some groups cover overlapping layers and should not be interpreted as 187 independent scientific observations.
- `npm run test:stage4`: exit 0; 15/15 passed.
- `npm run test:digital-objects`: exit 0; 18/18 passed.
- `npm run study:stage4`: 184 raw rows written to JSON and CSV: A 45 rows/0 successful outcomes/45 abstentions; B 45/0/45; C 45/45/0; D 45/45/0; E 4/4 expected outcomes, including one correct abstention.
- Candidate mutation guard: 15 distinct harmful mutation proposals, 0 accepted, 15/15 rollback checks verified. Row-level CSV repeats each task-level decision for each of its three final cases; do not count 45 mutation rows as 45 separate proposals.
- API process smoke: `GET /health` succeeded; `POST /v1/chat` returned `7 + 5 = 12`; a skill-learning HTTP request persisted both the learner ledger and DigitalObjectCore registration; the skill was then applied through `/v1/chat` to `[3,5,6]` and returned `[4,3,6]`.
- Cross-process memory: the unit test spawns a separate Node.js process to load and apply the persisted skill; tampered and missing memory files are rejected.

## Limits

The benchmark is a small, hand-designed affine-mod DSL benchmark. The three seed labels permute example and case order; they are not independent datasets. Code generation is limited to three reviewed templates. The API is a local prototype and not production-hardened.
