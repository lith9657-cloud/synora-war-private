# V8.1 verification artifacts

- `original-v8-sha256.txt`: measured SHA-256 of the preserved input archive.
- `baseline-npm-test.log`, `baseline-stage4-test.log`: tests run against the untouched extracted V8 source before changes.
- `npm-test-pass.log`, `stage4-test-pass.log`: passing test logs for the completed V8.1 source before the final manifest regeneration. The final post-manifest test run is also delivered as an external sidecar log.
- `initial-stage4-fixture-failure.log`, `initial-get-skills-method-failure.log`, `initial-stale-manifest-failure.log`: retained initial failures and diagnostics; none were hidden or fixed by deleting assertions.

The final archive SHA-256 is supplied alongside the ZIP, not embedded in the ZIP, to avoid a self-referential hash.
