# Synora WAR V8 — Stage 4 implementation map

## Source continuity

Stage 4 was developed as an additive change on top of `Synora_WAR_v7_DIGITAL_OBJECTS_EVALUATED_FINAL.zip`. The archive SHA-256 checked before modification was `8d6e326c94346813ddb280af2b52255b68dc7931ef63371ed397cfed5e2a1476`. The original ZIP is kept outside the working tree; the V7 core remains unchanged except for the explicitly documented correction of a duplicated history assignment in the newly added learning module. No CRI or Adaptive V2 engine implementation was modified.

## Component map

- `synora-v5/dialogue/index.mjs`: bounded Arabic/English lexical intent parser, request schema, basic slots, explicit code follow-up resolution. It is not a general parser or semantic model.
- `synora-v5/dialogue/agent.mjs`: request → intent → tool/template choice → result validation → answer/abstention, with trace records.
- `synora-v5/solution-engine/index.mjs`: three internally defined JavaScript templates (sum array, maximum array, factorial), boundary/negative tests, and explicit status. No arbitrary user source is executed.
- `synora-v5/tools/registry.mjs`: capability descriptions, input/result validation and timeout wrapper; the shipped tool is a bounded arithmetic calculator.
- `synora-v5/digital-object-learning/index.mjs`: bounded symbolic induction for affine modular rules, development validation, skill provenance, event history, composition, candidate mutation gate, checksum-protected atomic persistence and rollback metadata.
- `synora-v5/api/server.mjs`: dependency-free HTTP API, JSON body cap, history cap, local-only default binding, optional bearer token, simple per-IP request rate limit, persistent skill routes.
- `experiments/stage4/`: held-out benchmark definition, evaluator-only answer key, reproducible runner, raw JSON/CSV, and the earlier pilot kept separately.
- `tests/stage4/stage4.test.mjs`: dialogue, code generation, tool choice, induction, cross-process persistence, corruption rejection, mutation rollback, benchmark separation, and real HTTP API tests.

## Supported path

Natural-language request → bounded intent and slot representation → calculator or one of three fixed program templates → built-in tests → validated answer or explicit abstention. The separate skill API accepts a constrained affine-mod training set, checks a unique hypothesis against supplied development examples, saves the skill with SHA-256 integrity, and can apply it after process restart. The `/v1/chat` path can also invoke a caller-selected skill when the request includes `skillId` and `skillInput`; the system does not yet infer which stored skill to choose from free-form language.

## Boundaries

This implementation is a useful narrow prototype, not a general conversational language model. The parser is lexical/rule based; the code generator selects fixed templates rather than synthesizing arbitrary programs. The affine learner generalizes only within its small DSL and bounded numeric domain. The mutation system is a gated candidate parameter mutation, not open-ended autonomous code modification. The API is not production-hardened: it lacks user identity/authorization management, distributed rate limiting, TLS termination, a hostile-code OS sandbox, and multi-writer transactional storage. Do not expose it to the public internet without an authenticated, TLS-protected deployment boundary.
