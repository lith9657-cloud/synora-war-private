# Synora WAR — V7 baseline with V8 Stage 4 additive prototype

> **Stage 4 status:** The V7 reference engines (CRI and Adaptive V2) are retained. Stage 4 adds a bounded non-neural dialogue/request parser, five tested JavaScript templates, a validated calculator tool, constrained digital-object skill induction, persistent skill storage, a gated mutation mechanism, and a local HTTP API. This is an implemented narrow prototype, not a general language model or production-safe arbitrary-code agent.

## Stage 4 quick start

Requires Node.js 20+ and no third-party packages.

```sh
npm test
npm run test:stage4
npm run study:stage4
npm run api:stage4
```

The API defaults to `http://127.0.0.1:8787`. V8.1 adds exact-name/ID routing for explicitly requested accepted digital skills, a checksummed idempotent application ledger, and a tested cross-process API restart path. Example: `POST /v1/chat` with `{"text":"Apply affine7 to [3,5,6]"}` applies the skill only when the name/ID is unique, the skill is active and registered in `DigitalObjectCore`, and the values are in domain. Execution success is not treated as proof of objective correctness. See [`docs/V8_1_PRE_SERVER_FIXES_REPORT.md`](docs/V8_1_PRE_SERVER_FIXES_REPORT.md) and [`SYNORA_WAR_V8_STAGE4_RUNBOOK.md`](SYNORA_WAR_V8_STAGE4_RUNBOOK.md), [`docs/PHASE4-ARCHITECTURE.md`](docs/PHASE4-ARCHITECTURE.md), and [`docs/PHASE4-EXPERIMENT-REPORT.md`](docs/PHASE4-EXPERIMENT-REPORT.md). Code generation is restricted to five reviewed templates: sum-array, max-array, factorial, reverse-array, and ascending numeric sort. Unsupported tasks should be reported as unsupported; arbitrary user code is not executed.

---

# Synora Evo Farm — WAR v4 (stability revision)

Node.js-only evolutionary software system. No AI libraries, model weights, LLMs, external services, or third-party packages are required. Target runtime: Node.js 20+.

## Included

- `synora-evo-farm-v4.mjs` — evolutionary engine, worker timeout, validation gate, stable teacher and Ark persistence.
- `.github/workflows/farm.yml` — one scheduled workflow running all five tribes sequentially every 15 minutes.
- `convert-skill.js` — `fs`-only converter for explicitly tagged rules in `SKILL.md`.
- `tribes/{marketing,coding,arabic,english,discussion}/` — teacher, Ark, and executable/structural tests for each tribe.
- `synora-sleep.jsonl` — append-only failure log used as a source of mutation hints.
- `tests/self-test.mjs` — integration and regression test suite.
- `TEST_REPORT.txt` — results from the local verification run.

## Run

```sh
node synora-evo-farm-v4.mjs --tribe=coding --with-teacher --once
```

Use `marketing`, `arabic`, `english`, or `discussion` for the other tribes. Legacy random mode creates 100 candidates:

```sh
node synora-evo-farm-v4.mjs --tribe=coding --once
```

Set `SYNORA_TIMEOUT_MS=1000` to allow up to one second for each candidate after the worker is ready. The default is 500 ms; startup has a separate eight-second timeout. The genome limit is 144 UTF-8 bytes.

## Anti-regression design

- A candidate is scored separately on training tests and held-out validation tests (`"split":"validation"`).
- A teacher is not promoted if no validation tests exist.
- Promotion requires the candidate to be no worse than the current teacher on validation and to improve at least one score; the prior teacher is backed up to `teacher.js.bak` and retained in the Ark when replaced.
- Candidate evaluation failures and timeouts are appended to `synora-sleep.jsonl`.
- Ark entries are deduplicated, validated against the 144-byte limit, and capped at 100.
- If the test suite is empty or malformed JSONL is found, the engine stops instead of evolving against no tests or silently ignoring corrupted lines.
- Writes use temporary files and atomic rename.

Validation tests are only as strong as the examples they contain. Passing these small starter suites does not prove general intelligence or broad correctness. Expand and periodically refresh the held-out tests before making claims about improvement.

## Explicit rule conversion

Only lines in this form are converted:

```md
- [KILLER:marketing] Output must contain hook, pain, cta
- [KILLER:coding] Invalid input must return error
```

Run `node convert-skill.js SKILL.md` from the repository root. The converter does not interpret arbitrary prose. Supported structural rules are required output fields and invalid-input/error checks; unknown rules fail explicitly during evaluation.

## GitHub Actions

Push the package contents to the root of a GitHub repository. Enable Actions read/write repository contents permission and run the workflow manually once to verify repository-specific settings. Scheduled workflows can be delayed, and runner pricing/availability depends on GitHub's current policy.

## Security limitation

The engine evaluates each organism in a separate Node process and enforces a timeout, but **this is not a security sandbox**. JavaScript executed through `Function` can access Node capabilities in the worker. Only use trusted organisms and trusted killer snippets; do not treat this process separation as safe isolation for hostile code. A true hostile-code sandbox requires OS/container-level isolation that is not implemented by this package.

---

# WAR v5 — "CRI": engine additions (added 2026-10-24)

v4 above is **kept intact and remains the baseline**. v5 is a new engine in `synora-v5/` that
runs on the *same artifact format* (`function solution(a)`) and the *same killer format*, so both
engines can be measured on one benchmark.

## What v5 adds

| File | Purpose |
|---|---|
| `synora-v5/tasks.mjs` | 8-task reference benchmark: buggy seed, trusted oracle, train/validation killers, probe pool, held-out holdout. Set A (development) and set B (held out). |
| `synora-v5/judge.mjs` | Sandboxed evaluation (worker pool, hard timeout), the **soundness gate** (a killer must be passed by the oracle) and differential counterexample search. |
| `synora-v5/genome.mjs` | Tokenizer, the failure-signature algebra, and 18 generic semantic repair operators. |
| `synora-v5/ledger.mjs` | **CRI** — the memory: refutations, skills, witnesses, prohibitions, credit, pruning. |
| `synora-v5/engine.mjs` | Families (PATCHER / BREAKER / SKEPTIC), causal attribution by intervention, lineage-diverse elitism, composition, budgets. |
| `synora-v5/cli.mjs` | Single-task / single-set runner with metrics. |
| `synora-v5/experiments.mjs` | The full study: v5-full, v5-random, cold-B, warm-B, v4-baseline. |
| `synora-v5/baseline-v4.mjs` | Runs the **unmodified** v4 engine on the same benchmark. |
| `synora-v5/llm-compare.mjs` | LLM baseline on the same tasks, same prompt information, same judge. |
| `synora-v5/distractors.mjs` | Benchmark stress knob: generic irrelevant operators that enlarge the search space. |
| `tests/v5.test.mjs` | 14 automated checks (benchmark validity, CRI rules, anti-leak, determinism, budget, and two falsifiable claims about v4). |
| `docs/DIAGNOSIS.md` | Evidence-based audit of v4. |
| `docs/MECHANISM.md` | The CRI mechanism, its limits, and what is new vs. prior art. |
| `docs/REPORT.md` | Measured results, including the negative results. |
| `docs/PLAN-30D.md` | The 30-day plan with gates. |

### Phase 3 — long-term memory that survives the session

| File | Purpose |
|---|---|
| `synora-v5/phase3/tasks.mjs` | 19 task specs in three groups: **A** acquisition (7), **B** generalisation (6), **C** final held out (6). |
| `synora-v5/phase3/secrets.mjs` | The answer key — grader-private (a test proves the solver never imports it). |
| `synora-v5/phase3/grader.mjs` | The one-way grader (same scoring rules as Phase 2, its own key). |
| `synora-v5/phase3/operators.mjs` | The Phase-2 operator library + one measured addition (`INSERT_CALL_ARG`). |
| `synora-v5/phase3/engine.mjs` | The CRI engine + a **noise** memory mode + restore accounting. |
| `synora-v5/phase3/memory.mjs` | The persistent memory format (`synora-cri-memory/1`), sha256 integrity, answer scanning. |
| `synora-v5/phase3/acquire.mjs` | **Session 1**: learns on A, writes the memory file, exits. |
| `synora-v5/phase3/evaluate.mjs` | **Session 2**: a NEW process restores the file and works on B then C. |
| `synora-v5/phase3/experiments.mjs` | 5 arms x 5 seeds x 4 budgets, every arm in its own process. |
| `synora-v5/phase3/analysis.mjs` | Analytic defect families, the structural similarity matrix, the statistics. |
| `tests/phase3.test.mjs` | 20 checks: leak prevention, persistence round-trip, corruption rejection, falsification controls, diversity. |
| `scripts/reproduce-phase3.sh` | One script that runs everything. |
| `docs/06-REPORT-LONG-TERM-MEMORY.md` | The measured Phase-3 report and the final verdict. |
| `docs/07-FINAL-AUDIT-AND-REPRODUCTION.md` | **The audit**: every claim checked against the raw data, the bugs found (degenerate seeds, an unpaired bootstrap, a doubled Wilcoxon tail), the corrections, and the final verdicts. |
| `docs/08-REPORT-PHASE4-CROSS-DOMAIN.md` | **Phase 4**: the cross-domain memory-transfer experiment (a new domain: tariff rules, not file repair), its four arms, its controls, and its verdict. |
| `docs/09-PHASE4-PROTOCOL-DEVIATIONS.md` | Every deviation from the Phase-4 protocol, with the control that bounds each one. |
| `synora-v5/phase4/` | The Phase-4 domain (environment, tasks, answer key, grader, engine port) and the experiment orchestrator. |
| `tests/phase4.test.mjs` | 29 Phase-4 checks: no answer leaks, the grader's validity, the memory round-trip, the data separation, the seeds, the session boundary, the untouched core. |
| `scripts/reproduce-phase4.sh` | One script that reproduces the whole Phase-4 experiment. |
| `scripts/core-hashes.mjs` | SHA-256 of the 27 files that carry the engine's capabilities — the proof that the core did not change. |
| `docs/CHANGE-LOG.md` | Every change to the code or the reports, with its reason and its evidence. |
| `synora-v5/stats.mjs` | Paired statistics: paired bootstrap, McNemar (exact), Wilcoxon (exact), Holm–Bonferroni. |
| `synora-v5/phase3/report-tables.mjs` | Generates every table in the Phase-2/3 reports FROM the raw results. |
| `tests/audit.test.mjs` | 23 audit checks: immutability, leak prevention, grader validity, raw↔report consistency, statistics correctness, portability, clean-folder run. |
| `scripts/build-manifest.mjs` | SHA-256 manifest of every shipped file. |
| `audit/` | The pre-audit snapshot, the immutable baseline, and the package manifest. |

**Phase 4 — the cross-domain test (the current headline).** In a NEW domain (shipment settlement
by tariff rules, not file repair), the persistent memory was measured against three baselines on
a fully held-out group: at a 10-evaluation budget it solves **14/50** against **0/50** for the
no-memory baseline (McNemar exact p=0.000122, Holm-adjusted 0.0037); at a 40-evaluation budget the
median evaluations to success fall from **21.5 to 5** (paired effect −9, 95% CI [−14, 0],
Holm-adjusted 0.0144). The random-hint arm and the no-transfer arm both collapse back to the
baseline, the cross-process session control is **identical to the in-process one in 5/5 seeds**, and
no expected value is found inside any memory file. The benefit is **conditional**: it is entirely
concentrated in the held-out tasks whose rule was actually acquired, and it **reverses** at
generous budgets (78/90 vs 83/90 at 150 evaluations). See `docs/08-REPORT-PHASE4-CROSS-DOMAIN.md`.

**The Phase-3 headline (measured, 5 independent seeds, after the audit corrections):** on the held-out
group C at a 60-evaluation budget the persistent-memory arm solves **23/30** against **12/30** for
the no-memory baseline (McNemar exact p = 0.000977, Holm-adjusted p = 0.0225); at a 250-evaluation
budget the median evaluations to success drop from **89 to 36** (paired effect −40, 95% CI
[−53, −2], Wilcoxon p = 2e-06, Holm-adjusted 4.8e-05). A cross-process session control shows the
restored file is **identical in effect** to the in-memory memory (5/5 seeds), and two falsification
arms (within-task-only memory, and a memory with randomised hints) both collapse back to the
baseline — so the effect comes from *transferable, useful* knowledge, not from carrying a hint.

> **Audit note:** an earlier version of these reports claimed a larger effect (100% vs 50%). The
> audit found that the search was deterministic, so the "5 seeds" were 5 identical repeats; the
> numbers above are the corrected ones, recomputed with a paired analysis. See
> `docs/07-FINAL-AUDIT-AND-REPRODUCTION.md`.

### Phase 2 — the same memory on a domain with **no oracle**

| File | Purpose |
|---|---|
| `synora-v5/pst/environment.mjs` | The public workspace: 7 files, 10 tools with named argument slots, the public value pool. |
| `synora-v5/pst/tasks.mjs` | 12 public task specs (6 dev + 6 held out), each with a partially wrong seed program. |
| `synora-v5/pst/secrets.mjs` | **The answer key — grader-private.** Imported by the grader only; a test proves the engine never sees it. |
| `synora-v5/pst/sandbox-worker.mjs` | Runs a candidate with the tools bound, captures the trace, enforces the timeout. |
| `synora-v5/pst/grader.mjs` | The **one-way grader**: score + violation categories + trace. Never returns the expected value. |
| `synora-v5/pst/operators.mjs` | The 5 call-level operators (`SET_ARG`, `INSERT_CALL`, `REMOVE_CALL`, `SWAP_CALLS`, `FIELD_SET`). |
| `synora-v5/pst/engine.mjs` | CRI over grader categories: coverage, directed search, and **composed repairs** (chains of 2–3). |
| `synora-v5/pst/experiments.mjs` | 3 arms × 5 seeds + the budget sweep + the exhaustive single-operator check. |
| `synora-v5/pst/old-library-check.mjs` | Measures how far the OLD operator library gets on the new domain (0/12). |
| `tests/pst.test.mjs` | 19 checks: grader validity, no-leak, composition necessity, determinism, budget. |
| `docs/REPORT-PST.md` | The measured Phase-2 report, including the negative results and the verdict. |

## Run

```sh
# v5 on the whole benchmark
node synora-v5/cli.mjs --mode=full --set=all --seed=7 --budget=800

# the ablation (same operators, no memory)
node synora-v5/cli.mjs --mode=random --set=all --seed=7 --budget=800

# the whole study (adds the v4 baseline and the transfer arms)
node synora-v5/experiments.mjs --seeds=5 --budget=800 --out=experiments/results.json

# Phase 2: the no-Oracle domain (3 arms x 5 seeds + budget sweep)
node synora-v5/pst/experiments.mjs --seeds=5 --budget=250 --generations=80 \
     --out=experiments/results-pst.json
node synora-v5/pst/old-library-check.mjs

# Phase 3: long-term memory across sessions (5 arms x 5 seeds x 4 budgets)
bash scripts/reproduce-phase3.sh
node synora-v5/phase3/experiments.mjs --seeds=5 --budgets=10,30,60,250 \
     --out=experiments/results-phase3.json

# tests
node tests/self-test.mjs     # v4 regression suite (must stay green)
node tests/v5.test.mjs       # v5 suite
node tests/pst.test.mjs      # Phase-2 suite (no-oracle domain)
node tests/phase3.test.mjs   # Phase-3 suite (long-term memory)
node tests/audit.test.mjs    # audit suite (integrity, leaks, statistics, portability)
node tests/phase4.test.mjs   # Phase-4 suite (cross-domain transfer, no leaks, untouched core)
```

## The one-paragraph version of Phase 2 (the no-oracle domain)

The same CRI memory was pointed at a domain with **no reference implementation**: multi-step
tool-using programs, graded by a **one-way grader** that returns a score and a *category of
violation* but never the expected value. What transfers is therefore not an answer but a
**repair shape** (`wrong_arg:sortBy:dir` → `SET_ARG(sortBy,dir,*)`) plus the value that
worked (`desc`). On the held-out set this halves the evaluations needed (median 24.5 → 12.0)
and lifts the success rate at a 30-evaluation budget from 66.7% to 83.3%. It is *not* a new
capability: with a generous budget the memory-less arm also solves everything, and the
composition machinery itself is hand-written. The honest verdict is in
[`docs/REPORT-PST.md`](docs/REPORT-PST.md).

## The one-paragraph version of v5

The unit of evolution is not the organism, it is the **skill**: a rule of the form
`failure-signature -> repair operator`. A failure becomes knowledge only if a *counterfactual
test* shows the mutation caused it (the parent passed the same test), the rule is stored as a
hypothesis, and it is promoted to a skill only after it actually repairs something. Sound
counterexamples (where the candidate disagrees with a trusted oracle) become inherited
witnesses that every later candidate must satisfy, and a skeptic family fires edge-domain
inputs at anything that claims to pass, which is what catches over-fitted "guards" that merely
hard-code the demanded value.


# Adaptive Memory final validation (2026-10-26)

## Requirements and quick start

- Node.js 20 or newer; no third-party npm dependencies are required.
- Run the complete regression suite: `npm test`
- Run only the context-aware adaptive policy tests: `npm run test:adaptive`
- Re-run the low-budget matched comparison (seeds 1–5; budgets 10/20/40): `npm run study:adaptive`
- Rebuild the SHA-256 package manifest after any intentional file change: `npm run manifest`

The new validation reports and raw results are under `reports/` and `experiments/adaptive-final/`. See `reports/ADAPTIVE_MEMORY_FINAL_DECISION.md` for the verdict. Adaptive V2 remains experimental: it fixes context-specific abstention behavior but did not improve success rates over CRI in the matched runs. The new-seed check uses the existing B/C task identities and must not be described as an independent new-task generalization study.


---

# Digital Object Core — experimental first kernel

See [`synora-v5/digital-object-core/README.md`](synora-v5/digital-object-core/README.md) for the symbolic object/rule layer, API, persistence semantics, schema-v2 migration, backups, and limits. Run `npm run test:digital-objects` for focused tests. The opt-in `DigitalObjectSynoraAdapter` wraps the public `runTask(task)` boundary for CRI-compatible `PstEngine` and Adaptive V2 results; it records public results to the digital-object store but does not alter search behavior or CRI/Adaptive memory formats. Integration is explicitly opt-in and covered by a real-engine test.


## V7 Stage 2 — Digital Object Core comparative experiment

The reproducible Stage 2 study is in `experiments/stage2/` and is driven by `scripts/stage2/run-stage2-experiments.mjs`. It preserves the original CRI baseline and Adaptive V2 engine, and records cold, restored native-memory, core-only, and native-plus-core conditions. The report deliberately distinguishes the standalone symbolic core benchmark from the PST integration arms; it does not claim that CRI or Adaptive V2 solved symbolic QA tasks.

Run from the repository root with Node.js 20+:

```sh
npm test
npm run study:stage2 -- all
```

The run writes `experiments/stage2/results-raw.json`, `results-detailed.csv`, `paired-ablation.json`, `paired-ablation.csv`, and `failures-and-exclusions.json`. It uses seeds 17, 43, and 101; these vary insertion order and are not independent model initializations. The small hand-authored held-out symbolic suite is exploratory, not evidence of broad generalization. See `experiments/stage2/REPORT_STAGE2.md` and the external `SYNORA_WAR_V7_STAGE2_EXPERIMENT_REPORT.md` for the full protocol and verdict. The earlier invalid exploratory run is preserved under `experiments/stage2/archive/pre-fix-run/` and must not be pooled with corrected results.
