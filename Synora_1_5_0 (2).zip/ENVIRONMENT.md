# Environment and Reproduction

- Node.js: `v22.16.0`
- npm: `10.9.2`
- OS: Linux x86_64
- CPUs visible to Node: 3
- Network: DNS lookup for `registry.npmjs.org` failed during this run; no live network dependency was fetched.
- SQLite: `node:sqlite` available in Node 22.16.0 (Node emits its experimental warning). Other Node versions fall back to persistent JSON storage if `node:sqlite` is unavailable.

## Reproduce

```bash
npm run manifest
npm run manifest:sign
npm run manifest:verify
npm test
npm run bench
npm run bench:synth
node bench/eval-pbe-round2.mjs
node bench/eval-round2-devsets.mjs
node bench/eval-qa-round2.mjs
node bench/external-eval.mjs --tasks bench/external-eval/sample-tasks.json --out bench/results/round2-full-sample-eval.json
```

`npm run bench:synth` exceeded 300 seconds in this environment; see `logs/round2-bench-synth.status`. Do not treat its partial output as a completed benchmark.

The captured command output is in `logs/environment.txt`.

## Network policy

Runtime default is offline/no outbound connections. Optional web learning requires explicit opt-in, an injected fetcher, an injected robots checker, two distinct source hosts, captured allowlisted licence, and returns a connection log. Tests use mocks only. See `docs/OUTBOUND-CONNECTIONS.md`.
