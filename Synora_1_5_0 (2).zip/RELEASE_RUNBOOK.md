# Release runbook — Synora WAR v8.7.0

Every step below is executable and was executed for this release. Commands are run from
the package root (`Synora_WAR_v8_7_0`).

## 0. Prerequisites

| Requirement | Check |
|---|---|
| Node.js >= 20 | `node --version` |
| No npm dependencies to install | `npm ci` is not required (`npm install` is a no-op) |
| A user Ed25519 private key **outside** the package | see step 4 |
| Write access to the release output directory | `ls -ld "$OUT_DIR"` |

## 1. Clean the tree

```bash
cd Synora_WAR_v8_7_0
git status --porcelain          # or: rm -rf bench/results/*.tmp
node scripts/build-manifest.mjs --help >/dev/null 2>&1 || true
```

The manifest is rebuilt from the file system, so stale generated files are the only thing
that can make a release inconsistent. Remove any file that is not part of the release
before continuing.

## 2. Run the test suites

```bash
npm test                                                  # full harness
node --test --test-concurrency=1 tests/stage6/synthesis.test.mjs \
                                tests/stage6/round3-pbe-regressions.test.mjs
node --test --test-concurrency=1 tests/stage7/*.test.mjs
```

Expected: the harness exits 0 and reports every command as passed. Any failing command
stops the release.

## 3. Regenerate the evaluation artifacts

```bash
node bench/eval-pbe-round2.mjs  --out bench/results/pbe-round2-eval.json
node bench/eval-qa-round2.mjs
node bench/external-eval/make-independent-set.mjs
node bench/external-eval.mjs --tasks bench/external-eval/independent-set.json \
                             --out bench/results/external-final.json
```

`bench/external-eval/make-independent-set.mjs` prints the SHA-256 of the independent
evaluation set; the same digest is stored in `bench/external-eval/independent-set.sha256`
and must match.

## 4. Sign the manifest with a user key

```bash
# The private key MUST live outside the package.
export SYNORA_MANIFEST_PRIVATE_KEY_FILE=/secure/keys/synora-release-ed25519.pem
node scripts/build-manifest.mjs
node scripts/create-manifest-signature.mjs --require-user-key
```

* `--require-user-key` (or `SYNORA_MANIFEST_REQUIRE_USER_KEY=1`) makes the script refuse
  to sign with an ephemeral key. A release must never be signed that way.
* `SYNORA_MANIFEST_PRIVATE_KEY` (a PEM value) is accepted as an alternative to the file.
* A key file located inside the package is refused.
* A non-Ed25519 key is refused.

Only the public key, its fingerprint, the manifest digest and the signing time are
written to `audit/`. The private key is never copied, logged or archived.

## 5. Verify

```bash
npm run manifest:verify
node scripts/verify-manifest-signature.mjs     # detached Ed25519 signature
```

Both must exit 0. `manifest:verify` recomputes the manifest and compares it with the
signed digest, so any change after step 4 is detected.

## 6. Package

```bash
cd ..
rm -f Synora_WAR_v8_7_0_FINAL.zip
zip -r -X Synora_WAR_v8_7_0_FINAL.zip Synora_WAR_v8_7_0 \
    -x '*/node_modules/*' '*/.git/*'
sha256sum Synora_WAR_v8_7_0_FINAL.zip | tee Synora_WAR_v8_7_0_FINAL.zip.sha256
```

`-X` excludes extended attributes so the archive is reproducible on any host.

## 7. Clean-room verification of the archive

```bash
mkdir -p /tmp/clean-room && cd /tmp/clean-room
rm -rf Synora_WAR_v8_7_0
unzip -q /path/to/Synora_WAR_v8_7_0_FINAL.zip
cd Synora_WAR_v8_7_0
npm test
node scripts/verify-manifest-signature.mjs
```

The clean-room run must pass with the same counts as the development run. The log is
kept as `clean-room-npm-test.log`.

## 8. Key rotation

The release key is not embedded in the package, so rotation is a signing-side operation:

1. Generate a new Ed25519 key **outside** the package:
   `openssl genpkey -algorithm Ed25519 -out /secure/keys/synora-release-<date>.pem`
2. Keep the old key available for the verification window of the previous release.
3. Re-run steps 4-7 with `SYNORA_MANIFEST_PRIVATE_KEY_FILE` pointing at the new key.
   The fingerprint in `audit/manifest-key-fingerprint.txt` and
   `audit/manifest-signature.json` changes, and the old signature no longer verifies.
4. Publish the new public key (`audit/manifest-public.pem`) and the new fingerprint with
   the release notes. Verify a release with:
   `node scripts/verify-manifest-signature.mjs` and, independently, against the published
   fingerprint.
5. Retire the previous key only after the verification window of the previous release has
   closed. A compromised key must be retired immediately, and every release signed with it
   must be re-signed.

`audit/manifest-signature.json` records `keyOrigin: "user-supplied"`, the algorithm, the
public key fingerprint, the manifest digest and the signing time, so a verifier can
always tell which key produced a given artifact.

## 9. Rollback

The previous release archive and its `.sha256` are kept. To roll back, publish the
previous archive and its digest; no key operation is needed because each release carries
its own detached signature.
