# Synora — Deployment Guide

## 1. Cloudflare Worker (المحرك المحمي)

```bash
cd worker
npm install -g wrangler
wrangler login
wrangler deploy
# → synora-engine.workers.dev
```

## 2. Hugging Face Spaces (الواجهة)

1. أنشئ Space جديد: https://huggingface.co/new-space
2. SDK: **Static HTML**
3. ارفع `deploy/index.html` فقط
4. → huggingface.co/spaces/YOURNAME/synora

## 3. GitHub Pages (بديل)

1. أنشئ repo خاص (PRIVATE)
2. ارفع `deploy/index.html` في فرع `gh-pages`
3. فعّل Pages: Settings → Pages → gh-pages
4. → username.github.io/repo

## الحماية

- المحرك (synthesize.mjs, store.mjs, brain.mjs) → على Cloudflare Worker (مخفي)
- الواجهة (index.html) → على HF Spaces / GitHub Pages (عامة، لكنها فقط UI)
- الضوابط (ambiguity gate, anti-leak, sandbox) → على Worker (لا يمكن إزالتها)
- الـDSL + الكائنات → على Worker (لا يمكن نسخها)

## الكلفة: $0

- Cloudflare Workers: 100K طلب/يوم مجاناً
- Hugging Face Spaces: مجاني
- GitHub Pages: مجاني
