# Round 2 finalization addendum — 2026-11-01

This addendum records checks performed after the main Round-2 report was authored.

## Rechecks

- `npm run manifest` — exit 0; manifest enumerated 783 files totalling 72.40 MB.
- `npm run manifest:sign` — exit 0; Ed25519 detached signature generated with an ephemeral key; private key was discarded.
- `npm run manifest:verify` — exit 0; manifest file hashes and detached signature both PASS. Fingerprint: `0f60a9b4725fa5b2576b17653be31fa6a983b3f6839469f58378030609a0e831`.
- `node --test --test-concurrency=1 tests/stage7/*.test.mjs` — exit 0; 73 tests passed, 0 failed.
- `npm run bench` — exit 0. The included report records 35 paraphrase prompts (7 solved, 5 abstained, 0 wrong) and 12 trap prompts (12 abstained, 0 wrong).
- `npm run bench:synth` — did not finish within 600 seconds. The partial output is saved as `logs/round2-bench-synth-recheck.log`; no exit code or full result is claimed.
- A new `npm test` re-run exceeded the execution window while running `stage6/synthesis.test.mjs`; it has no exit code. The previously recorded clean-extraction run remains available at `logs/final-clean-extraction-npm-test.log` with `logs/final-clean-extraction-npm-test.status` = `0`, 33 passing test commands. The fresh stage7 run above passed independently.

## Provenance and limitations

No production code was modified during this finalization pass; only verification logs, this addendum, and the acceptance matrix were added. The v8.4.0 source archive remains untouched. This does not resolve the coverage, live-service, cross-platform, external-model, sealed-set, or long-running synthesis benchmark blockers listed in `ROUND2_ACCEPTANCE_MATRIX.md`.
