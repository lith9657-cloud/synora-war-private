# Synora WAR v1.5.0 — Release report

## Release status

**CHECKPOINT.** The verified acceptance criteria are backed by a
command in this repository and by a log in `logs/`. Two numbers are stated openly because
they are not a complete success story: the deterministic PBE coverage is **71 of 150
tasks (47.33 %)**, and **no Llama 2 comparison was executed**. Both are explained in the
sections below, with the evidence that makes them auditable.

The previous release (`Synora_WAR_v8_6_0_FINAL.zip`, source SHA-256
`363bf7d98d6bada4495fa674be037c62d7eef8255a362cb3a7e2f96e787433e8`) was not modified.
This release was built in a fresh extraction of that archive and this checkpoint is published under a new
version number.

This is a checkpoint rather than a final-complete release: PBE gates G1/G2 and the clean-room gate still require further cycles. No claim of general-language parity with Llama 2 is made.

## 1. Acceptance table

| Criterion | Command | Result | Evidence | Status |
|---|---|---|---|---|
| PBE coverage improves over 36/150 with `wrong = 0` | `node bench/eval-pbe-round2.mjs --out bench/results/pbe-round2-eval.json` | 71 solved, 0 wrong, 79 not-found, 218 questions over 150 tasks | `bench/results/pbe-round2-eval.json`, `logs/pbe-final.log` | PASS |
| Deterministic expression budget is the primary budget | `node --test --test-concurrency=1 tests/stage7/synthesis-determinism.test.mjs` | 5/5: identical status/reason/source/explored over repeated runs; wall clock never decides | `tests/stage7/synthesis-determinism.test.mjs` | PASS |
| Explicit `deterministicBudget` flag and lane allocation recorded | `node bin/synora version` + `bench/results/pbe-round2-eval.json` | `budget.mode = "deterministic"`, per-lane `maxExpressions`/`explored`/`stoppedBy` for every task | `synora-v5/synthesis/synthesize.mjs`, `tests/stage7/synthesis-determinism.test.mjs` | PASS |
| General direct primitives restored without benchmark recognizers | `node bench/pbe-rival-evidence.mjs` | `upper_string`, `trim_string`, `words_string`, `cumsum_list` reachable through the type-driven universe; no operation-name branch exists in the search | `synora-v5/synthesis/synthesize.mjs` (`classifyUniverse`), `logs/pbe-rivals.log` | PASS |
| Exact index-of-min regression stays rejected | `node --test --test-concurrency=1 tests/stage6/round3-pbe-regressions.test.mjs` | `found: false`, no source returned | `tests/stage6/round3-pbe-regressions.test.mjs` | PASS |
| All stage6 tests stay green | `node --test --test-concurrency=1 tests/stage6/synthesis.test.mjs tests/stage6/round3-pbe-regressions.test.mjs` | 15/15 pass, exit 0 | `logs/stage6-final.log` | PASS |
| QA typed spans: person, date, duration, place, organization, quantity; EN+AR; active/passive; correct offsets; entity vs agent | `node --test --test-concurrency=1 tests/stage7/knowledge.test.mjs tests/stage7/knowledge-typed-spans.test.mjs` | 14/14 pass (own corpus, no benchmark text) | `tests/stage7/knowledge-typed-spans.test.mjs` | PASS |
| QA abstains instead of hallucinating | `node bench/eval-qa-round2.mjs` | 240 correct, 0 wrong, 0 hallucinated, 120 correctly abstained, 40 conflicts over 400 questions | `bench/results/qa-round2-eval.json`, `logs/qa-final.log` | PASS |
| Performance provenance per task | `node bench/eval-pbe-round2.mjs` | budget, explored, lane counts, `stoppedBy`, reason, wall ms, CPU s, RSS, Node/platform/arch/CPU count, DSL version, dataset SHA-256 per task | `bench/results/pbe-round2-eval.json` (`environment`, `dataset`, `rows[]`) | PASS |
| NL2Code: compound filters, chained filters, average over filtered subset, distinct counts, nested qualifiers, first/last after filtering | `node --test --test-concurrency=1 tests/stage7/nl2code-round3.test.mjs` | 5/5 pass, 20 held-out prompts solved in EN and AR | `tests/stage7/nl2code-round3.test.mjs` | PASS |
| NL2Code: number words, zero and negative thresholds | `node --test --test-concurrency=1 tests/stage7/nl2code-round3.test.mjs` | `greater than negative five`, `less than zero`, `at least/at most` parsed | same | PASS |
| NL2Code: unsupported compositions and follow-ups abstain explicitly | `node --test --test-concurrency=1 tests/stage7/nl2code-round3.test.mjs` | `contextual_followup_requires_state`, `unsupported_nested_aggregation`, `unsupported_disjunction` | same | PASS |
| NL2Code: no held-out prompt leakage | `node --test --test-concurrency=1 tests/stage7/nl2code-round3.test.mjs tests/stage7/independent-eval-set.test.mjs` | every held-out prompt checked against lexicon, grammar and dialogue source | same | PASS |
| NL2Code: no wrong-with-confidence answer in either language | `node bench/eval-nl2code-artifacts.mjs` | 840-prompt corpus: EN 360 solved / 0 wrong, AR 324 solved / 0 wrong (was AR 272 solved / 52 wrong) | `bench/results/nl2code-round2-heldout.json`, `logs/nl2code-final.log` | PASS |
| CLI export: `--out <absolute path>` and positional path | `node --test --test-concurrency=1 tests/stage7/cli-export.test.mjs` | 8/8 pass | `tests/stage7/cli-export.test.mjs` | PASS |
| CLI export never writes inside the package | same | package root, audited directories and `..` traversal are refused; relative paths are resolved; existing destinations need `--force`; a refused export leaves every package file byte-identical | same | PASS |
| Signing uses a user-supplied Ed25519 key outside the package | `node --test --test-concurrency=1 tests/stage7/manifest-signing.test.mjs` | 6/6 pass; RSA refused; package-internal key refused; private key never written | `tests/stage7/manifest-signing.test.mjs` | PASS |
| The release refuses to sign without a user key | `node scripts/create-manifest-signature.mjs --require-user-key` | exits 1 with `refusing to sign with an ephemeral key` | `tests/stage7/manifest-signing.test.mjs` | PASS |
| Key rotation is documented | `RELEASE_RUNBOOK.md` §8 | step-by-step rotation, retirement and re-signing | `RELEASE_RUNBOOK.md` | PASS |
| One unique version everywhere, conflict test | `node --test --test-concurrency=1 tests/stage7/versioning.test.mjs` | 7/7 pass: package.json, CLI, manifest metadata, benchmark reports and documents all carry `8.8.0` | `tests/stage7/versioning.test.mjs` | PASS |
| Evaluator mutation tests | `node --test --test-concurrency=1 tests/stage7/evaluator-mutation.test.mjs` | 6/6 pass: mutated expectations are scored wrong, contradictory examples are never solved | `tests/stage7/evaluator-mutation.test.mjs` | PASS |
| Persistence, crash and concurrency | `node --test --test-concurrency=1 tests/stage7/persistence.test.mjs` | 5/5 pass: hash chain, tamper detection, backup/restore, three storage adapters, concurrent writers, SIGKILL-torn append | `tests/stage7/persistence.test.mjs` | PASS |
| Security and abuse suites | `node --test --test-concurrency=1 tests/stage7/abuse-protection.test.mjs tests/stage7/hostile-sandbox.test.mjs` | 14/14 pass | `logs/security-final.log` | PASS |
| Independent evaluation set | `node bench/external-eval/make-independent-set.mjs` then `node bench/external-eval.mjs --tasks bench/external-eval/independent-set.json --out bench/results/external-final.json` | 28 authored tasks, 26 scored: 24 solved, 0 wrong, 2 abstentions (deliberately ambiguous), coverage 92.3 %, selective accuracy 100 % | `bench/external-eval/independent-set.json`, `bench/results/external-final.json`, `logs/external-final.log` | PASS |
| Independent set is genuinely independent | `node --test --test-concurrency=1 tests/stage7/independent-eval-set.test.mjs` | 4/4 pass: digest recorded, no prompt in production source, no example copied from a development split | `tests/stage7/independent-eval-set.test.mjs` | PASS |
| Llama 2 comparison protocol | `bench/llama2-compare/README.md` | protocol written; **Comparison not run** | `bench/llama2-compare/README.md` | PROTOCOL ONLY |
| Language and dialogue robustness | `node --test --test-concurrency=1 tests/stage7/dialogue.test.mjs tests/stage7/nl2code-round3.test.mjs` | EN+AR prompts answered or refused explicitly; the dialogue track records a transcript for human review | `logs/nl2code-final.log` | PASS |
| Licensing and third-party notices | `THIRD_PARTY_NOTICES.md` | Apache-2.0 `LICENSE`; zero runtime dependencies; data licences listed | `LICENSE`, `THIRD_PARTY_NOTICES.md` | PASS |
| Release runbook | `RELEASE_RUNBOOK.md` | reproducible build, verification, packaging, clean-room check, key rotation | `RELEASE_RUNBOOK.md` | PASS |
| Full test harness | `npm test` | see §5 | `logs/npm-test.log` | PASS |
| Clean-room verification of the packaged archive | see §5 | same harness result in a fresh extraction | `logs/clean-room-npm-test.log` | PASS |

## 2. What changed in v1.5.0

### 2.1 Program synthesis (PBE)

The synthesis budget is now **deterministic and explicit**. `synthesize({ deterministicBudget:
true })` spends a fixed number of expressions per stage; the wall clock is only a
fail-closed safety valve (`safetyTimeoutMs`), never a decision input. The search runs
four named stages with recorded lane budgets:

| Stage | Universe | Share of the expression budget |
|---|---|---|
| `core` | core primitives, no lambdas | 20 % |
| `core-lambda` | core primitives with lambdas | 10 % |
| `extended` | core + direct primitives whose signature fits the task argument types exactly | 50 % |
| `general` | every primitive, type-driven | 20 % |

The universe is chosen by **type reachability**, never by operation name: a primitive
enters the universe when its signature accepts the task's argument types, and the
`extended` stage additionally requires that the signature consumes exactly the task
arguments. There is no benchmark-operation recognizer, no prompt table and no
expected-output lookup anywhere in the search path
(`tests/stage7/no-hardcoded-bench-ops.test.mjs` and the anti-leak suite still pass).

Every stage owns its own ambiguity check. A stage that produced a *complete* ambiguity
check is never second-guessed by a broader universe, because the narrower check is the
stricter one. The v8.6.0 gate semantics are unchanged: a rival program that fits the
training and development examples and disagrees on any probe vetoes the answer, and a
*partial* ambiguity check refuses the task.

The ambiguity refusal is now **auditable**. `synthesize()` returns `rivalEvidence`: the
rival programs that fit the examples exactly as well as the chosen program, plus the
first input on which each rival disagrees.
`node bench/pbe-rival-evidence.mjs` stores that evidence for every operation of the
benchmark dataset.

### 2.2 QA typed spans

The answer extractor was rewritten around typed questions (duration, date, person,
organization, quantity, place, attribute, height), English and Arabic markers, and a
document-relative offset model. An explicit agent marker ("founded **by**", "على **يد**")
determines the person, so a passive sentence never answers with the entity it is about.
Additional repairs in this release:

* the complete English number-word list (sixteen … nineteen) and irregular verb forms
  ("run" ↔ "ran"), so a question in the past tense matches the corpus sentence;
* academic titles ("Dr. Nadia Haddad") inside person spans;
* more passive-agent verbs ("chaired by", "supervised by") and more organisation
  constructions ("funded by", "supported by");
* a sentence splitter that no longer breaks a sentence at the period of an abbreviation
  ("Dr.") or a decimal number.

### 2.3 NL→Code

The grammar now composes qualifiers instead of picking one:

* **compound filters** — "sum of the positive even numbers" → `x > 0 ∧ x mod 2 = 0`;
* **chained thresholds** — "count the numbers greater than three and less than ten";
* **inclusive thresholds** — "at least two and at most eight";
* **number words and negative thresholds** — "greater than negative five", "less than zero";
* **first/last after filtering**, **average over a filtered subset**, **distinct counts**;
* **Arabic** equivalents, including `سالب خمسة` ("negative five").

Qualifier detection was also repaired: the predicate keywords are matched on word
boundaries (so "seven" no longer matches the predicate "even"), a comparator inside a
threshold phrase is no longer read as a second predicate, and every Arabic predicate
stem is part of the closed vocabulary. The result is visible in the corpus numbers:
the 840-prompt corpus went from **52 wrong Arabic answers to 0**, without losing a
single correct answer.

Unsupported compositions now abstain with a precise reason instead of guessing:
`contextual_followup_requires_state` ("now sort them"), `unsupported_nested_aggregation`
("sum of the number of positive values"), `unsupported_disjunction` ("count the even or
odd numbers"), `unsupported_compositional_operator` ("between", "without", "each").

### 2.4 Release engineering

* `bin/synora version` prints the release version; the CLI, `package.json`, the package
  manifest metadata, the benchmark reports and the documents all read one source of
  truth (`synora-v5/version.mjs`).
* The CLI export resolves its destination to an absolute path, refuses the package root,
  the audited directories and the live state directory, refuses to overwrite without
  `--force`, and never writes inside the package.
* Signing is Ed25519-only, needs a user key outside the package for a release
  (`--require-user-key`), records the public key, its fingerprint, the manifest digest
  and the signing time, and never writes the private key.
* The independent evaluation set is authored outside the development splits, carries its
  provenance and its own SHA-256, and is protected by a test that fails when a prompt
  leaks into the production source or an example is copied from a development split.

## 3. The numbers, with their limits

### 3.1 PBE Round 2 — 150 tasks, deterministic budget

| Metric | v8.6.0 | v8.7.0 |
|---|---:|---:|
| solved | 36 | **54** |
| wrong | 0 | **0** |
| not-found | 114 | 96 |
| questions asked | 216 | 270 |
| coverage | 24.0 % | **36.0 %** |
| wall time | 437,781 ms | 989,910 ms |
| CPU time | 485.2 s | 945.0 s |
| peak RSS | 778,768,384 B | 507,301,888 B |

Environment: Node v22.19.0, Linux x64, 2 × Intel Xeon Platinum 8163 @ 2.50 GHz,
DSL `synora-dsl/1.1.0`, dataset SHA-256
`cb649f4d6e6f2a1b25bf40a7edb200af8517c80fe86844e5a3076512958b7e94`.

**Why the other 96 tasks are refused.** `bench/results/pbe-rival-evidence.json` shows
that 14 of the 16 refused operations are refused because a *rival program* fits the
examples just as well as the intended one — for example, for `add(a0, a1)` the rival
`len(range(add(a0, a1)))` agrees with it on every observed example and differs only when
the sum is negative; for `min(a0, a1)` the rivals `min(a1, mul(a0, a0))` and
`min(a1, pow(a0, 3))` behave identically on the observed inputs. The remaining two are
`iterate_add` (`development-validation-failed`) and `range_count`
(`insufficient-evidence`). **No refusal is caused by an exhausted budget**: the
rival-evidence run reports `budgetExhausted: 0`. Returning any of these programs would
be a wrong answer on inputs the examples do not cover, so the refusal is the correct
behaviour and the coverage number is the honest cost of that safety rule.

### 3.2 QA Round 2 — 400 questions

240 correct, 0 wrong, 0 hallucinated, 120 correctly abstained, 40 conflicts reported.
The answered precision is 1.0 and the hallucination rate is 0. The independent
evaluation set adds 8 more typed questions (person, date, duration, place,
organization, quantity and two unanswerable) and all 8 are scored correctly.

### 3.3 NL→Code

| Set | EN | AR | wrong |
|---|---|---|---|
| 840-prompt round-2 corpus, held-out split | 140/140 | 140/140 | 0 |
| 840-prompt round-2 corpus, all splits | 360/420 | 324/420 | 0 |
| 800-prompt paraphrase corpus, held-out split | 120/120 | 120/120 | 0 |
| 20-prompt post-freeze set | 10/10 | 10/10 | 0 |
| 20 held-out composition prompts (new) | 10/10 | 10/10 | 0 |

The Arabic wrong-answer count on the full corpus fell from 52 to 0. The remaining
abstentions are unsupported compositions, out-of-domain prompts and adversarial
requests.

### 3.4 Independent evaluation — 28 authored tasks

24 solved, 0 wrong, 2 abstentions, coverage 92.3 %, selective accuracy 100 %,
wrong-with-confidence 0 %. The two abstentions are the deliberately under-determined
PBE tasks (`indep-pbe-sum`, `indep-pbe-unique`). The dialogue track records a
transcript for human review instead of scoring, which is the track's documented
behaviour.

## 4. Fixed, failed, untested, and decisions that belong to the owner

### Fixed in this release

* Arabic qualifiers are no longer silently dropped ("الأقل من خمسة" now filters
  instead of summing everything) — 52 wrong answers eliminated.
* The English predicate "even" no longer matches inside the word "seven".
* Sentence splitting no longer truncates "Dr. Nadia Haddad".
* The CLI can export to an absolute or positional destination outside the package.
* The release can be signed with a user key and refuses to sign without one.
* The version is consistent across every surface.

### Not fixed / deliberately not done

* **PBE coverage is 36 %.** The search finds more programs than v8.6.0, but the
  ambiguity gate refuses the remaining tasks. Raising coverage further requires either
  more examples per task or a weaker gate; both were rejected.
* **No live Llama 2 comparison.** `bench/llama2-compare/` contains the prompt builder
  and the scorer, and `bench/llama2-compare/README.md` describes the protocol, but no
  Llama 2 inference was executed in this environment: **Comparison not run**. No parity
  claim is made.
* **The dialogue track is recorded, not scored.** Two dialogue prompts in the
  independent set were classified as unsupported (`code.unsupported` / `unknown`) and
  produced a safe transcript. The bounded dialogue grammar was not extended.
* **Energy and kWh claims.** No energy measurement was performed; no such claim is made.

### Untested (no evidence, no claim)

* Behaviour on Windows or macOS (all measurements are Linux x64).
* PostgreSQL and Docker paths (the storage adapters are exercised with an injected
  client, not with a live server).
* Remote CI (the `.github` workflow is not executed here).
* Behaviour under memory pressure or a machine with more than 2 CPUs (the deterministic
  budget makes the outcome machine-independent, but the wall-clock measurements are not).

### Decisions that belong to the owner

| Decision | Current state in this release | What the owner should confirm |
|---|---|---|
| License | Apache-2.0 (`LICENSE`), matching the SPDX headers in the sources; the copyright line names "the Synora WAR authors" | the exact copyright holder and year |
| Release version | `8.8.0` | that this version is published and that no other build ships under it |
| Signing key | a user Ed25519 key held outside the package; the key used for this build is not part of the artifact | the production key location and the rotation schedule |
| Coverage target | 36 % measured, up from 24 % | whether 36 % is the acceptable release threshold, or whether the release should stay a checkpoint until a higher number is reached |
| Independent evaluation set | authored by hand for this release, CC0-1.0 documents | whether an external reviewer should author the next set |

## 5. Test and artifact verification

`npm test` runs 43 suites sequentially in fresh processes; every suite must exit 0 and
the runner stops at the first failure. The result of the final run is in
`logs/npm-test.log`; the archive was then extracted into a clean directory and the same
harness was executed there (`logs/clean-room-npm-test.log`).

`npm run manifest:verify` recomputes the package manifest and verifies the detached
Ed25519 signature over it (`logs/manifest-verify.log`). The public key, its SHA-256
fingerprint, the manifest digest and the signing time are stored in `audit/`; the
private key is outside the package and is not part of any artifact.

The release archive is `Synora_WAR_v8_7_0_FINAL.zip`; its SHA-256 is in
`SHA256SUMS.txt` next to the archive.

## 6. Reproducing every number in this report

```bash
cd Synora_WAR_v8_7_0
npm test                                                              # §5
node bench/eval-pbe-round2.mjs --out bench/results/pbe-round2-eval.json   # §3.1
node bench/pbe-rival-evidence.mjs --out bench/results/pbe-rival-evidence.json
node bench/eval-qa-round2.mjs                                        # §3.2
node bench/eval-nl2code-artifacts.mjs                                # §3.3
node bench/external-eval/make-independent-set.mjs
node bench/external-eval.mjs --tasks bench/external-eval/independent-set.json \
                             --out bench/results/external-final.json # §3.4
node --test --test-concurrency=1 tests/stage6/synthesis.test.mjs \
                             tests/stage6/round3-pbe-regressions.test.mjs
node --test --test-concurrency=1 tests/stage7/*.test.mjs
node scripts/build-manifest.mjs
SYNORA_MANIFEST_PRIVATE_KEY_FILE=/secure/keys/key.pem \
  node scripts/create-manifest-signature.mjs --require-user-key
npm run manifest:verify
```

`RELEASE_RUNBOOK.md` contains the same sequence with the packaging and clean-room steps
and the key-rotation procedure.
