# Round 3 cycles — Synora WAR v8.6.0

## Cycle 0 — baseline before changes
- Input: Synora_WAR_v8_5_2_FINAL.zip; untouched clean extraction `npm test` exit 0, 34/34 commands.
- Environment: Node.js v22.23.4, Linux x86_64, 6 CPUs.
- Exact reported `mod(sum(unique(init(a0))),3)` reproduction was not present in shipped datasets; independent related cases were tested and the current gate returned `ambiguous-examples` or `search-budget-exhausted`, never a solution.
- Pending: baseline bench runs and targeted Round 3 acceptance tests.

## Cycle 1 — reject partial ambiguity acceptance
- Changed `synora-v5/synthesis/synthesize.mjs`: a budget-truncated ambiguity pass now returns not-found/ambiguous and never `found:true`; added measurable evidence profile; made lambda-pool construction lazy.
- Added `tests/stage6/round3-pbe-regressions.test.mjs` with 31 thin argmin/argmax positional tasks plus a truncated-search regression.
- New regression tests: 31/31 passed.
- Existing synthesis suite: 12/14 passed; 2 failed because valid `average` and learner examples now hit the search budget instead of being accepted. This cycle is not acceptable.
- Action required: optimize general synthesis or add a complete independent ambiguity verifier; do not weaken the partial-search rule.

## Cycle 2 — generic search ordering and lazy lambda construction
- Added output-type/arity/lambda-aware primitive ordering and lazy lambda-pool construction; no operation-specific recognisers were added.
- The 31 new thin positional regressions still pass.
- Existing synthesis acceptance remains blocked: `average` and learner example synthesis exhaust the default search budget before a complete ambiguity pass.
- This cycle is not acceptable for packaging. The partial-result prohibition remains active; no ZIP was produced.
- Next action: reduce the generic enumeration state space or implement a separate complete candidate-equivalence verifier; do not restore partial acceptance.

## Cycle 3 — exact reproduction and API budget
- Reproduced the supplied v8.5.2 failure exactly: `mod(sum(unique(init(a0))),3)`, partial ambiguity, zero questions.
- v8.6.0 exact regression: not-found with `search-budget-exhausted`; 31 thin positional regressions pass.
- API endpoint was updated to pass a deterministic complete-search envelope; API synthesis test passes.
- First full run exposed stale freeze/signature and then API budget failure after an over-aggressive bank cap. Freeze, post-freeze digest, manifest, and signature were regenerated; the bank cap was restricted to small expression budgets so valid large-budget synthesis is preserved.

## Cycle 4 — clean verification checkpoint
- Re-ran PBE, QA, NL2Code, external sample, freeze, manifest, signature, and `npm test`.
- `npm test`: 35/35 commands passed, exit 0.
- PBE: 0 solved, 0 wrong, 150 not-found, 132 questions under the legacy 1000-expression budget. This is the remaining unmet coverage criterion; no partial acceptance was restored.
- QA: 240 correct, 0 wrong, 0 hallucinated, 120 correctly abstained, 40 conflicts.
- Deliverable status: CHECKPOINT, not final-complete.

## Cycle 5 — deterministic benchmark budget
- Measured PBE at 10,000 expressions/1,000 ms: 54 solved, 0 wrong, 96 not-found, 201 questions, 63,758 ms wall, 70.34 CPU-s, peak RSS 195,706,880 bytes.
- 30,000 and 100,000 expression runs added no solved tasks and only increased runtime; the 10,000-expression limit is retained and documented.
- PBE and devset evaluators were aligned to the same deterministic budget.

## Cycle 1 — 2026-11-03 (Round 5 hard-gated repair)

Environment: Linux arm64, Node v22.23.4, 6 CPUs (Neoverse-N1), 7.8 GiB RAM.

- Baseline reproduction: `node bench/eval-pbe-round2.mjs --out bench/results/baseline-v8.7.0-pbe.json`; 150 tasks, solved=54, wrong=0, notFound=96, elapsed=856210 ms, average=5708.07 ms, CPU=899.56 s.
- Baseline QA reproduction: `node bench/eval-qa-round2.mjs`; 400 questions, correct=240/240, abstained=120/120, conflicts=40/40, hallucinations=0.
- Baseline NL reproduction: `node bench/eval-nl2code-artifacts.mjs`; held-out EN=140/140 and AR=140/140. Direct required prompts exposed first/last cardinal selectors being reduced to singleton selectors.
- Technique A: added a general cardinal-selection parser for `first/last + number-word/digit + plural noun`, Arabic equivalents, and dual forms; emits `take` and reverse-take ASTs. Direct checks: first four=[9,8,7,6], first 4=[9,8,7,6], first two=[9,8], أول أربعة=[9,8,7,6], آخر عنصرين=[6,5].
- Technique B: expanded passive English agent extraction to allow intervening text before `by` (`was established in 1890 by ...`). All five required EN/AR QA prompts now answer with minimal spans and offsets.
- Technique C: corrected selector safety validation to use a sufficiently long probe for ordinal indices. `second element` now returns the second scalar.
- Technique D: updated the obsolete Round-2 regression expectation to require exact cardinal selection, regenerated freeze/post-freeze artifacts, and kept static anti-leak checks passing.
- Technique E: filtered only rivals with strictly worse measured plausibility prior than the selected candidate; retained complete ambiguity checks for equally plausible rivals. Added the general round-trip no-op `len(range(x))`. On a six-task `sum_list` sample, 6/6 changed from ambiguous refusal to solved; min/max remained conservatively ambiguous.
- Cycle-1 targeted synthesis, regression, determinism and anti-leak tests passed. NL/QA targeted tests pass after freeze regeneration.

Open measurement: full clean-room npm test and full updated PBE rerun are pending after this cycle.


## Cycle 1 packaging checkpoint

After versioning to 8.8.0, freeze artifacts and manifest were regenerated, the manifest was signed with an Ed25519 key stored outside the package, and targeted audit/packaging/versioning tests passed (23 audit checks; 10 targeted checks). The archive `Synora_WAR_v8_8_0_CHECKPOINT.zip` was created and tested with `unzip -t`; SHA-256 is `acb46b4c00ebfd27ed21efdd3e3e0cbad54d99e31aa9ec74666a8be9383d66f6`. A fresh extraction ran all 43 npm test commands successfully, including release audit, packaging, NL2Code, synthesis determinism and the extended PBE suite. The release remains explicitly a CHECKPOINT because the requested PBE thresholds G1/G2 and the Llama comparison were not completed; no unsupported parity claim is made.
