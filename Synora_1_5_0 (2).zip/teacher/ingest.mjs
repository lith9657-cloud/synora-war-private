/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { synthesize } from '../synora-v5/synthesis/synthesize.mjs';
import { evalAst, deepEqual, validateAst } from '../synora-v5/synthesis/dsl.mjs';
import { SkillManager } from '../synora-v5/synthesis/library-skills.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

export function checkLeakage(text, evalSets) {
  if (!text) return false;
  for (const setPath of evalSets) {
    if (!fs.existsSync(setPath)) continue;
    const content = fs.readFileSync(setPath, 'utf-8');
    if (content.includes(text)) return true;
  }
  return false;
}

export function ingestTeacherFile(filePath, options = {}) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Teacher file not found: ${filePath}`);
  }

  const raw = fs.readFileSync(filePath, 'utf-8');
  const lines = raw.split('\n').filter(Boolean);

  const evalSets = [
    path.join(ROOT_DIR, 'bench/external-eval/sample-tasks.json'),
    path.join(ROOT_DIR, 'bench/paraphrase-corpus.json')
  ];

  const skillManager = new SkillManager({ stateDir: options.stateDir || path.join(ROOT_DIR, 'data') });
  const report = {
    total: lines.length,
    accepted: 0,
    rejected: 0,
    reasons: []
  };

  for (let i = 0; i < lines.length; i++) {
    const item = JSON.parse(lines[i]);

    // 1. Validate license field
    if (!item.license || !item.license.includes('Apache')) {
      report.rejected++;
      report.reasons.push({ id: item.id, reason: 'unpermitted_license' });
      continue;
    }

    // 2. Anti-leak verification
    if (checkLeakage(item.description, evalSets)) {
      report.rejected++;
      report.reasons.push({ id: item.id, reason: 'evaluation_set_leakage_detected' });
      continue;
    }

    // 3. Symbolic program synthesis verification
    try {
      const synthRes = synthesize({
        training: item.training,
        development: item.development,
        budgetMs: 2000
      });

      const candidateAst = synthRes.found ? synthRes.ast : null;
      if (!candidateAst) {
        report.rejected++;
        report.reasons.push({ id: item.id, reason: 'synthesis_failed' });
        continue;
      }

      // 4. Verify on hidden tests
      let passesHidden = true;
      for (const h of (item.hidden || [])) {
        const actual = evalAst(candidateAst, h.input);
        if (!deepEqual(actual, h.output)) {
          passesHidden = false;
          break;
        }
      }

      if (!passesHidden) {
        report.rejected++;
        report.reasons.push({ id: item.id, reason: 'hidden_test_failure' });
        continue;
      }

      // 5. Register verified symbolic skill
      skillManager.registerSkill({
        id: `teacher-skill-${item.id}`,
        name: item.id,
        ast: candidateAst,
        source: synthRes.source,
        provenance: {
          source: 'teacher-induced-symbolic-verification',
          modelLicense: item.license,
          ingestedAt: new Date().toISOString()
        },
        tests: item.hidden || []
      });

      report.accepted++;
    } catch (err) {
      report.rejected++;
      report.reasons.push({ id: item.id, reason: err.message });
    }
  }

  return report;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const inFile = process.argv[2] || path.join(__dirname, 'out.jsonl');
  const res = ingestTeacherFile(inFile);
  console.log('Teacher Ingest Summary:');
  console.table([res]);
}
