# Synora Offline Teacher Pipeline

## Separation

- Teacher inference is a separate, opt-in notebook process. It is not imported by Synora runtime, API, or CLI.
- Generated records are untrusted proposals. They remain quarantined until anti-leak checks, synthesis, development checks, and hidden tests pass.
- The pipeline emits examples, not code. It does not register the teacher's completion as an executable program.

## Exact reference model and licence

The default reference model is **`Qwen/Qwen2.5-Coder-7B-Instruct`**. Its Hugging Face model card identifies the repository licence as `apache-2.0`: <https://huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct. This is the exact model ID; do not infer that other Qwen sizes or similarly named models share the same licence.

Relevant Apache License 2.0 grant wording (Section 2): “perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce” (abridged quote). See the model repository's `LICENSE` file and review the complete licence before use.

Do not use Meta Llama Community License models for this teacher pipeline. No model is recommended as a runtime dependency.

## Run offline

1. In a separate Colab/Kaggle or local GPU environment, install `torch` and `transformers` and cache the exact model files after reviewing their licence.
2. Upload `teacher/prompts.jsonl` and `teacher/generate.py`.
3. Run with the local cache only (default):

   ```bash
   python teacher/generate.py --input teacher/prompts.jsonl --output teacher/out.jsonl
   ```

4. `--allow-download` is an explicit opt-in if the notebook must fetch weights. It is not used by Synora.
5. Return `teacher/out.jsonl` to Synora and run:

   ```bash
   node teacher/ingest.mjs teacher/out.jsonl
   ```

The ingest stage validates the declared Apache licence, checks leakage, runs symbolic synthesis, and tests hidden examples. No teacher run was performed as part of this package build.
