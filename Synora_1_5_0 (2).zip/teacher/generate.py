#!/usr/bin/env python3
"""Offline-only teacher generation. Model weights must already be cached locally unless --allow-download is explicit."""
import argparse
import json
import re
import sys

MODEL_DEFAULT = "Qwen/Qwen2.5-Coder-7B-Instruct"
LICENSE = "Apache-2.0"


def parse_json_object(text):
    match = re.search(r"```(?:json)?\s*(\{[\s\S]*?\})\s*```", text, re.I)
    candidate = match.group(1) if match else text[text.find("{"):text.rfind("}") + 1]
    if not candidate or candidate == "}":
        raise ValueError("teacher output did not contain a JSON object")
    obj = json.loads(candidate)
    required = ("training", "development", "hidden")
    if any(not isinstance(obj.get(k), list) for k in required):
        raise ValueError("teacher JSON must contain training, development, and hidden arrays")
    return obj


def main():
    parser = argparse.ArgumentParser(description="Generate candidate examples with a locally cached Apache-2.0 teacher model.")
    parser.add_argument("--input", default="teacher/prompts.jsonl")
    parser.add_argument("--output", default="teacher/out.jsonl")
    parser.add_argument("--model", default=MODEL_DEFAULT)
    parser.add_argument("--allow-download", action="store_true", help="Allow Transformers to download model files; otherwise local cache only")
    parser.add_argument("--max-new-tokens", type=int, default=700)
    args = parser.parse_args()
    try:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
    except ImportError as exc:
        raise SystemExit("Install torch and transformers in the separate teacher notebook environment first: " + str(exc))

    local_only = not args.allow_download
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=local_only, trust_remote_code=False)
    model = AutoModelForCausalLM.from_pretrained(args.model, torch_dtype="auto", device_map="auto", local_files_only=local_only, trust_remote_code=False)
    model.eval()
    outputs = []
    with open(args.input, "r", encoding="utf-8") as src:
        for line_no, line in enumerate(src, 1):
            if not line.strip():
                continue
            task = json.loads(line)
            task_id = str(task.get("id", f"task-{line_no}"))
            prompt = str(task.get("prompt", ""))
            messages = [
                {"role": "system", "content": "Return only one JSON object with keys training, development, hidden. Each item must have input as an argument array and output as a JSON value. Do not copy benchmark examples. Do not emit JavaScript or executable code."},
                {"role": "user", "content": f"Create discriminating examples for this task: {prompt}. Include boundary cases (empty/singleton/duplicates/zero/negative/ties where applicable)."}
            ]
            rendered = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            inputs = tokenizer([rendered], return_tensors="pt").to(model.device)
            with torch.inference_mode():
                generated = model.generate(**inputs, max_new_tokens=args.max_new_tokens, do_sample=False)
            completion = tokenizer.decode(generated[0][inputs.input_ids.shape[-1]:], skip_special_tokens=True)
            try:
                candidate = parse_json_object(completion)
                outputs.append({"id": task_id, "modelId": args.model, "license": LICENSE, "description": prompt, **candidate})
            except Exception as exc:
                outputs.append({"id": task_id, "modelId": args.model, "license": LICENSE, "description": prompt, "rejected": True, "rejectionReason": str(exc), "rawCompletion": completion})

    with open(args.output, "w", encoding="utf-8") as dst:
        for item in outputs:
            dst.write(json.dumps(item, ensure_ascii=False) + "\n")
    print(f"Generated {len(outputs)} offline teacher records using {args.model}; no model scores or skill acceptance are implied.")


if __name__ == "__main__":
    main()
