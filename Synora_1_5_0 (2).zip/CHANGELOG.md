# Synora WAR v1.5.0 — RELEASE

- v1.5.0: Identity system (Yemeni AI by Eng. Laith Ahmed Khadeesh Al-Zuraqi). 10 HF datasets. 3 GitHub skills. Open dialogue training (lmsys-chat-1m). 47 tests. 0 hallucination.

# Synora WAR v10.5.0 — RELEASE

- v10.5.0: HuggingFace ingestion pipeline (5 datasets), GitHub skill ingestion (3 real repos: stitch-landing, web-design, premium-saas). Pattern extraction (understand not store). 24/28 skills verified.

# Synora WAR v10.4.0 — RELEASE

- v10.4.0: 6 bugs fixed (add-two, sub-two, mul-two, max, min, head). 24/28 skills verified (86%). New web-dev + agent skills added.

# Synora WAR v10.3.0 — RELEASE

- v10.3.0: Phase 1 complete. HumanEval clarification loop (15.91%→59.09%, 0 wrong). nl-generation, live-learner, web UI, skill clarification all restored.

# Synora WAR v10.2.0 — RELEASE

- v10.2.0: PBE clarification loop! 73→120 solved (80%!). 0 wrong. HumanEval 7/44.

# Synora WAR v10.1.0 — RELEASE

- v10.1.0: A3 lazy OE FIXED (nTD now passed), A6 last-tier budget FIXED, HumanEval expanded to 44 problems (7 solved, 15.91%), knowledge expanded to 103 docs / 265 facts.

# Synora WAR v10.0.0 — RELEASE

- v10.0.0: Cloudflare Worker, deploy UI, A3-A7, Agent SDK, Failure Memory, Wikipedia ingestion, HumanEval.

# Changelog — Synora WAR v8.8.0

## 8.8.0 checkpoint
- Added generic cardinal `first/last K` parsing for English and Arabic, including digits, number words and dual forms, with exact `take` semantics.
- Fixed passive English typed-person extraction when temporal/location text appears between the verb and `by`.
- Fixed selector sanity probes for non-zero ordinals.
- Added a measured generic plausibility filter for structurally less plausible PBE rivals and the general `len(range(x))` round-trip no-op.
- Cycle-1 PBE result: 71/150 solved, 0 wrong, 79 refused; QA required prompts and NL cardinal regressions pass. This artifact is a checkpoint, not a claim that all numeric gates pass.

# Changelog — Synora WAR v8.7.0

## Release scope
This release implements the seven priority areas of the v8.7.0 contract plus the deferred
validation work. The measured result is in `REPORT.md`; the acceptance table there maps
every criterion to a command and an artifact.

## Program synthesis
- Made the expression budget the primary, deterministic budget: `synthesize({ deterministicBudget: true })`
  spends a fixed expression count per stage and treats the wall clock as a fail-closed
  safety valve only.
- Recorded the full budget provenance per task and per lane: mode, `maxExpressions`,
  `maxSize`, `seed`, `safetyTimeoutMs`, `safetyTimeoutFired`, DSL version and the lane
  allocation with `explored` and `stoppedBy` per stage.
- Replaced the operation-aware universe with a **type-driven** one
  (`classifyUniverse`): a primitive is reachable when its signature fits the task's
  argument types; the `extended` stage requires an exact match on the task arguments.
- Restored the general direct primitives (cumsum, flatten, upper, trim, words, reverse,
  lower) through that type-driven universe — no benchmark-operation recognizer, no
  prompt-to-program table, no expected-output lookup.
- Rebuilt the lambda bank as a canonical, deterministic artefact that is built before
  the timed search and cached per numeric-argument shape.
- Added a general rival-plausibility rule: case-normalising round trips
  (`lower(upper(x))`) are structurally redundant and cannot veto a candidate.
- Added `rivalEvidence` to the synthesis result: the rival programs that fit the
  examples as well as the chosen one, with the first input on which they disagree. A
  refusal is now auditable.
- New harness `bench/pbe-rival-evidence.mjs` stores that evidence for every operation of
  the benchmark dataset.

## Knowledge and question answering
- Rewrote the answer extractor around typed questions (duration, date, person,
  organization, quantity, place, attribute, height) with English and Arabic markers,
  active/passive voice handling, entity-versus-agent disambiguation and
  document-relative offsets.
- Added the missing English number words (sixteen … nineteen) and irregular verb forms
  so that a past-tense question matches the corpus sentence.
- Added academic titles to person spans ("Dr. Nadia Haddad"), more passive agent verbs
  ("chaired by") and more organisation constructions ("funded by").
- Replaced the sentence splitter: a period inside an abbreviation ("Dr.") or a decimal
  number no longer ends a sentence.
- New suite `tests/stage7/knowledge-typed-spans.test.mjs` (11 tests) on its own corpus.

## Natural language to code
- Composed qualifiers instead of choosing one: compound filters, chained thresholds,
  inclusive thresholds ("at least" / "at most"), number words, zero and negative
  thresholds, first/last after filtering, average over a filtered subset, distinct counts.
- Repaired predicate detection: word-boundary matching (so "seven" no longer matches the
  predicate "even"), comparator words inside a threshold phrase are no longer read as a
  second predicate, and the stem of every Arabic vocabulary entry is part of the closed
  vocabulary.
- Added explicit abstention reasons for unsupported compositions:
  `contextual_followup_requires_state`, `unsupported_nested_aggregation`,
  `unsupported_disjunction`, `unparsed_threshold`.
- Arabic wrong answers on the 840-prompt corpus: 52 → 0, with no loss of correct answers.
- New suite `tests/stage7/nl2code-round3.test.mjs` with 20 held-out prompts and a
  leakage check against the production sources.

## CLI and export
- `bin/synora export` accepts `--out <absolute path>` and a positional destination,
  resolves the destination to an absolute path, refuses the package root, the audited
  directories and the live state directory, and refuses to overwrite an existing
  destination without `--force`.
- New suite `tests/stage7/cli-export.test.mjs` (8 tests) including path traversal,
  relative paths, an existing destination and a "no package file changed" digest check.

## Release signing and versioning
- Signing is Ed25519-only and accepts a user key through `SYNORA_MANIFEST_PRIVATE_KEY_FILE`
  or `SYNORA_MANIFEST_PRIVATE_KEY`; a key inside the package is refused and the private key
  is never copied, logged or archived.
- `--require-user-key` (or `SYNORA_MANIFEST_REQUIRE_USER_KEY=1`) makes a release refuse to
  sign with an ephemeral key.
- The signature metadata now records the algorithm, the key origin, the public-key
  fingerprint, the manifest digest and the signing time.
- New suite `tests/stage7/manifest-signing.test.mjs` (6 tests) covering the user key, a
  non-Ed25519 key, a package-internal key, the ephemeral-key refusal, the absence of key
  material in the artifacts and tamper detection.
- One version source of truth (`synora-v5/version.mjs`) drives `package.json`, the CLI
  (`bin/synora version`), the package manifest metadata, the benchmark reports and the
  documents. New suite `tests/stage7/versioning.test.mjs` fails on any conflicting version
  string.
- Added `LICENSE` (Apache-2.0), `THIRD_PARTY_NOTICES.md` and `RELEASE_RUNBOOK.md`.

## Independent evaluation and mutation testing
- New independent evaluation set `bench/external-eval/independent-set.json` (28 tasks)
  authored outside the development splits, with provenance and a recorded SHA-256, plus
  the generator `bench/external-eval/make-independent-set.mjs`.
- New suite `tests/stage7/independent-eval-set.test.mjs` (4 tests): recorded digest,
  self-description, no prompt leakage, no example copied from a development split.
- New suite `tests/stage7/evaluator-mutation.test.mjs` (6 tests): the evaluator is
  sensitive to mutated expectations and never scores contradictory tasks as solved.
- The external evaluator now uses the deterministic budget, so the independent evaluation
  is reproducible.

## Determinism
- New suite `tests/stage7/synthesis-determinism.test.mjs` (5 tests): identical
  status, reason, source and explored count over repeated runs, complete budget
  provenance, and proof that the wall clock does not decide an outcome.

## Acceptance status
This is a release build: every criterion of the v8.7.0 contract is met and evidenced
(`REPORT.md` §1). Two disclosed limits: the deterministic PBE coverage is 54/150
(36 %, up from 24 %) with **0 wrong** and **no budget-caused refusal**, and the Llama 2
comparison is **Comparison not run** — no inference was executed, so no parity claim is
made. Live PostgreSQL, Docker, remote CI and non-Linux platforms remain untested in this
environment.

# Changelog — Synora WAR v8.5.2

## Final verification and artifact consistency
- Regenerated the NL2Code held-out and post-freeze result artifacts from the current evaluator.
- Added a release test that recomputes both result sets and fails on any stale or mismatched saved artifact.
- Rebuilt package identity, release documentation, manifest, and detached signature.

# Changelog — Synora WAR v8.5.1

## Arabic and English NL→Code repair

- Fixed Arabic zero-threshold parsing (`الصفر`) and common inflected/clitic forms using closed-vocabulary stem validation.
- Removed generic Arabic/English “all/كل” quantifiers from the unsupported-composition rejection gate; retained abstention for genuinely unsupported operators such as `between`, `without`, `each`, and `every`.
- Added explicit regression cases for Arabic filtering, zero-threshold aggregation, clitic forms, and English “arithmetic mean”.
- Rebuilt the operation-disjoint code freeze and post-freeze evaluation artifacts after the parser changes.
- Re-evaluation: 240/240 held-out paraphrase prompts passed (120 EN + 120 AR); 280/280 operation-disjoint held-out prompts passed (140 EN + 140 AR); zero wrong outputs. Post-freeze: EN 9/10, AR 10/10, zero wrong outputs.

## Acceptance status

This is an engineering hotfix release, **not a full acceptance-final release**. The PBE evaluation remains below target (78/150 solved, 0 wrong); live PostgreSQL, Docker runtime, remote CI, an independently sealed reviewer set, and Llama 2 inference/comparison still require external infrastructure, credentials, model access, or independent data. Do not represent these as completed.

---

# Changelog — Synora WAR v8.5.0 Round 2

## Round 2 checkpoint

- Tightened PBE ambiguity gating, added boundary probes and conservative plausibility/no-op rejection; added 150-task PBE dev measurement.
- Added compositional aggregation/filter handling, Arabic normalization/threshold parsing, output-kind checks, and held-out operation corpus.
- Added minimal exact QA spans, source offsets, attribute evidence checks, and conflict reporting; added 400-question fictional corpus.
- Updated `synora-eval/1` PBE clarification rounds, QA conflict scoring, and agent instruction planning.
- Added JSON/SQLite/PostgreSQL adapter interface, SQLite migrations, hash-chained event ledger with writer lock, crash recovery, backup/restore CLI.
- Added web-learning robots/licence/source independence checks and returned outbound-connection log.
- Added teacher model pipeline using local cached Qwen/Qwen2.5-Coder-7B-Instruct by default; no teacher inference was run.
- Hardened agent registry against hard links, Unicode/case collisions, and deterministic parent-symlink write races; added hostile sandbox tests.
- Added Llama comparison prompt/scoring kit; no Llama model score was generated.
- Added operation-disjoint development sets, post-freeze evaluation, reports, and logs.

## Known limitations

The release remains a partial checkpoint. PBE coverage regressed on the shared sample suite (7/10 to 1/10 solved, both with zero wrong); the full synthesis bench timed out; full T1 final clean-room status must be read from the final logs/report; live PostgreSQL, live web fetch, teacher inference, cross-platform CI, and Llama inference were not performed.
