# Synora WAR V8.1.1 — FIX1 report (intent guard)

Base: `Synora_WAR_v8_1_RENDER_PREP.zip` (original untouched; this is a separate copy).
Date of work: 2026-10-30. Node v22.

## Defect fixed
V8.1 routed "write a function that returns the second largest number in an array" to the *max* template and reported
`tests-passed` (the template's own internal tests). The code was wrong. Root cause: lexical intent matching with no check
that the rest of the request was understood, plus a status that could be read as independent verification.

## Changes (5 files changed, 2 added dirs)
1. `synora-v5/dialogue/index.mjs`
   - **Vocabulary guard:** a code intent is accepted only if every content word is modelled. Otherwise the parser abstains
     (`code.unsupported`, `clarify`) and lists the unmodelled terms in `evidence.guard`.
   - Lexicon widened (inflections, synonyms, Arabic verbs). This is a stop-gap lexicon, not understanding.
   - `includesAny` now normalises its term list (Arabic terms with hamza / alef-maqsura could never match before).
   - Greeting now matches whole words ("hi" used to match "this", "which", "machine"; "hey" matched "they").
   - Parser label bumped to `bounded-lexical-intent-rules/2+vocabulary-guard`.
2. `synora-v5/solution-engine/index.mjs`: `verification.independence = template-self-tests-only...` is now explicit.
3. `tests/stage4/stage4.test.mjs`: one assertion updated for the parser label bump (the only existing test edited).
4. `tests/stage5/intent-guard.test.mjs` (new, 4 tests) + wired into `npm test`.
5. `bench/` (new): Synora-Bench v0 + v0b, baseline and post-fix results. `npm run bench`.
6. `package.json` version -> 8.1.1-intent-guard; `audit/package-manifest.json` regenerated.

## Measured effect
| Metric | V8.1 baseline | V8.1.1 |
|---|---|---|
| Wrong code reported as tests-passed (v0, 27 prompts) | 1 | 0 |
| Known-op prompts solved: canonical / paraphrase / Arabic (5 each) | 2 / 2 / 1 | 5 / 5 / 5 (*) |
| New operations solved (12) | 0 | 0 (all abstained honestly) |
| False success on non-coding/unsafe (8) | 0 | 0 |
| v0b held-out paraphrases (12, written after the patch) | n/a | 7 solved, 5 abstained, 0 wrong |
| v0b misroute traps (12) | n/a | 12 abstained, 0 wrong |
(*) The v0 known-op prompts were partly used to tune the lexicon, so this number is optimistic. The honest generalisation
figure is the v0b result: 7/12 on unseen paraphrases.

Full suite: `npm test` exit 0 (all suites incl. Stage 4 25/25, new Stage 5 4/4).
The original "197" total was not re-summed; per-suite counts were observed passing.

## Not fixed (by design, next steps)
- The engine still selects among 5 hand-written templates; 0/12 new operations. Fix = example-driven program synthesis.
- Language understanding is still a lexicon. 5/12 unseen paraphrases abstain.
- QuickJS/WASM + process isolation not yet added; `vm` is not a security boundary.
- Small, self-authored benchmark; needs independently sourced held-out sets.
