# Release note — local recheck

This ZIP is the v8.5.2 final locally verified engineering release. It is not certified as meeting every Round 2 acceptance requirement. Read `ROUND2_FINAL_RECHECK_REPORT.md` before relying on any benchmark claim. Raw recheck logs are in `audit/round2-recheck/`.
