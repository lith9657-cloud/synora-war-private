# Synora WAR — Round 2 final recheck (2026-11-01)

## Release verdict

**NOT ACCEPTED as fully satisfying the English Round 2 acceptance prompt.** This archive is a reproducibly tested local checkpoint, not a completed all-requirements release. External validation and several performance/coverage targets remain open. No unsupported completion claim is made.

## Exact artifact and environment

- Source archive rechecked: `Synora_WAR_v8_5_1_ENGINEERING_HOTFIX.zip`.
- Package version in `package.json`: `8.5.2`.
- Runtime: Node.js `v22.16.0`, Linux x86_64.
- The prior `v8.5.1_acceptance_work` directory contained reports but not the source tree described by those reports. Those claims were not imported as code facts. All numbers below were rechecked against the actual v8.5.2 source archive.
- `npm run manifest:sign` regenerated an Ed25519 keypair and detached signature after rebuilding the manifest. The private key is intentionally discarded; this is integrity evidence for this package, not an identity/trust signature from a publisher.

## Verified local results

| Check | Actual result | Status |
|---|---:|---|
| `npm run manifest:verify` | Manifest 785 files verified; detached signature verified | PASS |
| `npm run test:stage7` | 73/73 tests | PASS |
| `npm test` from clean extraction | 33/33 test commands; exit 0 | PASS |
| Stage 6 synthesis test run independently | 12/12 tests; 34.4 seconds | PASS |
| `npm run bench` | 15/27 solved, 0 wrong, 12 abstained; new-op subset 0/12 solved | PARTIAL |
| `npm run bench:synth` | 9/12 solved, 0 wrong, 3 not found; 25 questions | PARTIAL |
| PBE round-2 evaluation | 78/150 solved, 0 wrong, 72 not found; 54 new-operation tasks | PARTIAL |
| NL→Code held-out corpus | English 140/140; Arabic 140/140; zero wrong in either language | PARTIAL |
| NL→Code post-freeze | English 9/10; Arabic 9/10; zero wrong | PARTIAL |
| Strict extractive QA | 240/240 answerable exact-span correct; 120/120 unanswerable correctly abstained; 40 conflicts detected; 0 wrong/hallucinated | PASS on synthetic corpus only |
| 40-task external sample fixture | 22/37 scored solved, 0 wrong, 12 abstained, 3 dialogue transcripts recorded | PARTIAL |

### Important benchmark interpretation

The 40-task sample has 40 entries: PBE 1/10 solved, NL→Code 9/9, required abstentions 5/5, QA 7/7, skill sequence 1/2, agent scenarios 4/4, and dialogue 3/3 recorded for human review (not scored). Thus automatic scored coverage is 22/37, not a general capability guarantee.

The compatibility comparison reports PBE coverage fell from 7/10 in v8.4.0 to 1/10 in this checkpoint. This is a material regression and remains an acceptance blocker. QA improved from 5/7 with 2 wrong to 7/7 with 0 wrong on that small fixture. Skill-sequence coverage improved from 0/2 to 1/2. Dialogue scoring is not directly comparable because current dialogue is recorded for human review.

## Acceptance matrix A–F

### A — Synthesis ambiguity and PBE

- Ambiguity rejection, boundary probes, plausibility checks, fail-closed bounded search: locally tested.
- 150-task PBE development set: 78 solved, 0 wrong, 72 not found. Wrong-answer rate is zero on this fixture, but coverage is only 52%.
- 12-task synthesis diagnostic: 9 solved, 0 wrong, 3 not found.
- Compatibility PBE: 1/10 solved versus 7/10 baseline. **NOT ACCEPTED** because of the coverage regression and low coverage.

### B — Typed compositional NL→Code

- 840 prompts across 60 operation compositions; 20 complete operation IDs held out.
- Held-out: EN 140/140 solved; AR 140/140 solved; zero wrong. Arabic coverage 100%.
- Post-freeze 20-task check: 18/20 solved, 0 wrong, 2 abstained.
- Parser is a bounded grammar, not a general natural-language parser. Some requested qualifier compositions remain explicitly unsupported and abstain. **PARTIAL**, not accepted at the requested coverage level.

### C — Strict extractive QA

- 400 questions over a locally generated fictional corpus.
- 240 exact-span answers correct; 120 correct abstentions; 40 conflicting-source cases detected; 0 wrong and 0 hallucinated.
- **PASS only for this synthetic controlled corpus.** No real-world or external-corpus generalisation is claimed.

### D — Evaluation harness and agent scenarios

- `synora-eval/1` harness, task tracks, execution scoring, sample fixtures, and dialogue transcript recording are present.
- 40-task sample fixture: 22/37 scored solved, 0 wrong, 12 abstained, 3 dialogue transcripts recorded.
- The sample is not a sealed independent benchmark. **PARTIAL**.

### E — Persistence, CLI, sandbox, and operations

- Local hash-chain integrity, torn-tail recovery, backup/restore, JSON and native SQLite, independent-process concurrency, SIGKILL recovery, CLI smoke tests, and hostile-input tests passed locally.
- PostgreSQL adapter was tested with an injected client double only; no live PostgreSQL server was available.
- Dockerfile is statically checked as non-root; Docker runtime was unavailable.
- CI workflow matrix exists but no remote CI execution was performed.
- Teacher pipeline's offline policy and symbolic verification tests pass; no live teacher inference or live web-learning request was executed.
- **PARTIAL**: live service and deployment verification are not done.

### F — Llama 2 comparison

- Prompt kit and scorer are present, but no Llama 2 weights/runtime or inference results were available. **NOT RUN**. No comparative performance claim is made.

## T1–T6

| Test | Status | Evidence / limitation |
|---|---|---|
| T1 clean extraction + full test | PASS | `npm test`, 33/33 commands, exit 0; log in `audit/round2-recheck/npm-test-clean-extraction.log`. |
| T2 no hardcoded solutions / leakage | PASS locally | Stage 7 no-hardcoded and anti-leak tests passed. |
| T3 sealed independent reviewer set | NOT RUN | No third-party sealed dataset or reviewer delivery was supplied. The post-freeze set is locally generated. |
| T4 wrong emitted JS + substring QA adversarial cases | PASS locally | Stage 7 execution and exact-span/source-offset tests passed. |
| T5 CLI, concurrency, SIGKILL, hostile sandbox, backup/restore | PASS locally, external components partial | Local tests passed; live PostgreSQL and Docker runtime unavailable. |
| T6 v8.4.0 comparison | PARTIAL | Same compatibility fixture exists; PBE regressed 7/10 to 1/10; QA improved 5/7 to 7/7; skill sequence 0/2 to 1/2. |

## External blockers that cannot be truthfully closed in this environment

1. A sealed independent reviewer dataset and independent execution/review.
2. Live PostgreSQL server integration.
3. Docker daemon/runtime execution.
4. Remote CI execution on Linux, Windows, and macOS.
5. Live teacher-model inference and live web-learning fetch.
6. Llama 2 inference and model-to-model comparison.

## Final statement

The local archive has been rechecked and its manifest/signature refreshed. The local test suite passes. **It does not meet every acceptance condition in the original prompt** because A/B coverage and the PBE regression remain, and the external T3/E/F checks have not been executed. This report deliberately preserves those failures and limitations rather than weakening tests or relabelling partial results as complete.
