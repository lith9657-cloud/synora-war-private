import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const roots=['synora-v5','bin/synora','bench/external-eval.mjs','scripts'];
const files=[];
function walk(p){const st=fs.statSync(p);if(st.isDirectory()){for(const n of fs.readdirSync(p).sort())walk(path.join(p,n));}else if(st.isFile())files.push(p.replaceAll(path.sep,'/'));}
for(const root of roots)walk(root);
files.sort();
const entries=files.map(file=>({path:file,sha256:crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')}));
const digest=crypto.createHash('sha256').update(entries.map(x=>`${x.path} ${x.sha256}`).join('\n')).digest('hex');
const result={format:'synora-code-freeze/1',frozenAt:new Date().toISOString(),files:entries.length,digest,entries};
fs.writeFileSync('bench/results/round2-code-freeze.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({files:entries.length,digest},null,2));
