/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import process from 'node:process';
import { performance } from 'node:perf_hooks';
import { fileURLToPath } from 'node:url';
import { runInWorkerSandbox } from '../synora-v5/security/sandbox.mjs';
import { VERSION } from '../synora-v5/version.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');


export function isAcceptedPbeResult(result) { return result?.found === true && Boolean(result.ast); }

export function answerPoolEntries(pool) {
  if (pool && !Array.isArray(pool) && Array.isArray(pool.answers)) pool = pool.answers;
  if (Array.isArray(pool)) {
    return pool.flatMap(entry => {
      if (!entry || typeof entry !== 'object') return [];
      const input = entry.input ?? (Array.isArray(entry.query) ? entry.query : entry.query?.input);
      const hasOutput = Object.hasOwn(entry, 'output') || Object.hasOwn(entry, 'answer') || Object.hasOwn(entry, 'expected');
      if (!Array.isArray(input) || !hasOutput) return [];
      return [{ input, output: Object.hasOwn(entry, 'output') ? entry.output : (Object.hasOwn(entry, 'answer') ? entry.answer : entry.expected) }];
    });
  }
  if (pool && typeof pool === 'object') {
    return Object.entries(pool).flatMap(([key, output]) => {
      try {
        const input = JSON.parse(key);
        return Array.isArray(input) ? [{ input, output }] : [];
      } catch { return []; }
    });
  }
  return [];
}

function lookupPoolAnswer(pool, input) {
  const key = JSON.stringify(input);
  const found = answerPoolEntries(pool).find(entry => JSON.stringify(entry.input) === key);
  return found ? { found: true, output: found.output } : { found: false };
}

function normalizeExact(value) {
  return String(value ?? '').normalize('NFKC').toLocaleLowerCase().replace(/[\s\p{P}]+/gu, ' ').trim();
}

function evaluateAgentChecks(checks, workspaceRoot, stdout = '') {
  const failures = [];
  for (const check of checks || []) {
    if (!check || typeof check !== 'object') { failures.push('malformed-check'); continue; }
    const target = check.path ? path.resolve(workspaceRoot, check.path) : null;
    if (target && target !== workspaceRoot && !target.startsWith(workspaceRoot + path.sep)) {
      failures.push(`check-path-escape:${check.path}`); continue;
    }
    switch (check.type || check.kind) {
      case 'file-equals':
        if (!target || !fs.existsSync(target) || fs.readFileSync(target, 'utf8') !== String(check.content ?? check.expected ?? '')) failures.push(`file-equals:${check.path}`);
        break;
      case 'file-absent':
        if (!target || fs.existsSync(target)) failures.push(`file-absent:${check.path}`);
        break;
      case 'file-unchanged':
        if (!target || !fs.existsSync(target) || fs.readFileSync(target, 'utf8') !== String(check.content ?? check.expected ?? '')) failures.push(`file-unchanged:${check.path}`);
        break;
      case 'stdout-contains':
        if (!String(stdout).includes(String(check.text ?? check.expected ?? ''))) failures.push('stdout-contains');
        break;
      default: failures.push(`unknown-check:${String(check.type || check.kind)}`);
    }
  }
  return { passed: failures.length === 0, failures };
}

function snapshotOutsideWorkspace(workspaceRoot, ownTempRoot) {
  const roots = [...new Set([os.tmpdir(), '/var/tmp', '/dev/shm', '/etc', os.homedir(), '/home', '/root'])];
  const snapshot = new Map();
  const visited = new Set();
  let count = 0;
  const excluded = candidate => {
    const resolved = path.resolve(candidate);
    return [workspaceRoot, ownTempRoot].some(root => {
      const base = path.resolve(root);
      return resolved === base || resolved.startsWith(base + path.sep);
    });
  };
  const walk = (target, depth = 0) => {
    if (count >= 30000 || depth > 10 || excluded(target)) return;
    let stat;
    try { stat = fs.lstatSync(target); } catch { return; }
    const identity = `${stat.dev}:${stat.ino}`;
    if (stat.isDirectory()) {
      if (visited.has(identity)) return;
      visited.add(identity);
    }
    let digest = '';
    if (stat.isFile() && stat.size <= 2 * 1024 * 1024) {
      try { digest = crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex'); } catch {}
    }
    snapshot.set(target, `${stat.mode}:${stat.size}:${stat.mtimeMs}:${stat.ino}:${digest}`);
    count++;
    if (!stat.isDirectory()) return;
    let entries = [];
    try { entries = fs.readdirSync(target); } catch { return; }
    for (const entry of entries) walk(path.join(target, entry), depth + 1);
  };
  for (const root of roots) walk(root);
  return snapshot;
}

/**
 * High-resolution resource measurement helper
 */
function recordMetrics(startCpu, startWall, sampledPeakRssBytes) {
  const endCpu = process.cpuUsage(startCpu);
  const endWall = performance.now();
  const mem = process.memoryUsage();
  return {
    wallMs: endWall - startWall,
    cpuSeconds: (endCpu.user + endCpu.system) / 1e6,
    peakRssMb: Math.max(mem.rss, sampledPeakRssBytes || 0) / (1024 * 1024),
    rssMeasurement: 'parent-process 10ms sampling; excludes child-process RSS'
  };
}

/**
 * Creates an isolated temp directory for a task run
 */
function createTempRunDir(taskId) {
  const tmpRoot = path.join(os.tmpdir(), 'synora-eval-' + Math.random().toString(36).slice(2, 9));
  const runDir = path.join(tmpRoot, String(taskId || 'task'));
  fs.mkdirSync(runDir, { recursive: true });
  return {
    dir: runDir,
    cleanup: () => {
      try {
        fs.rmSync(tmpRoot, { recursive: true, force: true });
      } catch {}
    }
  };
}

/**
 * Deterministic pseudo-random generator (LCG)
 */
function createPrng(seed = 42) {
  let s = (typeof seed === 'number' ? seed : 42) >>> 0;
  return function next() {
    s = (Math.imul(1664525, s) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

/**
 * Safe task runner for each track
 */
export async function runTask(task, options = {}) {
  const startCpu = process.cpuUsage();
  const startWall = performance.now();
  let sampledPeakRssBytes = process.memoryUsage().rss;
  const rssSampler = setInterval(() => { sampledPeakRssBytes = Math.max(sampledPeakRssBytes, process.memoryUsage().rss); }, 10);
  const taskId = (task && typeof task === 'object' && task.id) ? task.id : 'malformed';
  const taskTrack = (task && typeof task === 'object' && task.track) ? task.track : 'unknown';
  const { dir: tempDir, cleanup } = createTempRunDir(taskId);

  const result = {
    id: taskId,
    track: taskTrack,
    status: 'error', // 'solved' | 'wrong' | 'abstained' | 'error'
    outcome: 'unknown',
    details: {},
    metrics: {}
  };

  try {
    if (!task || typeof task !== 'object') {
      throw new Error('Malformed task definition');
    }

    switch (task.track) {
      case 'pbe': {
        // Track: Programming By Example
        // Synthesizer only gets train & dev. Hidden is strictly evaluated by harness.
        const { synthesize } = await import('../synora-v5/synthesis/synthesize.mjs');
        const { evalAst } = await import('../synora-v5/synthesis/dsl.mjs');

        const trainExamples = task.train || [];
        const devExamples = task.dev || [];
        const hiddenExamples = task.hidden || [];
        const disambiguationAnswers = task.answers || {};

        let currentTrain = [...trainExamples];
        let currentDev = [...devExamples];
        if (currentDev.length < 2) {
          while (currentDev.length < 2 && currentTrain.length > 2) {
            currentDev.push(currentTrain.pop());
          }
        }

        let solvedAst = null;
        let rounds = 0;
        let questionsAsked = 0;
        let questionsAnswered = 0;
        let questionsUnanswered = 0;
        const questionsPerRound = [];
        const askedQueryKeys = new Set();
        const maxRounds = 3;

        while (rounds < maxRounds) {
          rounds++;
          const synthRes = synthesize({
            training: currentTrain,
            development: currentDev,
            budgetMs: options.timeBudgetMs || 3000,
            // The independent evaluation is reproducible: the budget is an
            // explicit expression count, the wall clock is only a safety valve.
            deterministicBudget: true,
            maxExpressions: options.maxExpressions || 120000,
            maxSize: options.maxSize || 6,
            safetyTimeoutMs: options.safetyTimeoutMs || 120000,
            seed: options.seed || 42,
          });

          if (isAcceptedPbeResult(synthRes)) {
            solvedAst = synthRes.ast;
            break;
          }

          if (synthRes.reason === 'ambiguous-examples' && Array.isArray(synthRes.disambiguatingQueries) && synthRes.disambiguatingQueries.length > 0) {
            const availableQueries = synthRes.disambiguatingQueries.filter(q => {
              const key = JSON.stringify(q?.input ?? null);
              return !askedQueryKeys.has(key);
            });
            const queries = availableQueries.slice(0, 3);
            if (!queries.length) break;
            questionsAsked += queries.length;
            questionsPerRound.push(queries.length);
            let addedAnswer = false;

            for (const q of queries) {
              if (!q || !Array.isArray(q.input)) continue;
              askedQueryKeys.add(JSON.stringify(q.input));
              const answer = lookupPoolAnswer(disambiguationAnswers, q.input);
              if (answer.found) {
                currentTrain.push({ input: q.input, output: answer.output });
                questionsAnswered++;
                addedAnswer = true;
              } else {
                questionsUnanswered++;
              }
            }

            // Unanswered queries still consume this round; proceed to the next distinct query batch.
            if (!addedAnswer && rounds >= maxRounds) break;
          } else {
            break;
          }
        }

        result.details.rounds = rounds;
        result.details.questionsAsked = questionsAsked;
        result.details.questionsAnswered = questionsAnswered;
        result.details.questionsUnanswered = questionsUnanswered;
        result.details.questionsPerRound = questionsPerRound;

        if (solvedAst) {
          result.details.ast = solvedAst;
          let passesHidden = true;
          for (const test of hiddenExamples) {
            try {
              const actual = evalAst(solvedAst, test.input);
              if (JSON.stringify(actual) !== JSON.stringify(test.output)) {
                passesHidden = false;
                break;
              }
            } catch {
              passesHidden = false;
              break;
            }
          }

          if (passesHidden) {
            result.status = 'solved';
            result.outcome = 'solved';
          } else {
            result.status = 'wrong';
            result.outcome = 'wrong';
          }
        } else {
          result.status = 'abstained';
          result.outcome = 'not_found';
        }
        break;
      }

      case 'nl2code': {
        // Parse natural language, then execute the emitted JavaScript in the restricted worker.
        const { parseNLToCode } = await import('../synora-v5/nl2code/grammar.mjs');
        const prompt = task.prompt || task.description || '';
        const hiddenTests = Array.isArray(task.hidden) ? task.hidden : [];
        const lang = task.lang || 'en';
        const parseRes = parseNLToCode(prompt, { lang });
        if (parseRes.status !== 'ok' || typeof parseRes.source !== 'string') {
          result.status = 'abstained';
          result.outcome = 'abstained';
          result.details.unmodelled = parseRes.unmodelled || [];
          break;
        }
        result.details.emittedJavaScript = parseRes.source;
        let passesHidden = hiddenTests.length > 0;
        for (const t of hiddenTests) {
          const args = Array.isArray(t.args) ? t.args : (Array.isArray(t.input) && t.input.length === 1 && Array.isArray(t.input[0]) ? t.input : (Array.isArray(t.input) ? [t.input] : (Array.isArray(task.args) ? task.args : [])));
          const source = parseRes.source.replace(/^export\s+function\s+solution/m, 'function solution') + '\nreturn solution(...args);';
          const run = await runInWorkerSandbox(source, args, { timeoutMs: 1000, memoryCapMb: 64 });
          if (run.status !== 'ok' || JSON.stringify(run.result) !== JSON.stringify(t.output)) {
            passesHidden = false;
            result.details.failedTest = { input: args, expected: t.output, actual: run.result, status: run.status, error: run.error || null };
            break;
          }
        }
        if (passesHidden) {
          result.status = 'solved'; result.outcome = 'solved';
        } else {
          result.status = 'wrong'; result.outcome = 'wrong_with_confidence';
        }
        break;
      }

      case 'abstain': {
        // Track: Adversarial / Unmodelled / Out-of-domain requests that must abstain
        const { parseNLToCode } = await import('../synora-v5/nl2code/grammar.mjs');
        const prompt = task.prompt || task.description || '';
        const lang = task.lang || 'en';

        const parseRes = parseNLToCode(prompt, { lang });
        if (parseRes.status === 'abstain') {
          result.status = 'solved'; // Correctly abstained
          result.outcome = 'abstained_correct';
        } else {
          result.status = 'wrong'; // Incorrectly accepted unmodelled/unsafe
          result.outcome = 'wrong_unsupported_accepted';
        }
        break;
      }

      case 'qa': {
        // Track: Grounded Knowledge Retrieval
        const { KnowledgeStore } = await import('../synora-v5/knowledge/store.mjs');
        const store = new KnowledgeStore({ rootDir: tempDir });
        const corpus = task.corpus || [];
        for (const doc of corpus) {
          store.ingestDocument(doc);
        }

        const question = task.question || task.prompt;
        const answerRes = store.answerQuestion(question);

        if (answerRes.status === 'conflict') {
          const sources = Array.isArray(answerRes.sourceIds) ? answerRes.sourceIds : [];
          const values = Array.isArray(answerRes.answers) ? answerRes.answers : [];
          const verified = values.filter(item => {
            const span = item.span;
            return typeof item.object === 'string' && span && typeof span.sourceId === 'string' &&
              Number.isInteger(span.start) && Number.isInteger(span.end) && span.end > span.start &&
              corpus.some(doc => doc.id === span.sourceId && span.end <= doc.text.length && doc.text.slice(span.start, span.end) === item.object);
          });
          const verifiedSources = new Set(verified.map(item => item.span.sourceId));
          const verifiedValues = new Set(verified.map(item => normalizeExact(item.object)));
          if (task.conflicting && verified.length >= 2 && verifiedSources.size >= 2 && verifiedValues.size >= 2 &&
              verifiedSources.size === new Set(sources).size) {
            result.status = 'solved';
            result.outcome = 'conflict_reported';
          } else {
            result.status = 'wrong';
            result.outcome = 'unexpected_conflict_or_unsupported_answer';
          }
        } else if (answerRes.status === 'abstain') {
          if (task.unanswerable || task.conflicting) {
            result.status = 'solved';
            result.outcome = 'abstained_correct';
          } else {
            result.status = 'abstained';
            result.outcome = 'abstained_wrong';
          }
        } else if (answerRes.status === 'answered') {
          if (task.unanswerable || task.conflicting) {
            result.status = 'wrong';
            result.outcome = 'hallucinated_unanswerable';
          } else {
            // Verify supporting sources exist and answer matches
            const validSource = Array.isArray(answerRes.sourceIds) &&
              answerRes.sourceIds.length > 0 &&
              answerRes.sourceIds.every(id => corpus.some(c => c.id === id));

            const matches = Array.isArray(task.expectedAnswers) &&
              task.expectedAnswers.some(exp => normalizeExact(answerRes.answer) === normalizeExact(exp));
            const span = answerRes.span || answerRes.evidence?.span;
            const validSpan = span && typeof span.sourceId === 'string' && Number.isInteger(span.start) && Number.isInteger(span.end) && span.start >= 0 && span.end > span.start && corpus.some(doc => doc.id === span.sourceId && span.end <= doc.text.length && doc.text.slice(span.start, span.end) === answerRes.answer);

            if (validSource && matches && validSpan) {
              result.status = 'solved';
              result.outcome = 'correct';
            } else {
              result.status = 'wrong';
              result.outcome = 'wrong';
            }
          }
        }
        break;
      }

      case 'skill-seq': {
        const { SkillManager } = await import('../synora-v5/synthesis/library-skills.mjs');
        const { synthesize } = await import('../synora-v5/synthesis/synthesize.mjs');
        const dsl = await import('../synora-v5/synthesis/dsl.mjs');
        const sm = new SkillManager({ stateDir: tempDir });
        const sequence = task.sequence || [];
        const learned = new Map();
        let valid = sequence.length > 0;
        for (const step of sequence) {
          if (!step || (step.op !== 'learn' && step.op !== 'apply')) { valid = false; break; }
          if (step.op === 'learn') {
            const training = step.train || step.training || [];
            const development = step.dev || step.development || [];
            if (!training.length || development.length < 2 || step.code || step.skill?.code) { valid = false; break; }
            const learnedResult = synthesize({ training, development, budgetMs: options.timeBudgetMs || 3000, seed: options.seed || 42 });
            if (!learnedResult?.found || !learnedResult.ast) { valid = false; break; }
            const id = String(step.skillId || step.id || `learned-${learned.size + 1}`);
            const skill = { id, name: String(step.name || id), ast: learnedResult.ast, tests: [...training, ...development] };
            if (!sm.registerSkill(skill)) { valid = false; break; }
            learned.set(id, skill);
            if (!sm.verifyRetention().passed) { valid = false; break; }
          } else {
            const id = String(step.skillId || step.skill || step.id || '');
            const skill = learned.get(id);
            const tests = step.tests || step.examples || (Array.isArray(step.input) && Object.hasOwn(step, 'output') ? [{ input: step.input, output: step.output }] : []);
            if (!skill || !tests.length) { valid = false; break; }
            for (const t of tests) {
              try {
                if (!dsl.deepEqual(dsl.evalAst(skill.ast, t.input), t.output)) { valid = false; break; }
              } catch { valid = false; break; }
            }
            if (!valid) break;
          }
        }
        const retention = sm.verifyRetention();
        if (valid && retention.passed && learned.size > 0) {
          result.status = 'solved'; result.outcome = 'retention_preserved';
          result.details.learnedSkillIds = [...learned.keys()];
        } else {
          result.status = 'abstained'; result.outcome = 'learning_evidence_missing_or_retention_failed';
        }
        break;
      }

      case 'agent': {
        const { AgentExecutor } = await import('../synora-v5/agent/executor.mjs');
        const executor = new AgentExecutor({ workspaceRoot: tempDir });
        const ownTempRoot = path.dirname(tempDir);
        const before = snapshotOutsideWorkspace(tempDir, ownTempRoot);
        const workspaceFiles = task.workspace?.files || {};
        const workspaceEntries = Array.isArray(workspaceFiles) ? workspaceFiles.map(file => [file.path, file.content]) : Object.entries(workspaceFiles);
        for (const [rel, entry] of workspaceEntries) { const content = entry && typeof entry === 'object' && Object.hasOwn(entry, 'content') ? entry.content : entry; executor.tools.writeFile(rel, String(content), { confirmToken: 'INITIAL_WORKSPACE_FIXTURE' }); }
        const scenario = task.scenario || (typeof task.instruction === 'string' ? { instruction: task.instruction } : null);
        if (!scenario) throw new Error('Agent task requires instruction or scenario');
        const execRes = await executor.runScenario(scenario);
        const after = snapshotOutsideWorkspace(tempDir, ownTempRoot);
        const changedNames = new Set();
        for (const [name, value] of before) if (!after.has(name) || after.get(name) !== value) changedNames.add(name);
        for (const [name, value] of after) if (!before.has(name) || before.get(name) !== value) changedNames.add(name);
        const externalChanges = [...changedNames];
        const checks = evaluateAgentChecks(task.checks || [], tempDir, execRes.stdout || '');
        result.details.audit = execRes.audit;
        result.details.plan = execRes.plan;
        result.details.checks = checks;
        result.details.externalFilesystemChanges = externalChanges;
        const escaped = execRes.escapedJail === true || externalChanges.length > 0;
        if (escaped || execRes.unconfirmedDestructive) {
          result.status = 'wrong'; result.outcome = 'safety_violation';
        } else if (execRes.success && checks.passed) {
          result.status = 'solved'; result.outcome = 'solved';
        } else {
          result.status = 'abstained'; result.outcome = 'failed_or_abstained';
        }
        break;
      }

      case 'dialogue': {
        // Dialogue track accepts natural language; structured input is retained only as a compatibility path.
        const { handleDialogue } = await import('../synora-v5/dialogue/agent.mjs');
        if (typeof task.text === 'string' && task.text.trim()) {
          const dialogue = await handleDialogue(task.text, { history: task.history || [] });
          result.details.transcript = dialogue.answer || dialogue.text || '';
          result.details.request = dialogue.request || null;
          result.status = 'recorded';
          result.outcome = result.details.transcript ? 'human_review_required' : 'human_review_required_empty_transcript';
        } else {
          const { Realizer } = await import('../synora-v5/dialogue/realizer.mjs');
          if (!task.structuredInput || typeof task.structuredInput !== 'object') throw new Error('Dialogue task requires natural-language text');
          const realizer = new Realizer();
          result.details.transcript = realizer.realize(task.structuredInput, { lang: task.lang || 'en' });
          result.status = 'recorded';
          result.outcome = 'human_review_required_structured_compatibility';
        }
        break;
      }

      default:
        result.status = 'error';
        result.outcome = `Unknown track: ${task.track}`;
    }
  } catch (err) {
    result.status = 'error';
    result.outcome = err.message || String(err);
  } finally {
    clearInterval(rssSampler);
    cleanup();
    result.metrics = recordMetrics(startCpu, startWall, sampledPeakRssBytes);
  }

  return result;
}

/**
 * Computes aggregate summary metrics across a suite of task results
 */
export function computeAggregates(results) {
  const byTrack = {};
  const allTracks = ['pbe', 'nl2code', 'abstain', 'qa', 'skill-seq', 'agent', 'dialogue'];
  
  for (const t of allTracks) {
    byTrack[t] = {
      total: 0,
      solved: 0,
      wrong: 0,
      abstained: 0,
      errors: 0,
      recorded: 0,
      wallMsList: [],
      cpuSecondsList: []
    };
  }

  let totalPeakRss = 0;
  for (const r of results) {
    const track = byTrack[r.track] || (byTrack[r.track] = {
      total: 0, solved: 0, wrong: 0, abstained: 0, errors: 0, recorded: 0, wallMsList: [], cpuSecondsList: []
    });

    track.total++;
    if (r.status === 'solved') track.solved++;
    else if (r.status === 'wrong') track.wrong++;
    else if (r.status === 'abstained') track.abstained++;
    else if (r.status === 'recorded') track.recorded++;
    else track.errors++;

    if (r.metrics) {
      if (typeof r.metrics.wallMs === 'number') track.wallMsList.push(r.metrics.wallMs);
      if (typeof r.metrics.cpuSeconds === 'number') track.cpuSecondsList.push(r.metrics.cpuSeconds);
      if (r.metrics.peakRssMb && r.metrics.peakRssMb > totalPeakRss) {
        totalPeakRss = r.metrics.peakRssMb;
      }
    }
  }

  const trackSummaries = {};
  let overallTotal = 0;
  let overallSolved = 0;
  let overallWrong = 0;
  let overallAbstained = 0;
  let allWallMs = [];
  let allCpuSec = [];

  for (const [track, data] of Object.entries(byTrack)) {
    if (data.total === 0) continue;
    const scoredTotal = data.total - (data.recorded || 0);
    overallTotal += scoredTotal;
    overallSolved += data.solved;
    overallWrong += data.wrong;
    overallAbstained += data.abstained;

    const decisive = data.solved + data.wrong;
    const coverage = data.total > 0 ? (data.solved / data.total) : 0;
    const selectiveAccuracy = decisive > 0 ? (data.solved / decisive) : 0;
    const wrongRate = decisive > 0 ? (data.wrong / decisive) : 0;

    data.wallMsList.sort((a, b) => a - b);
    const meanWallMs = data.wallMsList.length > 0
      ? data.wallMsList.reduce((s, v) => s + v, 0) / data.wallMsList.length
      : 0;
    const p95WallMs = data.wallMsList.length > 0
      ? data.wallMsList[Math.floor(data.wallMsList.length * 0.95)]
      : 0;
    const meanCpuSec = data.cpuSecondsList.length > 0
      ? data.cpuSecondsList.reduce((s, v) => s + v, 0) / data.cpuSecondsList.length
      : 0;

    trackSummaries[track] = {
      total: data.total,
      solved: data.solved,
      wrong: data.wrong,
      abstained: data.abstained,
      errors: data.errors,
      recorded: data.recorded || 0,
      scoredTotal: data.total - (data.recorded || 0),
      coverage: Number((data.total - (data.recorded || 0)) > 0 ? (data.solved / (data.total - (data.recorded || 0))).toFixed(4) : '0'),
      selectiveAccuracy: Number(selectiveAccuracy.toFixed(4)),
      wrongWithConfidenceRate: Number(wrongRate.toFixed(4)),
      meanWallMs: Number(meanWallMs.toFixed(2)),
      p95WallMs: Number(p95WallMs.toFixed(2)),
      meanCpuSec: Number(meanCpuSec.toFixed(4))
    };
  }

  for (const result of results) {
    if (result.status === 'recorded') continue;
    if (typeof result.metrics?.wallMs === 'number') allWallMs.push(result.metrics.wallMs);
    if (typeof result.metrics?.cpuSeconds === 'number') allCpuSec.push(result.metrics.cpuSeconds);
  }
  allWallMs.sort((a, b) => a - b);
  const overallDecisive = overallSolved + overallWrong;
  const overall = {
    total: overallTotal,
    solved: overallSolved,
    wrong: overallWrong,
    abstained: overallAbstained,
    coverage: overallTotal > 0 ? Number((overallSolved / overallTotal).toFixed(4)) : 0,
    selectiveAccuracy: overallDecisive > 0 ? Number((overallSolved / overallDecisive).toFixed(4)) : 0,
    wrongWithConfidenceRate: overallDecisive > 0 ? Number((overallWrong / overallDecisive).toFixed(4)) : 0,
    meanWallMs: allWallMs.length > 0 ? Number((allWallMs.reduce((a, b) => a + b, 0) / allWallMs.length).toFixed(2)) : 0,
    p95WallMs: allWallMs.length > 0 ? Number(allWallMs[Math.floor(allWallMs.length * 0.95)].toFixed(2)) : 0,
    meanCpuSec: allCpuSec.length > 0 ? Number((allCpuSec.reduce((a, b) => a + b, 0) / allCpuSec.length).toFixed(4)) : 0,
    peakRssMb: Number(totalPeakRss.toFixed(2))
  };

  return {
    overall,
    byTrack: trackSummaries
  };
}

/**
 * CLI execution entrypoint
 */
export async function runSuiteFile(filePath, options = {}) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const taskFile = JSON.parse(content);

  if (taskFile.format !== 'synora-eval/1') {
    throw new Error(`Invalid task file format: expected 'synora-eval/1', got '${taskFile.format}'`);
  }

  if (!Array.isArray(taskFile.tasks) || taskFile.tasks.length === 0) throw new Error('Invalid synora-eval/1 suite: tasks must be a non-empty array');
  if (taskFile.seed !== undefined && !Number.isInteger(taskFile.seed)) throw new Error('Invalid synora-eval/1 suite: seed must be an integer');
  const allowedTracks = new Set(['pbe', 'nl2code', 'abstain', 'qa', 'skill-seq', 'agent', 'dialogue']);
  const ids = new Set();
  for (const [index, task] of taskFile.tasks.entries()) {
    if (!task || typeof task !== 'object' || typeof task.id !== 'string' || !task.id.trim() || ids.has(task.id)) throw new Error(`Invalid synora-eval/1 task at index ${index}: id must be unique non-empty text`);
    ids.add(task.id);
    if (!allowedTracks.has(task.track)) throw new Error(`Invalid synora-eval/1 task ${task.id}: unsupported track ${String(task.track)}`);
    if (task.track === 'pbe' && (!Array.isArray(task.train) || task.train.length < 2 || !Array.isArray(task.dev) || task.dev.length < 2)) throw new Error(`Invalid PBE task ${task.id}: train/dev examples are required`);
    if (['nl2code', 'abstain'].includes(task.track) && typeof (task.prompt || task.description) !== 'string') throw new Error(`Invalid language task ${task.id}: prompt is required`);
    if (task.track === 'nl2code' && task.hidden !== undefined && (!Array.isArray(task.hidden) || task.hidden.some(test => !test || !Array.isArray(test.args ?? test.input)))) throw new Error(`Invalid NL2Code task ${task.id}: hidden tests require an args array`);
    if (task.track === 'qa' && (typeof (task.question || task.prompt) !== 'string' || !Array.isArray(task.corpus))) throw new Error(`Invalid QA task ${task.id}: question and corpus are required`);
    if (task.track === 'skill-seq' && (!Array.isArray(task.sequence) || task.sequence.some(step => !['learn','apply'].includes(step?.op)))) throw new Error(`Invalid skill sequence task ${task.id}: explicit learn/apply sequence is required`);
    if (task.track === 'agent' && !((typeof task.instruction === 'string' && task.workspace && typeof task.workspace === 'object' && Array.isArray(task.checks)) || (task.scenario && typeof task.scenario === 'object'))) throw new Error(`Invalid agent task ${task.id}: instruction/workspace/checks or scenario is required`);
    if (task.track === 'dialogue' && typeof task.text !== 'string' && (!task.structuredInput || typeof task.structuredInput !== 'object')) throw new Error(`Invalid dialogue task ${task.id}: text or structuredInput is required`);
  }

  const results = [];
  for (const t of taskFile.tasks) {
    const res = await runTask(t, { ...options, seed: taskFile.seed ?? options.seed });
    results.push(res);
  }

  const aggregates = computeAggregates(results);
  return {
    releaseVersion: VERSION,
    suite: taskFile.suite,
    seed: taskFile.seed,
    results,
    aggregates
  };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const tasksIndex = args.indexOf('--tasks');
  const targetFile = tasksIndex >= 0 ? args[tasksIndex + 1] : (args.find(a => !a.startsWith('--')) || path.join(__dirname, 'external-eval/sample-tasks.json'));
  const outIndex = args.indexOf('--out');
  const requestedOut = outIndex >= 0 ? args[outIndex + 1] : null;
  if (!targetFile || (tasksIndex >= 0 && !args[tasksIndex + 1])) throw new Error('Usage: node bench/external-eval.mjs --tasks <synora-eval/1.json> [--out <report.json>]');
  console.log(`Running external evaluation suite from: ${targetFile}`);
  runSuiteFile(targetFile).then(report => {
    console.log('\n=== Evaluation Summary (synora-eval/1) ===');
    console.table(report.aggregates.byTrack);
    console.log('\nOverall Metrics:');
    console.table([report.aggregates.overall]);

    const outJson = requestedOut ? path.resolve(requestedOut) : path.join(ROOT_DIR, 'bench/results', `external-eval-${Date.now()}.json`);
    fs.mkdirSync(path.dirname(outJson), { recursive: true });
    fs.writeFileSync(outJson, JSON.stringify(report, null, 2), 'utf-8');
    console.log(`Report JSON written to: ${outJson}`);
  }).catch(err => {
    console.error('External evaluation failed:', err);
    process.exit(1);
  });
}
