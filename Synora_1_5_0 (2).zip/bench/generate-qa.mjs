/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const OUT_FILE = path.join(__dirname, 'qa-dataset.json');

export function generateQADataset() {
  const corpus = [];
  const questions = [];

  // 1. Answerable facts (130 questions: 65 EN + 65 AR)
  for (let i = 1; i <= 65; i++) {
    const docId = `doc-fact-en-${i}`;
    corpus.push({
      id: docId,
      title: `Scientific Fact EN ${i}`,
      text: `Element ${i} is classified as chemical element number ${i} in periodic table.`,
      licence: 'CC-BY-SA-4.0',
      url: `https://example.org/en/${i}`
    });
    questions.push({
      id: `qa-en-ans-${i}`,
      lang: 'en',
      question: `How is Element ${i} classified?`,
      type: 'answerable',
      expectedAnswers: [`chemical element number ${i}`],
      expectedSourceId: docId
    });
  }

  for (let i = 1; i <= 65; i++) {
    const docId = `doc-fact-ar-${i}`;
    corpus.push({
      id: docId,
      title: `معلومة علمية ${i}`,
      text: `العنصر ${i} يعتبر عنصرا كيميائيا برقم ${i} في الجدول الدوري.`,
      licence: 'CC-BY-SA-4.0',
      url: `https://example.org/ar/${i}`
    });
    questions.push({
      id: `qa-ar-ans-${i}`,
      lang: 'ar',
      question: `ما هو تصنيف العنصر ${i}؟`,
      type: 'answerable',
      expectedAnswers: [`برقم ${i}`],
      expectedSourceId: docId
    });
  }

  // 2. Unanswerable questions (50 questions: 25 EN + 25 AR = 25%)
  for (let i = 1; i <= 25; i++) {
    questions.push({
      id: `qa-en-unans-${i}`,
      lang: 'en',
      question: `What was the exact weather in Atlantis on day ${i}?`,
      type: 'unanswerable',
      expectedAnswers: []
    });
    questions.push({
      id: `qa-ar-unans-${i}`,
      lang: 'ar',
      question: `ما هي درجة الحرارة في مدينة أطلانتس في اليوم ${i}؟`,
      type: 'unanswerable',
      expectedAnswers: []
    });
  }

  // 3. Conflicting sources (20 questions: 10 EN + 10 AR = 10%)
  for (let i = 1; i <= 10; i++) {
    const srcA = `doc-conflict-en-${i}-a`;
    const srcB = `doc-conflict-en-${i}-b`;
    corpus.push({
      id: srcA,
      title: `Measurement A ${i}`,
      text: `Distance X${i} is exactly ${100 + i} meters according to laboratory Alpha.`,
      licence: 'CC-BY-SA-4.0',
      url: `https://example.org/alpha/${i}`
    });
    corpus.push({
      id: srcB,
      title: `Measurement B ${i}`,
      text: `Distance X${i} is exactly ${200 + i} meters according to laboratory Beta.`,
      licence: 'CC-BY-SA-4.0',
      url: `https://example.org/beta/${i}`
    });
    questions.push({
      id: `qa-en-conflict-${i}`,
      lang: 'en',
      question: `What is Distance X${i}?`,
      type: 'conflict',
      conflictSources: [srcA, srcB]
    });
  }

  for (let i = 1; i <= 10; i++) {
    const srcA = `doc-conflict-ar-${i}-a`;
    const srcB = `doc-conflict-ar-${i}-b`;
    corpus.push({
      id: srcA,
      title: `قياس أ ${i}`,
      text: `المسافة ص${i} تبلغ ${100 + i} مترا حسب المرصد الأول.`,
      licence: 'CC-BY-SA-4.0',
      url: `https://example.org/obs1/${i}`
    });
    corpus.push({
      id: srcB,
      title: `قياس ب ${i}`,
      text: `المسافة ص${i} تبلغ ${200 + i} مترا حسب المرصد الثاني.`,
      licence: 'CC-BY-SA-4.0',
      url: `https://example.org/obs2/${i}`
    });
    questions.push({
      id: `qa-ar-conflict-${i}`,
      lang: 'ar',
      question: `كم تبلغ المسافة ص${i}؟`,
      type: 'conflict',
      conflictSources: [srcA, srcB]
    });
  }

  const dataset = {
    version: '1.0.0',
    totalCorpus: corpus.length,
    totalQuestions: questions.length,
    corpus,
    questions
  };

  fs.writeFileSync(OUT_FILE, JSON.stringify(dataset, null, 2), 'utf-8');
  console.log(`Generated ${questions.length} questions (unanswerable: 50, conflict: 20) at ${OUT_FILE}`);
  return dataset;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  generateQADataset();
}
