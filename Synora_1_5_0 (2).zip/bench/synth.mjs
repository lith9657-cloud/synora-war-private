// Synora-Bench track 4: programming by example on the 12 operations V8.1 could not do (0/12).
// Protocol = a realistic user: gives a few natural examples; if the system asks a disambiguating question the user
// (the oracle below) answers it; at most 3 rounds. Hidden tests are never shown to the synthesizer.
import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { synthesize } from '../synora-v5/synthesis/synthesize.mjs';
import { deepEqual } from '../synora-v5/synthesis/dsl.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const isPrime = n => { if (n < 2) return false; for (let i = 2; i * i <= n; i++) if (n % i === 0) return false; return true; };
const gcd = (a, b) => b === 0 ? a : gcd(b, a % b);
const fib = n => { let a = 0, b = 1; for (let i = 0; i < n; i++) [a, b] = [b, a + b]; return a; };
const TASKS = [
  { id: 'min', oracle: a => Math.min(...a), tr: [[[3, 1, 2]], [[5, 9]], [[7]]], dv: [[[4, 2, 8]], [[10, -3, 6]]], hidden: [[[2, 9, 4]], [[-5, -1]], [[0, 3, -2, 8]], [[6]], [[100, 99]]] },
  { id: 'average', oracle: a => a.reduce((s, v) => s + v, 0) / a.length, tr: [[[2, 4]], [[10]], [[1, 2, 3, 4]]], dv: [[[6, 6, 6]], [[0, 10]]], hidden: [[[5, 15]], [[1, 2]], [[7, 8, 9]], [[0, 0, 4]]] },
  { id: 'count-even', oracle: a => a.filter(x => x % 2 === 0).length, tr: [[[1, 2, 3, 4]], [[2]], [[1, 3, 5]]], dv: [[[]], [[2, 4, 6, 7]]], hidden: [[[0, 1]], [[11, 13]], [[2, 2, 2, 2, 2]], [[-2, -3]], [[]]] },
  { id: 'is-prime', oracle: n => isPrime(n), tr: [[2], [4], [7], [1]], dv: [[9], [13]], hidden: [[0], [3], [15], [17], [25], [29]] },
  { id: 'fibonacci', oracle: n => fib(n), tr: [[0], [1], [5], [7]], dv: [[10], [2]], hidden: [[3], [4], [6], [8], [12]] },
  { id: 'reverse-string', oracle: s => [...s].reverse().join(''), tr: [['abc'], ['hello'], ['']], dv: [['xy'], ['a b']], hidden: [['stressed'], ['Madam'], ['  x'], ['ab cd']] },
  { id: 'palindrome', oracle: s => s === [...s].reverse().join(''), tr: [['level'], ['abc'], ['noon']], dv: [['ab'], ['']], hidden: [['racecar'], ['Abba'], ['xy'], ['a'], ['abca']] },
  { id: 'unique', oracle: a => [...new Set(a)], tr: [[[1, 1, 2]], [[3, 3, 3]], [[1, 2, 3]]], dv: [[[]], [[2, 1, 2]]], hidden: [[[7, 7, 8, 7, 9]], [[5]], [[1, 2, 1, 2, 3, 3]], [[0, 0]]] },
  { id: 'flatten', oracle: a => a.flat(1), tr: [[[[1], [2]]], [[[1, 2], [3]]], [[[], [4]]]], dv: [[[[5, 6]]], [[[], []]]], hidden: [[[[0], [], [5, 5]]], [[[1], [1], [1]]], [[[9, 8, 7]]], [[[], [2], []]]] },
  { id: 'gcd', oracle: (a, b) => gcd(a, b), tr: [[12, 18], [7, 13], [0, 5]], dv: [[100, 75], [9, 3]], hidden: [[8, 12], [17, 5], [20, 100], [0, 0], [6, 6]] },
  { id: 'second-largest', oracle: a => [...new Set(a)].sort((x, y) => y - x)[1], tr: [[[1, 5, 3]], [[9, 2, 7]], [[4, 8]]], dv: [[[10, 20, 30]], [[5, 6, 1]]], hidden: [[[9, 9, 4]], [[3, 1, 2, 2]], [[100, 50, 75]], [[1, 2]], [[8, 8, 8, 3]]] },
  { id: 'word-count', oracle: s => s.split(/\s+/).filter(Boolean).length, tr: [['hello world'], ['one'], ['a b c']], dv: [['']  , ['x  y']], hidden: [['the quick brown fox'], ['   '], [' lead and trail '], ['single']] }
];
const run = (source, args) => { const fn = vm.runInNewContext(source.replace(/^export\s+function\s+solution/, 'function solution') + '\nsolution', Object.create(null), { timeout: 200 }); return fn(...structuredClone(args)); };
const out = { bench: 'Synora-Bench v0 track 4: programming by example', date: new Date().toISOString(), node: process.version, protocol: { maxRounds: 3, maxSize: 10, budgetMs: 8000, maxExpressions: 400000, oracleAnswersUpTo: 3 }, rows: [] };
for (const t of TASKS) {
  const ex = (args) => ({ input: args, output: t.oracle(...args) });
  let training = t.tr.map(ex); const development = t.dv.map(ex);
  const row = { id: t.id, rounds: 0, questionsAsked: 0, status: null, reason: null, elapsedMs: 0, explored: 0, source: null };
  for (let round = 1; round <= 3; round++) {
    row.rounds = round;
    const r = synthesize({ training, development, maxSize: 10, budgetMs: 8000, maxExpressions: 400000 });
    row.elapsedMs += r.elapsedMs; row.explored += r.explored;
    if (r.found) {
      let ok = true; try { ok = t.hidden.every(args => deepEqual(run(r.source, args), t.oracle(...args))); } catch { ok = false; }
      row.status = ok ? 'solved' : 'wrong'; row.programSize = r.size; row.source = r.source.split('\n').filter(l => l.includes('return ')).pop().trim(); row.ambiguityCheck = r.ambiguityCheck; break;
    }
    if (r.reason === 'ambiguous-examples') {
      // A realistic user answers only questions about inputs where the task is defined (e.g. not min of an empty list).
      const qs = r.disambiguatingQueries.filter(q => { try { const o = t.oracle(...q.input); return !(o === undefined || (typeof o === 'number' && !Number.isFinite(o))); } catch { return false; } }).slice(0, 3);
      if (!qs.length) { row.status = 'not-found'; row.reason = 'ambiguous-only-on-inputs-where-task-is-undefined'; break; }
      row.questionsAsked += qs.length;
      training = [...training, ...qs.map(q => ex(q.input))];
      row.status = 'asked-again'; continue;
    }
    row.status = 'not-found'; row.reason = r.reason; break;
  }
  if (row.status === 'asked-again') { row.status = 'not-found'; row.reason = 'still-ambiguous-after-3-rounds'; }
  out.rows.push(row);
  console.log(row.id.padEnd(15), row.status.padEnd(10), `rounds=${row.rounds} questions=${row.questionsAsked} ${row.elapsedMs}ms`, row.status === 'solved' ? row.source : (row.reason ?? ''));
}
const n = out.rows.length, c = s => out.rows.filter(r => r.status === s).length;
out.summary = { operations: n, solved: c('solved'), wrong: c('wrong'), notFound: c('not-found'), solvedWithoutQuestions: out.rows.filter(r => r.status === 'solved' && r.questionsAsked === 0).length, totalQuestions: out.rows.reduce((a, r) => a + r.questionsAsked, 0), totalMs: out.rows.reduce((a, r) => a + r.elapsedMs, 0) };
fs.writeFileSync(path.join(here, 'results-synth-v8.2.json'), JSON.stringify(out, null, 2));
console.log(JSON.stringify(out.summary));
