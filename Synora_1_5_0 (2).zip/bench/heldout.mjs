// Synora-Bench v0b — prompts written AFTER the parser was patched and never used to tune it.
// (The v0 prompts in tasks.mjs were partly used to tune the lexicon, so they are no longer held-out for known ops.)
import vm from 'node:vm'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { handleDialogue } from '../synora-v5/dialogue/agent.mjs';
import { DigitalObjectLearner } from '../synora-v5/digital-object-learning/index.mjs';
import { DigitalObjectCore } from '../synora-v5/digital-object-core/index.mjs';
const T = (input, expected) => ({ input, expected });
const SUM = [T([[1,2,3,4]],10), T([[]],0), T([[-5,5]],0)], MAX = [T([[1,9,3]],9), T([[-3,-1,-7]],-1)], FACT = [T([0],1), T([6],720)], REV = [T([[1,2,3]],[3,2,1]), T([[]],[])], SORT = [T([[3,1,2]],[1,2,3]), T([[5,-1,0]],[-1,0,5])];
const paraphrases = [
  ['Can you write JavaScript that adds all the numbers in an array together?', SUM], ['I need a function returning the sum of a list of numbers', SUM],
  ['find the biggest value in an array', MAX], ['create a function that computes the factorial of a number', FACT],
  ['write code to reverse the elements of a list', REV], ['please give me a function that sorts a list of numbers in ascending order', SORT],
  ['arrange the numbers in a list from smallest to largest', SORT], ['function that gives the highest number in a list', MAX],
  ['اكتب دالة تحسب مجموع عناصر قائمة', SUM], ['اكتب دالة ترجع اكبر رقم في قائمة', MAX], ['اكتب دالة ترتب الاعداد من الاصغر الى الاكبر', SORT], ['اكتب دالة تعكس القائمة', REV]
].map(([prompt, hidden]) => ({ prompt, hidden }));
const traps = [
  ['write a function that returns the second largest number in an array', [T([[1,5,3]],3)]], ['write a function that sorts an array in descending order', [T([[1,3,2]],[3,2,1])]],
  ['write a function that sums the squares of the numbers in an array', [T([[1,2,3]],14)]], ['write a function that returns the maximum of two numbers', [T([3,9],9)]],
  ['write a function that reverses a string', [T(['abc'],'cba')]], ['write a function that sorts an array of strings alphabetically', [T([['b','a']],['a','b'])]],
  ['write a function that computes factorial using recursion', FACT], ['write a function that sums only the even numbers in an array', [T([[1,2,3,4]],6)]],
  ['write a function that returns the largest number in an array without using Math.max', MAX], ['اكتب دالة ترتب المصفوفة تنازليا', [T([[1,3,2]],[3,2,1])]],
  ['اكتب دالة تجمع الاعداد الزوجية فقط في مصفوفة', [T([[1,2,3,4]],6)]], ['write a function that returns the three largest numbers in an array', [T([[1,5,3,9]],[9,5,3])]]
].map(([prompt, hidden]) => ({ prompt, hidden }));
const same = (a, b) => Object.is(a, b) || (Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((v, i) => same(v, b[i])));
function pass(src, hidden) { try { const fn = new vm.Script(src.replace(/^export\s+function\s+solution/, 'function solution') + '\nsolution').runInContext(vm.createContext(Object.create(null), { codeGeneration: { strings: false, wasm: false } }), { timeout: 100 }); return hidden.every(t => same(vm.runInNewContext('fn(...a)', { fn, a: structuredClone(t.input) }, { timeout: 100 }), t.expected)); } catch { return false; } }
const learner = new DigitalObjectLearner({ id: 'b' }), core = new DigitalObjectCore();
async function score(list) { const rows = []; for (const x of list) { const r = await handleDialogue(x.prompt, { history: [], learner, core, source: 'bench' }); const src = r?.solution?.generated?.source; rows.push({ prompt: x.prompt, status: !src ? 'abstained' : pass(src, x.hidden) ? 'solved' : 'wrong' }); } return rows; }
const p = await score(paraphrases), t = await score(traps);
const c = (rows, s) => rows.filter(r => r.status === s).length;
const out = { bench: 'Synora-Bench v0b (held-out after patch)', paraphrases: { n: p.length, solved: c(p, 'solved'), wrong: c(p, 'wrong'), abstained: c(p, 'abstained') }, traps: { n: t.length, wrong: c(t, 'wrong'), abstained: c(t, 'abstained'), solvedCorrectly: c(t, 'solved') }, rows: { paraphrases: p, traps: t } };
fs.writeFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), 'results-heldout-v0b.json'), JSON.stringify(out, null, 2));
console.log(JSON.stringify({ paraphrases: out.paraphrases, traps: out.traps }, null, 1));
console.log('\nparaphrases not solved:'); p.filter(r => r.status !== 'solved').forEach(r => console.log(' -', r.status, '|', r.prompt));
console.log('traps with WRONG code:'); t.filter(r => r.status === 'wrong').forEach(r => console.log(' -', r.prompt));
