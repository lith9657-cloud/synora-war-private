#!/usr/bin/env node
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Regenerates the two saved NL2Code result artifacts from the current evaluator.
 *
 * The artifacts are part of the release contract: `tests/stage7/benchmark-artifact-consistency.test.mjs`
 * recomputes them and fails when a saved artifact is stale or was produced by a
 * different evaluator.
 *
 *   node bench/eval-nl2code-artifacts.mjs
 */
import fs from 'node:fs';
import { parseNLToCode } from '../synora-v5/nl2code/grammar.mjs';
import { executeAST } from '../synora-v5/nl2code/sanity-checks.mjs';
import { deepEqual } from '../synora-v5/synthesis/dsl.mjs';
import { VERSION } from '../synora-v5/version.mjs';

function score(items) {
  const out = { en: { total: 0, solved: 0, wrong: 0, abstained: 0 }, ar: { total: 0, solved: 0, wrong: 0, abstained: 0 } };
  const rows = [];
  for (const item of items) {
    const bucket = out[item.lang];
    bucket.total++;
    const result = parseNLToCode(item.prompt, { lang: item.lang });
    if (result.status !== 'ok' || !result.ast) {
      bucket.abstained++;
      rows.push({ id: item.id, status: 'abstained', reason: result.reason ?? null, unmodelled: result.unmodelled ?? [] });
      continue;
    }
    let pass = true;
    for (const hidden of item.hidden ?? []) {
      try {
        if (!deepEqual(executeAST(result.ast, hidden.input), hidden.output)) { pass = false; break; }
      } catch { pass = false; break; }
    }
    if (pass) { bucket.solved++; rows.push({ id: item.id, status: 'solved', reason: null, unmodelled: [] }); }
    else { bucket.wrong++; rows.push({ id: item.id, status: 'wrong', reason: result.reason ?? null, unmodelled: result.unmodelled ?? [] }); }
  }
  return { out, rows };
}

// ---- held-out split of the 840-prompt round-2 corpus -------------------------
const corpus = JSON.parse(fs.readFileSync('bench/nl2code-round2-corpus.json', 'utf8'));
const heldout = score(corpus.items.filter(item => item.split === 'test'));
const heldoutArtifact = {
  format: 'synora-nl2code-heldout/1',
  generatedAt: new Date().toISOString(),
  releaseVersion: VERSION,
  langs: heldout.out
};
fs.writeFileSync('bench/results/nl2code-round2-heldout.json', JSON.stringify(heldoutArtifact, null, 2) + '\n');

// ---- post-freeze set ----------------------------------------------------------
const postfreezeSet = JSON.parse(fs.readFileSync('bench/nl2code-postfreeze-set.json', 'utf8'));
const postfreeze = score(postfreezeSet.tasks);
const postfreezeArtifact = {
  format: 'synora-postfreeze-eval/1',
  codeFreezeDigest: postfreezeSet.codeFreezeDigest,
  style: postfreezeSet.style,
  metrics: postfreeze.out,
  rows: postfreeze.rows,
  generatedAt: new Date().toISOString(),
  releaseVersion: VERSION
};
fs.writeFileSync('bench/results/nl2code-postfreeze-eval.json', JSON.stringify(postfreezeArtifact, null, 2) + '\n');

console.log(JSON.stringify({
  heldout: heldout.out,
  postfreeze: postfreeze.out,
  codeFreezeDigest: postfreezeSet.codeFreezeDigest
}, null, 2));
