/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const OUT_FILE = path.join(__dirname, 'paraphrase-corpus.json');

const EN_OPERATIONS = [
  { op: 'sum', templates: ['calculate the sum of the numbers', 'find the total of the list', 'add up all elements in the array', 'give me the sum of all values'] },
  { op: 'sum_positive', templates: ['calculate the sum of positive numbers in the list', 'sum only positive integers', 'find total of numbers greater than zero', 'add up all positive elements'] },
  { op: 'average', templates: ['find the average of the elements', 'calculate the mean value', 'get the arithmetic mean of the list', 'compute the average'] },
  { op: 'sort_asc', templates: ['sort the list in ascending order', 'arrange elements from smallest to largest', 'order the numbers increasingly', 'sort ascending'] },
  { op: 'sort_desc', templates: ['sort the elements in descending order', 'arrange numbers from largest to smallest', 'order the list decreasingly', 'sort descending'] },
  { op: 'filter_even', templates: ['filter only even numbers', 'keep only even elements', 'extract all even values', 'get even integers'] },
  { op: 'filter_odd', templates: ['filter only odd numbers', 'keep only odd elements', 'extract all odd values', 'get odd integers'] },
  { op: 'filter_positive', templates: ['filter numbers greater than zero', 'keep positive numbers', 'extract positive values', 'select positive elements'] },
  { op: 'filter_negative', templates: ['filter numbers less than zero', 'keep negative numbers', 'extract negative values', 'select negative elements'] },
  { op: 'count_even', templates: ['count how many even numbers are in the list', 'number of even elements', 'count even integers', 'how many even values'] },
  { op: 'count_odd', templates: ['count how many odd numbers are in the list', 'number of odd elements', 'count odd integers', 'how many odd values'] },
  { op: 'count_positive', templates: ['count numbers greater than zero', 'how many positive numbers', 'number of positive values', 'count positive integers'] },
  { op: 'distinct', templates: ['return only distinct elements', 'remove duplicates from array', 'get unique values', 'deduplicate the list'] },
  { op: 'reverse', templates: ['reverse the order of the list', 'invert the array elements', 'flip the list', 'turn the list backwards'] },
  { op: 'max', templates: ['find the maximum value in the list', 'get the largest number', 'find highest element', 'what is the maximum'] },
  { op: 'min', templates: ['find the minimum value in the list', 'get the smallest number', 'find lowest element', 'what is the minimum'] }
];

const AR_OPERATIONS = [
  { op: 'sum', templates: ['احسب مجموع الأعداد في القائمة', 'أوجد حاصل جمع العناصر', 'اجمع كل أرقام المصفوفة', 'ما هو المجموع الكلي'] },
  { op: 'sum_positive', templates: ['احسب مجموع الأعداد الموجبة فقط', 'أوجد حاصل جمع العناصر الأكبر من الصفر', 'اجمع الأرقام الموجبة', 'مجموع القيم الموجبة فقط'] },
  { op: 'average', templates: ['احسب المتوسط الحسابي للعناصر', 'أوجد معدل الأعداد في القائمة', 'ما هو متوسط الأرقام', 'احسب معدل القيم'] },
  { op: 'sort_asc', templates: ['رتب القائمة تصاعديا', 'رتب العناصر من الأصغر إلى الأكبر', 'فرز الأعداد تصاعديا', 'قم بترتيب تصاعدي للأرقام'] },
  { op: 'sort_desc', templates: ['رتب العناصر تنازليا', 'رتب الأعداد من الأكبر إلى الأصغر', 'فرز الأرقام تنازليا', 'قم بترتيب تنازلي للقائمة'] },
  { op: 'filter_even', templates: ['استخرج الأعداد الزوجية', 'صفي القائمة للأرقام الزوجية فقط', 'احتفظ بالقيم الزوجية', 'أوجد كل الأعداد الزوجية'] },
  { op: 'filter_odd', templates: ['استخرج الأعداد الفردية', 'صفي القائمة للأرقام الفردية فقط', 'احتفظ بالقيم الفردية', 'أوجد كل الأعداد الفردية'] },
  { op: 'filter_positive', templates: ['استخرج الأعداد الموجبة فقط', 'صفي الأرقام الأكبر من الصفر', 'احتفظ بالأرقام الموجبة', 'أوجد كل قيمة موجبة'] },
  { op: 'filter_negative', templates: ['استخرج الأعداد السالبة فقط', 'صفي الأرقام الأصغر من الصفر', 'احتفظ بالأرقام السالبة', 'أوجد كل قيمة سالبة'] },
  { op: 'count_even', templates: ['كم عدد الأرقام الزوجية في القائمة', 'احسب عدد العناصر الزوجية', 'أوجد كم رقما زوجيا موجود', 'عد الأعداد الزوجية'] },
  { op: 'count_odd', templates: ['كم عدد الأرقام الفردية في القائمة', 'احسب عدد العناصر الفردية', 'أوجد كم رقما فرديا موجود', 'عد الأعداد الفردية'] },
  { op: 'count_positive', templates: ['كم عدد الأرقام الموجبة', 'احسب عدد العناصر الأكبر من الصفر', 'أوجد كم قيمة موجبة', 'عد الأعداد الموجبة'] },
  { op: 'distinct', templates: ['استخرج العناصر الفريدة دون تكرار', 'احذف التكرارات من القائمة', 'أوجد القيم غير المكررة', 'احذف المكرر'] },
  { op: 'reverse', templates: ['اعكس ترتيب عناصر القائمة', 'اقلب المصفوفة بالعكس', 'أوجد مقلوب ترتيب العناصر', 'اعكس القائمة'] },
  { op: 'max', templates: ['أوجد القيمة الكبرى في القائمة', 'ما هو أكبر عدد', 'استخرج أعلى قيمة', 'أوجد الحد الأقصى'] },
  { op: 'min', templates: ['أوجد القيمة الصغرى في القائمة', 'ما هو أصغر عدد', 'استخرج أدنى قيمة', 'أوجد الحد الأدنى'] }
];

function getHiddenTestsForOp(op) {
  switch (op) {
    case 'sum':
      return [{ input: [1, 2, 3], output: 6 }, { input: [10, -5], output: 5 }];
    case 'sum_positive':
      return [{ input: [1, -2, 3, -4], output: 4 }, { input: [-10, 20], output: 20 }];
    case 'average':
      return [{ input: [2, 4, 6], output: 4 }, { input: [10, 20], output: 15 }];
    case 'sort_asc':
      return [{ input: [3, 1, 2], output: [1, 2, 3] }, { input: [9, 5, 7], output: [5, 7, 9] }];
    case 'sort_desc':
      return [{ input: [3, 1, 2], output: [3, 2, 1] }, { input: [5, 9, 7], output: [9, 7, 5] }];
    case 'filter_even':
      return [{ input: [1, 2, 3, 4], output: [2, 4] }, { input: [5, 7], output: [] }];
    case 'filter_odd':
      return [{ input: [1, 2, 3, 4], output: [1, 3] }, { input: [2, 4], output: [] }];
    case 'filter_positive':
      return [{ input: [-1, 2, -3, 4], output: [2, 4] }, { input: [-5], output: [] }];
    case 'filter_negative':
      return [{ input: [-1, 2, -3, 4], output: [-1, -3] }, { input: [5], output: [] }];
    case 'count_even':
      return [{ input: [1, 2, 3, 4], output: 2 }, { input: [1, 3], output: 0 }];
    case 'count_odd':
      return [{ input: [1, 2, 3, 4], output: 2 }, { input: [2, 4], output: 0 }];
    case 'count_positive':
      return [{ input: [-1, 2, -3, 4], output: 2 }, { input: [-1], output: 0 }];
    case 'distinct':
      return [{ input: [1, 1, 2, 3, 3], output: [1, 2, 3] }, { input: [5], output: [5] }];
    case 'reverse':
      return [{ input: [1, 2, 3], output: [3, 2, 1] }, { input: [9, 8], output: [8, 9] }];
    case 'max':
      return [{ input: [1, 9, 3], output: 9 }, { input: [-1, -5], output: -1 }];
    case 'min':
      return [{ input: [1, 9, 3], output: 1 }, { input: [-1, -5], output: -5 }];
    default:
      return [{ input: [1, 2], output: [1, 2] }];
  }
}

export function buildCorpus() {
  const items = [];
  let idCounter = 1;

  // Generate 400 EN prompts
  const enVariations = ['please ', 'kindly ', 'i want to ', 'help me ', 'could you ', ''];
  const enEndings = ['', ' please', ' now', ' precisely', ' thank you'];

  for (let i = 0; i < 400; i++) {
    const opObj = EN_OPERATIONS[i % EN_OPERATIONS.length];
    const baseTpl = opObj.templates[i % opObj.templates.length];
    const prefix = enVariations[(i * 3) % enVariations.length];
    const suffix = enEndings[(i * 7) % enEndings.length];
    const prompt = (prefix + baseTpl + suffix).trim();

    // Assign split: 50% train, 20% dev, 30% test
    const split = (i % 10 < 5) ? 'train' : (i % 10 < 7) ? 'dev' : 'test';

    items.push({
      id: `en-${idCounter++}`,
      lang: 'en',
      op: opObj.op,
      prompt,
      split,
      hidden: getHiddenTestsForOp(opObj.op)
    });
  }

  // Generate 400 AR prompts
  const arVariations = ['من فضلك ', 'لو سمحت ', 'أريد أن ', 'قم بـ ', 'ممكن ', ''];
  const arEndings = ['', ' من فضلك', ' الآن', ' بالضبط', ' شكرا'];

  for (let i = 0; i < 400; i++) {
    const opObj = AR_OPERATIONS[i % AR_OPERATIONS.length];
    const baseTpl = opObj.templates[i % opObj.templates.length];
    const prefix = arVariations[(i * 3) % arVariations.length];
    const suffix = arEndings[(i * 7) % arEndings.length];
    const prompt = (prefix + baseTpl + suffix).trim();

    const split = (i % 10 < 5) ? 'train' : (i % 10 < 7) ? 'dev' : 'test';

    items.push({
      id: `ar-${idCounter++}`,
      lang: 'ar',
      op: opObj.op,
      prompt,
      split,
      hidden: getHiddenTestsForOp(opObj.op)
    });
  }

  const corpus = {
    version: '1.0.0',
    total: items.length,
    splits: {
      train: items.filter(x => x.split === 'train').length,
      dev: items.filter(x => x.split === 'dev').length,
      test: items.filter(x => x.split === 'test').length
    },
    items
  };

  fs.writeFileSync(OUT_FILE, JSON.stringify(corpus, null, 2), 'utf-8');
  console.log(`Paraphrase corpus generated at ${OUT_FILE}: ${items.length} items (${corpus.splits.test} test).`);
  return corpus;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  buildCorpus();
}
