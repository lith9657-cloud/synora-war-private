import fs from 'node:fs';
const corpus=[]; const questions=[];
const enNames=['Neral','Veyra','Oltis','Mavren','Keldor','Ruvan','Talora','Eshwin','Demer','Orvane','Luthen','Cavria','Pellor','Zentha','Mirel','Averin','Qorath','Belden','Sarn','Ilyra'];
const arNames=['نيرال','فيرا','أولتا','مافرين','كيلدور','روفان','تالورا','إشفين','ديمر','أورفان','لوثين','كافريا','بيلور','زينثا','ميريل','أفيرين','قوراث','بيلدن','سارن','إيليرا'];
const founders=['Mira Vale','Jonas Reed','Talia North','Oren Hale','Nadia Crest','Elias Venn','Rhea Sol','Kamil Daro','Lena Frost','Arin Moss'];
const places=['Neral Bay','Veyra Reach','Oltis Plain','Mavren Coast','Keldor Ridge','Ruvan Vale','Talora Port','Eshwin Basin','Demer Point','Orvane Isle'];
for(let i=0;i<40;i++){
 const name=`Archive ${enNames[i%enNames.length]}-${i+1}`; const founder=founders[i%founders.length]; const year=1840+i; const place=places[i%places.length];
 const id=`qa2-en-${i+1}`;
 corpus.push({id,title:`Registry entry ${name}`,text:`${name} was founded by ${founder} in ${year}. ${name} is located in ${place}.`,licence:'CC0-1.0'});
 const forms=[`Who established ${name}?`,`Who founded ${name}?`,`Name the founder of ${name}.`];
 questions.push({id:`qa2-en-who-${i+1}`,lang:'en',question:forms[i%3],type:'answerable',operation:'who-established',expectedAnswers:[founder],expectedSourceId:id});
 questions.push({id:`qa2-en-when-${i+1}`,lang:'en',question:i%2?`In what year was ${name} founded?`:`When was ${name} established?`,type:'answerable',operation:'when-founded',expectedAnswers:[String(year)],expectedSourceId:id});
 questions.push({id:`qa2-en-where-${i+1}`,lang:'en',question:i%2?`Where can ${name} be found?`:`Where is ${name} located?`,type:'answerable',operation:'where-located',expectedAnswers:[place],expectedSourceId:id});
}
for(let i=0;i<40;i++){
 const name=`أرشيف ${arNames[i%arNames.length]}-${i+1}`; const founder=['ميرا فال','يونس ريد','تاليا نور','عمر هيل','ناديا كريست','إلياس فين','ريا سول','كامل دارو'][i%8]; const year=1880+i; const place=['خليج نيرال','ساحل فيرا','سهل أولتا','ميناء مافرین','وادي كيلدور','مرتفعات روفان'][i%6]; const id=`qa2-ar-${i+1}`;
 corpus.push({id,title:`سجل ${name}`,text:`تأسس ${name} على يد ${founder} عام ${year}. ${name} يقع في ${place}.`,licence:'CC0-1.0'});
 questions.push({id:`qa2-ar-who-${i+1}`,lang:'ar',question:i%2?`من أسس ${name}؟`:`على يد من تأسس ${name}؟`,type:'answerable',operation:'who-established',expectedAnswers:[founder],expectedSourceId:id});
 questions.push({id:`qa2-ar-when-${i+1}`,lang:'ar',question:`متى تأسس ${name}؟`,type:'answerable',operation:'when-founded',expectedAnswers:[String(year)],expectedSourceId:id});
 questions.push({id:`qa2-ar-where-${i+1}`,lang:'ar',question:`أين يقع ${name}؟`,type:'answerable',operation:'where-located',expectedAnswers:[place],expectedSourceId:id});
}
for(let i=0;i<120;i++){
 const doc=i%2===0?`qa2-en-${(i%40)+1}`:`qa2-ar-${(i%40)+1}`;
 const name=i%2===0?`Archive ${enNames[(i/2|0)%enNames.length]}-${(i/2|0)+1}`:`أرشيف ${arNames[(i/2|0)%arNames.length]}-${(i/2|0)+1}`;
 const question=i%2===0?`What colour is the tower belonging to ${name}?`:`ما لون برج ${name}؟`;
 questions.push({id:`qa2-unanswerable-${i+1}`,lang:i%2===0?'en':'ar',question,type:'unanswerable',operation:'unanswerable-attribute'});
}
for(let i=0;i<20;i++){
 const name=`Distance Q${i+1}`; const a=101+i*3,b=203+i*3;
 corpus.push({id:`qa2-conf-en-${i+1}-a`,title:`Lab A ${name}`,text:`${name} is exactly ${a} meters according to Survey Laboratory Alpha.`,licence:'CC0-1.0'});
 corpus.push({id:`qa2-conf-en-${i+1}-b`,title:`Lab B ${name}`,text:`${name} is exactly ${b} meters according to Survey Laboratory Beta.`,licence:'CC0-1.0'});
 questions.push({id:`qa2-conf-en-${i+1}`,lang:'en',question:`What is ${name}?`,type:'conflict',operation:'conflicting-measurement'});
}
for(let i=0;i<20;i++){
 const name=`المسافة ر${i+1}`; const a=301+i*3,b=403+i*3;
 corpus.push({id:`qa2-conf-ar-${i+1}-a`,title:`قياس أ ${name}`,text:`${name} تبلغ ${a} مترا حسب مرصد ألفا.`,licence:'CC0-1.0'});
 corpus.push({id:`qa2-conf-ar-${i+1}-b`,title:`قياس ب ${name}`,text:`${name} تبلغ ${b} مترا حسب مرصد بيتا.`,licence:'CC0-1.0'});
 questions.push({id:`qa2-conf-ar-${i+1}`,lang:'ar',question:`كم تبلغ ${name}؟`,type:'conflict',operation:'conflicting-measurement'});
}
const out={format:'synora-qa/2',provenance:'Synthetic fictional corpus generated locally by bench/generate-qa-round2.mjs; no external world facts or model-generated labels.',corpus,questions};
fs.writeFileSync('bench/qa-round2-dataset.json',JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify({documents:corpus.length,questions:questions.length,types:questions.reduce((a,q)=>(a[q.type]=(a[q.type]||0)+1,a),{})},null,2));
