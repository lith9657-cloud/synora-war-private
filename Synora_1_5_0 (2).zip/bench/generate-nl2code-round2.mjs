import fs from 'node:fs';
const aggs=['sum','count','average','min','max'];
const predicates=[
  {id:'even',en:'even',ar:'الزوجية',test:x=>x%2===0},
  {id:'odd',en:'odd',ar:'الفردية',test:x=>Math.abs(x%2)===1},
  {id:'positive',en:'positive',ar:'الموجبة',test:x=>x>0},
  {id:'negative',en:'negative',ar:'السالبة',test:x=>x<0},
  {id:'gt5',en:'greater than five',ar:'الأكبر من خمسة',test:x=>x>5},
  {id:'gt3',en:'greater than three',ar:'الأكبر من ثلاثة',test:x=>x>3},
  {id:'lt5',en:'less than five',ar:'الأقل من خمسة',test:x=>x<5},
  {id:'lt3',en:'less than three',ar:'الأقل من ثلاثة',test:x=>x<3},
  {id:'gt0',en:'greater than zero',ar:'الأكبر من الصفر',test:x=>x>0},
  {id:'lt0',en:'less than zero',ar:'الأقل من الصفر',test:x=>x<0},
  {id:'gt7',en:'greater than seven',ar:'الأكبر من سبعة',test:x=>x>7},
  {id:'lt7',en:'less than seven',ar:'الأقل من سبعة',test:x=>x<7}
];
const enForms={
 sum:p=>[`sum ${p} numbers`,`calculate the sum of ${p} values`,`add the ${p} integers together`,`find the total for ${p} numbers`,`what is the sum of values that are ${p}`,`compute a sum over ${p} items`,`total the numbers that are ${p}`],
 count:p=>[`count ${p} numbers`,`how many values are ${p}`,`number of ${p} values`,`count the integers that are ${p}`,`find the number of values that are ${p}`,`how many numbers satisfy ${p}`,`calculate the count of ${p} items`],
 average:p=>[`average of ${p} numbers`,`calculate the mean of ${p} values`,`find the average among numbers that are ${p}`,`mean of the values that are ${p}`,`compute the average for ${p} integers`,`what is the mean of ${p} numbers`,`calculate an average over ${p} items`],
 min:p=>[`smallest ${p} number`,`find the minimum ${p} value`,`minimum among numbers that are ${p}`,`least ${p} integer`,`identify the lowest ${p} number`,`which ${p} value is smallest`,`minimum of the ${p} numbers`],
 max:p=>[`largest ${p} number`,`find the maximum ${p} value`,`maximum among numbers that are ${p}`,`greatest ${p} integer`,`identify the highest ${p} number`,`which ${p} value is largest`,`maximum of the ${p} numbers`]
};
const arForms={
 sum:p=>[`اجمع الأعداد ${p}`,`احسب مجموع القيم ${p}`,`ما حاصل جمع الأعداد ${p}؟`,`أوجد مجموع الأعداد التي تكون ${p}`,`اجمع القيم التي تحقق شرط ${p}`,`احسب حاصل جمع الأعداد ${p}`,`ما مجموع الأعداد ${p}؟`],
 count:p=>[`عدد القيم ${p}`,`احسب عدد الأعداد ${p}`,`كم قيمة تكون ${p}؟`,`ما عدد الأعداد التي تحقق ${p}؟`,`أوجد عدد العناصر ${p}`,`كم عدد القيم ${p}؟`,`احسب عدد الأعداد التي تكون ${p}`],
 average:p=>[`متوسط الأعداد ${p}`,`احسب معدل القيم ${p}`,`ما متوسط الأعداد التي تكون ${p}؟`,`أوجد المتوسط الحسابي للقيم ${p}`,`احسب متوسط العناصر ${p}`,`ما معدل الأعداد ${p}؟`,`متوسط القيم التي تحقق ${p}`],
 min:p=>[`أصغر عدد ${p}`,`أوجد أقل قيمة ${p}`,`ما الحد الأدنى للأعداد ${p}؟`,`حدد أصغر قيمة من الأعداد ${p}`,`أقل عدد يحقق ${p}`,`ما أصغر عنصر ${p}؟`,`أوجد القيمة الصغرى للأعداد ${p}`],
 max:p=>[`أكبر عدد ${p}`,`أوجد أعلى قيمة ${p}`,`ما الحد الأقصى للأعداد ${p}؟`,`حدد أكبر قيمة من الأعداد ${p}`,`أعلى عدد يحقق ${p}`,`ما أكبر عنصر ${p}؟`,`أوجد القيمة العظمى للأعداد ${p}`]
};
const ops=[];
for(const agg of aggs) for(const pred of predicates) ops.push({id:`${agg}_${pred.id}`,agg,pred});
const items=[];
function solve(agg,pred,xs){const ys=xs.filter(pred.test);if(agg==='sum')return ys.reduce((a,b)=>a+b,0);if(agg==='count')return ys.length;if(agg==='average')return ys.length?ys.reduce((a,b)=>a+b,0)/ys.length:null;if(agg==='min')return ys.length?Math.min(...ys):null;return ys.length?Math.max(...ys):null;}
const inputs=[[ -9,-5,-2,0,1,2,3,4,5,6,7,8,10 ],[0,0,2,2,3,5,5,8,-4],[ -7,-3,-1,1,3,7,9 ],[2,4,6,8,10 ],[-6,-4,-2,0,1,3,5,7]];
ops.forEach((op,oi)=>{
 const en=enForms[op.agg](op.pred.en), ar=arForms[op.agg](op.pred.ar);
 const split=oi<40?'train-dev':'test';
 for(let j=0;j<7;j++){
   const prompt=en[j], hidden=inputs.map(xs=>({input:[xs],output:solve(op.agg,op.pred,xs)})).filter(x=>x.output!==null);
   items.push({id:`nl2r2-${op.id}-en-${j+1}`,lang:'en',operation:op.id,prompt,split:split==='test'?'test':j<3?'train':'dev',hidden});
 }
 for(let j=0;j<7;j++){
   const prompt=ar[j], hidden=inputs.map(xs=>({input:[xs],output:solve(op.agg,op.pred,xs)})).filter(x=>x.output!==null);
   items.push({id:`nl2r2-${op.id}-ar-${j+1}`,lang:'ar',operation:op.id,prompt,split:split==='test'?'test':j<3?'train':'dev',hidden});
 }
});
const data={format:'synora-nl2code/2',provenance:'Locally authored finite paraphrase bank with 14 phrasing variants per operation (7 English, 7 Arabic); operations are composed from aggregation and predicate semantics. Test split holds out 20 complete operation IDs and is not embedded in production source.',operationCount:ops.length,heldOutOperationCount:ops.filter((_,i)=>i>=40).length,items};
fs.writeFileSync('bench/nl2code-round2-corpus.json',JSON.stringify(data,null,2)+'\n');
console.log(JSON.stringify({prompts:items.length,operations:ops.length,heldOutOperations:20,split:items.reduce((a,x)=>(a[x.split]=(a[x.split]||0)+1,a),{}),languages:items.reduce((a,x)=>(a[x.lang]=(a[x.lang]||0)+1,a),{})},null,2));
