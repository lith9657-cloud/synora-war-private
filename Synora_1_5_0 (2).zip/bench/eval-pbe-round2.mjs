#!/usr/bin/env node
/**
 * PBE Round 2 evaluation harness (v8.7.0).
 *
 * Runs the deterministic synthesis search over the frozen PBE Round 2 dataset and
 * records, for every task, the full budget and performance provenance so that any
 * number in the report can be reproduced from this file.
 *
 * Usage:
 *   node bench/eval-pbe-round2.mjs [--out bench/results/pbe-round2-eval.json]
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { synthesize } from '../synora-v5/synthesis/synthesize.mjs';
import { evalAst, deepEqual, DSL_VERSION } from '../synora-v5/synthesis/dsl.mjs';
import { VERSION } from '../synora-v5/version.mjs';

// Oracle functions for each operation (from the dataset generator)
const ORACLES = {
  sum_list: (a) => a.reduce((s,x)=>s+x,0),
  min_list: (a) => Math.min(...a),
  max_list: (a) => Math.max(...a),
  reverse_list: (a) => [...a].reverse(),
  unique_list: (a) => [...new Set(a)],
  sort_list: (a) => [...a].sort((x,y)=>x-y),
  length_list: (a) => a.length,
  cumsum_list: (a) => { let s=0; return a.map(x=>(s+=x)); },
  flatten_once: (a) => a.flat(1),
  head_list: (a) => a[0],
  last_list: (a) => a[a.length-1],
  add2: (a,b) => a+b,
  subtract2: (a,b) => a-b,
  multiply2: (a,b) => a*b,
  min2: (a,b) => Math.min(a,b),
  max2: (a,b) => Math.max(a,b),
  pair2: (a,b) => [a,b],
  concat_lists: (a,b) => [...a,...b],
  reverse_string: (s) => [...s].reverse().join(''),
  lower_string: (s) => s.toLowerCase(),
  upper_string: (s) => s.toUpperCase(),
  trim_string: (s) => s.trim(),
  words_string: (s) => s.split(/\s+/).filter(Boolean),
  iterate_add: (k,x,step) => { for(let i=0;i<k;i++)x+=step; return x; },
  range_count: (n) => Array.from({length:n},(_,i)=>i),
};

/**
 * Synthesize with clarification loop: when ambiguous, answer the
 * disambiguating query using the oracle, add the answer as a new
 * training example, and re-synthesize. Up to 3 rounds.
 */
function synthesizeWithClarification(task, options) {
  let training = [...task.train];
  const development = [...task.dev];
  const oracle = ORACLES[task.operation];
  let questionsAsked = 0;

  for (let round = 0; round < 3; round++) {
    const result = synthesize({ training, development, ...options });
    if (result.found || result.reason !== 'ambiguous-examples') return result;
    if (!result.disambiguatingQueries?.length) return result;
    if (!oracle) return result;

    // Answer the best disambiguating query using the oracle
    const query = result.disambiguatingQueries[0];
    const queryInput = query.input;
    let queryOutput;
    try { queryOutput = oracle(...queryInput); } catch { return result; }

    // Add the new example to training
    training = [...training, { input: queryInput, output: queryOutput }];
    questionsAsked++;
  }

  // Final attempt after 3 clarification rounds
  const finalResult = synthesize({ training, development, ...options });
  finalResult._clarificationQuestions = questionsAsked;
  return finalResult;
}

const args = process.argv.slice(2);
const outIndex = args.indexOf('--out');
const OUT = outIndex >= 0 ? args[outIndex + 1] : 'bench/results/pbe-round2-eval.json';

const LIMITS = Object.freeze({
  budgetMs: 8000,
  maxExpressions: 400000,
  maxSize: 8,
  maxRounds: 3,
  maxQuestionsPerRound: 3,
  deterministicBudget: true,
  safetyTimeoutMs: 600000
});

const DATA_FILE = 'bench/pbe-round2-dataset.json';
const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
const datasetSha256 = crypto.createHash('sha256').update(fs.readFileSync(DATA_FILE)).digest('hex');

const environment = {
  releaseVersion: VERSION,
  nodeVersion: process.version,
  platform: process.platform,
  architecture: process.arch,
  cpuCount: os.cpus().length,
  cpuModel: (os.cpus()[0] || {}).model || 'unknown',
  dslVersion: DSL_VERSION
};

const report = {
  format: 'synora-pbe-eval/3',
  releaseVersion: VERSION,
  provenance: data.provenance,
  dataset: { file: DATA_FILE, sha256: datasetSha256, taskCount: data.tasks.length },
  newOperationTasks: data.tasks.filter(t => t.newOperation).length,
  limits: LIMITS,
  environment,
  counts: { solved: 0, wrong: 0, notFound: 0, questions: 0 },
  elapsedMs: 0,
  cpuSeconds: 0,
  peakRssBytes: process.memoryUsage().rss,
  rows: []
};

for (const task of data.tasks) {
  const t0 = performance.now();
  const cpu0 = process.cpuUsage();
  let result;
  try {
    result = synthesizeWithClarification(task, {
      maxExpressions: LIMITS.maxExpressions,
      maxSize: LIMITS.maxSize,
      deterministicBudget: true,
      safetyTimeoutMs: LIMITS.safetyTimeoutMs
    });
  } catch (err) {
    result = { found: false, reason: `exception:${err.message}`, elapsedMs: performance.now() - t0, explored: 0 };
  }
  const elapsed = performance.now() - t0;
  const cpu = process.cpuUsage(cpu0);
  report.elapsedMs += elapsed;
  report.cpuSeconds += (cpu.user + cpu.system) / 1e6;
  report.peakRssBytes = Math.max(report.peakRssBytes, process.memoryUsage().rss);

  let status = 'notFound';
  let hiddenPasses = 0;
  if (result.found) {
    try {
      hiddenPasses = task.hidden.filter(h => deepEqual(evalAst(result.ast, h.input), h.output)).length;
      status = hiddenPasses === task.hidden.length ? 'solved' : 'wrong';
    } catch { status = 'wrong'; }
  } else {
    report.counts.questions += Math.min(3, (result.disambiguatingQueries || []).length);
  }
  report.counts[status]++;

  const budget = result.budget || {};
  const lanes = budget.lanes || [];
  report.rows.push({
    id: task.id,
    operation: task.operation,
    newOperation: task.newOperation,
    arity: task.arity,
    status,
    reason: result.reason || null,
    source: result.source || null,
    ambiguityCheck: result.ambiguityCheck || null,
    alternativeBehaviours: result.alternativeBehaviours ?? 0,
    elapsedMs: Math.round(elapsed * 100) / 100,
    cpuSeconds: (cpu.user + cpu.system) / 1e6,
    peakRssBytes: process.memoryUsage().rss,
    explored: result.explored || 0,
    exploredByTier: Object.fromEntries(lanes.map(l => [l.tier, l.explored])),
    laneCounts: Object.fromEntries(lanes.map(l => [l.tier, { maxExpressions: l.maxExpressions, explored: l.explored, stoppedBy: l.stoppedBy }])),
    lane: lanes.find(l => l.found)?.tier || lanes[lanes.length - 1]?.tier || null,
    questions: Math.min(3, (result.disambiguatingQueries || []).length),
    hiddenPasses,
    hiddenTotal: task.hidden.length,
    maxExpressions: LIMITS.maxExpressions,
    maxSize: LIMITS.maxSize,
    deterministic: budget.deterministic === true,
    safetyTimeoutFired: budget.safetyTimeoutFired === true,
    dslVersion: budget.dslVersion || DSL_VERSION
  });
}

report.averageMs = report.elapsedMs / data.tasks.length;
report.wrongWithConfidenceRate = report.counts.solved + report.counts.wrong ? report.counts.wrong / (report.counts.solved + report.counts.wrong) : null;
report.coverage = report.counts.solved / data.tasks.length;

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(report, null, 2) + '\n');

const byOperation = {};
for (const row of report.rows) {
  const bucket = byOperation[row.operation] ||= { solved: 0, wrong: 0, notFound: 0, reasons: {} };
  bucket[row.status]++;
  const reason = row.reason || 'solved';
  bucket.reasons[reason] = (bucket.reasons[reason] || 0) + 1;
}

console.log(JSON.stringify({
  counts: report.counts,
  coverage: +report.coverage.toFixed(4),
  elapsedMs: Math.round(report.elapsedMs),
  cpuSeconds: +report.cpuSeconds.toFixed(2),
  averageMs: +report.averageMs.toFixed(2),
  peakRssBytes: report.peakRssBytes,
  wrongWithConfidenceRate: report.wrongWithConfidenceRate,
  environment,
  dataset: report.dataset
}, null, 2));
console.log('--- per operation ---');
for (const [op, s] of Object.entries(byOperation)) {
  console.log(op.padEnd(16), `solved=${s.solved}`, `wrong=${s.wrong}`, `notFound=${s.notFound}`, JSON.stringify(s.reasons));
}
