import fs from 'node:fs';
const defs=[
 ['sum_list',1,'list',false,(a)=>a.reduce((s,x)=>s+x,0)],
 ['min_list',1,'list',false,(a)=>Math.min(...a)],
 ['max_list',1,'list',false,(a)=>Math.max(...a)],
 ['reverse_list',1,'list',false,(a)=>[...a].reverse()],
 ['unique_list',1,'list',false,(a)=>[...new Set(a)]],
 ['sort_list',1,'list',false,(a)=>[...a].sort((x,y)=>x-y)],
 ['length_list',1,'list',false,(a)=>a.length],
 ['cumsum_list',1,'list',true,(a)=>{let s=0;return a.map(x=>(s+=x))}],
 ['flatten_once',1,'nested-list',true,(a)=>a.flat(1)],
 ['head_list',1,'list',false,(a)=>a[0]],
 ['last_list',1,'list',false,(a)=>a[a.length-1]],
 ['add2',2,'numbers',false,(a,b)=>a+b],
 ['subtract2',2,'numbers',false,(a,b)=>a-b],
 ['multiply2',2,'numbers',false,(a,b)=>a*b],
 ['min2',2,'numbers',false,(a,b)=>Math.min(a,b)],
 ['max2',2,'numbers',false,(a,b)=>Math.max(a,b)],
 ['pair2',2,'numbers',false,(a,b)=>[a,b]],
 ['concat_lists',2,'lists',false,(a,b)=>[...a,...b]],
 ['reverse_string',1,'string',true,(s)=>[...s].reverse().join('')],
 ['lower_string',1,'string',true,(s)=>s.toLowerCase()],
 ['upper_string',1,'string',true,(s)=>s.toUpperCase()],
 ['trim_string',1,'string',true,(s)=>s.trim()],
 ['words_string',1,'string',true,(s)=>s.split(/\\s+/).filter(Boolean)],
 ['iterate_add',3,'iterate',true,(k,x,step)=>{for(let i=0;i<k;i++)x+=step;return x}],
 ['range_count',1,'range',true,(n)=>Array.from({length:n},(_,i)=>i)]
];
function inputs(kind, variant){
 const n=variant+1;
 if(kind==='list') return [[[n,-n,0,n+2,-n,3]],[[n+3,1,n,2,-1]],[[0,n+4,-n-2,2,2]]];
 if(kind==='nested-list') return [[[[n,n+1],[],[-n]]],[[[1,n],[n+2]]],[[[n],[n+1,n+2]]]];
 if(kind==='numbers') return [[n,n+2],[n*2,-n],[n+3,n-1]];
 if(kind==='lists') return [[[n,n+1],[n+2]],[[-n],[n,0]],[[1,n],[2,n+3]]];
 if(kind==='string') return [[`  Alpha ${n} beta  `],[`Gamma-${n} delta`],[`  MiXeD ${n}  `]];
 if(kind==='iterate') return [[n,n+1,2],[n+2,-n,1],[n+3,0,-1]];
 if(kind==='range') return [[n],[n+1],[n+2]];
 return [[n],[n+1],[n+2]];
}
const tasks=[];

function extraInput(kind, v, which) {
 const n=v+1;
 if(kind==='list') return which===0?[[v+5,-2,0,1]]:[[v+6,0,-3]];
 if(kind==='nested-list') return which===0?[[[v+1],[],[2]]]:[[[3,4],[5]]];
 if(kind==='numbers') return which===0?[v+4,3]:[v+7,-2];
 if(kind==='lists') return which===0?[[v+1],[2,v+3]]:[[3],[4,5]];
 if(kind==='string') return which===0?[` Test ${v} `]:[` x${v} Y `];
 if(kind==='iterate') return which===0?[v+2,2,3]:[v+3,1,2];
 return which===0?[v+3]:[v+4];
}
for(const [op,arity,kind,isNew,oracle] of defs){
 for(let v=0;v<6;v++){
  const samples=inputs(kind,v);
  const make=xs=>({input:xs,output:oracle(...xs)});
  const all=samples.map(make);
  const train=[...all.slice(0,3)];
  const dev=[make(extraInput(kind,v,0)), make(extraInput(kind,v,1))];
  const hidden=[make(kind==='list'?[[v+7,-5,4,4]]:kind==='nested-list'?[[[v+4],[],[v+5,v+6]]]:kind==='numbers'?[v+8,-3]:kind==='lists'?[[v+2,1],[v+4]]:kind==='string'?[`  Zed ${v} omega  `]:kind==='iterate'?[v+4,-2,4]:[v+5])];
  tasks.push({id:`pbe2-${op}-${v+1}`,operation:op,arity,newOperation:isNew,train,dev,hidden});
 }
}
const data={format:'synora-pbe/2',provenance:'Locally generated input/output examples from a fixed list of DSL-supported transformations; no production code lookup is keyed by task labels.',taskCount:tasks.length,newOperationCount:tasks.filter(t=>t.newOperation).length,operations:defs.map(x=>x[0]),tasks};
fs.writeFileSync('bench/pbe-round2-dataset.json',JSON.stringify(data,null,2)+'\n');
console.log(JSON.stringify({tasks:tasks.length,newOperations:tasks.filter(t=>t.newOperation).length,operations:defs.length,arity:tasks.reduce((a,t)=>(a[t.arity]=(a[t.arity]||0)+1,a),{}),types:defs.reduce((a,d)=>(a[d[2]]=(a[d[2]]||0)+6,a),{})},null,2));
