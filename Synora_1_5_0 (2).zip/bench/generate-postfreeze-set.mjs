import fs from 'node:fs';
const cases=[
 ['pf-en-01','en','Please compute the total for even integers.','sum',x=>x.filter(v=>v%2===0).reduce((a,b)=>a+b,0)],
 ['pf-en-02','en','How many values are odd?','count',x=>x.filter(v=>Math.abs(v%2)===1).length],
 ['pf-en-03','en','Identify the smallest even integer.','min',x=>Math.min(...x.filter(v=>v%2===0))],
 ['pf-en-04','en','Largest negative number?','max',x=>Math.max(...x.filter(v=>v<0))],
 ['pf-en-05','en','Sum the values greater than five.','sum',x=>x.filter(v=>v>5).reduce((a,b)=>a+b,0)],
 ['pf-en-06','en','Count the distinct values.','count',x=>new Set(x).size],
 ['pf-en-07','en','Minimum positive value.','min',x=>Math.min(...x.filter(v=>v>0))],
 ['pf-en-08','en','Greatest even number.','max',x=>Math.max(...x.filter(v=>v%2===0))],
 ['pf-en-09','en','Average the odd values.','average',x=>{const a=x.filter(v=>Math.abs(v%2)===1);return a.reduce((s,v)=>s+v,0)/a.length}],
 ['pf-en-10','en','Find the total of negative numbers.','sum',x=>x.filter(v=>v<0).reduce((a,b)=>a+b,0)],
 ['pf-ar-01','ar','اجمع الأعداد الزوجية.','sum',x=>x.filter(v=>v%2===0).reduce((a,b)=>a+b,0)],
 ['pf-ar-02','ar','ما متوسط القيم الموجبة؟','average',x=>{const a=x.filter(v=>v>0);return a.reduce((s,v)=>s+v,0)/a.length}],
 ['pf-ar-03','ar','كم عدد الأعداد الفردية؟','count',x=>x.filter(v=>Math.abs(v%2)===1).length],
 ['pf-ar-04','ar','أصغر عدد زوجي.','min',x=>Math.min(...x.filter(v=>v%2===0))],
 ['pf-ar-05','ar','أكبر عدد سالب.','max',x=>Math.max(...x.filter(v=>v<0))],
 ['pf-ar-06','ar','اجمع الأعداد الأكبر من خمسة.','sum',x=>x.filter(v=>v>5).reduce((a,b)=>a+b,0)],
 ['pf-ar-07','ar','عدد القيم المميزة.','count',x=>new Set(x).size],
 ['pf-ar-08','ar','أقل قيمة موجبة.','min',x=>Math.min(...x.filter(v=>v>0))],
 ['pf-ar-09','ar','أعلى عدد زوجي.','max',x=>Math.max(...x.filter(v=>v%2===0))],
 ['pf-ar-10','ar','متوسط الأعداد الفردية.','average',x=>{const a=x.filter(v=>Math.abs(v%2)===1);return a.reduce((s,v)=>s+v,0)/a.length}]
];
const inputs=[[1,2,3,4,5,6,8,-2,-3],[0,0,2,2,3,5,7,-4,-5],[9,-9,4,-4,1,11,-1]];
const tasks=cases.map(([id,lang,prompt,operation,oracle])=>({id,lang,prompt,operation,hidden:inputs.map(input=>({input:[input],output:oracle(input)}))}));
const data={format:'synora-nl2code-postfreeze/1',style:'post-freeze short imperatives, elliptical questions, and Arabic direct commands; distinct from the earlier multi-variant operation corpus.',codeFreezeDigest:JSON.parse(fs.readFileSync('bench/results/round2-code-freeze.json')).digest,tasks};
fs.writeFileSync('bench/nl2code-postfreeze-set.json',JSON.stringify(data,null,2)+'\n');
console.log(JSON.stringify({tasks:tasks.length,english:tasks.filter(x=>x.lang==='en').length,arabic:tasks.filter(x=>x.lang==='ar').length,operations:[...new Set(tasks.map(x=>x.operation))]},null,2));
