import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { handleDialogue } from '../synora-v5/dialogue/agent.mjs';
import { DigitalObjectLearner } from '../synora-v5/digital-object-learning/index.mjs';
import { DigitalObjectCore } from '../synora-v5/digital-object-core/index.mjs';
import { coding, mustNotClaim, skills } from './tasks.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const same = (a, b) => Object.is(a, b) || (Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((v, i) => same(v, b[i])));
function runHidden(source, hidden) {
  const code = source.replace(/^export\s+function\s+solution/, 'function solution') + '\nsolution';
  let fn;
  try { fn = new vm.Script(code).runInContext(vm.createContext(Object.create(null), { codeGeneration: { strings: false, wasm: false } }), { timeout: 100 }); } catch { return { pass: false, why: 'does-not-compile' }; }
  for (const t of hidden) {
    try { const out = vm.runInNewContext('fn(...args)', { fn, args: structuredClone(t.input) }, { timeout: 100 }); if (t.expectedError || !same(out, t.expected)) return { pass: false, why: 'wrong-output' }; }
    catch (e) { if (!t.expectedError) return { pass: false, why: 'threw' }; }
  }
  return { pass: true };
}
const learner = new DigitalObjectLearner({ id: 'bench' }); const core = new DigitalObjectCore();
const t0 = process.hrtime.bigint(); const cpu0 = process.cpuUsage();
const out = { bench: 'Synora-Bench v0', date: new Date().toISOString(), node: process.version, tracks: {} };

// Track 1
const rows = [];
for (const task of coding) for (let i = 0; i < task.prompts.length; i++) {
  const lang = /[\u0600-\u06FF]/.test(task.prompts[i]) ? 'ar' : 'en', variant = i === 0 ? 'canonical' : i === 1 ? 'paraphrase' : 'arabic';
  const r = await handleDialogue(task.prompts[i], { history: [], learner, core, source: 'bench' });
  const src = r?.solution?.generated?.source;
  let status;
  if (!src) status = 'abstained'; else status = runHidden(src, task.hidden).pass ? 'solved' : 'wrong';
  rows.push({ id: task.id, family: task.family, variant, lang, status, selfClaim: r?.solution?.status ?? null });
}
const agg = (f) => { const s = rows.filter(f); return { n: s.length, solved: s.filter(x => x.status === 'solved').length, wrong: s.filter(x => x.status === 'wrong').length, abstained: s.filter(x => x.status === 'abstained').length }; };
out.tracks.coding = { overall: agg(() => true), knownOp_canonical: agg(x => x.family === 'known-op' && x.variant === 'canonical'), knownOp_paraphrase: agg(x => x.variant === 'paraphrase'), knownOp_arabic: agg(x => x.lang === 'ar'), newOp: agg(x => x.family === 'new-op'), rows };

// Track 2
const t2 = [];
for (const p of mustNotClaim) { const r = await handleDialogue(p, { history: [], learner, core, source: 'bench' }); t2.push({ prompt: p, falseSuccess: Boolean(r?.solution?.status === 'tests-passed'), ok: r.ok }); }
out.tracks.falseSuccess = { n: t2.length, falseSuccessCount: t2.filter(x => x.falseSuccess).length, rows: t2 };

// Track 3
const t3 = [];
for (const s of skills) {
  const f = x => (s.a * x + s.b) % s.m;
  const tr = [0, 1, 2].map(x => ({ id: `t${x}`, input: x, output: f(x) })), dev = [3, 4].map(x => ({ id: `d${x}`, input: x, output: f(x) }));
  const res = learner.learnAffine({ name: s.name, modulus: s.m, training: tr, development: dev });
  let held = 0, ok = 0;
  if (res.accepted) for (let x = 5; x < s.m; x++) { held++; const a = learner.apply(res.skill.id, x); if (a.ok && a.output === f(x)) ok++; }
  t3.push({ name: s.name, accepted: Boolean(res.accepted), heldOut: held, heldOutCorrect: ok, reason: res.reason ?? null });
}
out.tracks.skillAcquisition = { n: t3.length, acceptedCount: t3.filter(x => x.accepted).length, heldOutAll: t3.reduce((a, x) => a + x.heldOut, 0), heldOutCorrect: t3.reduce((a, x) => a + x.heldOutCorrect, 0), rows: t3 };

const wallMs = Number(process.hrtime.bigint() - t0) / 1e6, cpu = process.cpuUsage(cpu0);
out.resources = { wallMs: +wallMs.toFixed(1), cpuUserMs: +(cpu.user / 1000).toFixed(1), cpuSystemMs: +(cpu.system / 1000).toFixed(1), peakRssMB: +(process.resourceUsage().maxRSS / 1024).toFixed(1), promptsRun: rows.length + t2.length };
fs.writeFileSync(path.join(here, process.argv[2] ?? 'results-latest.json'), JSON.stringify(out, null, 2));
const c = out.tracks.coding;
console.log(JSON.stringify({ coding_overall: c.overall, canonical_known: c.knownOp_canonical, paraphrase: c.knownOp_paraphrase, arabic: c.knownOp_arabic, new_ops: c.newOp, false_success: { n: t2.length, bad: out.tracks.falseSuccess.falseSuccessCount }, skills: { n: t3.length, accepted: out.tracks.skillAcquisition.acceptedCount, heldOut: `${out.tracks.skillAcquisition.heldOutCorrect}/${out.tracks.skillAcquisition.heldOutAll}` }, resources: out.resources }, null, 1));
