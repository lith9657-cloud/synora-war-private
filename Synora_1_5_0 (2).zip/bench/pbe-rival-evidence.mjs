#!/usr/bin/env node
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Records WHY a PBE task was not solved.
 *
 * For every operation that the deterministic search refuses, this script stores the
 * rival programs that fit the examples exactly as well as the chosen program and the
 * first input on which they disagree. A refusal is therefore auditable: it is either
 * a genuine ambiguity (a rival program exists) or a search limitation (the budget
 * was exhausted), and the two are never mixed up.
 *
 *   node bench/pbe-rival-evidence.mjs [--out bench/results/pbe-rival-evidence.json]
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { synthesize } from '../synora-v5/synthesis/synthesize.mjs';
import { VERSION } from '../synora-v5/version.mjs';

const args = process.argv.slice(2);
const outIndex = args.indexOf('--out');
const OUT = outIndex >= 0 ? args[outIndex + 1] : 'bench/results/pbe-rival-evidence.json';
const DATA_FILE = 'bench/pbe-round2-dataset.json';
const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
const datasetSha256 = crypto.createHash('sha256').update(fs.readFileSync(DATA_FILE)).digest('hex');

const LIMIT = { maxExpressions: 400000, maxSize: 8, deterministicBudget: true, safetyTimeoutMs: 600000 };

const byOperation = new Map();
for (const task of data.tasks) if (!byOperation.has(task.operation)) byOperation.set(task.operation, task);

const rows = [];
for (const [operation, task] of byOperation) {
  const started = Date.now();
  const result = synthesize({ training: task.train, development: task.dev, ...LIMIT });
  rows.push({
    operation,
    taskId: task.id,
    found: result.found === true,
    reason: result.reason || null,
    ambiguityCheck: result.ambiguityCheck || null,
    alternativeBehaviours: result.alternativeBehaviours ?? 0,
    explored: result.explored || 0,
    elapsedMs: Date.now() - started,
    // The rival programs: each of them fits every training and development example,
    // and `divergesAt` is the first input on which it disagrees with the chosen
    // program. This is the evidence that the refusal is a real ambiguity.
    rivals: (result.rivalEvidence || []).map(r => ({ source: r.source, size: r.size, divergesAt: r.divergesAt }))
  });
  console.log(`${operation.padEnd(16)} ${result.found ? 'solved' : 'refused'} ${result.reason} `
    + `rivals=${result.alternativeBehaviours ?? 0} explored=${result.explored}`);
}

const report = {
  format: 'synora-pbe-rival-evidence/1',
  releaseVersion: VERSION,
  dataset: { file: DATA_FILE, sha256: datasetSha256 },
  limits: LIMIT,
  summary: {
    operations: rows.length,
    solved: rows.filter(r => r.found).length,
    refused: rows.filter(r => !r.found).length,
    ambiguous: rows.filter(r => r.reason === 'ambiguous-examples').length,
    budgetExhausted: rows.filter(r => r.reason === 'search-budget-exhausted').length
  },
  rows
};
fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(report, null, 2) + '\n');
console.log(`\nrival evidence -> ${OUT}`);
console.log(JSON.stringify(report.summary));
