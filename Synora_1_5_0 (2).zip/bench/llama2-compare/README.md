# Llama 2 Comparison Kit — Evaluation Only

This directory creates prompts from any `synora-eval/1` task file and scores returned model outputs against the same hidden tests. It is not part of Synora runtime, training, skill learning, or serving. No Llama 2 result is supplied or implied.

## Status of the comparison in release 8.7.0

**Comparison not run.**

No Llama 2 checkpoint was executed in the 8.7.0 release environment: the environment has
no GPU, no model weights and no model access, and no Llama 2 output file exists in this
package. Therefore this release makes **no parity, superiority or equivalence claim**
against any language model. The kit below is the protocol that a comparison must follow;
the numbers a comparison would produce are unknown until it is executed.

The independent evaluation set that a comparison must use is
`bench/external-eval/independent-set.json` (28 tasks, SHA-256 recorded in
`bench/external-eval/independent-set.sha256`). A comparison run that uses a different
task set, a different scorer or different hidden checks is not comparable and must not
be reported next to the Synora numbers in `REPORT.md`.

## Reproducible workflow

1. Generate prompts:

   ```bash
   node bench/llama2-compare/make-prompts.mjs bench/external-eval/sample-tasks.json bench/llama2-compare/prompts.jsonl
   ```

2. Run a Llama 2 checkpoint in a free GPU notebook (Colab/Kaggle availability and model access vary). Use deterministic decoding where supported and write one JSONL record per task: `{"id":"...","output":"..."}`. For QA, the prompt requires exact JSON answer spans and source offsets; for code, return a `solution` JavaScript function.

3. Score using the isolated worker sandbox and exact QA span rules:

   ```bash
   node bench/llama2-compare/score-outputs.mjs bench/external-eval/sample-tasks.json outputs.jsonl
   ```

4. Preserve the prompts file, model identifier and revision, notebook, raw outputs, scorer version, and resulting JSON. Do not compare different task sets or hidden checks.

5. Record the outcome in this file (replacing the "Comparison not run" line above) and in
   `REPORT.md`, together with the exact commands, the model revision, the task-set digest
   and the scorer output. Until that happens, the comparison does not exist.

The scorer measures only tracks with machine-checkable outputs. Dialogue and agent outputs are retained for human review, not assigned invented automatic quality scores. Unsupported or malformed answers are not counted as correct. QA requires exact normalized answer text plus a valid source ID and character offsets; conflict tasks require at least two distinct supporting sources.

## Published Llama 2 reference numbers (not Synora measurements)

These are published paper values only and are not a substitute for a same-task comparison:

| Benchmark | 7B | 13B | 34B | 70B |
|---|---:|---:|---:|---:|
| HumanEval pass@1 | 12.8 | 18.3 | 22.6 | 29.9 |
| MBPP | 20.8 | 30.6 | 33.0 | 45.0 |
| MMLU | 45.3 | — | — | 68.9 |

Do not place these values beside Synora scores as if they were measured on identical tasks. No comparison run is claimed by this package.
