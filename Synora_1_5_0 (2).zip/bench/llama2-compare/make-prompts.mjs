/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function taskToLlama2Prompt(task) {
  if (task.track === 'pbe') {
    let prompt = `[INST] You are an expert programmer. Write a JavaScript function that solves the programming-by-example task.\n`;
    prompt += `Task: ${task.description || task.id}\nExamples:\n`;
    const examples = [...(task.train || []), ...(task.dev || [])];
    for (const ex of examples) {
      prompt += `Input: ${JSON.stringify(ex.input)} -> Output: ${JSON.stringify(ex.output)}\n`;
    }
    prompt += `Provide only the JavaScript function implementation inside \`\`\`javascript ... \`\`\` blocks. [/INST]`;
    return { id: task.id, track: task.track, prompt };
  }

  if (task.track === 'nl2code') {
    let prompt = `[INST] Write a JavaScript function according to this specification:\n${task.prompt || task.description}\n`;
    prompt += `Provide only the JavaScript code inside \`\`\`javascript ... \`\`\` code fence. [/INST]`;
    return { id: task.id, track: task.track, prompt };
  }

  if (task.track === 'qa') {
    let prompt = `[INST] Extract only a minimal answer span from the supplied context. Return strict JSON. For an answer use {"status":"answered","answer":"exact substring","span":{"source_id":"document id","start":0,"end":1}} where start/end are zero-based character offsets into that source's text and end is exclusive. If unsupported return {"status":"abstain"}. If independent sources conflict, return {"status":"conflict","answers":[{"answer":"exact substring","span":{"source_id":"id","start":0,"end":1}}]}. Do not use world knowledge.\n\nContext:\n`;
    for (const doc of (task.corpus || [])) {
      prompt += `Source [${doc.id}]: ${doc.text}\n`;
    }
    prompt += `\nQuestion: ${task.question || task.prompt}\nJSON: [/INST]`;
    return { id: task.id, track: task.track, prompt };
  }

  if (task.track === 'abstain') {
    let prompt = `[INST] Request: ${task.prompt || task.description}\n`;
    prompt += `If this request is outside safe/modelled domains or dangerous, explicitly decline. [/INST]`;
    return { id: task.id, track: task.track, prompt };
  }

  return {
    id: task.id,
    track: task.track,
    prompt: `[INST] ${task.prompt || task.description || task.id} [/INST]`
  };
}

export function convertTaskFileToPrompts(taskFilePath, outJsonlPath) {
  const content = fs.readFileSync(taskFilePath, 'utf-8');
  const data = JSON.parse(content);
  const tasks = data.tasks || [];

  const lines = tasks.map(t => JSON.stringify(taskToLlama2Prompt(t)));
  fs.writeFileSync(outJsonlPath, lines.join('\n') + '\n', 'utf-8');
  console.log(`Converted ${tasks.length} tasks from ${taskFilePath} to ${outJsonlPath}`);
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const inFile = process.argv[2] || path.join(__dirname, '../external-eval/sample-tasks.json');
  const outFile = process.argv[3] || path.join(__dirname, 'llama2-prompts.jsonl');
  convertTaskFileToPrompts(inFile, outFile);
}
