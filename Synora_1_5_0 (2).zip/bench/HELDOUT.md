# Held-Out Evaluation Discipline & Data Hygiene

## 1. Split Definitions & Partitioning
To guarantee zero data contamination and prevent overfitting to benchmarks:

| Dataset / Track | Total Tasks | Dev / Train Split | Held-Out Test Split | Usage Protocol |
| :--- | :--- | :--- | :--- | :--- |
| **PBE Benchmark (`bench/synth.mjs`)** | 12 | 12 | 0 | Public baseline benchmark for comparison with v8.2.0. |
| **Extended PBE Suite (`tests/stage7/`)** | 160 | 60 train/dev | 100 sealed | Synthesizer coverage and ambiguity gate tests. |
| **NL2Code Paraphrase Corpus** | 800 (400 EN + 400 AR) | 480 (60%) | 320 (40% held-out) | Grammar & lexicon design strictly uses train/dev only. |
| **Knowledge Store QA** | 220 (EN + AR) | 120 | 100 held-out | QA evaluation across answerable, conflicting, unanswerable. |
| **External Evaluation (`synora-eval/1`)** | 30+ sample | 0 | 100% unseen | Sealed external evaluation harness for independent validation. |

## 2. Anti-Leak Verification
A static enforcement test (`tests/stage7/anti-leak.test.mjs`) automatically scans all source code and lexicons under `synora-v5/**`.
The test extracts:
- All benchmark task IDs
- Prompt strings and descriptions
- Expected outputs and hidden tests

The build fails with non-zero exit code if any held-out prompt or answer appears hardcoded in `synora-v5/**`.
