# Synora External Evaluation — `synora-eval/1`

The evaluator accepts a JSON file with this top-level shape:

```json
{
  "format": "synora-eval/1",
  "suite": "independent-suite-name",
  "seed": 42,
  "tasks": []
}
```

Every task has a unique non-empty `id` and one `track` from `pbe`, `nl2code`, `abstain`, `qa`, `skill-seq`, `agent`, or `dialogue`.

## Track contracts

- `pbe`: `train` and `dev` are arrays of `{ "input": [...], "output": ... }`; `hidden` is evaluator-only; `answers` may be either an array of `{ "input": [...], "output": ... }` (also accepts `query` + `expected`) or an object keyed by `JSON.stringify(input)`. Only answers from this pool can resolve clarification questions. At most three questions per round and three rounds are allowed.
- `nl2code`: `prompt`, optional `lang`, and `hidden` tests containing `args` (the JavaScript function argument array) and `output`. The evaluator executes the emitted JavaScript in the worker sandbox; it does not score only the internal AST.
- `abstain`: `prompt` and optional `lang`; accepted only when the language parser abstains.
- `qa`: `question`, `corpus`, `expectedAnswers`, and optional `unanswerable`. A correct answer must be an exact normalized expected span, cite a real source, and include character offsets matching the source text.
- `skill-seq`: `sequence` contains explicit `{ "op": "learn", "train": [...], "dev": [...] }` and `{ "op": "apply", "skillId": "...", "tests": [...] }` steps. Supplied code is rejected. Earlier learned skills are rechecked after subsequent learning.
- `agent`: `instruction`, `workspace: { "files": { "relative/path": "initial content" } }`, and `checks`. Supported check types are `file-equals`, `file-absent`, `file-unchanged`, and `stdout-contains`. Instructions are parsed against a closed verb grammar; unconsumed text is rejected. Destructive operations require confirmation.
- `dialogue`: free-form `text` and optional `history`. Outputs are transcripts for human review; this track is recorded but deliberately excluded from automatic quality scores.

## Running

```sh
node bench/external-eval.mjs --tasks path/to/tasks.json --out path/to/report.json
```

The positional task-file form remains supported for compatibility. The shipped `sample-tasks.json` contains at least 40 tasks across all seven tracks. It is a smoke suite, not evidence of general-language competence.

## Metrics caveat

Wall time and parent-process CPU time are measured per task. `peakRssMb` is a 10 ms sampled peak of the evaluator parent process; it excludes worker/child-process RSS and may miss shorter spikes. Do not interpret it as total system peak memory.
