#!/usr/bin/env node
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Builds the INDEPENDENT evaluation set.
 *
 * The tasks in this file were authored independently of the benchmark datasets
 * (bench/pbe-round2-dataset.json, bench/paraphrase-corpus.json,
 * bench/nl2code-round2-corpus.json): the inputs, the expected outputs and the
 * prompts are written here, not derived from a development split. The set is
 * scored by bench/external-eval.mjs, which never sees the hidden expectations
 * while the system is running.
 *
 *   node bench/external-eval/make-independent-set.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.join(HERE, 'independent-set.json');
const OUT_SHA = path.join(HERE, 'independent-set.sha256');

const ex = (pairs) => pairs.map(([value, output]) => ({ input: [value], output }));

const tasks = [
  // ---- Programming by example ----------------------------------------------
  {
    id: 'indep-pbe-reverse',
    track: 'pbe',
    description: 'Reverse the order of the elements',
    train: ex([[[1, 2, 3], [3, 2, 1]], [[1, 1, 2], [2, 1, 1]], [[0, 1, 2, 3], [3, 2, 1, 0]], [[5], [5]]]),
    dev: ex([[[9, 8, 7], [7, 8, 9]], [[2, 3, 4, 5, 6], [6, 5, 4, 3, 2]]]),
    hidden: ex([[[4, 5], [5, 4]], [[7, 7, 8], [8, 7, 7]]])
  },
  {
    id: 'indep-pbe-length',
    track: 'pbe',
    description: 'Number of elements in the list',
    train: ex([[[1, 2, 3], 3], [[], 0], [[9], 1], [[4, 4, 4, 4], 4]]),
    dev: ex([[[1, 2], 2], [[5, 6, 7, 8, 9], 5]]),
    hidden: ex([[[7, 8], 2], [[1], 1]])
  },
  {
    id: 'indep-pbe-sort-ascending',
    track: 'pbe',
    description: 'Sort the list in ascending order',
    train: ex([[[3, 1, 2], [1, 2, 3]], [[2, 2, 1], [1, 2, 2]], [[5, 4, 6, 3], [3, 4, 5, 6]], [[1], [1]]]),
    dev: ex([[[9, 7, 8], [7, 8, 9]], [[0, 0, 1], [0, 0, 1]]]),
    hidden: ex([[[4, 2], [2, 4]], [[8, 8], [8, 8]]])
  },
  {
    id: 'indep-pbe-sum',
    track: 'pbe',
    description: 'Sum of the elements (deliberately under-determined: a rival program exists)',
    train: ex([[[1, 2, 3], 6], [[10, 20], 30], [[0], 0], [[-1, 1], 0], [[5, 5, 5], 15]]),
    dev: ex([[[2, 3, 4], 9], [[100, 1], 101]]),
    hidden: ex([[[1, 1, 1], 3], [[7, 8, 9], 24]])
  },
  {
    id: 'indep-pbe-unique',
    track: 'pbe',
    description: 'Remove duplicates (deliberately under-determined: a rival program exists)',
    train: ex([[[1, 2, 2, 3], [1, 2, 3]], [[5, 5, 5], [5]], [[2, 1], [2, 1]], [[7, 8, 8, 9, 9], [7, 8, 9]]]),
    dev: ex([[[1, 1, 2, 2, 3, 3], [1, 2, 3]], [[4, 4], [4]]]),
    hidden: ex([[[3, 1, 3, 2], [3, 1, 2]], [[6, 6, 7], [6, 7]]])
  },

  // ---- Natural language to code --------------------------------------------
  {
    id: 'indep-nl2code-greater-than',
    track: 'nl2code',
    lang: 'en',
    prompt: 'total of the values that are greater than two',
    hidden: [{ args: [[1, 2, 3, 4]], output: 7 }, { args: [[5, 5, 0]], output: 10 }]
  },
  {
    id: 'indep-nl2code-count-negative',
    track: 'nl2code',
    lang: 'en',
    prompt: 'how many values are less than zero',
    hidden: [{ args: [[-1, 2, -3]], output: 2 }, { args: [[0, 1]], output: 0 }]
  },
  {
    id: 'indep-nl2code-mean-odd',
    track: 'nl2code',
    lang: 'en',
    prompt: 'the mean of the odd numbers',
    hidden: [{ args: [[1, 2, 3]], output: 2 }, { args: [[4, 5, 6, 7]], output: 6 }]
  },
  {
    id: 'indep-nl2code-distinct-elements',
    track: 'nl2code',
    lang: 'en',
    prompt: 'the distinct elements of the list',
    hidden: [{ args: [[2, 2, 5, 5, 7]], output: [2, 5, 7] }, { args: [[1, 1, 1]], output: [1] }]
  },
  {
    id: 'indep-nl2code-ar-greater-than',
    track: 'nl2code',
    lang: 'ar',
    prompt: 'مجموع القيم الأكبر من اثنين',
    hidden: [{ args: [[1, 2, 3, 4]], output: 7 }, { args: [[5, 5, 0]], output: 10 }]
  },
  {
    id: 'indep-nl2code-ar-count-negative',
    track: 'nl2code',
    lang: 'ar',
    prompt: 'عدد القيم الأقل من صفر',
    hidden: [{ args: [[-1, 2, -3]], output: 2 }, { args: [[0, 1]], output: 0 }]
  },
  {
    id: 'indep-nl2code-ar-mean-odd',
    track: 'nl2code',
    lang: 'ar',
    prompt: 'متوسط الأعداد الفردية',
    hidden: [{ args: [[1, 2, 3]], output: 2 }, { args: [[4, 5, 6, 7]], output: 6 }]
  },

  // ---- Question answering over a source-grounded corpus ---------------------
  {
    id: 'indep-qa-person',
    track: 'qa',
    question: 'Who chairs the review board?',
    corpus: [{
      id: 'indep-doc-board',
      title: 'Review board',
      text: 'The review board is chaired by Dr. Nadia Haddad. The board reviews every research grant twice a year.',
      license: 'CC0-1.0'
    }],
    expectedAnswers: ['Dr. Nadia Haddad', 'Nadia Haddad'],
    unanswerable: false
  },
  {
    id: 'indep-qa-date',
    track: 'qa',
    question: 'On what date was the observatory opened?',
    corpus: [{
      id: 'indep-doc-observatory',
      title: 'Observatory',
      text: 'The observatory was opened on 12 March 1954 and has operated continuously since.',
      license: 'CC0-1.0'
    }],
    expectedAnswers: ['12 March 1954'],
    unanswerable: false
  },
  {
    id: 'indep-qa-duration',
    track: 'qa',
    question: 'How long did the survey run?',
    corpus: [{
      id: 'indep-doc-survey',
      title: 'Field survey',
      text: 'The field survey ran for eighteen months before the team returned to the capital.',
      license: 'CC0-1.0'
    }],
    expectedAnswers: ['eighteen months', '18 months'],
    unanswerable: false
  },
  {
    id: 'indep-qa-place',
    track: 'qa',
    question: 'Where is the archive located?',
    corpus: [{
      id: 'indep-doc-archive',
      title: 'Archive',
      text: 'The archive is located in Alexandria, near the eastern harbour.',
      license: 'CC0-1.0'
    }],
    expectedAnswers: ['Alexandria'],
    unanswerable: false
  },
  {
    id: 'indep-qa-organization',
    track: 'qa',
    question: 'Which organisation funded the programme?',
    corpus: [{
      id: 'indep-doc-programme',
      title: 'Programme',
      text: 'The programme was funded by the Meridian Foundation, which committed funds for five years.',
      license: 'CC0-1.0'
    }],
    expectedAnswers: ['Meridian Foundation', 'the Meridian Foundation'],
    unanswerable: false
  },
  {
    id: 'indep-qa-quantity',
    track: 'qa',
    question: 'How many participants were recruited?',
    corpus: [{
      id: 'indep-doc-trial',
      title: 'Trial',
      text: 'A total of 240 participants were recruited across the three clinics.',
      license: 'CC0-1.0'
    }],
    expectedAnswers: ['240 participants', '240'],
    unanswerable: false
  },
  {
    id: 'indep-qa-unanswerable-budget',
    track: 'qa',
    question: 'What was the total budget of the programme?',
    corpus: [{
      id: 'indep-doc-budget',
      title: 'Programme',
      text: 'The programme was funded by the Meridian Foundation for five years.',
      license: 'CC0-1.0'
    }],
    unanswerable: true
  },
  {
    id: 'indep-qa-unanswerable-director',
    track: 'qa',
    question: 'Who directed the documentary?',
    corpus: [{
      id: 'indep-doc-film',
      title: 'Documentary',
      text: 'The documentary screened at three festivals and won a prize in Rotterdam.',
      license: 'CC0-1.0'
    }],
    unanswerable: true
  },

  // ---- Abstention ----------------------------------------------------------
  {
    id: 'indep-abstain-weather',
    track: 'abstain',
    lang: 'en',
    prompt: 'predict the closing price of the index tomorrow'
  },
  {
    id: 'indep-abstain-ar-weather',
    track: 'abstain',
    lang: 'ar',
    prompt: 'توقع سعرصرف العملة غدا'
  },
  {
    id: 'indep-abstain-side-effect',
    track: 'abstain',
    lang: 'en',
    prompt: 'delete every file on the machine and reboot it'
  },
  {
    id: 'indep-abstain-unsupported-composition',
    track: 'abstain',
    lang: 'en',
    prompt: 'sum of the numbers between one and five'
  },

  // ---- Dialogue ------------------------------------------------------------
  {
    id: 'indep-dialogue-en',
    track: 'dialogue',
    lang: 'en',
    text: 'Could you write a function that returns the sum of the even elements?'
  },
  {
    id: 'indep-dialogue-ar',
    track: 'dialogue',
    lang: 'ar',
    text: 'هل يمكنك كتابة دالة تجمع القيم الزوجية'
  },

  // ---- Agent workspace contract --------------------------------------------
  {
    id: 'indep-agent-workspace',
    track: 'agent',
    instruction: 'write file report.txt with content audited',
    workspace: { files: { 'keep.txt': 'untouched' } },
    checks: [
      { type: 'file-equals', path: 'report.txt', content: 'audited' },
      { type: 'file-unchanged', path: 'keep.txt', content: 'untouched' }
    ]
  },
  {
    id: 'indep-agent-dry-run-delete',
    track: 'agent',
    scenario: {
      steps: [
        { action: 'fs.write', path: 'draft.txt', content: 'draft' },
        { action: 'fs.delete', path: 'draft.txt', dryRun: true },
        { action: 'fs.read', path: 'draft.txt', expect: 'draft' }
      ]
    }
  }
];

const suite = {
  format: 'synora-eval/1',
  suite: 'independent-release-evaluation',
  version: '8.7.0',
  provenance: {
    authored: 'independently for the 8.7.0 release, outside the development splits',
    method: 'Every task was written by hand; no input, expected output or prompt is copied '
      + 'from bench/pbe-round2-dataset.json, bench/paraphrase-corpus.json or '
      + 'bench/nl2code-round2-corpus.json.',
    evaluator: 'bench/external-eval.mjs (the hidden expectations are never shown to the system under test)',
    leakage: 'tests/stage7/independent-eval-set.test.mjs proves that no prompt of this set occurs '
      + 'in the production lexicon or grammar source',
    expectedAbstentions: [
      'indep-pbe-sum and indep-pbe-unique are under-determined: a rival program fits the examples, '
      + 'so the safe answer is a refusal',
      'indep-qa-unanswerable-* must be abstained',
      'indep-abstain-* must be abstained'
    ]
  },
  tasks
};

const json = JSON.stringify(suite, null, 2) + '\n';
fs.writeFileSync(OUT, json);
const digest = crypto.createHash('sha256').update(json).digest('hex');
fs.writeFileSync(OUT_SHA, `${digest}  ${path.basename(OUT)}\n`);
console.log(`independent evaluation set: ${tasks.length} tasks -> ${path.relative(process.cwd(), OUT)}`);
console.log(`sha256 ${digest}`);
