/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synora HumanEval-style benchmark — 20 programming problems adapted to
 * Synora's DSL. Each problem has: prompt, examples, hidden tests, expected
 * operation. Measures Pass@1 (does the synthesized program pass all hidden
 * tests on the first attempt).
 */
import { synthesize } from '../synora-v5/synthesis/synthesize.mjs';
import { evalAst, deepEqual } from '../synora-v5/synthesis/dsl.mjs';

// Oracle functions keyed by problem prompt — used to answer disambiguating queries
const ORACLES = {
  'sum of a list of numbers': (a) => a.reduce((s,x)=>s+x,0),
  'length of a list': (a) => a.length,
  'maximum of a list': (a) => Math.max(...a),
  'minimum of a list': (a) => Math.min(...a),
  'reverse a list': (a) => [...a].reverse(),
  'sort a list ascending': (a) => [...a].sort((x,y)=>x-y),
  'unique elements of a list': (a) => [...new Set(a)],
  'cumulative sum of a list': (a) => { let s=0; return a.map(x=>(s+=x)); },
  'first element of a list': (a) => a[0],
  'last element of a list': (a) => a[a.length-1],
  'add two numbers': (a,b) => a+b,
  'subtract two numbers': (a,b) => a-b,
  'multiply two numbers': (a,b) => a*b,
  'pair two numbers': (a,b) => [a,b],
  'concatenate two lists': (a,b) => [...a,...b],
  'flatten a nested list': (a) => a.flat(1),
  'range from 0 to n': (n) => Array.from({length:n},(_,i)=>i),
  'tail of a list (all but first)': (a) => a.slice(1),
  'init of a list (all but last)': (a) => a.slice(0,-1),
  'absolute value': (a) => Math.abs(a),
  'double each element': (a) => a.map(x=>x*2),
  'second element': (a) => a[1],
  'third element': (a) => a[2],
  'drop first two': (a) => a.slice(2),
  'drop last two': (a) => a.slice(0,-2),
  'take first three': (a) => a.slice(0,3),
  'take first two': (a) => a.slice(0,2),
  'sum of squares': (a) => a.reduce((s,x)=>s+x*x,0),
  'product of list': (a) => a.reduce((p,x)=>p*x,1),
  'count elements': (a) => a.length,
  'swap first and last': (a) => { if(a.length<2) return [...a]; const r=[...a]; [r[0],r[r.length-1]]=[r[r.length-1],r[0]]; return r; },
  'square each element': (a) => a.map(x=>x*x),
  'negate each element': (a) => a.map(x=>-x),
  'increment each': (a) => a.map(x=>x+1),
  'decrement each': (a) => a.map(x=>x-1),
  'max of two numbers': (a,b) => Math.max(a,b),
  'min of two numbers': (a,b) => Math.min(a,b),
  'double a number': (a) => a*2,
  'triple a number': (a) => a*3,
  'halve a number': (a) => a/2,
  'negate a number': (a) => -a,
  'first three of list': (a) => a.slice(0,3),
  'last three of list': (a) => a.slice(-3),
  'middle element': (a) => a[Math.floor(a.length/2)],
};

const PROBLEMS = [
  { id: 'he-001', prompt: 'sum of a list of numbers', train: [[ [1,2,3,4], 10], [[5,5,5], 15], [[-1,1], 0]], dev: [[[10,20], 30], [[0], 0]], hidden: [[[100,200,300], 600], [[1,2,3,4,5], 15]] },
  { id: 'he-002', prompt: 'length of a list', train: [[[1,2,3], 3], [[1], 1], [[], 0]], dev: [[[1,2,3,4,5], 5], [[7,8,9], 3]], hidden: [[[10,20,30,40,50,60], 6], [[0], 1]] },
  { id: 'he-003', prompt: 'maximum of a list', train: [[[1,2,3], 3], [[5,5,5], 5], [[-1,0,1], 1]], dev: [[[10,20,30], 30], [[7,8,9], 9]], hidden: [[[100,200,300], 300], [[-5,-1,-10], -1]] },
  { id: 'he-004', prompt: 'minimum of a list', train: [[[1,2,3], 1], [[5,5,5], 5], [[-1,0,1], -1]], dev: [[[10,20,30], 10], [[7,8,9], 7]], hidden: [[[100,200,300], 100], [[-5,-1,-10], -10]] },
  { id: 'he-005', prompt: 'reverse a list', train: [[[1,2,3], [3,2,1]], [[5,0], [0,5]], [[7], [7]]], dev: [[[10,20,30,40], [40,30,20,10]], [[1,2], [2,1]]], hidden: [[[9,8,7,6,5], [5,6,7,8,9]], [[1], [1]]] },
  { id: 'he-006', prompt: 'sort a list ascending', train: [[[3,1,2], [1,2,3]], [[5,5,1], [1,5,5]], [[7], [7]]], dev: [[[10,5,20], [5,10,20]], [[1,2,3], [1,2,3]]], hidden: [[[9,3,6,1,8], [1,3,6,8,9]], [[5], [5]]] },
  { id: 'he-007', prompt: 'unique elements of a list', train: [[[1,1,2,2,3], [1,2,3]], [[5,5,5], [5]], [[1,2,3], [1,2,3]]], dev: [[[10,10,20], [10,20]], [[7,7,7,7], [7]]], hidden: [[[1,2,1,3,1], [1,2,3]], [[100,100,200,200], [100,200]]] },
  { id: 'he-008', prompt: 'cumulative sum of a list', train: [[[1,2,3], [1,3,6]], [[5,5], [5,10]], [[7], [7]]], dev: [[[10,20,30], [10,30,60]], [[1,1,1,1], [1,2,3,4]]], hidden: [[[100,200,300], [100,300,600]], [[0], [0]]] },
  { id: 'he-009', prompt: 'first element of a list', train: [[[1,2,3], 1], [[5,0], 5], [[7], 7]], dev: [[[10,20,30], 10], [[-1,0,1], -1]], hidden: [[[100,200], 100], [[42], 42]] },
  { id: 'he-010', prompt: 'last element of a list', train: [[[1,2,3], 3], [[5,0], 0], [[7], 7]], dev: [[[10,20,30], 30], [[-1,0,1], 1]], hidden: [[[100,200], 200], [[42], 42]] },
  { id: 'he-011', prompt: 'add two numbers', arity: 2,
    train: [ [[3,4], 7], [[1,2], 3], [[5,5], 10] ],
    dev: [ [[10,20], 30], [[0,0], 0] ],
    hidden: [ [[100,200], 300], [[-1,1], 0] ] },
  { id: 'he-012', prompt: 'subtract two numbers', arity: 2,
    train: [ [[10,3], 7], [[5,2], 3], [[0,0], 0] ],
    dev: [ [[20,5], 15], [[1,1], 0] ],
    hidden: [ [[100,30], 70], [[10,20], -10] ] },
  { id: 'he-013', prompt: 'multiply two numbers', arity: 2,
    train: [ [[3,4], 12], [[2,5], 10], [[0,9], 0] ],
    dev: [ [[5,6], 30], [[1,1], 1] ],
    hidden: [ [[10,20], 200], [[7,7], 49] ] },
  { id: 'he-019', prompt: 'pair two numbers', arity: 2,
    train: [ [[3,4], [3,4]], [[1,2], [1,2]], [[5,6], [5,6]] ],
    dev: [ [[5,6], [5,6]], [[0,0], [0,0]] ],
    hidden: [ [[10,20], [10,20]], [[7,9], [7,9]] ] },
  { id: 'he-014', prompt: 'concatenate two lists', arity: 2,
    train: [ [[[1,2],[3,4]], [1,2,3,4]], [[[5],[6]], [5,6]], [[[1],[2]], [1,2]] ],
    dev: [ [[[10,20],[30]], [10,20,30]], [[[1],[1]], [1,1]] ],
    hidden: [ [[[10,20],[30,40]], [10,20,30,40]] ] },
  { id: 'he-015', prompt: 'flatten a nested list',
    train: [ [[[1,2],[3,4]], [1,2,3,4]], [[[5],[6]], [5,6]], [[[1,2,3]], [1,2,3]] ],
    dev: [ [[[10,20],[30]], [10,20,30]], [[[1],[2],[3]], [1,2,3]] ],
    hidden: [ [[[100],[200,300]], [100,200,300]] ] },
  { id: 'he-016', prompt: 'range from 0 to n',
    train: [ [[3], [0,1,2]], [[5], [0,1,2,3,4]], [[1], [0]] ],
    dev: [ [[7], [0,1,2,3,4,5,6]], [[2], [0,1]] ],
    hidden: [ [[10], [0,1,2,3,4,5,6,7,8,9]] ] },
  { id: 'he-017', prompt: 'tail of a list (all but first)',
    train: [ [[1,2,3], [2,3]], [[5,0], [0]], [[7], []] ],
    dev: [ [[10,20,30], [20,30]], [[1,2], [2]] ],
    hidden: [ [[9,8,7,6], [8,7,6]] ] },
  { id: 'he-018', prompt: 'init of a list (all but last)',
    train: [ [[1,2,3], [1,2]], [[5,0], [5]], [[7], []] ],
    dev: [ [[10,20,30], [10,20]], [[1,2], [1]] ],
    hidden: [ [[9,8,7,6], [9,8,7]] ] },
  { id: 'he-020', prompt: 'absolute value', train: [[[-5], 5], [[5], 5], [[0], 0]], dev: [[[-10], 10], [[10], 10]], hidden: [[[-100], 100], [[100], 100]] },
  { id: 'he-021', prompt: 'double each element', train: [[[1,2,3], [2,4,6]], [[5,0], [10,0]], [[7], [14]]], dev: [[[10,20], [20,40]], [[-1], [-2]]], hidden: [[[100,200], [200,400]]] },
  { id: 'he-023', prompt: 'second element', train: [[[1,2,3], 2], [[5,0,9], 0], [[7,8], 8]], dev: [[[10,20,30], 20], [[-1,0,1], 0]], hidden: [[[100,200], 200]] },
  { id: 'he-024', prompt: 'third element', train: [[[1,2,3], 3], [[5,0,9], 9], [[7,8,9,10], 9]], dev: [[[10,20,30], 30], [[0,1,2], 2]], hidden: [[[9,8,7,6,5], 7]] },
  { id: 'he-025', prompt: 'drop first two', train: [[[1,2,3,4,5], [3,4,5]], [[5,0,9], [9]], [[7,8], []]], dev: [[[10,20,30,40], [30,40]], [[1,2,3], [3]]], hidden: [[[9,8,7,6,5,4], [7,6,5,4]]] },
  { id: 'he-026', prompt: 'drop last two', train: [[[1,2,3,4,5], [1,2,3]], [[5,0,9], [5]], [[7,8], []]], dev: [[[10,20,30,40], [10,20]], [[1,2,3], [1]]], hidden: [[[9,8,7,6,5,4], [9,8,7,6]]] },
  { id: 'he-027', prompt: 'take first three', train: [[[1,2,3,4,5], [1,2,3]], [[5,0,9,8], [5,0,9]], [[7,8,9], [7,8,9]]], dev: [[[10,20,30,40,50], [10,20,30]], [[1,2], [1,2]]], hidden: [[[9,8,7,6,5,4,3], [9,8,7]]] },
  { id: 'he-028', prompt: 'take first two', train: [[[1,2,3,4,5], [1,2]], [[5,0,9,8], [5,0]], [[7], [7]]], dev: [[[10,20,30], [10,20]], [[1], [1]]], hidden: [[[9,8,7,6,5], [9,8]]] },
  { id: 'he-033', prompt: 'sum of squares', train: [[[1,2,3], 14], [[0,1], 1], [[2,2], 8]], dev: [[[3,4], 25], [[1,1,1], 3]], hidden: [[[5,5,5], 75]] },
  { id: 'he-034', prompt: 'product of list', train: [[[1,2,3], 6], [[2,2,2], 8], [[1], 1]], dev: [[[3,4], 12], [[1,1,1,1], 1]], hidden: [[[2,3,4], 24]] },
  { id: 'he-035', prompt: 'count elements', train: [[[1,2,3], 3], [[1], 1], [[], 0]], dev: [[[1,2,3,4,5], 5], [[7,8,9], 3]], hidden: [[[10,20,30,40,50,60], 6]] },
  { id: 'he-037', prompt: 'first three of list', train: [[[1,2,3,4,5], [1,2,3]], [[5,0,9,8], [5,0,9]], [[7,8,9], [7,8,9]]], dev: [[[10,20,30,40,50], [10,20,30]], [[1,2], [1,2]]], hidden: [[[9,8,7,6,5,4,3], [9,8,7]]] },
  { id: 'he-038', prompt: 'last three of list', train: [[[1,2,3,4,5], [3,4,5]], [[5,0,9,8], [0,9,8]], [[7,8,9], [7,8,9]]], dev: [[[10,20,30,40,50], [30,40,50]], [[1,2,3], [1,2,3]]], hidden: [[[9,8,7,6,5,4,3], [5,4,3]]] },
  { id: 'he-039', prompt: 'middle element', train: [[[1,2,3], 2], [[5,0,9], 0], [[7,8,9,10,11], 9]], dev: [[[10,20,30], 20], [[0,1,2], 1]], hidden: [[[9,8,7,6,5,4,3], 6]] },
  { id: 'he-040', prompt: 'swap first and last', train: [[[1,2,3], [3,2,1]], [[5,0], [0,5]], [[7], [7]]], dev: [[[10,20,30], [30,20,10]], [[1,2], [2,1]]], hidden: [[[9,8,7,6,5], [5,8,7,6,9]]] },
  { id: 'he-041', prompt: 'square each element', train: [[[1,2,3], [1,4,9]], [[0,1], [0,1]], [[2,2], [4,4]]], dev: [[[3,4], [9,16]], [[1,1,1], [1,1,1]]], hidden: [[[5,5,5], [25,25,25]]] },
  { id: 'he-042', prompt: 'negate each element', train: [[[1,2,3], [-1,-2,-3]], [[-5,0], [5,0]], [[7], [-7]]], dev: [[[10,20], [-10,-20]], [[-1,1], [1,-1]]], hidden: [[[100,200], [-100,-200]]] },
  { id: 'he-043', prompt: 'increment each', train: [[[1,2,3], [2,3,4]], [[0,0], [1,1]], [[-1,0], [0,1]]], dev: [[[10,20], [11,21]], [[5,5,5], [6,6,6]]], hidden: [[[100,200], [101,201]]] },
  { id: 'he-044', prompt: 'decrement each', train: [[[2,3,4], [1,2,3]], [[1,1], [0,0]], [[0,-1], [-1,-2]]], dev: [[[10,20], [9,19]], [[5,5,5], [4,4,4]]], hidden: [[[100,200], [99,199]]] },
  { id: 'he-045', prompt: 'max of two numbers', arity: 2, train: [ [[3,4], 4], [[1,2], 2], [[5,5], 5] ], dev: [ [[10,20], 20], [[-1,0], 0] ], hidden: [ [[100,200], 200] ] },
  { id: 'he-046', prompt: 'min of two numbers', arity: 2, train: [ [[3,4], 3], [[1,2], 1], [[5,5], 5] ], dev: [ [[10,20], 10], [[-1,0], -1] ], hidden: [ [[100,200], 100] ] },
  { id: 'he-047', prompt: 'double a number', train: [[[3], 6], [[5], 10], [[0], 0]], dev: [[[-1], -2], [[10], 20]], hidden: [[[100], 200]] },
  { id: 'he-048', prompt: 'triple a number', train: [[[3], 9], [[5], 15], [[0], 0]], dev: [[[-1], -3], [[10], 30]], hidden: [[[100], 300]] },
  { id: 'he-049', prompt: 'halve a number', train: [[[4], 2], [[10], 5], [[0], 0]], dev: [[[6], 3], [[20], 10]], hidden: [[[100], 50]] },
  { id: 'he-050', prompt: 'negate a number', train: [[[3], -3], [[-5], 5], [[0], 0]], dev: [[[10], -10], [[-1], 1]], hidden: [[[100], -100]] },
];

function normalizeExamples(problem) {
  if (problem.arity === 2) {
    return {
      training: problem.train.map(([input, output]) => ({ input, output })),
      development: problem.dev.map(([input, output]) => ({ input, output })),
      hidden: problem.hidden.map(([input, output]) => ({ input, output }))
    };
  }
  // Default: list operations
  const t = problem.train;
  return {
    training: t.map(([input, output]) => ({ input: [input], output })),
    development: problem.dev.map(([input, output]) => ({ input: [input], output })),
    hidden: problem.hidden.map(([input, output]) => ({ input: [input], output }))
  };
}

export function runHumanEval() {
  const results = [];
  let solved = 0, wrong = 0, notFound = 0;

  for (const problem of PROBLEMS) {
    const { training, development, hidden } = normalizeExamples(problem);
    // Skip problems with unsupported output types (boolean)
    const allOutputs = [...training, ...development, ...hidden].map(e => e.output);
    if (allOutputs.some(o => typeof o === 'boolean')) { notFound++; results.push({id:problem.id,prompt:problem.prompt,status:'notFound',hiddenPasses:0,hiddenTotal:hidden.length,explored:0,reason:'unsupported_output_type'}); continue; }
    const oracle = ORACLES[problem.prompt];
    const opts = { maxSize: 8, maxExpressions: 400000, deterministicBudget: true, safetyTimeoutMs: 30000 };

    // Clarification loop: up to 3 rounds
    let train = [...training];
    let result;
    for (let round = 0; round < 3; round++) {
      try {
        result = synthesize({ training: train, development, ...opts });
      } catch (e) {
        result = { found: false, reason: `exception:${e.message}`, explored: 0 };
        break;
      }
      if (result.found || result.reason !== 'ambiguous-examples') break;
      if (!result.disambiguatingQueries?.length || !oracle) break;
      // Answer the query using the oracle
      const q = result.disambiguatingQueries[0];
      try {
        const output = problem.arity === 2 ? oracle(q.input[0], q.input[1]) : oracle(q.input[0]);
        train = [...train, { input: q.input, output }];
      } catch { break; }
    }

    let status = 'notFound';
    let hiddenPasses = 0;

    if (result.found && result.ast) {
      try {
        hiddenPasses = hidden.filter(h => deepEqual(evalAst(result.ast, h.input), h.output)).length;
        if (hiddenPasses === hidden.length) {
          status = 'solved';
          solved++;
        } else {
          status = 'wrong';
          wrong++;
        }
      } catch {
        status = 'wrong';
        wrong++;
      }
    } else {
      notFound++;
    }

    results.push({
      id: problem.id,
      prompt: problem.prompt,
      status,
      hiddenPasses,
      hiddenTotal: hidden.length,
      explored: result.explored || 0,
      reason: result.reason || null,
      source: result.source ? result.source.slice(0, 80) : null
    });
  }

  const passAt1 = solved / PROBLEMS.length;
  return {
    total: PROBLEMS.length,
    solved,
    wrong,
    notFound,
    passAt1,
    passAt1Percent: (passAt1 * 100).toFixed(2) + '%',
    results
  };
}
