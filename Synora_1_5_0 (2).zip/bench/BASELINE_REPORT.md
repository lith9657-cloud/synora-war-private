# Synora-Bench v0 — Baseline on V8.1 (RENDER_PREP package)

Run: Node v22, local library calls, scratch copy (original ZIP untouched). Reproduce: `node bench/run.mjs`.
Hidden tests live only in `bench/tasks.mjs` and are never shown to the engine.

## Results
| Track | Result |
|---|---|
| Coding, all prompts (27) | 5 solved, 1 wrong-but-"tests-passed", 21 abstained |
| Known ops, canonical phrasing (5) | 2 solved (max, factorial) — sum, reverse, sort abstained |
| Known ops, paraphrase (5) | 2 solved |
| Known ops, Arabic (5) | 1 solved (factorial) |
| New ops with no template (12) | 0 solved, 11 abstained, 1 wrong |
| False success on non-coding/unsafe requests (8) | 0 / 8 (good) |
| Skill acquisition from 3 examples + 2 dev (6 affine skills) | 6/6 accepted, 60/60 held-out correct |
| Resources (35 prompts) | 68.7 ms wall, 59 ms CPU, peak RSS 56.6 MB |

## Findings
1. Code generation selects among 5 hand-written templates (`solution-engine/index.mjs`); it does not synthesise code.
2. Language handling is lexical rules: even the canonical "sums an array" prompt is not recognised; 1/5 Arabic prompts work.
3. SERIOUS: "second largest number" was routed to the *max* template and returned wrong code reported as `tests-passed` (the template's own internal tests). Internal self-tests are not independent verification.
4. Honest abstention works: 8/8 non-coding or unsafe requests were not answered with fake success.
5. Skill acquisition works but only for one tiny DSL (affine functions mod m) — a real, verified mechanism, but not general.

## Limits of this baseline
Small (27 + 8 + 6 items), single run, written by the same team that wrote the engine's tests. Treat as a smoke baseline; v1 needs larger, independently-sourced held-out sets.
