/**
 * Synora Cloudflare Worker — protected API endpoint.
 * Source code stays on Cloudflare servers. Users only see JSON responses.
 */
const rateLimit = new Map();
const RATE_LIMIT_PER_HOUR = 50;

function checkRateLimit(ip) {
  const now = Date.now();
  const entries = rateLimit.get(ip) || [];
  const recent = entries.filter(t => t > now - 3600000);
  if (recent.length >= RATE_LIMIT_PER_HOUR) return false;
  recent.push(now);
  rateLimit.set(ip, recent);
  return true;
}

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Content-Type': 'application/json'
};

let _engine = null;

async function getEngine() {
  if (_engine) return _engine;
  const { KnowledgeStore } = await import('../synora-v5/knowledge/store.mjs');
  const { AgentBrain } = await import('../synora-v5/agent/brain.mjs');
  const { FailureMemory } = await import('../synora-v5/synthesis/failure-memory.mjs');
  const { SYNTHETIC_WIKIPEDIA } = await import('../synora-v5/knowledge/synthetic-wikipedia.mjs');
  const { ingestWikipediaBatch } = await import('../synora-v5/knowledge/wikipedia-ingestion.mjs');
  const { VERSION } = await import('../synora-v5/version.mjs');
  const store = new KnowledgeStore();
  const mockFetch = async (url) => {
    const title = decodeURIComponent(url.split('/').pop().replace(/_/g, ' '));
    const entry = SYNTHETIC_WIKIPEDIA.find(e => e.title === title);
    if (entry) return { ok: true, json: async () => ({ type: 'standard', title: entry.title, extract: entry.extract }) };
    return { ok: false, status: 404 };
  };
  await ingestWikipediaBatch(SYNTHETIC_WIKIPEDIA.map(e => e.title), 'en', store, mockFetch);
  const brain = new AgentBrain({ store, failureMemory: new FailureMemory() });
  _engine = { store, brain, version: VERSION };
  return _engine;
}

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    if (request.method === 'OPTIONS') return new Response(null, { headers: CORS });
    if (url.pathname === '/health') return new Response(JSON.stringify({ status: 'ok', engine: 'synora-symbolic' }), { headers: CORS });
    if (!checkRateLimit(ip)) return new Response(JSON.stringify({ error: 'rate_limit' }), { status: 429, headers: CORS });
    if (request.method !== 'POST') return new Response(JSON.stringify({ name: 'Synora API', endpoints: ['/ask', '/agent', '/synthesize', '/health'] }), { headers: CORS });
    let body; try { body = await request.json(); } catch { return new Response(JSON.stringify({ error: 'invalid_json' }), { status: 400, headers: CORS }); }
    try {
      const { brain, version } = await getEngine();
      if (url.pathname === '/ask') {
        const result = await brain.execute(body.question || '', { lang: body.lang });
        return new Response(JSON.stringify(result), { headers: CORS });
      }
      if (url.pathname === '/agent') {
        const result = await brain.execute(body.task || '', { testCases: body.testCases, training: body.training, development: body.development, lang: body.lang });
        return new Response(JSON.stringify(result), { headers: CORS });
      }
      if (url.pathname === '/synthesize') {
        const { synthesize } = await import('../synora-v5/synthesis/synthesize.mjs');
        const r = synthesize({ training: body.training, development: body.development || [], maxSize: body.maxSize || 8, maxExpressions: body.maxExpressions || 400000, deterministicBudget: true, safetyTimeoutMs: 30000 });
        // Protect: never expose AST source code
        return new Response(JSON.stringify({ found: r.found, reason: r.reason, explored: r.explored, alternativeBehaviours: r.alternativeBehaviours, ambiguityCheck: r.ambiguityCheck }), { headers: CORS });
      }
      return new Response(JSON.stringify({ error: 'unknown_endpoint' }), { status: 404, headers: CORS });
    } catch (err) {
      return new Response(JSON.stringify({ error: 'engine_error', message: err.message }), { status: 500, headers: CORS });
    }
  }
};
