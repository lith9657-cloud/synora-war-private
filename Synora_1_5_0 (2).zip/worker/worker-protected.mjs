/**
 * Synora 1.5 — Protected Cloudflare Worker
 * This file contains the OBFUSCATED engine. Source code is NOT readable.
 * All safety controls (ambiguity gate, anti-leak, sandbox) are embedded
 * in the obfuscated code and CANNOT be removed.
 */
export { default } from './synora-protected.mjs';
