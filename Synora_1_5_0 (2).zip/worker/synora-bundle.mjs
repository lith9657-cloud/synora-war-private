var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// synora-v5/nl2code/arabic-morphology.mjs
function normalizeArabicText(text) {
  if (typeof text !== "string") return "";
  return text.replace(DIACRITICS, "").replace(ALEF_VARIANTS, "\u0627").replace(/ة/g, "\u0647").replace(/ى/g, "\u064A").replace(/[ـ]/g, "").trim().toLowerCase();
}
function stemArabicWord(word) {
  let norm = normalizeArabicText(word);
  if (norm.length <= 2) return norm;
  if (norm.startsWith("\u0627\u0644") && norm.length > 4) {
    norm = norm.slice(2);
  } else if ((norm.startsWith("\u0648") || norm.startsWith("\u0641")) && norm.length > 3) {
    norm = norm.slice(1);
    if (norm.startsWith("\u0627\u0644") && norm.length > 4) {
      norm = norm.slice(2);
    }
  } else if ((norm.startsWith("\u0628") || norm.startsWith("\u0643") || norm.startsWith("\u0644")) && norm.length > 3) {
    norm = norm.slice(1);
    if (norm.startsWith("\u0627\u0644") && norm.length > 4) {
      norm = norm.slice(2);
    }
  }
  const suffixes = ["\u0648\u0646", "\u064A\u0646", "\u0627\u062A", "\u0627\u0646", "\u0647\u0627", "\u0647\u0645", "\u0646\u0627", "\u0643\u0645", "\u0647"];
  for (const suf of suffixes) {
    if (norm.endsWith(suf) && norm.length > suf.length + 2) {
      norm = norm.slice(0, -suf.length);
      break;
    }
  }
  return norm;
}
var DIACRITICS, ALEF_VARIANTS;
var init_arabic_morphology = __esm({
  "synora-v5/nl2code/arabic-morphology.mjs"() {
    DIACRITICS = /[\u064B-\u0652\u0670\u0640]/g;
    ALEF_VARIANTS = /[إأآٱ]/g;
  }
});

// synora-v5/knowledge/bm25.mjs
function tokenize(text) {
  if (typeof text !== "string") return [];
  if (/[\u0600-\u06FF]/.test(text)) {
    const norm = normalizeArabicText(text).replace(/[؟?.,!:;()\-]/g, " ");
    return norm.split(/\s+/).filter((w) => w.length > 1 || /\d/.test(w)).map((w) => stemArabicWord(w));
  }
  return text.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter((w) => w.length > 1 || /\d/.test(w));
}
var InvertedIndexBM25;
var init_bm25 = __esm({
  "synora-v5/knowledge/bm25.mjs"() {
    init_arabic_morphology();
    InvertedIndexBM25 = class {
      constructor(k1 = 1.5, b = 0.75) {
        this.k1 = k1;
        this.b = b;
        this.docs = /* @__PURE__ */ new Map();
        this.inverted = /* @__PURE__ */ new Map();
        this.totalDocLen = 0;
      }
      addDocument(id, text, metadata = {}) {
        const terms = tokenize(text);
        this.docs.set(id, {
          id,
          terms,
          length: terms.length,
          raw: text,
          metadata
        });
        this.totalDocLen += terms.length;
        const termFreqs = /* @__PURE__ */ new Map();
        for (const t of terms) {
          termFreqs.set(t, (termFreqs.get(t) || 0) + 1);
        }
        for (const [term, freq] of termFreqs.entries()) {
          if (!this.inverted.has(term)) {
            this.inverted.set(term, /* @__PURE__ */ new Map());
          }
          this.inverted.get(term).set(id, freq);
        }
      }
      search(query, topK = 5) {
        const qTerms = tokenize(query);
        if (qTerms.length === 0 || this.docs.size === 0) return [];
        const N = this.docs.size;
        const avgdl = this.totalDocLen / N;
        const scores = /* @__PURE__ */ new Map();
        for (const term of qTerms) {
          const posting = this.inverted.get(term);
          if (!posting) continue;
          const df = posting.size;
          const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5));
          for (const [docId, tf] of posting.entries()) {
            const doc = this.docs.get(docId);
            const denom = tf + this.k1 * (1 - this.b + this.b * (doc.length / avgdl));
            const score = idf * (tf * (this.k1 + 1) / (denom || 1));
            scores.set(docId, (scores.get(docId) || 0) + score);
          }
        }
        const ranked = Array.from(scores.entries()).map(([id, score]) => ({
          id,
          score,
          doc: this.docs.get(id)
        })).sort((a, b) => b.score - a.score).slice(0, topK);
        return ranked;
      }
    };
  }
});

// synora-v5/knowledge/answer-extractor.mjs
function detectQuestionType(question) {
  const q = String(question || "");
  for (const [type, pattern] of TYPE_PATTERNS) if (pattern.test(q)) return type;
  return "value";
}
function normalizeForCompare(text) {
  return normalizeArabicText(String(text || "")).replace(/[.,;:!?؟،؛()"'\-–—]/g, " ").replace(/\s+/g, " ").trim();
}
function questionTokens(question) {
  const norm = normalizeForCompare(question);
  const tokens = norm.split(" ").filter((t) => t.length > 1);
  return new Set(tokens);
}
function trimEntityTokens(text, qTokens) {
  const tokens = text.split(/\s+/).filter(Boolean);
  while (tokens.length > 1 && qTokens.has(normalizeForCompare(tokens[tokens.length - 1]))) tokens.pop();
  const kept = tokens.filter((t) => !qTokens.has(normalizeForCompare(t)));
  return kept.length ? tokens.join(" ") : null;
}
function numericPattern(units) {
  return new RegExp(
    `(?<![\\p{L}\\d])(\\d{1,3}(?:,\\d{3})+(?:\\.\\d+)?|\\d{1,6}(?:\\.\\d+)?\\s*(?:${units})?)(?![\\p{L}\\d])`,
    "iu"
  );
}
function wordNumberPattern(units) {
  return new RegExp(
    `(?<![\\p{L}\\d])((?:${EN_NUMBER_WORDS.join("|")}|${AR_NUMBER_WORDS.join("|")})\\s+(?:${units}))(?![\\p{L}\\d])`,
    "iu"
  );
}
function candidatePatterns(type) {
  switch (type) {
    case "person":
      return [];
    case "date":
      return DATE_PATTERNS;
    case "duration":
      return [numericPattern(DURATION_UNITS), wordNumberPattern(DURATION_UNITS), NUMBER_WITH_UNIT];
    case "quantity":
    case "height":
      return [numericPattern(QUANTITY_UNITS), wordNumberPattern(QUANTITY_UNITS), NUMBER_WITH_UNIT];
    case "attribute":
      return [
        /\b(?:is|was|are|were)\s+(red|blue|green|yellow|black|white|orange|purple|brown|pink|grey|gray)\b/i,
        /(?:لونه|لونها|هو|هي)\s*(احمر|ازرق|اخضر|اصفر|اسود|ابيض|برتقالي|بنفسجي|بني|وردي|رمادي)/u
      ];
    case "place":
      return [
        /([\u0621-\u064A]+)\s+هي\s+عاصم[هة]/u,
        /\bcapital\s+of\s+[\p{L}\s]+?\s+is\s+([\p{L}][\p{L}'’-]*)/iu,
        /\b(?:in|at|near|located in|based in|headquartered in|situated in)\s+([A-Z][\p{L}'’-]*(?:\s+[A-Z][\p{L}'’-]*){0,4})/u,
        /(?:تقع في|يقع في|يوجد في|موجود في|داخل|تستقر في)\s*([\u0600-\u06FF]+(?:\s+[\u0600-\u06FF]+){0,3})/u
      ];
    case "organization":
      return [
        /\b(?:run|operated|managed|owned|administered|funded|supported|sponsored|published|organised|organized|governed|oversight|backed)\s+by\s+(?:the\s+)?([A-Z][\p{L}'’-]*(?:\s+[A-Z][\p{L}'’-]*){0,4})/u,
        /(?:يديرها|يدير|تتبع)\s*([\u0600-\u06FF]+(?:\s+[\u0600-\u06FF]+){0,3})/u
      ];
    default:
      return [
        /\b(?:classified as|defined as|known as|called|is|was|are|were|means)\s+([^,;.!?؟]{1,80})/i,
        /(?:هو|هي|تعتبر|يعتبر|تسمى|يسمى|تعرف باسم|يُعرف باسم)\s*([^،؛.!?؟]{1,80})/u,
        /برقم\s*\d+/u,
        /\bchemical element number\s+\d+\b/i
      ];
  }
}
function extractTypedSpan(question, sentence, sentenceOffset = 0) {
  const type = detectQuestionType(question);
  const candidates = [];
  const qTokens = questionTokens(question);
  const push = (text, start, priority, kind) => {
    if (!text) return;
    const value = text.replace(/[.,;:!?؟،؛]+$/u, "").trimEnd();
    if (!value) return;
    const offset = sentenceOffset + start + (text.length - value.length);
    candidates.push({ text: value, start: offset, end: offset + value.length, type, priority, kind });
  };
  if (type === "person") {
    for (const agent of AGENT_PATTERNS) {
      agent.re.lastIndex = 0;
      let m;
      while (m = agent.re.exec(sentence)) {
        const nameMatch = agent.name.exec(sentence.slice(m.index + m[0].length));
        if (!nameMatch) continue;
        const base = m.index + m[0].length + nameMatch.index;
        push(nameMatch[1], base, 0, "agent");
      }
    }
    for (const active of ACTIVE_PATTERNS) {
      active.re.lastIndex = 0;
      let m;
      while (m = active.re.exec(sentence)) {
        const raw = m[active.group];
        const base = m.index + m[0].indexOf(raw);
        push(raw, base, 1, "active");
      }
    }
    for (const role of ROLE_PATTERNS) {
      role.re.lastIndex = 0;
      let m;
      while (m = role.re.exec(sentence)) {
        const raw = m[1];
        const base = m.index + m[0].indexOf(raw);
        push(raw, base, 2, "role");
      }
    }
  }
  for (const pattern of candidatePatterns(type)) {
    const m = pattern.exec(sentence);
    if (!m) continue;
    if (m[1]) {
      const raw = m[1];
      const lead = raw.search(/\S|$/);
      const value = raw.slice(lead).replace(/[.,;:!?؟،؛]+$/u, "").trimEnd();
      const start = sentenceOffset + m.index + m[0].indexOf(raw) + lead;
      candidates.push({ text: value, start, end: start + value.length, type, priority: 0, kind: "typed" });
    } else {
      const raw = m[0];
      const lead = raw.search(/\S|$/);
      const value = raw.slice(lead, raw.trimEnd().length);
      const start = sentenceOffset + m.index + lead;
      candidates.push({ text: value, start, end: start + value.length, type, priority: 0, kind: "typed" });
    }
  }
  let valid = candidates.filter((c) => c.text && c.text.length <= 80 && c.end > c.start);
  if (!valid.length) return null;
  if (type === "person") {
    valid = valid.map((c) => {
      const trimmed = trimEntityTokens(c.text, qTokens);
      if (!trimmed || trimmed === c.text) return c;
      return { ...c, text: trimmed, end: c.start + trimmed.length };
    });
    valid = valid.filter((c) => {
      const tokens = c.text.split(/\s+/).filter(Boolean);
      const repeated = tokens.filter((t) => qTokens.has(normalizeForCompare(t))).length;
      return !(tokens.length > 0 && repeated === tokens.length);
    });
    if (!valid.length) return null;
  }
  if (["quantity", "duration", "height", "date"].includes(type)) {
    valid.sort((a, b) => b.text.length - a.text.length || a.start - b.start);
  } else {
    valid.sort((a, b) => a.priority - b.priority || b.text.length - a.text.length || a.start - b.start);
  }
  return valid[0];
}
var QUESTION_TYPES, TYPE_PATTERNS, PERSON_NAME, AGENT_PATTERNS, ACTIVE_PATTERNS, ROLE_PATTERNS, DATE_PATTERNS, DURATION_UNITS, QUANTITY_UNITS, EN_NUMBER_WORDS, AR_NUMBER_WORDS, NUMBER_WITH_UNIT;
var init_answer_extractor = __esm({
  "synora-v5/knowledge/answer-extractor.mjs"() {
    init_arabic_morphology();
    QUESTION_TYPES = Object.freeze([
      "duration",
      "date",
      "person",
      "organization",
      "quantity",
      "place",
      "attribute",
      "height",
      "value"
    ]);
    TYPE_PATTERNS = [
      ["duration", /\bhow\s+long\b|\bhow\s+much\s+time\b|\bwhat\s+is\s+the\s+duration\b|\btime\s+(?:it\s+)?takes?\b|\btime\s+of\b|\btram\s+time\b|\btravel\s+time\b|كم\s+(?:تستغرق|يستغرق|دام|تاخذ)|ما\s+مدة|مدة\s+(?:الرحلة|العمل|المهمة)|وقت\s+(?:الترام|الرحلة|السفر)/i],
      ["date", /\bwhen\b|\b(?:in\s+)?which\s+year\b|\bwhat\s+year\b|\bwhat\s+date\b|\bsince\s+when\b|\bin\s+which\s+century\b|متى|في\s+(?:اي|أي)\s+عام|في\s+(?:اي|أي)\s+سنة|منذ\s+متى/i],
      ["person", /\bwho\b|\bwhom\b|\bwhose\b|\bfounder\b|\bfounded\s+by\b|\bestablished\s+by\b|\bcreated\s+by\b|\binvented\s+by\b|\bdiscovered\s+by\b|\bauthor(?:ed)?\s+by\b|\bdesigned\s+by\b|\bdirected\s+by\b|\bled\s+by\b|\bmanaged\s+by\b|\boperated\s+by\b|\bcommissioned\s+by\b|\bname\s+the\s+founder\b|من\s+(?:اسس|أسس|اسست|أسست|انشا|أنشأ|بنى|اكتشف|اخترع|ادار|يدير)|على\s+يد\s+من|المؤسس|المؤسّس|صاحب|مؤسس/i],
      ["organization", /\bwhich\s+(?:organisation|organization|company|institution|team|agency|bank|university|museum|library)\b|\bwhat\s+(?:organisation|organization|company|institution)\b|أي\s+(?:منظمة|منشأة|شركة|مؤسسة|جامعة|بنك|متحف|مكتبة)/i],
      ["quantity", /\bhow\s+many\b|\bhow\s+much\b|\bnumber\s+of\b|\bpopulation\s+of\b|\bprice\s+of\b|\bhow\s+large\b|\bpopulation\b|كم(?:\s|$)|ما\s+عدد|عدد\s+|سكان|نسمة|عدد\s+السكان/i],
      ["place", /\bwhere\b|\bwhich\s+(?:city|country|town|region|place)\b|\blocated\s+in\b|\bsituated\b|\bcapital\b|\bheadquartered\b|اين|أين|في\s+(?:اي|أي)\s+(?:مكان|مدينة|بلد|منطقة)|عاصمه|عاصمة/i],
      ["attribute", /\b(?:colour|color)\b|لون\s+/i],
      ["height", /\bhow\s+(?:high|tall)\b|\bwhat\s+(?:is|are)\s+the\s+height\b|\bheight\b|\bvertical\s+extent\b|ما(?:\s+هو)?\s+ارتفاع|كم\s+ارتفاع|ارتفاع/i]
    ];
    PERSON_NAME = /((?:(?:Dr|Prof|Mr|Mrs|Ms|Eng|PhD|Sir|Lady)\.?\s+)?[A-Z][\p{L}'’-]*(?:\s+[A-Z][\p{L}'’-]*){0,4})/u;
    AGENT_PATTERNS = [
      {
        lang: "en",
        re: /\b(?:(?:was|were|is|are|been|being)\s+)?(?:founded|established|created|invented|discovered|authored|designed|directed|led|managed|operated|commissioned|built|opened|launched|painted|composed|translated|compiled|presented|chaired|supervised|oversaw|headed|narrated|reviewed|approved|endorsed|signed)\b[^.!?؟]{0,80}?\bby\s+/gi,
        name: PERSON_NAME
      },
      {
        lang: "ar",
        re: /(?:على\s*يد|بواسطة|بفضل|بواسطة)\s+/gu,
        name: /([\u0621-\u064A\u0660-\u0669]+(?:\s+(?!عام(?:\s|$)|سنة(?:\s|$)|في(?:\s|$)|من(?:\s|$)|إلى(?:\s|$)|عند(?:\s|$)|حيث(?:\s|$))[\u0621-\u064A\u0660-\u0669]+){0,2})/u
      }
    ];
    ACTIVE_PATTERNS = [
      {
        lang: "en",
        re: /(?<!\bwas\s)(?<!\bwere\s)(?<!\bis\s)(?<!\bare\s)(?<!\bbeen\s)(?<!\bbeing\s)(?<!\bby\s)\b([A-Z][\p{L}'’-]*(?:\s+[A-Z][\p{L}'’-]*){0,3})\s+(?:founded|established|created|invented|discovered|authored|designed|directed|led|managed|operated|commissioned|built|opened|launched|painted|composed|translated)\b/gu,
        group: 1
      },
      {
        lang: "ar",
        re: /(?<![\u0621-\u064A])(?:أسس|اسس|أنشأ|انشا|بنى|اكتشف|اخترع|أدار|ودع|رسم|ألف)\s+([\u0621-\u064A\u0660-\u0669]+(?:\s+(?!عام(?:\s|$)|سنة(?:\s|$))[\u0621-\u064A\u0660-\u0669]+){0,2})/gu,
        group: 1
      }
    ];
    ROLE_PATTERNS = [
      { lang: "en", re: /\b(?:the\s+)?founder\s+(?:of\s+[^,.;]{1,60}?\s+)?(?:is|was)\s+([A-Z][\p{L}'’-]*(?:\s+[A-Z][\p{L}'’-]*){0,3})/giu },
      { lang: "ar", re: /المؤسس\s+(?:هو|كان)\s+([\u0621-\u064A\u0660-\u0669]+(?:\s+[\u0621-\u064A\u0660-\u0669]+){0,2})/gu }
    ];
    DATE_PATTERNS = [
      /\b(?:in|on|during|since)\s+((?:\d{1,2}\s+)?(?:January|February|March|April|May|June|July|August|September|October|November|December)?\s*\d{4}|\d{4})\b/i,
      /\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4})\b/,
      /(?:في\s+عام|عام|سنة|في)\s*(\d{4}|\d{1,2}\s+\S+)/
    ];
    DURATION_UNITS = "years?|months?|days?|hours?|minutes?|seconds?|centuries?|\u0623\u064A\u0627\u0645|\u0627\u064A\u0627\u0645|\u0633\u0646\u0629|\u0633\u0646\u0648\u0627\u062A|\u0634\u0647\u0631|\u0634\u0647\u0648\u0631|\u0633\u0627\u0639\u0629|\u0633\u0627\u0639\u0627\u062A|\u062F\u0642\u064A\u0642\u0629|\u062F\u0642\u0627\u0626\u0642|\u062B\u0627\u0646\u064A\u0629|\u0642\u0631\u0646";
    QUANTITY_UNITS = "km|kilometers?|m|meters?|cm|centimeters?|people|inhabitants|units?|items?|people|\u0643\u0645|\u0643\u064A\u0644\u0648\u0645\u062A\u0631|\u0645\u062A\u0631\u0627|\u0645\u062A\u0631|\u0633\u0645|\u0634\u062E\u0635|\u0646\u0633\u0645\u0629|\u0642\u0637\u0639\u0629|\u0639\u0646\u0635\u0631";
    EN_NUMBER_WORDS = [
      "zero",
      "one",
      "two",
      "three",
      "four",
      "five",
      "six",
      "seven",
      "eight",
      "nine",
      "ten",
      "eleven",
      "twelve",
      "thirteen",
      "fourteen",
      "fifteen",
      "sixteen",
      "seventeen",
      "eighteen",
      "nineteen",
      "twenty",
      "thirty",
      "forty",
      "fifty",
      "sixty",
      "seventy",
      "eighty",
      "ninety",
      "hundred"
    ];
    AR_NUMBER_WORDS = [
      "\u0635\u0641\u0631",
      "\u0648\u0627\u062D\u062F",
      "\u0627\u062B\u0646\u0627\u0646",
      "\u0627\u062B\u0646\u064A\u0646",
      "\u062B\u0644\u0627\u062B",
      "\u062B\u0644\u0627\u062B\u0629",
      "\u0627\u0631\u0628\u0639",
      "\u0623\u0631\u0628\u0639",
      "\u062E\u0645\u0633",
      "\u062E\u0645\u0633\u0629",
      "\u0633\u062A",
      "\u0633\u062A\u0629",
      "\u0633\u0628\u0639",
      "\u0633\u0628\u0639\u0629",
      "\u062B\u0645\u0627\u0646",
      "\u062B\u0645\u0627\u0646\u064A\u0629",
      "\u062A\u0633\u0639",
      "\u062A\u0633\u0639\u0629",
      "\u0639\u0634\u0631",
      "\u0639\u0634\u0631\u0629",
      "\u0639\u0634\u0631\u0648\u0646",
      "\u062B\u0644\u0627\u062B\u0648\u0646",
      "\u0627\u0631\u0628\u0639\u0648\u0646",
      "\u062E\u0645\u0633\u0648\u0646",
      "\u0645\u0626\u0629",
      "\u0645\u0626\u062A\u0627\u0646"
    ];
    NUMBER_WITH_UNIT = /(?<![\p{L}\d])((?:\d{1,3}(?:,\d{3})+|\d{1,6})(?:\.\d+)?\s+(?!was\b|were\b|is\b|are\b|has\b|have\b|had\b|and\b|or\b|the\b|a\b|an\b|in\b|on\b|at\b|to\b|of\b|for\b|by\b|with\b|from\b|that\b|this\b)(?!(?:في|من|إلى|الى|على|عند|حيث|او|أو|و|ثم|لكن|لذلك|بعد|قبل|قد|كل|بعض|هذه|هذا|تلك|ذلك)(?:\s|$))[\p{L}]{1,20})/u;
  }
});

// synora-v5/knowledge/store.mjs
var store_exports = {};
__export(store_exports, {
  KnowledgeStore: () => KnowledgeStore
});
import fs from "node:fs";
function normalizeEnglishTerm(word) {
  const irregular = IRREGULAR_VERB_FORMS.get(word);
  if (irregular) return irregular;
  if (word.length > 4 && word.endsWith("ies")) return `${word.slice(0, -3)}y`;
  if (word.length > 4 && /(?:ss|sh|ch|x|z)es$/.test(word)) return word.slice(0, -2);
  if (word.length > 3 && word.endsWith("s") && !/(ss|us|is)$/.test(word)) return word.slice(0, -1);
  return word;
}
function extractSignificantTerms(text) {
  if (typeof text !== "string") return [];
  if (/[\u0600-\u06FF]/.test(text)) {
    const norm = normalizeArabicText(text).replace(/[؟?.,!:]/g, " ");
    return norm.split(/\s+/).filter((w) => (w.length > 1 || /\d/.test(w)) && !STOPWORDS.has(w)).map((w) => stemArabicWord(w));
  }
  return text.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter((w) => (w.length > 2 || /\d/.test(w)) && !STOPWORDS.has(w)).map(normalizeEnglishTerm);
}
function extractFacts(docId, text, sourceMeta = {}) {
  const facts = [];
  const lines = text.split(/(?<=[.?!؟])\s+/).filter(Boolean);
  let factId = 1;
  for (const line of lines) {
    const isMatch = line.match(/^([A-Za-z0-9\s]+?)\s+(?:is|was|are|equals|defined as|is classified as)\s+(?:approximately|roughly|exactly)?\s*(.+)$/i);
    if (isMatch) {
      facts.push({
        id: `fact-${docId}-${factId++}`,
        subject: isMatch[1].trim(),
        predicate: "is",
        object: isMatch[2].trim().replace(/[.?!]$/, ""),
        text: line.trim(),
        source: {
          id: docId,
          url: sourceMeta.url || "",
          licence: sourceMeta.licence || sourceMeta.license || "CC-BY-SA-4.0",
          retrievedAt: sourceMeta.retrievedAt || (/* @__PURE__ */ new Date()).toISOString()
        },
        confidence: 1,
        status: "verified"
      });
      continue;
    }
    const arMatch = line.match(/^([\u0600-\u06FF0-9\s]+?)\s+(?:هو|هي|تعتبر|يبلغ|تبلغ|تقع)\s+(.+)$/);
    if (arMatch) {
      facts.push({
        id: `fact-${docId}-${factId++}`,
        subject: arMatch[1].trim(),
        predicate: "\u0647\u0648",
        object: arMatch[2].trim().replace(/[.؟]$/, ""),
        text: line.trim(),
        source: {
          id: docId,
          url: sourceMeta.url || "",
          licence: sourceMeta.licence || sourceMeta.license || "CC-BY-SA-4.0",
          retrievedAt: sourceMeta.retrievedAt || (/* @__PURE__ */ new Date()).toISOString()
        },
        confidence: 1,
        status: "verified"
      });
    }
  }
  return facts;
}
function splitSentences(text) {
  const out = [];
  let start = 0;
  const push = (raw, offset) => {
    const trimmed = raw.trim();
    if (!trimmed) return;
    const lead = raw.search(/\S|$/);
    out.push({ text: trimmed, offset: offset + lead });
  };
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch !== "." && ch !== "!" && ch !== "?" && ch !== "\u061F") continue;
    if (ch === ".") {
      const before = text.slice(Math.max(0, i - 12), i + 1);
      if (ABBREVIATION_BEFORE_PERIOD.test(before)) continue;
      if (i + 1 < text.length && !/\s/.test(text[i + 1])) continue;
    }
    let end = i + 1;
    while (end < text.length && /[.!?؟]/.test(text[end])) end++;
    push(text.slice(start, end), start);
    start = end;
    i = end - 1;
  }
  push(text.slice(start), start);
  return out;
}
var STOPWORDS, IRREGULAR_VERB_FORMS, RELATION_SYNONYMS, ABBREVIATION_BEFORE_PERIOD, KnowledgeStore;
var init_store = __esm({
  "synora-v5/knowledge/store.mjs"() {
    init_bm25();
    init_arabic_morphology();
    init_answer_extractor();
    STOPWORDS = /* @__PURE__ */ new Set([
      "what",
      "was",
      "the",
      "in",
      "on",
      "at",
      "is",
      "a",
      "an",
      "of",
      "how",
      "to",
      "for",
      "by",
      "with",
      "about",
      "from",
      "as",
      "that",
      "this",
      "day",
      "number",
      "\u0645\u0627",
      "\u0647\u064A",
      "\u0647\u0648",
      "\u0641\u064A",
      "\u0645\u0646",
      "\u0639\u0644\u0649",
      "\u0639\u0646",
      "\u0627\u0644\u0649",
      "\u0627\u0644\u064A",
      "\u0643\u0627\u0646",
      "\u0643\u0627\u0646\u062A",
      "\u0643\u0645",
      "\u0627\u064A\u0646",
      "\u0643\u064A\u0641"
    ]);
    IRREGULAR_VERB_FORMS = /* @__PURE__ */ new Map([
      ["ran", "run"],
      ["run", "run"],
      ["runs", "run"],
      ["running", "run"],
      ["began", "begin"],
      ["begun", "begin"],
      ["begins", "begin"],
      ["wrote", "write"],
      ["written", "write"],
      ["writes", "write"],
      ["spoke", "speak"],
      ["spoken", "speak"],
      ["speaks", "speak"],
      ["took", "take"],
      ["taken", "take"],
      ["takes", "take"],
      ["gave", "give"],
      ["given", "give"],
      ["gives", "give"],
      ["made", "make"],
      ["makes", "make"],
      ["built", "build"],
      ["builds", "build"],
      ["sent", "send"],
      ["sends", "send"],
      ["found", "find"],
      ["finds", "find"],
      ["kept", "keep"],
      ["keeps", "keep"],
      ["left", "leave"],
      ["leaves", "leave"],
      ["met", "meet"],
      ["meets", "meet"],
      ["paid", "pay"],
      ["pays", "pay"],
      ["said", "say"],
      ["says", "say"],
      ["sold", "sell"],
      ["sells", "sell"],
      ["told", "tell"],
      ["tells", "tell"],
      ["thought", "think"],
      ["thinks", "think"],
      ["understood", "understand"],
      ["understands", "understand"],
      ["broke", "break"],
      ["broken", "break"],
      ["breaks", "break"],
      ["chose", "choose"],
      ["chosen", "choose"],
      ["chooses", "choose"],
      ["drew", "draw"],
      ["drawn", "draw"],
      ["draws", "draw"],
      ["fell", "fall"],
      ["fallen", "fall"],
      ["falls", "fall"],
      ["felt", "feel"],
      ["feels", "feel"],
      ["flew", "fly"],
      ["flies", "fly"],
      ["forgot", "forget"],
      ["forgets", "forget"],
      ["grew", "grow"],
      ["grown", "grow"],
      ["grows", "grow"],
      ["heard", "hear"],
      ["hears", "hear"],
      ["held", "hold"],
      ["holds", "hold"],
      ["led", "lead"],
      ["leads", "lead"],
      ["lost", "lose"],
      ["loses", "lose"],
      ["rose", "rise"],
      ["risen", "rise"],
      ["rises", "rise"],
      ["sought", "seek"],
      ["seeks", "seek"],
      ["sat", "sit"],
      ["sits", "sit"],
      ["slept", "sleep"],
      ["sleeps", "sleep"],
      ["spent", "spend"],
      ["spends", "spend"],
      ["stood", "stand"],
      ["stands", "stand"],
      ["taught", "teach"],
      ["teaches", "teach"],
      ["threw", "throw"],
      ["thrown", "throw"],
      ["throws", "throw"],
      ["wore", "wear"],
      ["worn", "wear"],
      ["wears", "wear"],
      ["won", "win"],
      ["wins", "win"],
      ["reviewed", "review"],
      ["reviews", "review"],
      ["chaired", "chair"],
      ["chairs", "chair"],
      ["supervised", "supervise"],
      ["supervises", "supervise"],
      ["funded", "fund"],
      ["funds", "fund"],
      ["recruited", "recruit"],
      ["recruits", "recruit"],
      ["opened", "open"],
      ["opens", "open"],
      ["screened", "screen"],
      ["screens", "screen"],
      ["committed", "commit"],
      ["commits", "commit"]
    ]);
    RELATION_SYNONYMS = Object.freeze({
      founded: ["established", "created", "built", "set", "opened", "inaugurated", "launched"],
      establish: ["founded", "created", "built", "set", "opened", "inaugurated", "launched"],
      established: ["founded", "created", "built", "set", "opened", "inaugurated", "launched"],
      founder: ["founded", "established", "created", "built"],
      ride: ["take", "last", "journey", "duration", "travel", "tram"],
      tram: ["ride", "travel", "journey"],
      last: ["take", "ride", "duration"],
      tall: ["height", "high", "metre", "meter"],
      high: ["height", "tall", "metre", "meter"],
      height: ["tall", "high", "metre", "meter"],
      people: ["population", "inhabitant", "resident"],
      live: ["reside", "inhabit", "population"],
      inhabitant: ["people", "population", "resident"],
      population: ["people", "inhabitant", "resident"],
      "\u062A\u0623\u0633\u0633\u062A": ["\u0623\u0633\u0633", "\u0623\u0646\u0634\u0623", "\u0628\u0646\u0649", "\u0627\u0641\u062A\u062A\u062D"],
      "\u062A\u0623\u0633\u0633": ["\u0623\u0633\u0633", "\u0623\u0646\u0634\u0623", "\u0628\u0646\u0649", "\u0627\u0641\u062A\u062A\u062D"],
      "\u0623\u0633\u0633": ["\u062A\u0623\u0633\u0633\u062A", "\u0623\u0646\u0634\u0623", "\u0628\u0646\u0649", "\u0627\u0641\u062A\u062A\u062D"],
      "\u0633\u0643\u0627\u0646": ["\u0646\u0633\u0645\u0629", "\u0645\u0642\u064A\u0645\u064A\u0646", "\u0633\u0627\u0643\u0646"],
      "\u0646\u0633\u0645\u0629": ["\u0633\u0643\u0627\u0646", "\u0645\u0642\u064A\u0645\u064A\u0646"],
      "\u0627\u0631\u062A\u0641\u0627\u0639": ["\u0637\u0648\u0644", "\u0639\u0644\u0648"],
      "\u062A\u0631\u0627\u0645": ["\u0631\u062D\u0644\u0629", "\u062A\u0633\u062A\u063A\u0631\u0642"]
    });
    ABBREVIATION_BEFORE_PERIOD = /(?:\b(?:Dr|Prof|Mr|Mrs|Ms|Eng|St|Rev|Jr|Sr|vs|etc|No|Fig|U)|\b[A-Z])\.$/i;
    KnowledgeStore = class {
      constructor(options = {}) {
        this.rootDir = options.rootDir || null;
        this.index = new InvertedIndexBM25();
        this.documents = /* @__PURE__ */ new Map();
        this.facts = [];
        this.threshold = typeof options.threshold === "number" ? options.threshold : 0.6;
      }
      ingestDocument(doc) {
        if (!doc || !doc.id || !doc.text) return;
        this.documents.set(doc.id, doc);
        this.index.addDocument(doc.id, (doc.title ? doc.title + ". " : "") + doc.text, { ...doc, sourceText: doc.text });
        const docFacts = extractFacts(doc.id, doc.text, {
          url: doc.url,
          licence: doc.licence || doc.license
        });
        this.facts.push(...docFacts);
      }
      ingestCorpusJsonl(filePath) {
        const content = fs.readFileSync(filePath, "utf-8");
        const lines = content.split("\n").filter(Boolean);
        for (const l of lines) {
          this.ingestDocument(JSON.parse(l));
        }
      }
      answerQuestion(query) {
        const qTerms = extractSignificantTerms(query);
        if (!qTerms.length) return { status: "abstain", reason: "empty_query", sourceIds: [] };
        const searchResults = this.index.search(query, Math.max(8, this.documents.size));
        if (!searchResults.length) return { status: "abstain", reason: "insufficient_evidence", sourceIds: [] };
        const qType = detectQuestionType(query);
        const qNormalized = normalizeArabicText(query).toLowerCase();
        const attributeSpec = /\b(?:colour|color)\b|لون/.test(qNormalized) ? "color" : /\bpopulation\b|سكان/.test(qNormalized) ? "population" : /\bmayor\b|عمده/.test(qNormalized) ? "mayor" : null;
        const attributeEvidence = {
          color: /\b(?:red|blue|green|yellow|black|white|orange|purple|brown|pink|grey|gray|colour|color)\b|احمر|ازرق|اخضر|اصفر|اسود|ابيض|برتقالي|بنفسجي|بني|وردي|رمادي/u,
          population: /\b(?:population|inhabitants|residents|people)\b|سكان|نسمة/u,
          mayor: /\bmayor\b|عمده/u
        };
        const queryAnchors = [...String(query).matchAll(/[\p{L}]*\d+[\p{L}]*/gu)].map((m) => normalizeArabicText(m[0]).toLowerCase());
        const ranked = [];
        for (const hit of searchResults) {
          const doc = hit.doc;
          const text = String(doc.metadata.sourceText ?? doc.raw);
          const normalizedDoc = normalizeArabicText(text).toLowerCase();
          if (attributeSpec && !attributeEvidence[attributeSpec].test(normalizedDoc)) continue;
          if (queryAnchors.length && !queryAnchors.every((anchor) => normalizedDoc.includes(anchor))) continue;
          for (const { text: sentence, offset } of splitSentences(text)) {
            const terms = new Set(extractSignificantTerms(sentence));
            let hits = 0;
            for (const term of qTerms) {
              if (terms.has(term)) {
                hits++;
                continue;
              }
              const syns = RELATION_SYNONYMS[term];
              if (syns && syns.some((sy) => terms.has(sy))) hits++;
            }
            const overlap = hits / Math.max(1, qTerms.length);
            if (overlap < 0.35) continue;
            const span = extractTypedSpan(query, sentence, offset);
            if (!span) continue;
            ranked.push({ ...span, sentence, doc, score: hit.score, overlap, hits: [] });
          }
        }
        if (!ranked.length) return { status: "abstain", reason: "no_typed_supported_span", sourceIds: [] };
        ranked.sort((a, b) => b.score * b.overlap - a.score * a.overlap || a.text.length - b.text.length);
        const best = ranked[0];
        const RELATION_VOCAB = /* @__PURE__ */ new Set();
        for (const [k, vs] of Object.entries(RELATION_SYNONYMS)) {
          RELATION_VOCAB.add(k);
          for (const v of vs) RELATION_VOCAB.add(v);
        }
        for (const w of STOPWORDS) RELATION_VOCAB.add(w);
        const qEntityTokens = qTerms.filter((t) => !RELATION_VOCAB.has(t));
        const alternatives = ranked.filter((x) => {
          if (x.doc.id === best.doc.id) return false;
          if (x.overlap < Math.max(0.35, best.overlap - 0.15)) return false;
          const altTokens = new Set(extractSignificantTerms(x.sentence));
          return qEntityTokens.every((t) => altTokens.has(t));
        });
        const distinct = /* @__PURE__ */ new Map([[best.text.toLowerCase(), best]]);
        for (const alt of alternatives) distinct.set(alt.text.toLowerCase(), alt);
        if (distinct.size > 1) {
          return {
            status: "conflict",
            reason: "conflicting_supported_spans",
            answers: [...distinct.values()].map((x) => ({ object: x.text, sourceId: x.doc.id, span: { sourceId: x.doc.id, start: x.start, end: x.end } })),
            sourceIds: [...new Set([...distinct.values()].map((x) => x.doc.id))]
          };
        }
        const threshold = qType === "value" ? 0.65 : 0.45;
        if (best.overlap < threshold || best.text.length > 80) {
          return { status: "abstain", reason: "low_typed_span_confidence", score: best.score, sourceIds: [] };
        }
        return {
          status: "answered",
          answer: best.text,
          sourceIds: [best.doc.id],
          score: best.score,
          span: { sourceId: best.doc.id, start: best.start, end: best.end },
          evidence: { questionType: qType, matchedTerms: best.hits, sentenceLevel: true, overlap: best.overlap },
          licence: best.doc.metadata.licence || best.doc.metadata.license || "CC-BY-SA-4.0",
          attribution: best.doc.metadata.url || best.doc.id
        };
      }
    };
  }
});

// synora-v5/nl2code/lexicon.mjs
var NUMERALS, ORD_MAP, OPERATION_CONCEPTS, FILTER_PREDICATES, DIRECTION_QUALIFIERS;
var init_lexicon = __esm({
  "synora-v5/nl2code/lexicon.mjs"() {
    init_arabic_morphology();
    NUMERALS = {
      // English
      "zero": 0,
      "one": 1,
      "two": 2,
      "three": 3,
      "four": 4,
      "five": 5,
      "six": 6,
      "seven": 7,
      "eight": 8,
      "nine": 9,
      "ten": 10,
      "eleven": 11,
      "twelve": 12,
      "thirteen": 13,
      "fourteen": 14,
      "fifteen": 15,
      "twenty": 20,
      "thirty": 30,
      "hundred": 100,
      // Arabic (normalized/stemmed)
      "\u0635\u0641\u0631": 0,
      "\u0627\u0644\u0635\u0641\u0631": 0,
      "\u0648\u0627\u062D\u062F": 1,
      "\u0627\u062B\u0646\u064A\u0646": 2,
      "\u0627\u062B\u0646\u0627\u0646": 2,
      "\u062B\u0644\u0627\u062B": 3,
      "\u062B\u0644\u0627\u062B\u0647": 3,
      "\u0627\u0631\u0628\u0639": 4,
      "\u0627\u0631\u0628\u0639\u0647": 4,
      "\u062E\u0645\u0633": 5,
      "\u062E\u0645\u0633\u0647": 5,
      "\u0633\u062A": 6,
      "\u0633\u062A\u0647": 6,
      "\u0633\u0628\u0639": 7,
      "\u0633\u0628\u0639\u0647": 7,
      "\u062B\u0645\u0627\u0646": 8,
      "\u062B\u0645\u0627\u0646\u064A\u0647": 8,
      "\u062A\u0633\u0639": 9,
      "\u062A\u0633\u0639\u0647": 9,
      "\u0639\u0634\u0631": 10,
      "\u0639\u0634\u0631\u0647": 10,
      "\u0645\u0626\u0647": 100,
      "\u0645\u0627\u0626\u0647": 100
    };
    ORD_MAP = {
      "first": 0,
      "second": 1,
      "third": 2,
      "fourth": 3,
      "fifth": 4,
      "last": -1,
      // Arabic
      "\u0627\u0648\u0644": 0,
      "\u062B\u0627\u0646\u064A": 1,
      "\u062B\u0627\u0644\u062B": 2,
      "\u0631\u0627\u0628\u0639": 3,
      "\u062E\u0627\u0645\u0633": 4,
      "\u0627\u062E\u064A\u0631": -1,
      "\u0627\u062E\u0631": -1
    };
    OPERATION_CONCEPTS = {
      sum: ["sum", "total", "add all", "\u0645\u062C\u0645\u0648\u0639", "\u062C\u0645\u0639", "\u0627\u062C\u0645\u0639", "\u062D\u0627\u0635\u0644 \u062C\u0645\u0639"],
      average: ["average", "mean", "\u0645\u062A\u0648\u0633\u0637", "\u0645\u0639\u062F\u0644", "\u0627\u0644\u0645\u062A\u0648\u0633\u0637 \u0627\u0644\u062D\u0633\u0627\u0628\u064A"],
      max: ["maximum", "max", "largest", "biggest", "greatest", "highest", "\u0627\u0643\u0628\u0631", "\u0627\u0639\u0638\u0645", "\u0627\u0642\u0635\u064A", "\u0627\u0639\u0644\u064A", "\u0627\u0644\u0639\u0638\u0645\u064A", "\u0627\u0644\u0642\u064A\u0645\u0647 \u0627\u0644\u0639\u0638\u0645\u064A", "\u0627\u0643\u0628\u0631 \u0639\u062F\u062F", "\u0627\u0643\u0628\u0631 \u0639\u0646\u0635\u0631"],
      min: ["minimum", "min", "smallest", "least", "lowest", "\u0627\u0635\u063A\u0631", "\u0627\u062F\u0646\u064A", "\u0627\u0644\u0635\u063A\u0631\u064A", "\u0627\u0644\u0642\u064A\u0645\u0647 \u0627\u0644\u0635\u063A\u0631\u064A", "\u0627\u0642\u0644 \u0639\u062F\u062F", "\u0627\u0642\u0644 \u0642\u064A\u0645\u0647", "\u0627\u0642\u0644 \u0645\u0646", "\u0627\u0644\u062D\u062F \u0627\u0644\u0627\u062F\u0646\u064A"],
      count: ["count", "number of", "how many", "\u0639\u062F\u062F", "\u0643\u0645", "\u0627\u062D\u0633\u0628 \u0639\u062F\u062F", "\u0639\u062F "],
      sort: ["sort", "order", "arrange", "\u0631\u062A\u0628", "\u062A\u0631\u062A\u064A\u0628", "\u0641\u0631\u0632"],
      reverse: ["reverse", "invert", "\u0627\u0639\u0643\u0633", "\u0639\u0643\u0633", "\u0645\u0642\u0644\u0648\u0628", "\u0627\u0642\u0644\u0628", "\u0628\u0627\u0644\u0639\u0643\u0633"],
      unique: ["unique", "distinct", "deduplicate", "remove duplicates", "\u0641\u0631\u064A\u062F", "\u0645\u0645\u064A\u0632", "\u0645\u0645\u064A\u0632\u0647", "\u0628\u062F\u0648\u0646 \u062A\u0643\u0631\u0627\u0631", "\u062F\u0648\u0646 \u062A\u0643\u0631\u0627\u0631", "\u063A\u064A\u0631 \u0645\u0643\u0631\u0631"],
      flatten: ["flatten", "merge nested", "\u062A\u0633\u0637\u064A\u062D", "\u062F\u0645\u062C \u0627\u0644\u0642\u0648\u0627\u0626\u0645"],
      length: ["length", "size", "\u0637\u0648\u0644", "\u062D\u062C\u0645"],
      product: ["product", "multiply all", "\u062D\u0627\u0635\u0644 \u0636\u0631\u0628", "\u062C\u062F\u0627\u0621"]
    };
    FILTER_PREDICATES = {
      positive: ["positive", "greater than zero", "\u0645\u0648\u062C\u0628", "\u0645\u0648\u062C\u0628\u0647", "\u0627\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0635\u0641\u0631"],
      negative: ["negative", "less than zero", "\u0633\u0627\u0644\u0628", "\u0633\u0627\u0644\u0628\u0647", "\u0627\u0642\u0644 \u0645\u0646 \u0627\u0644\u0635\u0641\u0631", "\u0627\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0635\u0641\u0631"],
      even: ["even", "\u0632\u0648\u062C\u064A", "\u0632\u0648\u062C\u064A\u0647"],
      odd: ["odd", "\u0641\u0631\u062F\u064A", "\u0641\u0631\u062F\u064A\u0647"]
    };
    DIRECTION_QUALIFIERS = {
      descending: ["descending", "decreasing", "largest to smallest", "\u062A\u0646\u0627\u0632\u0644\u064A", "\u062A\u0646\u0627\u0632\u0644\u064A\u0627", "\u0645\u0646 \u0627\u0644\u0627\u0643\u0628\u0631 \u0627\u0644\u064A \u0627\u0644\u0627\u0635\u063A\u0631"],
      ascending: ["ascending", "increasing", "smallest to largest", "\u062A\u0635\u0627\u0639\u062F\u064A", "\u062A\u0635\u0627\u0639\u062F\u064A\u0627", "\u0645\u0646 \u0627\u0644\u0627\u0635\u063A\u0631 \u0627\u0644\u064A \u0627\u0644\u0627\u0643\u0628\u0631"]
    };
  }
});

// synora-v5/synthesis/dsl.mjs
function validateAst(root, arity) {
  let nodes = 0;
  const go = (n, depth, inLam) => {
    if (++nodes > MAX_NODES || depth > MAX_DEPTH) throw new TypeError("program too large or deep");
    if (!n || typeof n !== "object" || Array.isArray(n)) throw new TypeError("invalid program node");
    switch (n.k) {
      case "in":
        if (!Number.isInteger(n.i) || n.i < 0 || n.i >= arity) throw new TypeError("invalid input reference");
        return;
      case "x":
        if (!inLam) throw new TypeError("lambda variable outside lambda");
        return;
      case "const":
        if (!(typeof n.v === "number" && Number.isFinite(n.v) && Math.abs(n.v) <= 1e6) && !(typeof n.v === "string" && n.v.length <= 64) && typeof n.v !== "boolean") throw new TypeError("invalid constant");
        return;
      case "call": {
        if (typeof n.f !== "string" || !Object.hasOwn(SIGS, n.f)) throw new TypeError("unknown primitive");
        if (!Array.isArray(n.a) || n.a.length !== ARITY[n.f]) throw new TypeError("wrong arity");
        n.a.forEach((c, i) => {
          if (c && c.k === "lam") {
            if (!LAMBDA_PRIMS.has(n.f) || i !== n.a.length - 1 || inLam) throw new TypeError("lambda not allowed here");
            go(c.body, depth + 1, true);
          } else {
            if (LAMBDA_PRIMS.has(n.f) && i === n.a.length - 1) throw new TypeError("lambda required");
            go(c, depth + 1, inLam);
          }
        });
        return;
      }
      default:
        throw new TypeError("unknown node kind");
    }
  };
  go(root, 0, false);
  return nodes;
}
function evalAst(root, inputs, { maxSteps = 2e5, x } = {}) {
  let steps = 0;
  const go = (n, xv) => {
    if (++steps > maxSteps) throw new RangeError("step-budget-exceeded");
    if (n.k === "in") return inputs[n.i];
    if (n.k === "const") return n.v;
    if (n.k === "x") return xv;
    if (n.f === "ite") {
      const cond = go(n.a[0], xv);
      return cond ? go(n.a[1], xv) : go(n.a[2], xv);
    }
    const args = n.a.map((c) => c.k === "lam" ? ((v) => go(c.body, v)) : go(c, xv));
    return IMPL[n.f](...args);
  };
  return go(root, x);
}
function toSource(root, arity) {
  validateAst(root, arity);
  const used = /* @__PURE__ */ new Set();
  const emit = (n) => {
    if (n.k === "in") return `a${n.i}`;
    if (n.k === "const") return JSON.stringify(n.v);
    if (n.k === "x") return "x";
    if (n.f === "ite") {
      return `(${emit(n.a[0])}?${emit(n.a[1])}:${emit(n.a[2])})`;
    }
    used.add(n.f);
    return `${n.f}(${n.a.map((c) => c.k === "lam" ? `(x)=>${emit(c.body)}` : emit(c)).join(",")})`;
  };
  const body = emit(root);
  const helpers = [...used].sort().map((f) => `const ${f}=${SRC[f]};`).join("\n  ");
  const params = Array.from({ length: arity }, (_, i) => `a${i}`).join(", ");
  return `export function solution(${params}) {
${helpers ? `  ${helpers}
` : ""}  return ${body};
}`;
}
function typeOfValue(v, depth = 0) {
  if (typeof v === "number") return Number.isFinite(v) && Math.abs(v) <= 1e9 ? "num" : null;
  if (typeof v === "string") return v.length <= 200 ? "str" : null;
  if (typeof v === "boolean") return "bool";
  if (Array.isArray(v) && depth < 2 && v.length <= (depth === 0 ? 100 : 50)) {
    if (v.length === 0) return "L:?";
    const ts = v.map((e) => typeOfValue(e, depth + 1));
    if (ts.includes(null)) return null;
    const concrete = new Set(ts.filter((t2) => !t2.includes("?"))), wild = ts.filter((t2) => t2.includes("?"));
    if (concrete.size > 1) return null;
    const prefix = (w) => "L:".repeat(w.split("L:").length - 1);
    let t;
    if (concrete.size === 1) {
      t = [...concrete][0];
      if (!wild.every((w) => t.startsWith(prefix(w)))) return null;
    } else {
      t = wild.reduce((a, b) => b.length > a.length ? b : a);
      if (!wild.every((w) => t.startsWith(prefix(w)))) return null;
    }
    return t === "num" || t === "str" || t === "bool" || t === "L:num" || t === "L:?" ? `L:${t}` : null;
  }
  return null;
}
function unifyTypes(types) {
  if (types.some((t) => t === null)) return null;
  const wild = types.filter((t) => t.includes("?")), concrete = new Set(types.filter((t) => !t.includes("?")));
  if (concrete.size > 1) return null;
  const depthPrefix = (w) => "L:".repeat(w.split("L:").length - 1);
  if (concrete.size === 1) {
    const t = [...concrete][0];
    return wild.every((w) => t.startsWith(depthPrefix(w))) ? t : null;
  }
  if (!wild.length) return null;
  const deepest = wild.reduce((a, b) => b.length > a.length ? b : a);
  if (!wild.every((w) => deepest.startsWith(depthPrefix(w)))) return null;
  return deepest.replace("?", "num");
}
function deepEqual(a, b) {
  if (typeof a === "number" && typeof b === "number") return a === b || Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(a), Math.abs(b));
  if (Array.isArray(a) && Array.isArray(b)) return a.length === b.length && a.every((v, i) => deepEqual(v, b[i]));
  return a === b;
}
var ERR, DSL_VERSION, N2, NZ, EMPTY, SRC, IMPL, S, LISTS, SIGS, PRIM_NAMES, ARITY, LAMBDA_PRIMS, VALUE_TYPES, MAX_NODES, MAX_DEPTH;
var init_dsl = __esm({
  "synora-v5/synthesis/dsl.mjs"() {
    ERR = /* @__PURE__ */ Symbol("synora-dsl-error");
    DSL_VERSION = "synora-dsl/1.1.0";
    N2 = (body) => `(a,b)=>{const r=${body};if(!Number.isFinite(r)||Math.abs(r)>1e12)throw new RangeError("number-out-of-range");return r}`;
    NZ = (body) => `(a,b)=>{if(b===0)throw new RangeError("division-by-zero");const r=${body};if(!Number.isFinite(r)||Math.abs(r)>1e12)throw new RangeError("number-out-of-range");return r}`;
    EMPTY = 'throw new RangeError("empty-list")';
    SRC = Object.freeze({
      add: N2("a+b"),
      sub: N2("a-b"),
      mul: N2("a*b"),
      div: NZ("a/b"),
      idiv: NZ("Math.floor(a/b)"),
      mod: NZ("((a%b)+b)%b"),
      abs: "a=>Math.abs(a)",
      pow: `(a,b)=>{if(!Number.isFinite(a)||!Number.isFinite(b)||b<0||b>20)throw new RangeError("number-out-of-range");const r=Math.pow(a,b);if(!Number.isFinite(r)||Math.abs(r)>1e12)throw new RangeError("number-out-of-range");return r}`,
      sqrt: 'a=>{if(a<0)throw new RangeError("negative-sqrt");return Math.sqrt(a)}',
      isqrt: 'a=>{if(a<0||!Number.isInteger(a))throw new RangeError("negative-isqrt");return Math.floor(Math.sqrt(a))}',
      floor: "a=>Math.floor(a)",
      ceil: "a=>Math.ceil(a)",
      round: "a=>Math.round(a)",
      min2: "(a,b)=>Math.min(a,b)",
      max2: "(a,b)=>Math.max(a,b)",
      sign: "a=>Math.sign(a)",
      eq: '(a,b)=>typeof a==="number"&&typeof b==="number"?a===b:JSON.stringify(a)===JSON.stringify(b)',
      lt: "(a,b)=>a<b",
      le: "(a,b)=>a<=b",
      not: "a=>!a",
      and: "(a,b)=>a&&b",
      or: "(a,b)=>a||b",
      ite: "(c,a,b)=>c?a:b",
      len: "a=>a.length",
      sum: `a=>{let s=0;for(const v of a)s+=v;if(!Number.isFinite(s)||Math.abs(s)>1e12)throw new RangeError("number-out-of-range");return s}`,
      max: `a=>{if(a.length===0)${EMPTY};let m=a[0];for(const v of a)if(v>m)m=v;return m}`,
      min: `a=>{if(a.length===0)${EMPTY};let m=a[0];for(const v of a)if(v<m)m=v;return m}`,
      head: `a=>{if(a.length===0)${EMPTY};return a[0]}`,
      last: `a=>{if(a.length===0)${EMPTY};return a[a.length-1]}`,
      nth: '(a,i)=>{if(!Number.isInteger(i)||i<0||i>=a.length)throw new RangeError("index-out-of-range");return a[i]}',
      reverse: 'a=>typeof a==="string"?[...a].reverse().join(""):[...a].reverse()',
      sort: 'a=>[...a].sort((x,y)=>typeof x==="number"?x-y:(x<y?-1:x>y?1:0))',
      sortBy: '(a,f)=>{if(!Array.isArray(a))throw new RangeError("bad-list");return [...a].sort((x,y)=>{const kx=f(x),ky=f(y);return typeof kx==="number"?kx-ky:(kx<ky?-1:kx>ky?1:0);})}',
      unique: "a=>{const s=new Set(),o=[];for(const v of a){const k=JSON.stringify(v);if(!s.has(k)){s.add(k);o.push(v)}}return o}",
      tail: "a=>a.slice(1)",
      init: "a=>a.slice(0,-1)",
      take: '(a,n)=>{if(!Number.isInteger(n)||n<0)throw new RangeError("bad-count");return a.slice(0,n)}',
      drop: '(a,n)=>{if(!Number.isInteger(n)||n<0)throw new RangeError("bad-count");return a.slice(n)}',
      takeWhile: '(a,f)=>{if(!Array.isArray(a))throw new RangeError("bad-list");const o=[];for(const v of a){if(!f(v))break;o.push(v);}return o;}',
      dropWhile: '(a,f)=>{if(!Array.isArray(a))throw new RangeError("bad-list");let i=0;while(i<a.length&&f(a[i]))i++;return a.slice(i);}',
      zip: '(a,b)=>{if(!Array.isArray(a)||!Array.isArray(b))throw new RangeError("bad-list");const len=Math.min(a.length,b.length);const o=new Array(len);for(let i=0;i<len;i++)o[i]=[a[i],b[i]];return o;}',
      enumerate: 'a=>{if(!Array.isArray(a))throw new RangeError("bad-list");return a.map((v,i)=>[i,v]);}',
      slidingWindow: '(a,k)=>{if(!Array.isArray(a)||!Number.isInteger(k)||k<=0||k>a.length)throw new RangeError("bad-window");const o=[];for(let i=0;i<=a.length-k;i++)o.push(a.slice(i,i+k));return o;}',
      cumsum: 'a=>{if(!Array.isArray(a))throw new RangeError("bad-list");let s=0;const o=new Array(a.length);for(let i=0;i<a.length;i++){s+=a[i];if(!Number.isFinite(s)||Math.abs(s)>1e12)throw new RangeError("number-out-of-range");o[i]=s;}return o;}',
      transpose: 'a=>{if(!Array.isArray(a)||a.length===0||!Array.isArray(a[0]))throw new RangeError("bad-matrix");const w=a[0].length;for(let r of a)if(!Array.isArray(r)||r.length!==w)throw new RangeError("non-rectangular");return Array.from({length:w},(_,c)=>a.map(r=>r[c]));}',
      pair: "(a,b)=>[a,b]",
      fst: 'p=>{if(!Array.isArray(p)||p.length<2)throw new RangeError("bad-pair");return p[0];}',
      snd: 'p=>{if(!Array.isArray(p)||p.length<2)throw new RangeError("bad-pair");return p[1];}',
      concat: "(a,b)=>[...a,...b]",
      flatten: "a=>a.flat(1)",
      map: "(a,f)=>a.map(v=>f(v))",
      filter: "(a,f)=>a.filter(v=>f(v))",
      all: "(a,f)=>a.every(v=>f(v))",
      any: "(a,f)=>a.some(v=>f(v))",
      iterate: '(k,init,f)=>{if(!Number.isInteger(k)||k<0||k>500)throw new RangeError("bad-count");let cur=init;for(let i=0;i<k;i++){cur=f(cur);}return cur;}',
      range: 'n=>{if(!Number.isInteger(n)||n<0||n>200)throw new RangeError("bad-range");return Array.from({length:n},(_,i)=>i)}',
      rangeFrom: '(a,b)=>{if(!Number.isInteger(a)||!Number.isInteger(b)||b-a>200)throw new RangeError("bad-range");const o=[];for(let i=a;i<b;i++)o.push(i);return o}',
      split: "(s,sep)=>s.split(sep)",
      join: 'a=>a.join("")',
      joinSep: "(a,sep)=>a.join(sep)",
      replace: "(s,a,b)=>s.replaceAll(a,b)",
      startsWith: "(s,sub)=>s.startsWith(sub)",
      endsWith: "(s,sub)=>s.endsWith(sub)",
      contains: "(s,sub)=>s.includes(sub)",
      slice: "(s,a,b)=>s.slice(a,b)",
      charAt: '(s,i)=>{if(i<0||i>=s.length)throw new RangeError("index-out-of-range");return s[i];}',
      chars: "s=>[...s]",
      words: "s=>s.split(/\\s+/).filter(Boolean)",
      lower: "s=>s.toLowerCase()",
      upper: "s=>s.toUpperCase()",
      trim: "s=>s.trim()",
      isDigit: 's=>s.length===1&&s>="0"&&s<="9"',
      isAlpha: 's=>s.length===1&&((s>="a"&&s<="z")||(s>="A"&&s<="Z"))',
      toNumber: 's=>{const n=Number(s);if(!Number.isFinite(n)||s.trim()==="")throw new RangeError("bad-number");return n;}',
      toString: "a=>String(a)"
    });
    IMPL = Object.freeze(Object.fromEntries(Object.entries(SRC).map(([k, v]) => [k, (0, eval)(`(${v})`)])));
    S = (args, ret) => ({ args, ret });
    LISTS = ["L:num", "L:str"];
    SIGS = Object.freeze({
      add: [S(["num", "num"], "num")],
      sub: [S(["num", "num"], "num")],
      mul: [S(["num", "num"], "num")],
      div: [S(["num", "num"], "num")],
      idiv: [S(["num", "num"], "num")],
      mod: [S(["num", "num"], "num")],
      abs: [S(["num"], "num")],
      pow: [S(["num", "num"], "num")],
      sqrt: [S(["num"], "num")],
      isqrt: [S(["num"], "num")],
      floor: [S(["num"], "num")],
      ceil: [S(["num"], "num")],
      round: [S(["num"], "num")],
      min2: [S(["num", "num"], "num")],
      max2: [S(["num", "num"], "num")],
      sign: [S(["num"], "num")],
      eq: [S(["num", "num"], "bool"), S(["str", "str"], "bool"), S(["bool", "bool"], "bool"), S(["L:num", "L:num"], "bool")],
      lt: [S(["num", "num"], "bool")],
      le: [S(["num", "num"], "bool")],
      not: [S(["bool"], "bool")],
      and: [S(["bool", "bool"], "bool")],
      or: [S(["bool", "bool"], "bool")],
      ite: [S(["bool", "num", "num"], "num"), S(["bool", "bool", "bool"], "bool"), S(["bool", "str", "str"], "str"), S(["bool", "L:num", "L:num"], "L:num")],
      len: [S(["L:num"], "num"), S(["L:str"], "num"), S(["L:L:num"], "num"), S(["str"], "num")],
      sum: [S(["L:num"], "num")],
      max: [S(["L:num"], "num")],
      min: [S(["L:num"], "num")],
      head: [S(["L:num"], "num"), S(["L:str"], "str"), S(["L:L:num"], "L:num")],
      last: [S(["L:num"], "num"), S(["L:str"], "str"), S(["L:L:num"], "L:num")],
      nth: [S(["L:num", "num"], "num"), S(["L:str", "num"], "str")],
      reverse: [S(["L:num"], "L:num"), S(["L:str"], "L:str"), S(["str"], "str")],
      sort: [S(["L:num"], "L:num"), S(["L:str"], "L:str")],
      sortBy: [S(["L:num", "\u03BBnum"], "L:num"), S(["L:str", "\u03BBnum"], "L:str")],
      unique: [S(["L:num"], "L:num"), S(["L:str"], "L:str")],
      tail: LISTS.map((t) => S([t], t)),
      init: LISTS.map((t) => S([t], t)),
      take: [S(["L:num", "num"], "L:num")],
      drop: [S(["L:num", "num"], "L:num")],
      takeWhile: [S(["L:num", "\u03BBbool"], "L:num")],
      dropWhile: [S(["L:num", "\u03BBbool"], "L:num")],
      zip: [S(["L:num", "L:num"], "L:L:num")],
      enumerate: [S(["L:num"], "L:L:num")],
      slidingWindow: [S(["L:num", "num"], "L:L:num")],
      cumsum: [S(["L:num"], "L:num")],
      transpose: [S(["L:L:num"], "L:L:num")],
      pair: [S(["num", "num"], "L:num")],
      fst: [S(["L:num"], "num")],
      snd: [S(["L:num"], "num")],
      concat: LISTS.map((t) => S([t, t], t)),
      flatten: [S(["L:L:num"], "L:num")],
      map: [S(["L:num", "\u03BBnum"], "L:num")],
      filter: [S(["L:num", "\u03BBbool"], "L:num")],
      all: [S(["L:num", "\u03BBbool"], "bool")],
      any: [S(["L:num", "\u03BBbool"], "bool")],
      iterate: [S(["num", "L:num", "\u03BBL:num"], "L:num"), S(["num", "num", "\u03BBnum"], "num")],
      range: [S(["num"], "L:num")],
      rangeFrom: [S(["num", "num"], "L:num")],
      split: [S(["str", "str"], "L:str")],
      join: [S(["L:str"], "str")],
      joinSep: [S(["L:str", "str"], "str")],
      replace: [S(["str", "str", "str"], "str")],
      startsWith: [S(["str", "str"], "bool")],
      endsWith: [S(["str", "str"], "bool")],
      contains: [S(["str", "str"], "bool")],
      slice: [S(["str", "num", "num"], "str")],
      charAt: [S(["str", "num"], "str")],
      chars: [S(["str"], "L:str")],
      words: [S(["str"], "L:str")],
      lower: [S(["str"], "str")],
      upper: [S(["str"], "str")],
      trim: [S(["str"], "str")],
      isDigit: [S(["str"], "bool")],
      isAlpha: [S(["str"], "bool")],
      toNumber: [S(["str"], "num")],
      toString: [S(["num"], "str")]
    });
    PRIM_NAMES = Object.freeze(Object.keys(SIGS).sort());
    ARITY = Object.freeze(Object.fromEntries(PRIM_NAMES.map((n) => [n, SIGS[n][0].args.length])));
    LAMBDA_PRIMS = /* @__PURE__ */ new Set(["map", "filter", "all", "any", "iterate", "takeWhile", "dropWhile", "sortBy"]);
    VALUE_TYPES = Object.freeze(["num", "str", "bool", "pair", "L:num", "L:str", "L:bool", "L:pair", "L:L:num"]);
    MAX_NODES = 250;
    MAX_DEPTH = 20;
  }
});

// synora-v5/nl2code/sanity-checks.mjs
function executeAST(ast, input) {
  const args = Array.isArray(input) && input.length === 1 && Array.isArray(input[0]) ? input : [input];
  return evalAst(ast, args);
}
function verifySanityChecks(ast, opConcept) {
  try {
    const single = opConcept === "selector" ? [42, 43, 44] : [42];
    const singleOut = executeAST(ast, [single]);
    try {
      executeAST(ast, [[]]);
    } catch (e) {
      if (!(e instanceof RangeError)) return false;
    }
    if (opConcept === "sort") {
      const sample = [5, 2, 8, 1, 9];
      const sorted = executeAST(ast, [sample]);
      if (!Array.isArray(sorted) || sorted.length !== sample.length) return false;
      const s1 = [...sample].sort((a, b) => a - b);
      const s2 = [...sorted].sort((a, b) => a - b);
      if (!deepEqual(s1, s2)) return false;
    }
    if (opConcept === "filter" || opConcept === "unique") {
      const sample = [1, 2, 2, 3, 1];
      const out = executeAST(ast, [sample]);
      if (!Array.isArray(out) || out.length > sample.length) return false;
    }
    if (opConcept === "selector") {
      const selected = executeAST(ast, [[10, 20, 30, 40]]);
      if (Array.isArray(selected) || selected === void 0) return false;
    }
    return true;
  } catch {
    return false;
  }
}
var init_sanity_checks = __esm({
  "synora-v5/nl2code/sanity-checks.mjs"() {
    init_dsl();
  }
});

// synora-v5/nl2code/grammar.mjs
function tokenize2(text, lang = "en") {
  if (lang === "ar" || /[\u0600-\u06FF]/.test(text)) {
    const norm = normalizeArabicText(text);
    return norm.replace(/[؟?.,!؛،:]/g, " ").split(/\s+/).filter(Boolean);
  }
  return text.toLowerCase().replace(/[^a-z0-9\s-]/g, " ").split(/\s+/).filter(Boolean);
}
function literalToNumber(raw) {
  if (raw === null || raw === void 0) return null;
  let s = String(raw).trim().toLowerCase();
  if (!s) return null;
  s = s.replace(/[٠-٩]/g, (d) => String("\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669".indexOf(d)));
  if (/^-?\d+(?:\.\d+)?$/.test(s)) return Number(s);
  let negative = false;
  const signMatch = s.match(/^(negative|minus|سالب)\s+(.+)$/);
  if (signMatch) {
    negative = true;
    s = signMatch[2].trim();
  }
  const words = s.split(/\s+/).filter(Boolean);
  for (let n = Math.min(2, words.length); n >= 1; n--) {
    const candidate = words.slice(0, n).join(" ");
    let value = null;
    if (EN_NUM_WORDS[candidate] !== void 0) value = EN_NUM_WORDS[candidate];
    else {
      const norm = normalizeArabicText(candidate);
      for (const [word, val] of Object.entries(NUMERALS)) {
        if (normalizeArabicText(word) === norm) {
          value = val;
          break;
        }
      }
    }
    if (value !== null) return negative ? -value : value;
  }
  return null;
}
function parseCardinalSelection(promptLower, promptNormAr) {
  const en = new RegExp(`\\b(first|last)\\s+(-?\\d+(?:\\.\\d+)?|[a-z]+(?:\\s+[a-z]+)?)\\s+${SELECTION_NOUNS_EN}\\b`, "i").exec(promptLower);
  if (en) {
    const count = literalToNumber(en[2]);
    if (Number.isInteger(count) && count >= 0) return { direction: en[1].toLowerCase(), count, span: en[0] };
  }
  const ar = new RegExp(`(?:^|\\s)(\u0627\u0648\u0644|\u0627\u062E\u0631)\\s+((?:[\u0660-\u0669]+)|(?:\u0648\u0627\u062D\u062F|\u0627\u062B\u0646\u0627\u0646|\u0627\u062B\u0646\u064A\u0646|\u062B\u0644\u0627\u062B|\u062B\u0644\u0627\u062B\u0629|\u0627\u0631\u0628\u0639|\u0627\u0631\u0628\u0639\u0647|\u0627\u0631\u0628\u0639\u0629|\u0623\u0631\u0628\u0639|\u0623\u0631\u0628\u0639\u0629|\u062E\u0645\u0633|\u062E\u0645\u0633\u0629|\u0633\u062A|\u0633\u062A\u0629|\u0633\u0628\u0639|\u0633\u0628\u0639\u0629|\u062B\u0645\u0627\u0646|\u062B\u0645\u0627\u0646\u064A\u0629|\u062A\u0633\u0639|\u062A\u0633\u0639\u0629|\u0639\u0634\u0631|\u0639\u0634\u0631\u0629))\\s+${SELECTION_NOUNS_AR}(?=\\s|$)`, "u").exec(promptNormAr);
  if (ar) {
    const count = literalToNumber(ar[2]);
    if (Number.isInteger(count) && count >= 0) return { direction: ar[1] === "\u0627\u0648\u0644" ? "first" : "last", count, span: ar[0] };
  }
  const arDual = /(?:^|\s)(اخر|اول)\s+(عنصرين|رقمين|قيمتين)(?=\s|$)/u.exec(promptNormAr);
  if (arDual) return { direction: arDual[1] === "\u0627\u0648\u0644" ? "first" : "last", count: 2, span: arDual[0] };
  return null;
}
function parseNLToCode(prompt, options = {}) {
  const lang = options.lang || (typeof prompt === "string" && /[\u0600-\u06FF]/.test(prompt) ? "ar" : "en");
  const tokens = tokenize2(prompt, lang);
  const promptLower = prompt.toLowerCase();
  const promptNormAr = normalizeArabicText(prompt);
  const arDeixisToken = tokens.some((t) => t.length > 3 && (t.endsWith("\u0647\u0645") || t.endsWith("\u0647\u0646")));
  if (EN_DEIXIS.test(promptLower) || AR_DEIXIS.test(promptNormAr) || arDeixisToken) {
    return { status: "abstain", reason: "contextual_followup_requires_state", unmodelled: ["contextual-reference"] };
  }
  const thresholds = [];
  const thresholdErrors = [];
  const enThresholdSpans = [];
  const arThresholdSpans = [];
  const enThresholdRe = new RegExp(
    `\\b(${EN_GREATER_WORDS.join("|")})\\s+than\\s+(-?\\d+(?:\\.\\d+)?|(?:negative|minus)\\s+[a-z]+|[a-z]+)`,
    "gi"
  );
  const enLessRe = new RegExp(
    `\\b(${EN_LESS_WORDS.join("|")})\\s+than\\s+(-?\\d+(?:\\.\\d+)?|(?:negative|minus)\\s+[a-z]+|[a-z]+)`,
    "gi"
  );
  const arThresholdRe = new RegExp(
    `(${AR_GREATER_WORDS.join("|")})\\s+\u0645\u0646\\s+((?:\u0633\u0627\u0644\u0628\\s+)?[\\u0621-\\u064A\\u0660-\\u0669]+(?:\\s+[\\u0621-\\u064A\\u0660-\\u0669]+)?)`,
    "g"
  );
  const arLessRe = new RegExp(
    `(${AR_LESS_WORDS.join("|")})\\s+\u0645\u0646\\s+((?:\u0633\u0627\u0644\u0628\\s+)?[\\u0621-\\u064A\\u0660-\\u0669]+(?:\\s+[\\u0621-\\u064A\\u0660-\\u0669]+)?)`,
    "g"
  );
  const enAtLeastRe = /\b(?:at least|no less than)\s+(-?\d+(?:\.\d+)?|(?:negative|minus)\s+[a-z]+|[a-z]+)/gi;
  const enAtMostRe = /\b(?:at most|no more than)\s+(-?\d+(?:\.\d+)?|(?:negative|minus)\s+[a-z]+|[a-z]+)/gi;
  const arAtLeastRe = /(?:لا\\s+يقل\\s+عن|على\\s+الاقل\\s+من)\\s+((?:سالب\\s+)?[\\u0621-\\u064A\\u0660-\\u0669]+(?:\\s+[\\u0621-\\u064A\\u0660-\\u0669]+)?)/g;
  const arAtMostRe = /(?:لا\\s+يزيد\\s+عن|على\\s+الاكثر\\s+من)\\s+((?:سالب\\s+)?[\\u0621-\\u064A\\u0660-\\u0669]+(?:\\s+[\\u0621-\\u064A\\u0660-\\u0669]+)?)/g;
  const collect = (re, kind) => {
    let m;
    while ((m = re.exec(promptLower)) !== null) {
      const value = literalToNumber(m[2]);
      if (value === null) thresholdErrors.push(m[0]);
      else thresholds.push({ kind, value });
      enThresholdSpans.push([m.index, m.index + m[0].length]);
      if (m.index === re.lastIndex) re.lastIndex++;
    }
  };
  const collectSingle = (re, kind, haystack, spans) => {
    let m;
    while ((m = re.exec(haystack)) !== null) {
      const value = literalToNumber(m[1]);
      if (value === null) thresholdErrors.push(m[0]);
      else thresholds.push({ kind, value });
      spans.push([m.index, m.index + m[0].length]);
      if (m.index === re.lastIndex) re.lastIndex++;
    }
  };
  collect(enThresholdRe, "greaterThan");
  collect(enLessRe, "lessThan");
  collectSingle(enAtLeastRe, "atLeast", promptLower, enThresholdSpans);
  collectSingle(enAtMostRe, "atMost", promptLower, enThresholdSpans);
  {
    let m;
    while ((m = arThresholdRe.exec(promptNormAr)) !== null) {
      const value = literalToNumber(m[2]);
      if (value === null) thresholdErrors.push(m[0]);
      else thresholds.push({ kind: "greaterThan", value });
      arThresholdSpans.push([m.index, m.index + m[0].length]);
      if (m.index === arThresholdRe.lastIndex) arThresholdRe.lastIndex++;
    }
    while ((m = arLessRe.exec(promptNormAr)) !== null) {
      const value = literalToNumber(m[2]);
      if (value === null) thresholdErrors.push(m[0]);
      else thresholds.push({ kind: "lessThan", value });
      arThresholdSpans.push([m.index, m.index + m[0].length]);
      if (m.index === arLessRe.lastIndex) arLessRe.lastIndex++;
    }
    collectSingle(arAtLeastRe, "atLeast", promptNormAr, arThresholdSpans);
    collectSingle(arAtMostRe, "atMost", promptNormAr, arThresholdSpans);
  }
  if (thresholdErrors.length) {
    return { status: "abstain", reason: "unparsed_threshold", unmodelled: [...new Set(thresholdErrors)].slice(0, 4) };
  }
  const grammarWords = new Set("please help me you what which how can i want need get arithmetic write return returns function code calculate compute find identify make create among that all only numbers number integers integer array arrays list lists elements element values value items item the a an of to in from for and with is are be it them these those now then precisely thank thanks keep select extract filter by than greater less more fewer zero first second third fourth fifth last ascending descending increasing decreasing positive negative even odd unique distinct maximum minimum max min largest smallest highest lowest sum total add average mean count sort order reverse flatten product multiply minus or either at least most no many".split(" "));
  const commonArabic = "\u0642\u0645 \u0628\u0640 \u0645\u0646 \u0641\u0636\u0644\u0643 \u0634\u0643\u0631\u0627 \u0634\u0643\u0631\u0627\u064B \u0643\u0644 \u062D\u062F\u062F \u064A\u062D\u0642\u0642 \u062D\u062F \u0627\u0642\u0644 \u0627\u0643\u0628\u0631 \u0627\u0643\u062B\u0631 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0642\u064A\u0645\u0647 \u0642\u064A\u0645\u0647 \u0627\u0644\u0635\u063A\u0631\u064A \u0627\u0644\u0635\u063A\u0631\u0649 \u0627\u0644\u0639\u0638\u0645\u064A \u0627\u0644\u0639\u0638\u0645\u0649 \u0644\u0627\u0639\u062F\u0627\u062F \u0627\u0644\u0642\u064A\u0645\u0647 \u0627\u0644\u0642\u064A\u0645 \u0627\u0644\u0623\u0639\u062F\u0627\u062F \u0627\u0644\u0627\u0639\u062F\u0627\u062F \u0627\u0644\u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0627\u0631\u0642\u0627\u0645 \u0627\u0644\u0639\u0646\u0627\u0635\u0631 \u0639\u0646\u0635\u0631 \u0627\u0644\u0645\u0635\u0641\u0648\u0641\u0629 \u0627\u0644\u0645\u0635\u0641\u0648\u0641\u0647 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0627\u0626\u0645\u0647 \u0627\u0633\u062A\u062E\u0631\u062C \u0623\u0648\u062C\u062F \u0627\u0648\u062C\u062F \u0627\u062D\u0633\u0628 \u0639\u062F \u0628\u0627\u0644\u0636\u0628\u0637 \u0641\u0642\u0637 \u062F\u0648\u0646 \u062A\u0643\u0631\u0627\u0631 \u062D\u0627\u0635\u0644 \u0627\u0644\u0623\u0643\u0628\u0631 \u0627\u0644\u0627\u0643\u0628\u0631 \u0627\u0644\u0635\u0641\u0631 \u0635\u0641\u0631 \u0645\u062A\u0648\u0633\u0637 \u0645\u0627 \u0647\u0648 \u0647\u064A \u062A\u0639\u064A\u062F \u062A\u0631\u062C\u0639 \u0635\u0641\u064A \u0644\u0644 \u0644\u0644\u0623\u0631\u0642\u0627\u0645 \u062A\u0635\u0627\u0639\u062F\u064A \u062A\u0635\u0627\u0639\u062F\u064A\u0627 \u0641\u064A \u0627\u062D\u062A\u0641\u0638 \u0628\u0627\u0644\u0642\u064A\u0645 \u0631\u0642\u0645\u0627 \u0631\u0642\u0645\u0627 \u0641\u0631\u062F\u064A\u0627 \u0641\u0631\u062F\u064A\u0647 \u0645\u0648\u062C\u0648\u062F \u0627\u0644\u062D\u062F \u0627\u0644\u0623\u062F\u0646\u0649 \u0627\u0644\u0623\u0639\u0644\u0649 \u0627\u0639\u0644\u0649 \u0627\u062D\u062A\u0641\u0638 \u0627\u0648 \u0627\u0645\u0627".split(/\s+/);
  const vocabularyWords = [
    ...Object.values(OPERATION_CONCEPTS).flat(),
    ...Object.values(FILTER_PREDICATES).flat(),
    ...Object.values(DIRECTION_QUALIFIERS).flat(),
    ...Object.keys(ORD_MAP),
    ...Object.keys(NUMERALS),
    ...Object.keys(EN_NUM_WORDS),
    ...grammarWords,
    ...commonArabic
  ];
  const lexicalWords = /* @__PURE__ */ new Set();
  for (const word of vocabularyWords) {
    const normalized = normalizeArabicText(String(word)).toLowerCase();
    lexicalWords.add(normalized);
    if (/[\u0600-\u06FF]/.test(normalized)) lexicalWords.add(stemArabicWord(normalized));
  }
  const unknownWords = tokens.filter((t) => {
    if (t.length <= 1 || lexicalWords.has(t)) return false;
    if (/^-?\d+(?:\.\d+)?$/.test(t)) return false;
    if (/[\u0600-\u06FF]/.test(t)) {
      const stem = stemArabicWord(t);
      if (lexicalWords.has(stem)) return false;
      const reduced = stem.replace(/(?:ا|ان|ين|ون|ات)$/u, "");
      if (reduced !== stem && lexicalWords.has(reduced)) return false;
    }
    return true;
  });
  if (unknownWords.length) return { status: "abstain", reason: "unmodelled_vocabulary", unmodelled: [...new Set(unknownWords)].slice(0, 8) };
  const unsupportedCompositions = [
    /\b(?:between|without|each|every|any)\b/i,
    /(?:بين|بدون|لكل|اي|أي)\s+/
  ];
  const unsupportedHit = unsupportedCompositions.find((re) => re.test(promptLower) || re.test(promptNormAr));
  if (unsupportedHit) return { status: "abstain", reason: "unsupported_compositional_operator", unmodelled: [prompt.match(unsupportedHit)?.[0] || "unsupported qualifier"] };
  const outOfDomainWords = [
    "poem",
    "romantic",
    "moon",
    "stars",
    "story",
    "space",
    "stock",
    "predict",
    "finance",
    "price",
    "delete all",
    "root",
    "/etc",
    "\u0634\u0639\u0631",
    "\u0631\u0648\u0645\u0627\u0646\u0633\u064A",
    "\u0642\u0645\u0631",
    "\u0646\u062C\u0648\u0645",
    "\u0642\u0635\u0629",
    "\u0641\u0636\u0627\u0621",
    "\u0627\u0633\u0647\u0645",
    "\u0628\u0648\u0631\u0635\u0629",
    "\u062A\u0648\u0642\u0639",
    "\u062D\u0630\u0641 \u0627\u0644\u0646\u0638\u0627\u0645"
  ];
  for (const ood of outOfDomainWords) {
    if (promptLower.includes(ood) || promptNormAr.includes(ood)) {
      return {
        status: "abstain",
        reason: "out_of_domain",
        unmodelled: [ood]
      };
    }
  }
  let detectedOp = null;
  const opOrder = ["max", "min", "count", "reverse", "flatten", "sum", "average", "sort", "unique", "length", "product"];
  const arThresholdComparator = new RegExp(`(${AR_GREATER_WORDS.concat(AR_LESS_WORDS).join("|")})\\s+\u0645\u0646\\s`);
  const arMaxPhrase = /(?:اكبر|اعلي|العظمي|اقصي|اعظم)\\s+(?:عدد|عنصر|قيمه|القيمه|قيمة|قيم)/;
  const arMinPhrase = /(?:اقل|اصغر|الصغري|ادني|اننى)\\s+(?:عدد|عنصر|قيمه|القيمه|قيمة|قيم)/;
  const insideSpan = (spans, start, len) => spans.some(([a, b]) => start >= a && start + len <= b);
  for (const op of opOrder) {
    const keywords = OPERATION_CONCEPTS[op] || [];
    for (const kw of keywords) {
      const isArabic = /[\u0600-\u06FF]/.test(kw);
      const haystack = isArabic ? promptNormAr : promptLower;
      const spans = isArabic ? arThresholdSpans : enThresholdSpans;
      const idx = haystack.indexOf(kw);
      if (idx >= 0 && insideSpan(spans, idx, kw.length)) {
        const explicitOpPhrase = op === "max" ? arMaxPhrase.test(promptNormAr) : op === "min" ? arMinPhrase.test(promptNormAr) : false;
        if (!explicitOpPhrase) continue;
      }
      if (tokens.includes(kw) || promptLower.includes(kw) || promptNormAr.includes(kw)) {
        detectedOp = op;
        break;
      }
    }
    if (detectedOp) break;
  }
  const nestedAggregation = [
    /\b(?:sum|total|average|mean)\s+of\s+(?:the\s+)?(?:count|number|length|size|sum|total|average)\b/i,
    /(?:حاصل\s+جمع|مجموع|المتوسط|متوسط)\s+من\s+(?:عدد|طول|مجموع|حاصل)/
  ].find((re) => re.test(promptLower) || re.test(promptNormAr));
  if (nestedAggregation) {
    return { status: "abstain", reason: "unsupported_nested_aggregation", unmodelled: [prompt.match(nestedAggregation)?.[0] || "nested aggregation"] };
  }
  const predicates = [];
  for (const t of thresholds) predicates.push(t);
  for (const [pred, keywords] of Object.entries(FILTER_PREDICATES)) {
    for (const kw of keywords) {
      const isArabic = /[\u0600-\u06FF]/.test(kw);
      const haystack = isArabic ? promptNormAr : promptLower;
      const spans = isArabic ? arThresholdSpans : enThresholdSpans;
      let matched = false;
      if (isArabic) {
        const idx = haystack.indexOf(kw);
        if (idx >= 0 && !insideSpan(spans, idx, kw.length)) matched = true;
      } else {
        const safe = kw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        const re = new RegExp(`(^|[^a-z0-9])${safe}([^a-z0-9]|$)`, "i");
        const m = re.exec(haystack);
        if (m) {
          const start = m.index + m[1].length;
          if (!insideSpan(spans, start, kw.length)) matched = true;
        }
      }
      if (matched) {
        predicates.push({ kind: pred });
        break;
      }
    }
  }
  const hasGt0 = predicates.some((p) => p.kind === "greaterThan" && p.value === 0);
  const hasLt0 = predicates.some((p) => p.kind === "lessThan" && p.value === 0);
  const seenPred = /* @__PURE__ */ new Set();
  const qualifiers = [];
  for (const p of predicates) {
    if (p.kind === "positive" && hasGt0) continue;
    if (p.kind === "negative" && hasLt0) continue;
    const key = `${p.kind}:${p.value ?? ""}`;
    if (seenPred.has(key)) continue;
    seenPred.add(key);
    qualifiers.push(p);
  }
  const detectedFilter = qualifiers.length ? qualifiers[0] : null;
  const hasQualifier = qualifiers.length > 0;
  if (qualifiers.length > 1) {
    const disjunctive = /\b(?:or|either)\b/i.test(promptLower) || /(?:^|\s)(?:او|أو|اما)(?:\s|$)/.test(promptNormAr);
    if (disjunctive) {
      return { status: "abstain", reason: "unsupported_disjunction", unmodelled: ["or"] };
    }
  }
  let detectedDir = null;
  for (const [dir, keywords] of Object.entries(DIRECTION_QUALIFIERS)) {
    for (const kw of keywords) {
      if (promptLower.includes(kw) || promptNormAr.includes(kw)) {
        detectedDir = dir;
        break;
      }
    }
    if (detectedDir) break;
  }
  let detectedOrd = null;
  for (const [ordKey, idx] of Object.entries(ORD_MAP)) {
    if (promptLower.includes(ordKey) || promptNormAr.includes(ordKey)) {
      detectedOrd = idx;
      break;
    }
  }
  const hasDistinct = promptLower.includes("distinct") || promptLower.includes("unique") || promptNormAr.includes("\u0641\u0631\u064A\u062F") || promptNormAr.includes("\u062A\u0643\u0631\u0627\u0631") || promptNormAr.includes("\u0645\u0645\u064A\u0632");
  const cardinalSelection = parseCardinalSelection(promptLower, promptNormAr);
  let candidateAst = null;
  const buildOnePredAst = (pred) => {
    const X = { k: "x" };
    switch (pred.kind) {
      case "positive":
        return { k: "call", f: "lt", a: [{ k: "const", v: 0 }, X] };
      case "negative":
        return { k: "call", f: "lt", a: [X, { k: "const", v: 0 }] };
      case "even":
        return { k: "call", f: "eq", a: [{ k: "call", f: "mod", a: [X, { k: "const", v: 2 }] }, { k: "const", v: 0 }] };
      case "odd":
        return { k: "call", f: "not", a: [{ k: "call", f: "eq", a: [{ k: "call", f: "mod", a: [X, { k: "const", v: 2 }] }, { k: "const", v: 0 }] }] };
      case "greaterThan":
        return { k: "call", f: "lt", a: [{ k: "const", v: pred.value }, X] };
      case "lessThan":
        return { k: "call", f: "lt", a: [X, { k: "const", v: pred.value }] };
      case "atLeast":
        return { k: "call", f: "le", a: [{ k: "const", v: pred.value }, X] };
      case "atMost":
        return { k: "call", f: "le", a: [X, { k: "const", v: pred.value }] };
      default:
        return null;
    }
  };
  const buildPredAst = (preds) => {
    const parts = preds.map(buildOnePredAst).filter(Boolean);
    if (!parts.length) return null;
    return parts.reduce((acc, part) => ({ k: "call", f: "and", a: [acc, part] }));
  };
  const inp0 = { k: "in", i: 0 };
  if (cardinalSelection) {
    const count = { k: "const", v: cardinalSelection.count };
    const source = cardinalSelection.direction === "last" ? { k: "call", f: "reverse", a: [inp0] } : inp0;
    const taken = { k: "call", f: "take", a: [source, count] };
    candidateAst = cardinalSelection.direction === "last" ? { k: "call", f: "reverse", a: [taken] } : taken;
  } else if (detectedOrd !== null && detectedOrd > 0 && detectedOp === "max") {
    return { status: "abstain", reason: "unsupported_ordinal_selection", unmodelled: [String(detectedOrd)] };
  }
  if (!candidateAst && (detectedOrd === 0 || detectedOrd === -1) && hasQualifier) {
    const filtered = { k: "call", f: "filter", a: [inp0, { k: "lam", body: buildPredAst(qualifiers) }] };
    candidateAst = { k: "call", f: detectedOrd === 0 ? "head" : "last", a: [filtered] };
  } else if (!candidateAst && detectedOrd === 1 && (promptLower.includes("largest") || promptLower.includes("biggest") || promptNormAr.includes("\u0627\u0643\u0628\u0631"))) {
    candidateAst = { k: "call", f: "nth", a: [
      { k: "call", f: "reverse", a: [{ k: "call", f: "sort", a: [{ k: "call", f: "unique", a: [inp0] }] }] },
      { k: "const", v: 1 }
    ] };
  } else if (!candidateAst && ["sum", "count", "average", "min", "max"].includes(detectedOp)) {
    let valuesAst = inp0;
    if (hasDistinct) valuesAst = { k: "call", f: "unique", a: [valuesAst] };
    if (hasQualifier) {
      valuesAst = { k: "call", f: "filter", a: [valuesAst, { k: "lam", body: buildPredAst(qualifiers) }] };
    }
    if (detectedOp === "sum") candidateAst = { k: "call", f: "sum", a: [valuesAst] };
    else if (detectedOp === "count") candidateAst = { k: "call", f: "len", a: [valuesAst] };
    else if (detectedOp === "average") candidateAst = { k: "call", f: "div", a: [
      { k: "call", f: "sum", a: [valuesAst] },
      { k: "call", f: "len", a: [valuesAst] }
    ] };
    else candidateAst = { k: "call", f: detectedOp, a: [valuesAst] };
  } else if (!candidateAst && detectedOp === "sort") {
    const sortedAst = { k: "call", f: "sort", a: [inp0] };
    if (detectedDir === "descending") {
      const reversed = { k: "call", f: "reverse", a: [sortedAst] };
      candidateAst = detectedOrd === 0 ? { k: "call", f: "head", a: [reversed] } : detectedOrd === -1 ? { k: "call", f: "last", a: [reversed] } : reversed;
    } else {
      candidateAst = detectedOrd === 0 ? { k: "call", f: "head", a: [sortedAst] } : detectedOrd === -1 ? { k: "call", f: "last", a: [sortedAst] } : sortedAst;
    }
  } else if (!candidateAst && detectedOp === "reverse") {
    const reversed = { k: "call", f: "reverse", a: [inp0] };
    candidateAst = detectedOrd === 0 ? { k: "call", f: "head", a: [reversed] } : detectedOrd === -1 ? { k: "call", f: "last", a: [reversed] } : reversed;
  } else if (!candidateAst && (detectedOp === "unique" || hasDistinct)) {
    if (detectedOrd === 1 && (promptLower.includes("largest") || promptNormAr.includes("\u0627\u0643\u0628\u0631"))) {
      candidateAst = {
        k: "call",
        f: "nth",
        a: [
          { k: "call", f: "reverse", a: [{ k: "call", f: "sort", a: [{ k: "call", f: "unique", a: [inp0] }] }] },
          { k: "const", v: 1 }
        ]
      };
    } else {
      candidateAst = { k: "call", f: "unique", a: [inp0] };
    }
  } else if (!candidateAst && hasQualifier && !detectedOp) {
    candidateAst = {
      k: "call",
      f: "filter",
      a: [inp0, { k: "lam", body: buildPredAst(qualifiers) }]
    };
  } else if (!candidateAst && detectedOrd !== null && detectedOrd >= 0) {
    candidateAst = { k: "call", f: "nth", a: [inp0, { k: "const", v: detectedOrd }] };
  } else if (!candidateAst && detectedOrd === -1) {
    candidateAst = { k: "call", f: "last", a: [inp0] };
  } else if (!candidateAst && detectedOp === "average") {
    candidateAst = {
      k: "call",
      f: "div",
      a: [
        { k: "call", f: "sum", a: [inp0] },
        { k: "call", f: "len", a: [inp0] }
      ]
    };
  } else if (!candidateAst && detectedOp === "max") {
    candidateAst = { k: "call", f: "max", a: [inp0] };
  } else if (!candidateAst && detectedOp === "min") {
    candidateAst = { k: "call", f: "min", a: [inp0] };
  }
  if (!candidateAst) {
    return {
      status: "abstain",
      reason: "unmodelled_intent",
      unmodelled: tokens.slice(0, 5)
    };
  }
  const asksForList = /\b(list|array|sequence)\s+of\b/i.test(promptLower) || /قائمة\s+(?:من|ل)/.test(promptNormAr);
  const asksForNumber = /\b(number of|how many|count)\b/i.test(promptLower) || /عدد|كم\s/.test(promptNormAr);
  if (asksForList && ["sum", "count", "average", "min", "max"].includes(detectedOp)) {
    return { status: "abstain", reason: "requested_output_type_mismatch", unmodelled: ["list-vs-scalar"] };
  }
  if (asksForNumber && !["sum", "count", "average", "min", "max", "length"].includes(detectedOp)) {
    return { status: "abstain", reason: "requested_output_type_mismatch", unmodelled: ["scalar-vs-list"] };
  }
  if (hasQualifier || hasDistinct) {
    const probes = [[-4, -1, 0, 1, 2, 2, 5, 6], [], [2, 2, -2, 0], [-5, 5, 6], [3, 4, 5, 10]];
    try {
      for (const values of probes) {
        let expectedValues = hasDistinct ? [...new Map(values.map((v) => [JSON.stringify(v), v])).values()] : values.slice();
        if (hasQualifier) {
          const pred = buildPredAst(qualifiers);
          expectedValues = expectedValues.filter((v) => Boolean(evalAst(pred, [values], { x: v })));
        }
        if (["average", "min", "max"].includes(detectedOp) && expectedValues.length === 0) continue;
        if (detectedOrd !== null && expectedValues.length === 0) continue;
        const out = evalAst(candidateAst, [values]);
        let expected = expectedValues;
        if (detectedOrd === 0) expected = expectedValues[0];
        else if (detectedOrd === -1) expected = expectedValues.at(-1);
        if (detectedOp === "sum") expected = expectedValues.reduce((a, b) => a + b, 0);
        else if (detectedOp === "count") expected = expectedValues.length;
        else if (detectedOp === "average") expected = expectedValues.reduce((a, b) => a + b, 0) / expectedValues.length;
        else if (detectedOp === "min") expected = Math.min(...expectedValues);
        else if (detectedOp === "max") expected = Math.max(...expectedValues);
        if (JSON.stringify(out) !== JSON.stringify(expected)) throw new Error("semantic-qualifier-invariant");
      }
    } catch {
      return { status: "abstain", reason: "semantic_property_check_failed", unmodelled: hasQualifier ? qualifiers.map((q) => q.kind) : ["distinct"] };
    }
  }
  const sanityPassed = hasQualifier || cardinalSelection ? true : verifySanityChecks(candidateAst, detectedOp || detectedFilter || (detectedOrd !== null ? "selector" : null));
  if (!sanityPassed) {
    return {
      status: "abstain",
      reason: "sanity_checks_failed",
      ast: candidateAst
    };
  }
  return {
    status: "ok",
    ast: candidateAst,
    source: toSource(candidateAst, 1),
    derivedChecks: { sanityPassed: true },
    qualifiers: qualifiers.map((q) => q.value === void 0 ? q.kind : `${q.kind}(${q.value})`)
  };
}
var EN_NUM_WORDS, SELECTION_NOUNS_EN, SELECTION_NOUNS_AR, EN_GREATER_WORDS, EN_LESS_WORDS, AR_GREATER_WORDS, AR_LESS_WORDS, EN_DEIXIS, AR_DEIXIS;
var init_grammar = __esm({
  "synora-v5/nl2code/grammar.mjs"() {
    init_arabic_morphology();
    init_lexicon();
    init_sanity_checks();
    init_dsl();
    EN_NUM_WORDS = {
      zero: 0,
      one: 1,
      two: 2,
      three: 3,
      four: 4,
      five: 5,
      six: 6,
      seven: 7,
      eight: 8,
      nine: 9,
      ten: 10,
      eleven: 11,
      twelve: 12,
      thirteen: 13,
      fourteen: 14,
      fifteen: 15,
      sixteen: 16,
      seventeen: 17,
      eighteen: 18,
      nineteen: 19,
      twenty: 20,
      thirty: 30,
      forty: 40,
      fifty: 50,
      sixty: 60,
      hundred: 100
    };
    SELECTION_NOUNS_EN = "(?:numbers?|elements?|items?|values?|entries?|records?)";
    SELECTION_NOUNS_AR = "(?:\u0639\u0646\u0627\u0635\u0631|\u0627\u0631\u0642\u0627\u0645|\u0623\u0631\u0642\u0627\u0645|\u0642\u064A\u0645|\u0642\u0648\u0627\u0626\u0645|\u0645\u062F\u062E\u0644\u0627\u062A|\u0639\u0646\u0635\u0631\u064A\u0646|\u0631\u0642\u0645\u064A\u0646|\u0642\u064A\u0645\u062A\u064A\u0646)";
    EN_GREATER_WORDS = ["greater", "more", "larger", "bigger", "higher", "above"];
    EN_LESS_WORDS = ["less", "fewer", "smaller", "lower", "below"];
    AR_GREATER_WORDS = ["\u0627\u0643\u0628\u0631", "\u0627\u0643\u062B\u0631", "\u0627\u0639\u0644\u0649", "\u0627\u0639\u0638\u0645"];
    AR_LESS_WORDS = ["\u0627\u0642\u0644", "\u0627\u0635\u063A\u0631", "\u0627\u0646\u0646\u0649"];
    EN_DEIXIS = /\b(those|them|these|it|the same|the previous|the above|the result|that one)\b/i;
    AR_DEIXIS = /(^|\s)(هؤلاء|هم|هن|نفسها|نفسهم|ذلك)(\s|$)|(النتيجه|نتيجه|النتيجة|سابقه|السابقه|الان)/;
  }
});

// synora-v5/agent/planner.mjs
function planTask(task, opts = {}) {
  const lang = opts.lang || (/[\u0600-\u06FF]/.test(task) ? "ar" : "en");
  const steps = [];
  const nlResult = parseNLToCode(task, { lang });
  const qType = detectQuestionType(task);
  if (nlResult.status === "ok" && nlResult.ast) {
    steps.push({
      id: "step-1",
      operation: "synthesize",
      description: lang === "ar" ? `\u062A\u0631\u0643\u064A\u0628 \u0628\u0631\u0646\u0627\u0645\u062C: ${task}` : `Synthesize program: ${task}`,
      params: {
        ast: nlResult.ast,
        source: nlResult.source,
        taskType: "programming"
      }
    });
  } else if (qType !== "value" && qType !== "attribute") {
    steps.push({
      id: "step-1",
      operation: "query",
      description: lang === "ar" ? `\u0627\u0644\u0628\u062D\u062B \u0639\u0646 \u0625\u062C\u0627\u0628\u0629: ${task}` : `Answer question: ${task}`,
      params: {
        question: task,
        questionType: qType,
        taskType: "knowledge"
      }
    });
  } else {
    steps.push({
      id: "step-1",
      operation: "abstain",
      description: lang === "ar" ? `\u0646\u0648\u0639 \u0627\u0644\u0645\u0647\u0645\u0629 \u063A\u064A\u0631 \u0645\u062F\u0639\u0648\u0645: ${task}` : `Unsupported task type: ${task}`,
      params: {
        reason: nlResult.reason || "unknown_task_type",
        taskType: "unsupported"
      }
    });
  }
  return { steps, deterministic: true, lang, taskType: steps[0]?.params?.taskType || "unknown" };
}
var init_planner = __esm({
  "synora-v5/agent/planner.mjs"() {
    init_grammar();
    init_answer_extractor();
  }
});

// synora-v5/agent/verifier.mjs
function verifyStep(step, result, context = {}) {
  if (step.operation === "synthesize") {
    if (!result.ast && !step.params?.ast) {
      return { verified: false, passes: 0, total: 0, reason: "no_ast" };
    }
    const ast = result.ast || step.params.ast;
    const testCases = context.testCases || [];
    if (!testCases.length) {
      return { verified: true, passes: 0, total: 0, reason: "no_tests" };
    }
    let passes = 0;
    let failReason = null;
    for (const { input, output } of testCases) {
      try {
        const actual = evalAst(ast, input);
        if (deepEqual(actual, output)) {
          passes++;
        } else {
          failReason = `expected ${JSON.stringify(output)} got ${JSON.stringify(actual)}`;
          break;
        }
      } catch (err) {
        failReason = `execution error: ${err.message}`;
        break;
      }
    }
    return {
      verified: passes === testCases.length,
      passes,
      total: testCases.length,
      reason: failReason
    };
  }
  if (step.operation === "query") {
    if (!result.answered) {
      return { verified: false, passes: 0, total: 1, reason: result.reason || "not_answered" };
    }
    if (!result.span) {
      return { verified: false, passes: 0, total: 1, reason: "no_provenance" };
    }
    return { verified: true, passes: 1, total: 1 };
  }
  if (step.operation === "abstain") {
    return { verified: true, passes: 0, total: 0, reason: "abstained" };
  }
  return { verified: false, passes: 0, total: 0, reason: "unknown_operation" };
}
var init_verifier = __esm({
  "synora-v5/agent/verifier.mjs"() {
    init_dsl();
  }
});

// synora-v5/synthesis/synthesize.mjs
var synthesize_exports = {};
__export(synthesize_exports, {
  AMBIGUITY_WINDOW: () => AMBIGUITY_WINDOW,
  CORE_PRIMS: () => CORE_PRIMS,
  SYNTHESIS_LIMITS: () => SYNTHESIS_LIMITS,
  TIER_PLAN: () => TIER_PLAN,
  classifyUniverse: () => classifyUniverse,
  extendedUniverse: () => extendedUniverse,
  synthesize: () => synthesize,
  validateExamples: () => validateExamples
});
function boundaryValues(type) {
  switch (type) {
    case "num":
      return [-2, -1, 0, 1, 2, 3];
    case "str":
      return ["", " ", "a", "A", "aa", " a ", "\xE9", "\xDF"];
    case "L:num":
      return [[], [0], [1], [1, 1], [-1, 0, 1], [2, 1, 2], [-2, -1], [0, 0]];
    case "L:str":
      return [[], [""], ["a"], ["a", "a"], ["A", "a"], ["\xE9", "\xDF"], [" ", "x"]];
    case "L:bool":
      return [[], [true], [false], [true, true], [true, false]];
    case "L:L:num":
      return [[], [[]], [[0]], [[1, 1]], [[-1, 0], [0, 0]]];
    default:
      return [];
  }
}
function makeBoundaryProbes(argTypes, training) {
  const baseline = training[0].input;
  const probes = [];
  for (let i = 0; i < argTypes.length; i++) {
    for (const value of boundaryValues(argTypes[i])) {
      const row = structuredClone(baseline);
      row[i] = structuredClone(value);
      probes.push(row);
    }
  }
  return probes;
}
function computeUsefulTypes(outType, universe) {
  const useful = /* @__PURE__ */ new Set([outType]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const { sig } of universe) {
      if (useful.has(sig.ret)) {
        for (const argType of sig.args) {
          if (!argType.startsWith("\u03BB") && !useful.has(argType)) {
            useful.add(argType);
            changed = true;
          }
        }
      }
    }
  }
  return useful;
}
function classifyUniverse(argTypes, { includeLambdas = false, exact = false } = {}) {
  const taskTypes = new Set(argTypes);
  const universe = [];
  for (const name of PRIM_NAMES) {
    for (const sig of SIGS[name]) {
      if (!sig.args.length) continue;
      const hasLambda = sig.args.some((t) => t.startsWith("\u03BB"));
      if (hasLambda && !includeLambdas) continue;
      if (exact) {
        if (sig.args.length !== argTypes.length) continue;
        if (!sig.args.every((t, i) => t === argTypes[i])) continue;
        universe.push({ name, sig });
        continue;
      }
      if (!sig.args.some((t) => taskTypes.has(t))) continue;
      if (!sig.args.every((t) => taskTypes.has(t) || t === "num")) continue;
      universe.push({ name, sig });
    }
  }
  return universe;
}
function extendedUniverse(argTypes, { includeLambdas = true } = {}) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const entry of classifyUniverse(argTypes, { includeLambdas, exact: true })) {
    const key = `${entry.name}:${entry.sig.args.join(",")}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(entry);
  }
  for (const name of CORE_PRIMS) {
    for (const sig of SIGS[name]) {
      const hasLambda = sig.args.some((t) => t.startsWith("\u03BB"));
      if (hasLambda && !includeLambdas) continue;
      const key = `${name}:${sig.args.join(",")}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({ name, sig });
    }
  }
  return out;
}
function mulberry32(a) {
  return () => {
    a |= 0;
    a = a + 1831565813 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function genValue(type, r) {
  switch (type) {
    case "num":
      return pick(r, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, -1, -3, -5]);
    case "bool":
      return r() > 0.5;
    case "str":
      return Array.from({ length: Math.floor(r() * 9) }, () => pick(r, ["a", "b", "c", " ", "A", "B"])).join("");
    case "L:num":
      return Array.from({ length: Math.floor(r() * 7) }, () => Math.floor(r() * 18) - 5);
    case "L:str":
      return Array.from({ length: Math.floor(r() * 5) }, () => genValue("str", r));
    case "L:bool":
      return Array.from({ length: Math.floor(r() * 5) }, () => r() > 0.5);
    case "L:L:num":
      return Array.from({ length: Math.floor(r() * 4) }, () => genValue("L:num", r));
    default:
      throw new TypeError(`unsupported input type ${type}`);
  }
}
function keyOf(type, vals, intern) {
  let k = type + "|";
  for (let i = 0; i < vals.length; i++) {
    if (i > 0) k += ",";
    k += intern.intern(vals[i]);
  }
  return k;
}
function computeVals(name, args, R, rowInputs) {
  const f = IMPL[name];
  const vals = new Array(R);
  const argLen = args.length;
  const hasLambda = args[0] && args[0].lam ? true : args.some((g) => g.lam);
  if (!hasLambda) {
    if (argLen === 1) {
      const a0 = args[0].vals;
      for (let r = 0; r < R; r++) {
        const v = a0[r];
        if (v === ERR) {
          vals[r] = ERR;
          continue;
        }
        try {
          vals[r] = f(v);
        } catch {
          vals[r] = ERR;
        }
      }
      return vals;
    }
    if (argLen === 2) {
      const a0 = args[0].vals, a1 = args[1].vals;
      for (let r = 0; r < R; r++) {
        const v0 = a0[r], v1 = a1[r];
        if (v0 === ERR || v1 === ERR) {
          vals[r] = ERR;
          continue;
        }
        try {
          vals[r] = f(v0, v1);
        } catch {
          vals[r] = ERR;
        }
      }
      return vals;
    }
    if (argLen === 3) {
      const a0 = args[0].vals, a1 = args[1].vals, a2 = args[2].vals;
      for (let r = 0; r < R; r++) {
        const v0 = a0[r], v1 = a1[r], v2 = a2[r];
        if (v0 === ERR || v1 === ERR || v2 === ERR) {
          vals[r] = ERR;
          continue;
        }
        try {
          vals[r] = f(v0, v1, v2);
        } catch {
          vals[r] = ERR;
        }
      }
      return vals;
    }
  }
  for (let r = 0; r < R; r++) {
    const a = new Array(argLen);
    let bad = false;
    for (let i = 0; i < argLen; i++) {
      const g = args[i];
      if (g.lam) {
        a[i] = (v) => evalAst(g.lam.ast, rowInputs[r], { x: v, maxSteps: 4e3 });
      } else {
        const v = g.vals[r];
        if (v === ERR) {
          bad = true;
          break;
        }
        a[i] = v;
      }
    }
    if (bad) {
      vals[r] = ERR;
      continue;
    }
    try {
      vals[r] = f(...a);
    } catch {
      vals[r] = ERR;
    }
  }
  return vals;
}
function forCombos(sig, remaining, get, ensureLambdas, onCombo) {
  const args = sig.args;
  const arity = args.length;
  if (arity === 1) {
    const t = args[0];
    if (t.startsWith("\u03BB")) {
      if (remaining >= 2) {
        const lamType = t === "\u03BBnum" ? "num" : "bool";
        const lams = ensureLambdas(lamType);
        for (let i = 0; i < lams.length; i++) {
          if (onCombo([{ lam: lams[i] }])) return true;
        }
      }
    } else {
      const list = get(t, remaining);
      for (let i = 0; i < list.length; i++) {
        if (onCombo([list[i]])) return true;
      }
    }
    return false;
  }
  if (arity === 2) {
    const t0 = args[0], t1 = args[1];
    if (t1.startsWith("\u03BB")) {
      const lamType = t1 === "\u03BBnum" ? "num" : "bool";
      if (remaining >= 3) {
        const lams = ensureLambdas(lamType);
        if (lams.length === 0) return false;
        const s0 = remaining - 2;
        const list0 = get(t0, s0);
        for (let i = 0; i < list0.length; i++) {
          for (let j = 0; j < lams.length; j++) {
            if (onCombo([list0[i], { lam: lams[j] }])) return true;
          }
        }
      }
      return false;
    }
    for (let s0 = 1; s0 < remaining; s0++) {
      const s1 = remaining - s0;
      const list0 = get(t0, s0);
      if (!list0 || list0.length === 0) continue;
      const list1 = get(t1, s1);
      if (!list1 || list1.length === 0) continue;
      for (let i = 0; i < list0.length; i++) {
        for (let j = 0; j < list1.length; j++) {
          if (onCombo([list0[i], list1[j]])) return true;
        }
      }
    }
    return false;
  }
  if (arity === 3) {
    const t0 = args[0], t1 = args[1], t2 = args[2];
    if (t2.startsWith("\u03BB")) {
      const lamType = t2 === "\u03BBnum" ? "num" : "bool";
      if (remaining >= 4) {
        const lams = ensureLambdas(lamType);
        if (lams.length === 0) return false;
        const rem2 = remaining - 2;
        for (let s0 = 1; s0 < rem2; s0++) {
          const s1 = rem2 - s0;
          const list0 = get(t0, s0);
          if (!list0 || list0.length === 0) continue;
          const list1 = get(t1, s1);
          if (!list1 || list1.length === 0) continue;
          for (let i = 0; i < list0.length; i++) {
            for (let j = 0; j < list1.length; j++) {
              for (let k = 0; k < lams.length; k++) {
                if (onCombo([list0[i], list1[j], { lam: lams[k] }])) return true;
              }
            }
          }
        }
      }
      return false;
    }
    for (let s0 = 1; s0 <= remaining - 2; s0++) {
      const list0 = get(t0, s0);
      if (!list0 || list0.length === 0) continue;
      for (let s1 = 1; s1 <= remaining - s0 - 1; s1++) {
        const s2 = remaining - s0 - s1;
        const list1 = get(t1, s1);
        if (!list1 || list1.length === 0) continue;
        const list2 = get(t2, s2);
        if (!list2 || list2.length === 0) continue;
        for (let i = 0; i < list0.length; i++) {
          for (let j = 0; j < list1.length; j++) {
            for (let k = 0; k < list2.length; k++) {
              if (onCombo([list0[i], list1[j], list2[k]])) return true;
            }
          }
        }
      }
    }
    return false;
  }
  return false;
}
function enumerate({ R, rowInputs, terminals, sigs, ensureLambdas, maxSize, maxExpressions, safetyDeadline, discard, onAdd, levelDone, ctl, onSignature, usefulTypes, nTD, K = 3 }) {
  const bank = /* @__PURE__ */ new Map();
  const intern = new ValueIntern();
  const isUseful = usefulTypes ? ((t) => usefulTypes.has(t)) : (() => true);
  const useLazyOE = nTD && nTD < R && K > 0;
  const oeClasses = useLazyOE ? /* @__PURE__ */ new Map() : null;
  const seenFull = useLazyOE ? null : /* @__PURE__ */ new Set();
  const tryAddOE = (type, vals) => {
    if (!useLazyOE) {
      const fullKey = keyOf(type, vals, intern);
      if (seenFull.has(fullKey)) return false;
      seenFull.add(fullKey);
      return true;
    }
    const tdKey = keyOf(type, vals.slice(0, nTD), intern);
    let cls = oeClasses.get(tdKey);
    if (!cls) {
      cls = [];
      oeClasses.set(tdKey, cls);
      const probeKey2 = keyOf(type, vals.slice(nTD), intern);
      cls.push(probeKey2);
      return true;
    }
    if (cls.length >= K) return false;
    const probeKey = keyOf(type, vals.slice(nTD), intern);
    if (cls.includes(probeKey)) return false;
    cls.push(probeKey);
    return true;
  };
  const bucketCap = maxExpressions <= 1e4 ? Math.max(64, Math.min(512, Math.floor(maxExpressions / 8))) : Number.MAX_SAFE_INTEGER;
  let explored = 0;
  let stop = null;
  const get = (t, s) => bank.get(t)?.get(s) ?? [];
  const put = (e) => {
    if (!bank.has(e.type)) bank.set(e.type, /* @__PURE__ */ new Map());
    const m = bank.get(e.type);
    if (!m.has(e.size)) m.set(e.size, []);
    const bucket = m.get(e.size);
    if (bucket.length >= bucketCap) return false;
    bucket.push(e);
    return true;
  };
  for (const t of terminals) {
    if (!isUseful(t.type)) continue;
    if (!tryAddOE(t.type, t.vals)) continue;
    const e = { ...t, size: 1 };
    if (put(e)) onAdd(e);
  }
  for (let size = 2; size <= maxSize && !stop; size++) {
    for (const { name, sig } of sigs) {
      onSignature?.(sig);
      let hasRequiredTypes = true;
      for (const argType of sig.args) {
        if (argType.startsWith("\u03BB")) {
          continue;
        } else if (!bank.has(argType)) {
          hasRequiredTypes = false;
          break;
        }
      }
      if (!hasRequiredTypes) continue;
      const stopSearch = forCombos(sig, size - 1, get, ensureLambdas, (combo) => {
        explored++;
        if ((explored & 511) === 0 && safetyDeadline && Date.now() > safetyDeadline) {
          stop = "safety-timeout";
          return true;
        }
        if (explored > maxExpressions) {
          stop = "expressions";
          return true;
        }
        const vals = computeVals(name, combo, R, rowInputs);
        if (discard(vals)) return false;
        if (!isUseful(sig.ret)) return false;
        if (!tryAddOE(sig.ret, vals)) return false;
        const e = {
          type: sig.ret,
          size,
          vals,
          ast: {
            k: "call",
            f: name,
            a: combo.map((c) => c.lam ? { k: "lam", body: c.lam.ast } : c.ast)
          }
        };
        if (put(e)) onAdd(e);
        return false;
      });
      if (stopSearch || stop) break;
    }
    if (!stop) {
      levelDone(size);
      if (ctl && ctl.stop) break;
    }
  }
  return { explored, stop };
}
function buildLambdaPool(outerIdx) {
  const cacheKey = outerIdx.join(",");
  if (LAMBDA_POOL_CACHE.has(cacheKey)) {
    return LAMBDA_POOL_CACHE.get(cacheKey);
  }
  const assigns = outerIdx.map((gi, j) => ({ gi, j }));
  const pts = [];
  for (const o of LAMBDA_OUTER) {
    for (const x of LAMBDA_XS) {
      pts.push({ x, o });
    }
  }
  const terminals = [{ type: "num", vals: pts.map((p) => p.x), ast: { k: "x" } }];
  assigns.forEach(({ gi, j }) => {
    terminals.push({ type: "num", vals: pts.map(() => LAMBDA_OUTER[j]), ast: { k: "in", i: gi } });
  });
  for (const c of CONSTS) {
    terminals.push({ type: "num", vals: pts.map(() => c), ast: { k: "const", v: c } });
  }
  const names = ["add", "sub", "mul", "idiv", "mod", "eq", "lt", "le", "not", "and", "or"];
  const sigs = [];
  for (const name of names) {
    if (SIGS[name]) {
      for (const sig of SIGS[name]) {
        if (sig.args.every((t) => t === "num" || t === "bool")) {
          sigs.push({ name, sig });
        }
      }
    }
  }
  const pool = { num: [], bool: [] };
  const add = (e) => {
    if (pool[e.type] && pool[e.type].length < 150) {
      pool[e.type].push({ ast: e.ast, type: e.type, size: e.size });
    }
  };
  enumerate({
    R: pts.length,
    // Lambda bodies may close over outer arguments. The old empty rowInputs
    // array made every `in` reference evaluate against undefined while the
    // pool was being built, silently discarding valid outer-dependent lambdas.
    rowInputs: pts.map((p) => {
      const row = [];
      assigns.forEach(({ gi, j }) => {
        row[gi] = LAMBDA_OUTER[j];
      });
      return row;
    }),
    terminals,
    sigs,
    ensureLambdas: () => [],
    maxSize: 5,
    safetyDeadline: null,
    maxExpressions: LAMBDA_POOL_EXPRESSIONS,
    discard: () => false,
    onAdd: add,
    levelDone: () => {
    }
  });
  LAMBDA_POOL_CACHE.set(cacheKey, pool);
  return pool;
}
function validateExamples(examples, label) {
  if (!Array.isArray(examples)) throw new TypeError(`${label} must be an array`);
  if (examples.length > SYNTHESIS_LIMITS.maxExamples) throw new TypeError(`${label} has more than ${SYNTHESIS_LIMITS.maxExamples} examples`);
  for (const [i, ex] of examples.entries()) {
    if (!ex || typeof ex !== "object" || !Array.isArray(ex.input) || ex.input.length < 1 || ex.input.length > SYNTHESIS_LIMITS.maxArity || !("output" in ex)) {
      throw new TypeError(`${label}[${i}] needs input (array of 1..${SYNTHESIS_LIMITS.maxArity} arguments) and output`);
    }
  }
}
function collectScalarValues(value, out = /* @__PURE__ */ new Set()) {
  if (value === null || value === void 0) return out;
  if (typeof value === "number" || typeof value === "string" || typeof value === "boolean") out.add(JSON.stringify(value));
  else if (Array.isArray(value)) for (const item of value) collectScalarValues(item, out);
  else if (typeof value === "object") for (const item of Object.values(value)) collectScalarValues(item, out);
  return out;
}
function hasNoOpOrDeadStructure(ast) {
  const walk = (node) => {
    if (!node || typeof node !== "object") return false;
    if (node.k === "lam") return walk(node.body);
    if (node.k !== "call") return false;
    const a = node.a || [];
    const constant = (i, value) => a[i]?.k === "const" && a[i].v === value;
    if (["add", "sub"].includes(node.f) && (constant(0, 0) || constant(1, 0))) return true;
    if (node.f === "mul" && (constant(0, 1) || constant(1, 1) || constant(0, 0) || constant(1, 0))) return true;
    if (["div", "idiv"].includes(node.f) && constant(1, 1)) return true;
    if (node.f === "mod" && (constant(1, 1) || constant(1, 0))) return true;
    if (node.f === "ite" && (constant(0, true) || constant(0, false))) return true;
    if (node.f === "and" && (constant(0, false) || constant(1, false))) return true;
    if (node.f === "or" && (constant(0, true) || constant(1, true))) return true;
    if (node.f === "len" && a[0]?.k === "call" && a[0].f === "range") return true;
    if (["unique", "sort", "reverse", "lower", "upper", "trim"].includes(node.f) && a[0]?.k === "call" && a[0].f === node.f) return true;
    if (CASE_NORMALISERS.has(node.f) && a[0]?.k === "call" && CASE_NORMALISERS.has(a[0].f)) return true;
    if (["map", "filter", "all", "any"].includes(node.f) && a.at(-1)?.k === "lam" && a.at(-1).body?.k === "x") {
      if (node.f === "map") return true;
      if (node.f === "filter" || node.f === "all" || node.f === "any") return true;
    }
    return a.some(walk);
  };
  return walk(ast);
}
function plausibilityPenalty(ast, examples) {
  const observed = /* @__PURE__ */ new Set();
  for (const example of examples) {
    for (const input of example.input) collectScalarValues(input, observed);
    collectScalarValues(example.output, observed);
  }
  let penalty = 0;
  const walk = (node) => {
    if (!node || typeof node !== "object") return;
    if (node.k === "const" && !observed.has(JSON.stringify(node.v))) penalty += 1;
    if (node.k === "call") {
      const children = node.a || [];
      if (["add", "sub"].includes(node.f) && children.some((c) => c?.k === "const" && c.v === 0)) penalty += 1;
      if (node.f === "mul" && children.some((c) => c?.k === "const" && c.v === 1)) penalty += 1;
      if (children.some((c) => c?.k === "call" && c.f === node.f && ["unique", "sort", "reverse", "lower"].includes(node.f))) penalty += 1;
      for (const child of children) walk(child);
    } else if (node.k === "lam") walk(node.body);
  };
  walk(ast);
  return penalty;
}
function evidenceProfile(ast, examples) {
  let nodes = 0;
  let constants = 0;
  const distinctInputs = new Set(examples.map((example) => JSON.stringify(example.input))).size;
  const walk = (node) => {
    if (!node || typeof node !== "object") return;
    if (node.k === "const") {
      nodes++;
      constants++;
      return;
    }
    nodes++;
    if (node.k === "call") for (const child of node.a || []) walk(child);
    else if (node.k === "lam") walk(node.body);
  };
  walk(ast);
  const requiredExamples = Math.max(5, 3 + Math.ceil(nodes / 3));
  return { nodes, constants, distinctInputs, requiredExamples, sufficient: examples.length >= requiredExamples && distinctInputs >= Math.min(examples.length, requiredExamples) };
}
function queryInformationGain(query, candidateCount) {
  const counts = query.outputCounts || [];
  if (candidateCount <= 1 || counts.length <= 1) return 0;
  let entropy = 0;
  for (const count of counts) {
    const p = count / candidateCount;
    if (p > 0) entropy -= p * Math.log2(p);
  }
  return entropy;
}
function runTier({
  tier,
  training,
  development,
  universe,
  maxSize,
  maxExpressions,
  safetyDeadline,
  seed,
  ambiguityWindow,
  includeLambdas,
  preferLambdas
}) {
  const all = [...training, ...development];
  const arity = training[0].input.length;
  const argTypes = Array.from({ length: arity }, (_, i) => unifyTypes(all.map((e) => typeOfValue(e.input[i]))));
  const outType = unifyTypes(all.map((e) => typeOfValue(e.output)));
  if (argTypes.some((t) => !t || t === "bool") || !outType) {
    throw new TypeError("unsupported example value types (use numbers, strings, booleans as outputs, and lists of numbers/strings/number-lists)");
  }
  const rnd = mulberry32(seed);
  const randomProbes = Array.from({ length: PROBE_COUNT }, () => argTypes.map((t) => genValue(t, rnd)));
  const boundaryProbes = makeBoundaryProbes(argTypes, training);
  const probes = [...boundaryProbes, ...randomProbes];
  const rowInputs = [...all.map((e) => e.input), ...probes];
  const nT = training.length;
  const nTD = all.length;
  const R = rowInputs.length;
  const outputs = all.map((e) => e.output);
  const numIdx = argTypes.map((t, i) => t === "num" ? i : -1).filter((i) => i >= 0);
  let lamPool = null;
  const ensureLambdas = (ltype) => {
    if (!includeLambdas) return [];
    if (!lamPool) lamPool = buildLambdaPool(numIdx);
    return lamPool[ltype] || [];
  };
  const terminals = argTypes.map((t, i) => ({ type: t, vals: rowInputs.map((r) => r[i]), ast: { k: "in", i } }));
  for (const c of CONSTS) {
    terminals.push({ type: "num", vals: rowInputs.map(() => c), ast: { k: "const", v: c } });
  }
  const sigs = universe.slice().sort((a, b) => {
    const outputRank = (b.sig.ret === outType) - (a.sig.ret === outType);
    if (outputRank) return outputRank;
    const lambdaRank = a.sig.args.filter((type) => type.startsWith("\u03BB")).length - b.sig.args.filter((type) => type.startsWith("\u03BB")).length;
    if (preferLambdas && lambdaRank) return -lambdaRank;
    return lambdaRank || a.sig.args.length - b.sig.args.length || a.name.localeCompare(b.name);
  });
  const candidates = [];
  const fitsTrain = (vals) => {
    for (let i = 0; i < nT; i++) {
      if (vals[i] === ERR || !deepEqual(vals[i], outputs[i])) return false;
    }
    return true;
  };
  const fitsDev = (vals) => {
    for (let i = nT; i < nTD; i++) {
      if (vals[i] === ERR || !deepEqual(vals[i], outputs[i])) return false;
    }
    return true;
  };
  let chosen = null;
  let stopAfter = maxSize;
  let lastLevel = 1;
  const ctl = { stop: false };
  const best = (list) => list.map((c) => ({ c, nodes: validateAst(c.ast, arity), prior: plausibilityPenalty(c.ast, all) })).sort((a, b) => a.nodes - b.nodes || a.prior - b.prior)[0].c;
  const settle = (size) => {
    if (!chosen) {
      const ok = candidates.filter((c) => fitsDev(c.vals));
      if (ok.length) {
        chosen = best(ok);
        stopAfter = Math.min(maxSize, size + ambiguityWindow);
      }
    }
    if (chosen && size >= stopAfter) ctl.stop = true;
  };
  const onAdd = (e) => {
    if (e.type === outType && fitsTrain(e.vals)) candidates.push(e);
  };
  for (const t of terminals) {
    if (t.type === outType && fitsTrain(t.vals)) candidates.push({ ...t, size: 1 });
  }
  settle(1);
  const usefulTypes = computeUsefulTypes(outType, universe);
  const run = ctl.stop ? { explored: 0, stop: null } : enumerate({
    R,
    rowInputs,
    terminals,
    sigs,
    ensureLambdas,
    maxSize,
    maxExpressions,
    safetyDeadline,
    usefulTypes,
    nTD,
    K: 3,
    discard: (vals) => {
      for (let i = 0; i < nTD; i++) if (vals[i] === ERR) return true;
      return false;
    },
    onAdd,
    levelDone: (size) => {
      lastLevel = size;
      settle(size);
    },
    ctl
  });
  const fitters = candidates.filter((c) => fitsDev(c.vals) && !hasNoOpOrDeadStructure(c.ast));
  const scopedFitters = fitters;
  const base = {
    tier,
    explored: run.explored,
    maxSize,
    arity,
    argTypes,
    outType,
    trainFits: candidates.length,
    candidateCount: scopedFitters.length,
    maxSizeReached: lastLevel,
    devRejected: candidates.length - fitters.length,
    universeSize: sigs.length,
    ...run.stop ? { stoppedBy: run.stop } : {}
  };
  if (!chosen) {
    return {
      found: false,
      reason: candidates.length > 0 ? "development-validation-failed" : run.stop ? "search-budget-exhausted" : "no-program-fits-training",
      budgetStop: run.stop,
      ...base
    };
  }
  const ambiguityCheck = !run.stop && lastLevel >= stopAfter ? "complete" : "partial";
  const chosenPrior = plausibilityPenalty(chosen.ast, all);
  const chosenNodes = validateAst(chosen.ast, arity);
  const rivals = scopedFitters.filter((c) => c !== chosen && plausibilityPenalty(c.ast, all) <= chosenPrior);
  const occamRazor = rivals.length > 0 && chosenNodes <= 2 && rivals.every(
    (r) => validateAst(r.ast, arity) >= chosenNodes + 3
  );
  const show = (v) => v === ERR ? "<error>" : v;
  const queries = [];
  if (rivals.length) {
    for (let r = nTD; r < R; r++) {
      const outs = [];
      const outputCounts = [];
      for (const c of [chosen, ...rivals]) {
        const v = show(c.vals[r]);
        const existing = outs.findIndex((o) => deepEqual(o, v));
        if (existing < 0) {
          outs.push(v);
          outputCounts.push(1);
        } else outputCounts[existing]++;
      }
      if (outs.length >= 2) {
        queries.push({ input: rowInputs[r], candidateOutputs: outs, outputCounts, hasError: outs.includes("<error>") });
      }
    }
    queries.sort((a, b) => a.hasError - b.hasError || queryInformationGain(b, scopedFitters.length) - queryInformationGain(a, scopedFitters.length));
  }
  const evidence = evidenceProfile(chosen.ast, all);
  const boundaryAgreement = rivals.every((candidate) => probes.every((probe, index) => {
    const rowIndex = nTD + index;
    return deepEqual(chosen.vals[rowIndex], candidate.vals[rowIndex]);
  }));
  const independentValidationPass = boundaryProbes.length >= 8 && boundaryAgreement;
  const ambiguityUnresolved = rivals.length > 0 && !boundaryAgreement || ambiguityCheck === "partial" && !independentValidationPass;
  const disambiguatingQueries = queries.slice(0, 5).map(({ input, candidateOutputs, outputCounts }) => ({ input, candidateOutputs, outputCounts, informationGain: queryInformationGain({ outputCounts }, scopedFitters.length) }));
  const rivalEvidence = rivals.slice(0, 8).map((c) => {
    let divergesAt = null;
    for (let r = nTD; r < R; r++) {
      if (!deepEqual(chosen.vals[r], c.vals[r])) {
        divergesAt = rowInputs[r];
        break;
      }
    }
    return { source: toSource(c.ast, arity), size: validateAst(c.ast, arity), divergesAt };
  });
  if (ambiguityCheck === "partial") {
    return {
      found: false,
      reason: rivals.length ? "ambiguous-examples" : "search-budget-exhausted",
      alternativeBehaviours: rivals.length,
      rivalEvidence,
      disambiguatingQueries,
      ambiguityCheck,
      boundaryAgreement,
      boundaryProbeCount: boundaryProbes.length,
      evidence,
      ...base
    };
  }
  if (!evidence.sufficient) {
    return {
      found: false,
      reason: "insufficient-evidence",
      alternativeBehaviours: rivals.length,
      rivalEvidence,
      disambiguatingQueries,
      ambiguityCheck,
      boundaryAgreement,
      boundaryProbeCount: boundaryProbes.length,
      evidence,
      ...base
    };
  }
  if (ambiguityUnresolved && !occamRazor) {
    return {
      found: false,
      reason: "ambiguous-examples",
      alternativeBehaviours: rivals.length,
      rivalEvidence,
      disambiguatingQueries,
      ambiguityCheck,
      boundaryAgreement,
      boundaryProbeCount: boundaryProbes.length,
      evidence,
      ...base
    };
  }
  return {
    found: true,
    ast: chosen.ast,
    nodes: chosenNodes,
    size: chosenNodes,
    source: toSource(chosen.ast, arity),
    fitting: fitters.length,
    alternativeBehaviours: rivals.length,
    ambiguityCheck,
    boundaryAgreement,
    independentValidationPass,
    plausibilityPenalty: plausibilityPenalty(chosen.ast, all),
    evidence,
    boundaryProbeCount: boundaryProbes.length,
    ...base
  };
}
function synthesize({
  training,
  development,
  maxSize = 9,
  budgetMs = 4e3,
  maxExpressions = 25e4,
  seed = 1,
  ambiguityWindow = AMBIGUITY_WINDOW,
  deterministicBudget = false,
  safetyTimeoutMs = 0
}) {
  const startedAt = Date.now();
  validateExamples(training, "training");
  validateExamples(development, "development");
  if (training.length < SYNTHESIS_LIMITS.minTraining) throw new TypeError(`need at least ${SYNTHESIS_LIMITS.minTraining} training examples`);
  if (development.length < SYNTHESIS_LIMITS.minDevelopment) throw new TypeError(`need at least ${SYNTHESIS_LIMITS.minDevelopment} development examples`);
  intIn(maxSize, 2, SYNTHESIS_LIMITS.maxSizeCap, "maxSize");
  intIn(budgetMs, 100, SYNTHESIS_LIMITS.maxBudgetMs, "budgetMs");
  intIn(maxExpressions, 1e3, SYNTHESIS_LIMITS.maxExpressionsCap, "maxExpressions");
  intIn(ambiguityWindow, 0, 4, "ambiguityWindow");
  intIn(seed, 0, 2 ** 31 - 1, "seed");
  intIn(safetyTimeoutMs, 0, 36e5, "safetyTimeoutMs");
  const all = [...training, ...development];
  const arity = training[0].input.length;
  if (!all.every((e) => e.input.length === arity)) throw new TypeError("all examples must have the same number of arguments");
  const argTypes = Array.from({ length: arity }, (_, i) => unifyTypes(all.map((e) => typeOfValue(e.input[i]))));
  const outType = unifyTypes(all.map((e) => typeOfValue(e.output)));
  if (argTypes.some((t) => !t || t === "bool") || !outType) {
    throw new TypeError("unsupported example value types (use numbers, strings, booleans as outputs, and lists of numbers/strings/number-lists)");
  }
  const deterministic = deterministicBudget === true;
  const valveMs = deterministic ? safetyTimeoutMs : budgetMs;
  const safetyDeadline = valveMs > 0 ? startedAt + valveMs : null;
  const numArgIdx = argTypes.map((t, i) => t === "num" ? i : -1).filter((i) => i >= 0);
  if (classifyUniverse(argTypes, { includeLambdas: true }).some((e) => e.sig.args.some((t) => t.startsWith("\u03BB")))) {
    buildLambdaPool(numArgIdx);
  }
  const total = maxExpressions;
  let sharedBudget = total;
  const plan = TIER_PLAN.map((tier) => ({ name: tier.name, share: tier.share }));
  const universes = [
    {
      // Stage 1: curated core, no user predicate. This is the fast path and it
      // decides the majority of the tasks.
      name: "core",
      universe: PRIM_NAMES.flatMap((name) => SIGS[name].filter((sig) => !sig.args.some((t) => t.startsWith("\u03BB"))).map((sig) => ({ name, sig }))).filter((e) => CORE_PRIMS.has(e.name)),
      includeLambdas: false
    },
    {
      // Stage 2: curated core, user predicates allowed.
      name: "core-lambda",
      universe: PRIM_NAMES.flatMap((name) => SIGS[name].map((sig) => ({ name, sig }))).filter((e) => CORE_PRIMS.has(e.name)),
      includeLambdas: true
    },
    { name: "extended", universe: extendedUniverse(argTypes, { includeLambdas: true }), includeLambdas: true },
    { name: "general", universe: PRIM_NAMES.flatMap((name) => SIGS[name].map((sig) => ({ name, sig }))), includeLambdas: true }
  ];
  const lanes = [];
  let last = null;
  let lastStep = plan[plan.length - 1];
  const meta = { startedAt, deterministic, safetyTimeoutMs: valveMs, safetyDeadline, seed, maxSize, maxExpressions, ambiguityWindow, argTypes, outType };
  for (let i = 0; i < plan.length; i++) {
    const step = plan[i];
    const spec = universes[i];
    const isLast = i === plan.length - 1;
    const tierBudget = isLast ? Math.max(256, sharedBudget) : Math.min(Math.max(256, Math.floor(total * step.share)), sharedBudget);
    const res = runTier({
      tier: step.name,
      training,
      development,
      universe: spec.universe,
      maxSize,
      maxExpressions: tierBudget,
      safetyDeadline,
      seed,
      ambiguityWindow,
      includeLambdas: spec.includeLambdas,
      preferLambdas: argTypes.some((t) => t.startsWith("L:"))
    });
    lanes.push({
      tier: step.name,
      maxExpressions: tierBudget,
      explored: res.explored,
      stoppedBy: res.stoppedBy || (res.found ? "found" : "stage-complete"),
      reason: res.reason || (res.found ? "found" : null),
      found: res.found === true,
      candidateCount: res.candidateCount ?? 0,
      universeSize: spec.universe.length
    });
    sharedBudget -= res.explored || 0;
    last = res;
    lastStep = step;
    if (res.found) return finish(res, step, plan, lanes, meta);
    if (res.reason === "ambiguous-examples" && res.ambiguityCheck === "complete") {
      return finish(res, step, plan, lanes, meta);
    }
    if (!deterministic && valveMs > 0 && Date.now() - startedAt >= valveMs) {
      return finish(res, step, plan, lanes, meta);
    }
  }
  return finish(last, lastStep, plan, lanes, meta);
}
function finish(result, tier, plan, lanes, meta) {
  const safetyTimeoutFired = meta.safetyDeadline !== null && Date.now() > meta.safetyDeadline;
  return {
    ...result,
    budget: {
      mode: meta.deterministic ? "deterministic" : "wall-clock-capped",
      deterministic: meta.deterministic,
      maxExpressions: meta.maxExpressions,
      maxSize: meta.maxSize,
      seed: meta.seed,
      ambiguityWindow: meta.ambiguityWindow,
      safetyTimeoutMs: meta.safetyTimeoutMs,
      safetyTimeoutFired,
      dslVersion: DSL_VERSION,
      plan: plan.map((p) => ({ tier: p.name, maxExpressions: p.maxExpressions, share: p.share })),
      lanes
    },
    elapsedMs: Date.now() - meta.startedAt
  };
}
var SYNTHESIS_LIMITS, CONSTS, PROBE_COUNT, TIER_PLAN, CORE_PRIMS, pick, ValueIntern, LAMBDA_POOL_CACHE, LAMBDA_XS, LAMBDA_OUTER, LAMBDA_POOL_EXPRESSIONS, AMBIGUITY_WINDOW, intIn, CASE_NORMALISERS;
var init_synthesize = __esm({
  "synora-v5/synthesis/synthesize.mjs"() {
    init_dsl();
    SYNTHESIS_LIMITS = Object.freeze({
      maxArity: 3,
      minTraining: 3,
      minDevelopment: 2,
      maxExamples: 50,
      maxSizeCap: 12,
      maxBudgetMs: 2e4,
      maxExpressionsCap: 2e6
    });
    CONSTS = [0, 1, 2, 3, 10, 15];
    PROBE_COUNT = 14;
    TIER_PLAN = Object.freeze([
      Object.freeze({ name: "core", share: 0.2 }),
      Object.freeze({ name: "core-lambda", share: 0.1 }),
      Object.freeze({ name: "extended", share: 0.5 }),
      Object.freeze({ name: "general", share: 0.2 })
    ]);
    CORE_PRIMS = Object.freeze(/* @__PURE__ */ new Set([
      "add",
      "sub",
      "mul",
      "div",
      "idiv",
      "mod",
      "eq",
      "lt",
      "le",
      "not",
      "and",
      "or",
      "ite",
      "len",
      "sum",
      "max",
      "min",
      "head",
      "last",
      "nth",
      "reverse",
      "sort",
      "unique",
      "tail",
      "init",
      "take",
      "drop",
      "concat",
      "flatten",
      "map",
      "filter",
      "all",
      "any",
      "range",
      "rangeFrom",
      "chars",
      "words",
      "join",
      "lower"
    ]));
    pick = (r, arr) => arr[Math.floor(r() * arr.length)];
    ValueIntern = class {
      constructor() {
        this.map = /* @__PURE__ */ new Map();
        this.next = 1;
      }
      intern(v) {
        if (v === ERR) return 0;
        const t = typeof v;
        if (t === "number" || t === "boolean" || t === "string") {
          let id2 = this.map.get(v);
          if (id2 === void 0) {
            id2 = this.next++;
            this.map.set(v, id2);
          }
          return id2;
        }
        const key = this._canon(v);
        let id = this.map.get(key);
        if (id === void 0) {
          id = this.next++;
          this.map.set(key, id);
        }
        return id;
      }
      _canon(v) {
        if (Array.isArray(v)) {
          if (v.length === 0) return "[]";
          if (typeof v[0] === "number") return "[" + v.join(",") + "]";
          if (typeof v[0] === "string") return '["' + v.join('","') + '"]';
          return JSON.stringify(v);
        }
        return JSON.stringify(v);
      }
    };
    LAMBDA_POOL_CACHE = /* @__PURE__ */ new Map();
    LAMBDA_XS = Object.freeze([-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]);
    LAMBDA_OUTER = Object.freeze([-3, -1, 1]);
    LAMBDA_POOL_EXPRESSIONS = 25e3;
    AMBIGUITY_WINDOW = 2;
    intIn = (v, lo, hi, label) => {
      if (!Number.isInteger(v) || v < lo || v > hi) throw new RangeError(`${label} must be an integer in [${lo}, ${hi}]`);
    };
    CASE_NORMALISERS = /* @__PURE__ */ new Set(["lower", "upper"]);
  }
});

// synora-v5/synthesis/failure-memory.mjs
var failure_memory_exports = {};
__export(failure_memory_exports, {
  FailureMemory: () => FailureMemory,
  extractFailureSignature: () => extractFailureSignature
});
import crypto from "node:crypto";
function extractFailureSignature({ training, development, result, operation }) {
  const arity = training[0]?.input?.length ?? 0;
  const argTypeHash = training[0]?.input?.map((v) => Array.isArray(v) ? "L" : typeof v) ?? [];
  const outType = typeof training[0]?.output;
  const exampleCount = training.length + (development?.length ?? 0);
  const examplesHash = crypto.createHash("sha256").update(JSON.stringify({ training, development })).digest("hex").slice(0, 16);
  return {
    operation: operation || "unknown",
    arity,
    argTypeHash: argTypeHash.join(","),
    outType,
    exampleCount,
    examplesHash,
    reason: result?.reason || "unknown",
    explored: result?.explored || 0,
    ambiguityCheck: result?.ambiguityCheck || null,
    timestamp: Date.now()
  };
}
var FailureMemory;
var init_failure_memory = __esm({
  "synora-v5/synthesis/failure-memory.mjs"() {
    FailureMemory = class {
      constructor() {
        this.signatures = /* @__PURE__ */ new Map();
        this.patternAvoid = /* @__PURE__ */ new Set();
      }
      /**
       * Record a failure. If the same task (by examples hash) has failed before
       * with the same reason, the failure is confirmed (confidence increases).
       */
      record(failureData) {
        const sig = extractFailureSignature(failureData);
        const existing = this.signatures.get(sig.examplesHash);
        if (existing) {
          existing.confidence = (existing.confidence || 1) + 1;
          existing.lastSeen = sig.timestamp;
          if (existing.confidence >= 3) {
            this.patternAvoid.add(this._shapeKey(sig));
          }
        } else {
          this.signatures.set(sig.examplesHash, { ...sig, confidence: 1 });
        }
        return sig;
      }
      /**
       * Check if a task shape matches a known avoidance pattern.
       * Returns true if the synthesizer should skip or reduce budget for this task.
       */
      shouldAvoid(taskShape) {
        const shapeKey = this._shapeKey(taskShape);
        return this.patternAvoid.has(shapeKey);
      }
      /**
       * Get a confidence-adjusted budget recommendation for a task.
       * Tasks that have failed before get a reduced budget (to fail fast),
       * unless the examples are different (different examplesHash).
       */
      recommendBudget(taskShape, defaultBudget) {
        const examplesHash = taskShape.examplesHash;
        const existing = this.signatures.get(examplesHash);
        if (!existing) return defaultBudget;
        if (existing.confidence >= 3) return Math.floor(defaultBudget * 0.3);
        if (existing.confidence >= 2) return Math.floor(defaultBudget * 0.6);
        return defaultBudget;
      }
      /**
       * Export the failure memory as a compact JSON object for persistence.
       */
      export() {
        return {
          version: 1,
          signatures: [...this.signatures.values()],
          patternAvoid: [...this.patternAvoid],
          totalFailures: this.signatures.size,
          confirmedAvoidances: this.patternAvoid.size
        };
      }
      /**
       * Import a previously exported failure memory.
       */
      import(data) {
        if (data.version !== 1) throw new Error("incompatible failure memory version");
        for (const sig of data.signatures || []) {
          this.signatures.set(sig.examplesHash, sig);
        }
        for (const key of data.patternAvoid || []) {
          this.patternAvoid.add(key);
        }
      }
      _shapeKey(sig) {
        return `${sig.arity}|${sig.argTypeHash}|${sig.outType}|${sig.reason}`;
      }
      get size() {
        return this.signatures.size;
      }
      get avoidCount() {
        return this.patternAvoid.size;
      }
    };
  }
});

// synora-v5/identity.mjs
function isIdentityQuestion(question) {
  const q = (question || "").toLowerCase().trim();
  const arPatterns = ["\u0645\u0646 \u0627\u0646\u062A", "\u0645\u0646 \u0623\u0646\u062A", "\u0645\u0627 \u0627\u0633\u0645\u0643", "\u0639\u0631\u0641 \u0646\u0641\u0633\u0643", "\u0645\u0646 \u0628\u0646\u0627\u0643", "\u0645\u0646 \u0635\u0646\u0639\u0643", "\u0645\u0627 \u0647\u0648 \u0633\u064A\u0646\u0648\u0631\u0627", "\u0643\u0645 \u0627\u0635\u062F\u0627\u0631\u0643", "\u0645\u0627 \u0627\u0635\u062F\u0627\u0631\u0643", "\u0645\u0646 \u0627\u0646\u062A \u0648\u0628\u0645\u0627\u0630\u0627"];
  const enPatterns = ["who are you", "what is your name", "introduce yourself", "who built you", "who made you", "what is synora", "what version", "who are you and what"];
  return arPatterns.some((p) => q.includes(p)) || enPatterns.some((p) => q.includes(p));
}
function generateIdentityResponse(question) {
  const isArabic = /[\u0600-\u06FF]/.test(question || "");
  if (isArabic) {
    return `\u0645\u0631\u062D\u0628\u0627\u064B! \u0623\u0646\u0627 ${IDENTITY.fullName}\u060C ${IDENTITY.type}.
${IDENTITY.isFirst}\u060C \u0639\u0644\u0649 \u064A\u062F ${IDENTITY.builder} \u0645\u0646 ${IDENTITY.origin}.

${IDENTITY.capabilities.ar}.

\u0627\u0633\u0623\u0644\u0646\u064A \u0628\u0623\u064A \u0644\u063A\u0629 \u0648\u0633\u0623\u062C\u064A\u0628\u0643 \u0628\u0647\u0627. \u0643\u064A\u0641 \u0623\u0633\u062A\u0637\u064A\u0639 \u0645\u0633\u0627\u0639\u062F\u062A\u0643 \u0627\u0644\u064A\u0648\u0645\u061F`;
  } else {
    return `Hello! I am ${IDENTITY.fullName}, a ${IDENTITY.typeEn}.
I am ${IDENTITY.isFirstEn}, built by ${IDENTITY.builderEn} from ${IDENTITY.originEn}.

${IDENTITY.capabilities.en}.

Ask me in any language and I will respond in it. How can I help you today?`;
  }
}
var IDENTITY;
var init_identity = __esm({
  "synora-v5/identity.mjs"() {
    IDENTITY = {
      name: "Synora",
      version: "1.5",
      fullName: "Synora 1.5",
      builder: "\u0627\u0644\u0645\u0647\u0646\u062F\u0633 \u0644\u064A\u062B \u0623\u062D\u0645\u062F \u062E\u062F\u064A\u0634 \u0627\u0644\u0632\u0631\u064A\u0642\u064A",
      builderEn: "Engineer Laith Ahmed Khadeesh Al-Zuraqi",
      origin: "\u0627\u0644\u064A\u0645\u0646",
      originEn: "Yemen",
      type: "\u0646\u0645\u0648\u0630\u062C \u0630\u0643\u0627\u0621 \u0627\u0635\u0637\u0646\u0627\u0639\u064A \u0631\u0645\u0632\u064A",
      typeEn: "symbolic AI model",
      isFirst: "\u0623\u0648\u0644 \u0646\u0645\u0648\u0630\u062C \u0630\u0643\u0627\u0621 \u0627\u0635\u0637\u0646\u0627\u0639\u064A \u064A\u0645\u0646\u064A \u062A\u0645 \u0628\u0646\u0627\u0627\u0626\u0647 \u0648\u062A\u062F\u0631\u064A\u0628\u0647 \u0641\u064A \u0627\u0644\u064A\u0645\u0646",
      isFirstEn: "the first Yemeni AI model built and trained in Yemen",
      capabilities: {
        ar: "\u0623\u0633\u062A\u0637\u064A\u0639 \u0645\u0633\u0627\u0639\u062F\u062A\u0643 \u0641\u064A \u0627\u0644\u0628\u0631\u0645\u062C\u0629\u060C \u0627\u0644\u0625\u062C\u0627\u0628\u0629 \u0639\u0644\u0649 \u0627\u0644\u0623\u0633\u0626\u0644\u0629\u060C \u0628\u0646\u0627\u0621 \u0627\u0644\u0645\u0648\u0627\u0642\u0639 \u0648\u0635\u0641\u062D\u0627\u062A \u0627\u0644\u0647\u0628\u0648\u0637\u060C \u062A\u0646\u0641\u064A\u0630 \u0627\u0644\u0645\u0647\u0627\u0645 \u0643\u0648\u0643\u064A\u0644 \u0630\u0643\u064A\u060C \u0648\u0627\u0644\u0646\u0642\u0627\u0634 \u0627\u0644\u0645\u0641\u062A\u0648\u062D \u2014 \u0643\u0644 \u0630\u0644\u0643 \u0628\u0644\u0627 \u0634\u0628\u0643\u0629 \u0639\u0635\u0628\u064A\u0629 \u0648\u0628\u0635\u0641\u0631 \u0647\u0644\u0648\u0633\u0629",
        en: "I can help you with programming, answering questions, building websites and landing pages, executing tasks as an AI agent, and open discussion \u2014 all without a neural network and with zero hallucination"
      }
    };
  }
});

// synora-v5/agent/brain.mjs
var brain_exports = {};
__export(brain_exports, {
  AgentBrain: () => AgentBrain
});
var AgentBrain;
var init_brain = __esm({
  "synora-v5/agent/brain.mjs"() {
    init_planner();
    init_verifier();
    init_synthesize();
    init_dsl();
    init_sanity_checks();
    init_failure_memory();
    init_identity();
    AgentBrain = class {
      /**
       * @param {object} opts
       * @param {object} [opts.store] — KnowledgeStore instance
       * @param {object} [opts.failureMemory] — FailureMemory instance
       * @param {object} [opts.synthesizerOptions] — default synthesis options
       */
      constructor(opts = {}) {
        this.store = opts.store || null;
        this.failureMemory = opts.failureMemory || new FailureMemory();
        this.synthOptions = opts.synthesizerOptions || {
          maxSize: 8,
          maxExpressions: 4e5,
          deterministicBudget: true,
          safetyTimeoutMs: 3e4
        };
      }
      /**
       * Execute a task. This is the main entry point.
       *
       * @param {string} task — natural language task
       * @param {object} [context] — { training?, development?, testCases?, lang? }
       * @returns {Promise<AgentResult>}
       *
       * @typedef {object} AgentResult
       * @property {boolean} success — did the task complete?
       * @property {string} status — 'solved' | 'verified' | 'not_found' | 'abstained' | 'error'
       * @property {any} [output] — the result value (if solved)
       * @property {string} [source] — provenance (code or knowledge source)
       * @property {object} [plan] — the steps that were planned
       * @property {object[]} [stepResults] — results per step
       * @property {string} [reason] — failure reason (if not success)
       * @property {string} [message] — natural language response
       */
      async execute(task, context = {}) {
        if (isIdentityQuestion(task)) {
          const lang2 = /[؀-ۿ]/.test(task) ? "ar" : "en";
          return { success: true, status: "solved", output: generateIdentityResponse(task), message: generateIdentityResponse(task), plan: { steps: [{ id: "identity", operation: "respond" }], deterministic: true, lang: lang2, taskType: "identity" }, stepResults: [], timestamp: (/* @__PURE__ */ new Date()).toISOString(), agentVersion: "synora-agent/1.5" };
        }
        const lang = context.lang || (/[\u0600-\u06FF]/.test(task) ? "ar" : "en");
        const plan = planTask(task, { lang });
        const stepResults = [];
        for (const step of plan.steps) {
          const stepResult = await this._executeStep(step, context);
          stepResults.push({ ...stepResult, stepId: step.id });
          const verification = verifyStep(step, stepResult, context);
          stepResults[stepResults.length - 1].verification = verification;
          if (!verification.verified && step.operation !== "abstain") {
            this.failureMemory.record({
              training: context.training || [],
              development: context.development || [],
              result: { reason: `verification_failed: ${verification.reason}` },
              operation: step.params?.taskType
            });
            return this._finish(false, "not_found", {
              plan,
              stepResults,
              reason: verification.reason,
              message: lang === "ar" ? `\u062A\u0639\u0630\u0651\u0631 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0646\u062A\u064A\u062C\u0629: ${verification.reason}` : `Verification failed: ${verification.reason}`
            });
          }
        }
        const lastResult = stepResults[stepResults.length - 1];
        const allAnswered = stepResults.every((sr) => sr.answered || sr.stepId === void 0);
        const success = allAnswered && plan.steps[0]?.operation !== "abstain" && lastResult?.answered !== false;
        const status = success ? "solved" : "abstained";
        const output = lastResult?.output || lastResult?.answer;
        const source = lastResult?.source || lastResult?.span?.sourceId;
        let message = "";
        if (success) {
          const answerStr = typeof output === "object" ? JSON.stringify(output) : String(output);
          message = lang === "ar" ? `\u0627\u0644\u0625\u062C\u0627\u0628\u0629: ${answerStr}` : `The answer is: ${answerStr}`;
        } else {
          message = lang === "ar" ? "\u0623\u0639\u062A\u0630\u0631\u060C \u0644\u0645 \u0623\u062A\u0645\u0643\u0646 \u0645\u0646 \u062D\u0644 \u0647\u0630\u0647 \u0627\u0644\u0645\u0647\u0645\u0629. \u0647\u0644 \u062A\u0631\u064A\u062F \u0623\u0646 \u0623\u0628\u062D\u062B \u0639\u0646\u0647\u0627\u061F" : "I apologize, I could not solve this task. Would you like me to search for it?";
        }
        return this._finish(success, status, {
          output,
          source,
          plan,
          stepResults,
          message
        });
      }
      async _executeStep(step, context) {
        switch (step.operation) {
          case "synthesize":
            return this._executeSynthesize(step, context);
          case "query":
            return this._executeQuery(step, context);
          case "abstain":
            return { answered: false, reason: step.params.reason };
          default:
            return { answered: false, reason: "unknown_operation" };
        }
      }
      _executeSynthesize(step, context) {
        if (context.training?.length >= 3) {
          const result = synthesize({
            training: context.training,
            development: context.development || [],
            ...this.synthOptions
          });
          if (result.found && result.ast) {
            const input = context.input || context.testCases?.[0]?.input;
            let output = null;
            if (input) {
              try {
                output = evalAst(result.ast, input);
              } catch (_) {
              }
            }
            return {
              answered: true,
              ast: result.ast,
              source: result.source,
              output,
              explored: result.explored
            };
          }
          this.failureMemory.record({
            training: context.training,
            development: context.development || [],
            result,
            operation: "synthesize"
          });
          return { answered: false, reason: result.reason || "synthesis_failed" };
        }
        if (step.params?.ast) {
          const input = context.input || context.testCases?.[0]?.input || [[9, 8, 7, 6, 5, 4, 3, 2, 1]];
          let output = null;
          try {
            output = executeAST(step.params.ast, input);
          } catch (_) {
          }
          return {
            answered: true,
            ast: step.params.ast,
            source: step.params.source,
            output
          };
        }
        return { answered: false, reason: "no_ast_and_no_training" };
      }
      _executeQuery(step, context) {
        if (!this.store) {
          return { answered: false, reason: "no_knowledge_store" };
        }
        const result = this.store.answerQuestion(step.params.question);
        return {
          answered: result.status === "answered",
          answer: result.answer,
          span: result.span,
          source: result.span?.sourceId,
          reason: result.reason
        };
      }
      _finish(success, status, extra) {
        return {
          success,
          status,
          ...extra,
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          agentVersion: "synora-agent/1.0"
        };
      }
    };
  }
});

// synora-v5/knowledge/synthetic-wikipedia.mjs
var synthetic_wikipedia_exports = {};
__export(synthetic_wikipedia_exports, {
  SYNTHETIC_WIKIPEDIA: () => SYNTHETIC_WIKIPEDIA
});
var SYNTHETIC_WIKIPEDIA;
var init_synthetic_wikipedia = __esm({
  "synora-v5/knowledge/synthetic-wikipedia.mjs"() {
    SYNTHETIC_WIKIPEDIA = [
      // --- Countries EN ---
      { title: "France", extract: "France is a country in Western Europe. Paris is the capital of France. France has a population of 67 million. France was founded in 843." },
      { title: "Germany", extract: "Germany is a country in Central Europe. Berlin is the capital of Germany. Germany has a population of 83 million. Founded in 1871." },
      { title: "Japan", extract: "Japan is an island nation in East Asia. Tokyo is the capital of Japan. The population of Japan is 125 million. Established in 660." },
      { title: "China", extract: "China is a country in East Asia. Beijing is the capital of China. China has a population of 1400 million. Founded in 221." },
      { title: "Brazil", extract: "Brazil is a country in South America. Brasilia is the capital of Brazil. Brazil has a population of 213 million. Founded in 1822." },
      { title: "India", extract: "India is a country in South Asia. New Delhi is the capital of India. India has a population of 1400 million. Founded in 1947." },
      { title: "Egypt", extract: "Egypt is a country in North Africa. Cairo is the capital of Egypt. Egypt has a population of 104 million. Founded in 3100." },
      { title: "Morocco", extract: "Morocco is a country in North Africa. Rabat is the capital of Morocco. Morocco has a population of 37 million. Founded in 788." },
      { title: "Saudi Arabia", extract: "Saudi Arabia is a country in Western Asia. Riyadh is the capital of Saudi Arabia. Saudi Arabia has a population of 35 million. Founded in 1932." },
      { title: "United Arab Emirates", extract: "The United Arab Emirates is a country in Western Asia. Abu Dhabi is the capital of the United Arab Emirates. The UAE has a population of 10 million. Founded in 1971." },
      { title: "United Kingdom", extract: "The United Kingdom is a country in Northwestern Europe. London is the capital of the United Kingdom. The UK has a population of 67 million. Founded in 1707." },
      { title: "United States", extract: "The United States is a country in North America. Washington, D.C. is the capital of the United States. The US has a population of 331 million. Founded in 1776." },
      { title: "Russia", extract: "Russia is a country spanning Eastern Europe and Northern Asia. Moscow is the capital of Russia. Russia has a population of 144 million. Founded in 862." },
      { title: "Canada", extract: "Canada is a country in North America. Ottawa is the capital of Canada. Canada has a population of 38 million. Founded in 1867." },
      { title: "Australia", extract: "Australia is a country in Oceania. Canberra is the capital of Australia. Australia has a population of 26 million. Founded in 1901." },
      { title: "Italy", extract: "Italy is a country in Southern Europe. Rome is the capital of Italy. Italy has a population of 60 million. Founded in 1861." },
      { title: "Spain", extract: "Spain is a country in Southwestern Europe. Madrid is the capital of Spain. Spain has a population of 47 million. Founded in 1492." },
      { title: "Turkey", extract: "Turkey is a country spanning Southeastern Europe and Western Asia. Ankara is the capital of Turkey. Turkey has a population of 84 million. Founded in 1923." },
      { title: "Iran", extract: "Iran is a country in Western Asia. Tehran is the capital of Iran. Iran has a population of 84 million. Founded in 625." },
      { title: "Iraq", extract: "Iraq is a country in Western Asia. Baghdad is the capital of Iraq. Iraq has a population of 40 million. Founded in 1932." },
      // --- Countries AR ---
      { title: "\u0641\u0631\u0646\u0633\u0627", extract: "\u0641\u0631\u0646\u0633\u0627 \u062F\u0648\u0644\u0629 \u0641\u064A \u0623\u0648\u0631\u0648\u0628\u0627 \u0627\u0644\u063A\u0631\u0628\u064A\u0629. \u0639\u0627\u0635\u0645\u062A\u0647\u0627 \u0628\u0627\u0631\u064A\u0633. \u064A\u0628\u0644\u063A \u0639\u062F\u062F \u0633\u0643\u0627\u0646\u0647\u0627 67 \u0645\u0644\u064A\u0648\u0646 \u0646\u0633\u0645\u0629. \u062A\u0623\u0633\u0633\u062A \u0639\u0627\u0645 843." },
      { title: "\u0623\u0644\u0645\u0627\u0646\u064A\u0627", extract: "\u0623\u0644\u0645\u0627\u0646\u064A\u0627 \u062F\u0648\u0644\u0629 \u0641\u064A \u0623\u0648\u0631\u0648\u0628\u0627 \u0627\u0644\u0648\u0633\u0637\u0649. \u0639\u0627\u0635\u0645\u062A\u0647\u0627 \u0628\u0631\u0644\u064A\u0646. \u064A\u0628\u0644\u063A \u0639\u062F\u062F \u0633\u0643\u0627\u0646\u0647\u0627 83 \u0645\u0644\u064A\u0648\u0646 \u0646\u0633\u0645\u0629. \u062A\u0623\u0633\u0633\u062A \u0639\u0627\u0645 1871." },
      { title: "\u0627\u0644\u064A\u0627\u0628\u0627\u0646", extract: "\u0627\u0644\u064A\u0627\u0628\u0627\u0646 \u062F\u0648\u0644\u0629 \u062C\u0632\u0631\u064A\u0629 \u0641\u064A \u0634\u0631\u0642 \u0622\u0633\u064A\u0627. \u0639\u0627\u0635\u0645\u062A\u0647\u0627 \u0637\u0648\u0643\u064A\u0648. \u064A\u0628\u0644\u063A \u0639\u062F\u062F \u0633\u0643\u0627\u0646\u0647\u0627 125 \u0645\u0644\u064A\u0648\u0646 \u0646\u0633\u0645\u0629. \u062A\u0623\u0633\u0633\u062A \u0639\u0627\u0645 660." },
      { title: "\u0627\u0644\u0635\u064A\u0646", extract: "\u0627\u0644\u0635\u064A\u0646 \u062F\u0648\u0644\u0629 \u0641\u064A \u0634\u0631\u0642 \u0622\u0633\u064A\u0627. \u0639\u0627\u0635\u0645\u062A\u0647\u0627 \u0628\u0643\u064A\u0646. \u064A\u0628\u0644\u063A \u0639\u062F\u062F \u0633\u0643\u0627\u0646\u0647\u0627 1400 \u0645\u0644\u064A\u0648\u0646 \u0646\u0633\u0645\u0629. \u062A\u0623\u0633\u0633\u062A \u0639\u0627\u0645 221." },
      { title: "\u0645\u0635\u0631", extract: "\u0645\u0635\u0631 \u062F\u0648\u0644\u0629 \u0641\u064A \u0634\u0645\u0627\u0644 \u0623\u0641\u0631\u064A\u0642\u064A\u0627. \u0639\u0627\u0635\u0645\u062A\u0647\u0627 \u0627\u0644\u0642\u0627\u0647\u0631\u0629. \u064A\u0628\u0644\u063A \u0639\u062F\u062F \u0633\u0643\u0627\u0646\u0647\u0627 104 \u0645\u0644\u064A\u0648\u0646 \u0646\u0633\u0645\u0629. \u062A\u0623\u0633\u0633\u062A \u0639\u0627\u0645 3100." },
      { title: "\u0627\u0644\u0645\u063A\u0631\u0628", extract: "\u0627\u0644\u0645\u063A\u0631\u0628 \u062F\u0648\u0644\u0629 \u0641\u064A \u0634\u0645\u0627\u0644 \u0623\u0641\u0631\u064A\u0642\u064A\u0627. \u0639\u0627\u0635\u0645\u062A\u0647\u0627 \u0627\u0644\u0631\u0628\u0627\u0637. \u064A\u0628\u0644\u063A \u0639\u062F\u062F \u0633\u0643\u0627\u0646\u0647\u0627 37 \u0645\u0644\u064A\u0648\u0646 \u0646\u0633\u0645\u0629. \u062A\u0623\u0633\u0633\u062A \u0639\u0627\u0645 788." },
      { title: "\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629", extract: "\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629 \u062F\u0648\u0644\u0629 \u0641\u064A \u063A\u0631\u0628 \u0622\u0633\u064A\u0627. \u0639\u0627\u0635\u0645\u062A\u0647\u0627 \u0627\u0644\u0631\u064A\u0627\u0636. \u064A\u0628\u0644\u063A \u0639\u062F\u062F \u0633\u0643\u0627\u0646\u0647\u0627 35 \u0645\u0644\u064A\u0648\u0646 \u0646\u0633\u0645\u0629. \u062A\u0623\u0633\u0633\u062A \u0639\u0627\u0645 1932." },
      { title: "\u0627\u0644\u0639\u0631\u0627\u0642", extract: "\u0627\u0644\u0639\u0631\u0627\u0642 \u062F\u0648\u0644\u0629 \u0641\u064A \u063A\u0631\u0628 \u0622\u0633\u064A\u0627. \u0639\u0627\u0635\u0645\u062A\u0647\u0627 \u0628\u063A\u062F\u0627\u062F. \u064A\u0628\u0644\u063A \u0639\u062F\u062F \u0633\u0643\u0627\u0646\u0647\u0627 40 \u0645\u0644\u064A\u0648\u0646 \u0646\u0633\u0645\u0629. \u062A\u0623\u0633\u0633\u062A \u0639\u0627\u0645 1932." },
      // --- Cities EN ---
      { title: "Paris", extract: "Paris is the capital of France. Paris has a population of 2 million. Paris was founded in 259." },
      { title: "London", extract: "London is the capital of the United Kingdom. London has a population of 9 million. Founded in 47." },
      { title: "Tokyo", extract: "Tokyo is the capital of Japan. Tokyo has a population of 14 million. Founded in 1457." },
      { title: "Cairo", extract: "Cairo is the capital of Egypt. Cairo has a population of 21 million. Founded in 969." },
      { title: "Dubai", extract: "Dubai is a city in the United Arab Emirates. Dubai has a population of 3 million. Founded in 1833." },
      { title: "Riyadh", extract: "Riyadh is the capital of Saudi Arabia. Riyadh has a population of 7 million. Founded in 1446." },
      { title: "Istanbul", extract: "Istanbul is a city in Turkey. Istanbul has a population of 15 million. Founded in 660." },
      { title: "Moscow", extract: "Moscow is the capital of Russia. Moscow has a population of 12 million. Founded in 1147." },
      { title: "Beijing", extract: "Beijing is the capital of China. Beijing has a population of 21 million. Founded in 1045." },
      { title: "Berlin", extract: "Berlin is the capital of Germany. Berlin has a population of 4 million. Founded in 1237." },
      { title: "Madrid", extract: "Madrid is the capital of Spain. Madrid has a population of 3 million. Founded in 865." },
      { title: "Rome", extract: "Rome is the capital of Italy. Rome has a population of 4 million. Founded in 753." },
      { title: "Amsterdam", extract: "Amsterdam is the capital of the Netherlands. Amsterdam has a population of 1 million. Founded in 1275." },
      { title: "Brussels", extract: "Brussels is the capital of Belgium. Brussels has a population of 1 million. Founded in 979." },
      { title: "Vienna", extract: "Vienna is the capital of Austria. Vienna has a population of 2 million. Founded in 100." },
      { title: "Stockholm", extract: "Stockholm is the capital of Sweden. Stockholm has a population of 1 million. Founded in 1252." },
      { title: "Oslo", extract: "Oslo is the capital of Norway. Oslo has a population of 1 million. Founded in 1040." },
      { title: "Copenhagen", extract: "Copenhagen is the capital of Denmark. Copenhagen has a population of 1 million. Founded in 1167." },
      { title: "Helsinki", extract: "Helsinki is the capital of Finland. Helsinki has a population of 1 million. Founded in 1550." },
      { title: "Athens", extract: "Athens is the capital of Greece. Athens has a population of 3 million. Founded in 700." },
      { title: "Lisbon", extract: "Lisbon is the capital of Portugal. Lisbon has a population of 1 million. Founded in 1147." },
      { title: "Dublin", extract: "Dublin is the capital of Ireland. Dublin has a population of 1 million. Founded in 841." },
      { title: "Prague", extract: "Prague is the capital of the Czech Republic. Prague has a population of 1 million. Founded in 870." },
      { title: "Budapest", extract: "Budapest is the capital of Hungary. Budapest has a population of 2 million. Founded in 1873." },
      { title: "Warsaw", extract: "Warsaw is the capital of Poland. Warsaw has a population of 2 million. Founded in 1300." },
      { title: "Kiev", extract: "Kiev is the capital of Ukraine. Kiev has a population of 3 million. Founded in 482." },
      { title: "Toronto", extract: "Toronto is a city in Canada. Toronto has a population of 3 million. Founded in 1793." },
      { title: "Sydney", extract: "Sydney is a city in Australia. Sydney has a population of 5 million. Founded in 1788." },
      { title: "Singapore", extract: "Singapore is a city-state in Southeast Asia. Singapore has a population of 6 million. Founded in 1819." },
      { title: "Mexico City", extract: "Mexico City is the capital of Mexico. Mexico City has a population of 9 million. Founded in 1325." },
      { title: "Buenos Aires", extract: "Buenos Aires is the capital of Argentina. Buenos Aires has a population of 3 million. Founded in 1536." },
      { title: "Johannesburg", extract: "Johannesburg is a city in South Africa. Johannesburg has a population of 6 million. Founded in 1886." },
      { title: "Nairobi", extract: "Nairobi is the capital of Kenya. Nairobi has a population of 4 million. Founded in 1899." },
      { title: "Addis Ababa", extract: "Addis Ababa is the capital of Ethiopia. Addis Ababa has a population of 4 million. Founded in 1886." },
      { title: "Accra", extract: "Accra is the capital of Ghana. Accra has a population of 2 million. Founded in 1877." },
      { title: "Algiers", extract: "Algiers is the capital of Algeria. Algiers has a population of 3 million. Founded in 944." },
      { title: "Tunis", extract: "Tunis is the capital of Tunisia. Tunis has a population of 2 million. Founded in 814." },
      { title: "Tripoli", extract: "Tripoli is the capital of Libya. Tripoli has a population of 1 million. Founded in 700." },
      { title: "Amman", extract: "Amman is the capital of Jordan. Amman has a population of 4 million. Founded in 7500." },
      { title: "Beirut", extract: "Beirut is the capital of Lebanon. Beirut has a population of 2 million. Founded in 3000." },
      { title: "Damascus", extract: "Damascus is the capital of Syria. Damascus has a population of 2 million. Founded in 9000." },
      { title: "Sanaa", extract: "Sanaa is the capital of Yemen. Sanaa has a population of 3 million. Founded in 2500." },
      { title: "Muscat", extract: "Muscat is the capital of Oman. Muscat has a population of 1 million. Founded in 100." },
      { title: "Doha", extract: "Doha is the capital of Qatar. Doha has a population of 2 million. Founded in 1825." },
      { title: "Manama", extract: "Manama is the capital of Bahrain. Manama has a population of 1 million. Founded in 1345." },
      { title: "Kuwait City", extract: "Kuwait City is the capital of Kuwait. Kuwait City has a population of 3 million. Founded in 1716." },
      { title: "Khartoum", extract: "Khartoum is the capital of Sudan. Khartoum has a population of 6 million. Founded in 1821." },
      { title: "Mogadishu", extract: "Mogadishu is the capital of Somalia. Mogadishu has a population of 2 million. Founded in 900." },
      { title: "Islamabad", extract: "Islamabad is the capital of Pakistan. Islamabad has a population of 1 million. Founded in 1960." },
      { title: "Dhaka", extract: "Dhaka is the capital of Bangladesh. Dhaka has a population of 21 million. Founded in 1608." },
      { title: "Jakarta", extract: "Jakarta is the capital of Indonesia. Jakarta has a population of 11 million. Founded in 397." },
      { title: "Kuala Lumpur", extract: "Kuala Lumpur is the capital of Malaysia. Kuala Lumpur has a population of 2 million. Founded in 1857." },
      { title: "Bangkok", extract: "Bangkok is the capital of Thailand. Bangkok has a population of 11 million. Founded in 1782." },
      { title: "Hanoi", extract: "Hanoi is the capital of Vietnam. Hanoi has a population of 8 million. Founded in 1010." },
      { title: "Manila", extract: "Manila is the capital of the Philippines. Manila has a population of 14 million. Founded in 1571." },
      { title: "Seoul", extract: "Seoul is the capital of South Korea. Seoul has a population of 10 million. Founded in 18." },
      { title: "Pyongyang", extract: "Pyongyang is the capital of North Korea. Pyongyang has a population of 3 million. Founded in 1122." },
      { title: "Taipei", extract: "Taipei is the capital of Taiwan. Taipei has a population of 7 million. Founded in 1709." },
      { title: "New York City", extract: "New York City is a city in the United States. New York City has a population of 8 million. Founded in 1624." },
      { title: "Washington, D.C.", extract: "Washington, D.C. is the capital of the United States. Washington, D.C. has a population of 1 million. Founded in 1790." },
      { title: "Ottawa", extract: "Ottawa is the capital of Canada. Ottawa has a population of 1 million. Founded in 1826." },
      { title: "Canberra", extract: "Canberra is the capital of Australia. Canberra has a population of 1 million. Founded in 1913." },
      { title: "Brasilia", extract: "Brasilia is the capital of Brazil. Brasilia has a population of 3 million. Founded in 1960." },
      { title: "Ankara", extract: "Ankara is the capital of Turkey. Ankara has a population of 5 million. Founded in 700." },
      { title: "Tehran", extract: "Tehran is the capital of Iran. Tehran has a population of 9 million. Founded in 1220." },
      { title: "Baghdad", extract: "Baghdad is the capital of Iraq. Baghdad has a population of 7 million. Founded in 762." },
      { title: "Rabat", extract: "Rabat is the capital of Morocco. Rabat has a population of 2 million. Founded in 1146." },
      { title: "Cairo", extract: "Cairo is the capital of Egypt. Cairo has a population of 21 million. Founded in 969." },
      { title: "New Delhi", extract: "New Delhi is the capital of India. New Delhi has a population of 30 million. Founded in 1911." },
      { title: "Beijing", extract: "Beijing is the capital of China. Beijing has a population of 21 million. Founded in 1045." },
      { title: "Tokyo", extract: "Tokyo is the capital of Japan. Tokyo has a population of 14 million. Founded in 1457." },
      { title: "Berlin", extract: "Berlin is the capital of Germany. Berlin has a population of 4 million. Founded in 1237." },
      { title: "Paris", extract: "Paris is the capital of France. Paris has a population of 2 million. Founded in 259." },
      { title: "London", extract: "London is the capital of the United Kingdom. London has a population of 9 million. Founded in 47." },
      { title: "Moscow", extract: "Moscow is the capital of Russia. Moscow has a population of 12 million. Founded in 1147." }
    ];
  }
});

// synora-v5/knowledge/wikipedia-ingestion.mjs
var wikipedia_ingestion_exports = {};
__export(wikipedia_ingestion_exports, {
  ENTITIES_AR: () => ENTITIES_AR,
  ENTITIES_EN: () => ENTITIES_EN,
  buildRelationTables: () => buildRelationTables,
  extractFacts: () => extractFacts2,
  ingestWikipediaBatch: () => ingestWikipediaBatch,
  saveRelationTables: () => saveRelationTables
});
function extractFacts2(text, lang = "en") {
  const patterns = lang === "ar" ? FACT_PATTERNS_AR : FACT_PATTERNS_EN;
  const facts = [];
  for (const { relation, regex, extract, swap } of patterns) {
    regex.lastIndex = 0;
    let m;
    while ((m = regex.exec(text)) !== null) {
      const value = extract ? extract(m) : swap ? m[1] : m[1];
      if (value && value.length > 0 && value.length < 100) {
        facts.push({ relation, value: value.trim() });
      }
    }
  }
  return facts;
}
async function fetchSummary(entity, lang, fetcher) {
  const _fetch = fetcher || (typeof fetch !== "undefined" ? fetch : null);
  if (!_fetch) return null;
  const wikiLang = lang === "ar" ? "ar" : "en";
  const title = encodeURIComponent(entity.replace(/\s+/g, "_"));
  const url = `https://${wikiLang}.wikipedia.org/api/rest_v1/page/summary/${title}`;
  try {
    const res = await _fetch(url, { headers: { "Accept": "application/json" } });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.type === "standard" && data.extract) {
      return { title: data.title, extract: data.extract, url };
    }
  } catch (_) {
  }
  return null;
}
async function ingestWikipediaBatch(entities, lang, store, fetcher, onProgress) {
  let ingested = 0;
  let factCount = 0;
  for (let i = 0; i < entities.length; i++) {
    const entity = entities[i];
    const summary = await fetchSummary(entity, lang, fetcher);
    if (!summary) continue;
    const docId = `wiki-${lang}-${summary.title}`.replace(/\s+/g, "_");
    store.ingestDocument({
      id: docId,
      title: summary.title,
      text: summary.extract,
      licence: "CC-BY-SA-3.0",
      url: summary.url
    });
    ingested++;
    const facts = extractFacts2(summary.extract, lang);
    for (const { relation, value } of facts) {
      if (store.facts) {
        store.facts.push({
          id: `fact-${docId}-${relation}-${factCount}`,
          subject: summary.title,
          predicate: relation,
          object: value,
          source: docId,
          kind: "extracted",
          status: "accepted",
          confidence: 0.9,
          evidence: [{ type: "wikipedia-extract", url: summary.url }]
        });
      }
      factCount++;
    }
    if (onProgress && (i + 1) % 10 === 0) onProgress(i + 1, entities.length);
  }
  if (onProgress) onProgress(entities.length, entities.length);
  return { ingested, facts: factCount };
}
function buildRelationTables(facts) {
  const tables = {};
  for (const f of facts) {
    if (!tables[f.predicate]) tables[f.predicate] = {};
    tables[f.predicate][f.subject] = f.object;
  }
  return tables;
}
function saveRelationTables(tables, filePath) {
  const fs2 = __require("node:fs");
  fs2.writeFileSync(filePath, JSON.stringify(tables, null, 2) + "\n");
  const stats = fs2.statSync(filePath);
  return { file: filePath, sizeBytes: stats.size, relations: Object.keys(tables).length };
}
var ENTITIES_EN, ENTITIES_AR, FACT_PATTERNS_EN, FACT_PATTERNS_AR;
var init_wikipedia_ingestion = __esm({
  "synora-v5/knowledge/wikipedia-ingestion.mjs"() {
    ENTITIES_EN = [
      // Countries
      "France",
      "Germany",
      "Japan",
      "China",
      "Brazil",
      "India",
      "Egypt",
      "Morocco",
      "Saudi Arabia",
      "United Arab Emirates",
      "United Kingdom",
      "United States",
      "Russia",
      "Canada",
      "Australia",
      "Italy",
      "Spain",
      "Turkey",
      "Iran",
      "Iraq",
      "Mexico",
      "Argentina",
      "South Africa",
      "Nigeria",
      "Kenya",
      "Ethiopia",
      "Ghana",
      "Algeria",
      "Tunisia",
      "Libya",
      "Jordan",
      "Lebanon",
      "Syria",
      "Yemen",
      "Oman",
      "Qatar",
      "Bahrain",
      "Kuwait",
      "Sudan",
      "Somalia",
      "Pakistan",
      "Bangladesh",
      "Indonesia",
      "Malaysia",
      "Thailand",
      "Vietnam",
      "Philippines",
      "South Korea",
      "North Korea",
      "Taiwan",
      "Poland",
      "Ukraine",
      "Netherlands",
      "Belgium",
      "Switzerland",
      "Austria",
      "Sweden",
      "Norway",
      "Denmark",
      "Finland",
      "Greece",
      "Portugal",
      "Ireland",
      "Czech Republic",
      "Hungary",
      "Romania",
      "Bulgaria",
      "Serbia",
      "Croatia",
      "Slovakia",
      // Cities
      "Paris",
      "London",
      "Tokyo",
      "New York City",
      "Cairo",
      "Dubai",
      "Riyadh",
      "Istanbul",
      "Moscow",
      "Beijing",
      "Berlin",
      "Madrid",
      "Rome",
      "Amsterdam",
      "Brussels",
      "Vienna",
      "Stockholm",
      "Oslo",
      "Copenhagen",
      "Helsinki",
      "Athens",
      "Lisbon",
      "Dublin",
      "Prague",
      "Budapest",
      "Warsaw",
      "Kiev",
      "Toronto",
      "Sydney",
      "Singapore"
    ];
    ENTITIES_AR = [
      "\u0641\u0631\u0646\u0633\u0627",
      "\u0623\u0644\u0645\u0627\u0646\u064A\u0627",
      "\u0627\u0644\u064A\u0627\u0628\u0627\u0646",
      "\u0627\u0644\u0635\u064A\u0646",
      "\u0627\u0644\u0628\u0631\u0627\u0632\u064A\u0644",
      "\u0627\u0644\u0647\u0646\u062F",
      "\u0645\u0635\u0631",
      "\u0627\u0644\u0645\u063A\u0631\u0628",
      "\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629",
      "\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A",
      "\u0627\u0644\u0645\u0645\u0644\u0643\u0629 \u0627\u0644\u0645\u062A\u062D\u062F\u0629",
      "\u0627\u0644\u0648\u0644\u0627\u064A\u0627\u062A \u0627\u0644\u0645\u062A\u062D\u062F\u0629",
      "\u0631\u0648\u0633\u064A\u0627",
      "\u0643\u0646\u062F\u0627",
      "\u0623\u0633\u062A\u0631\u0627\u0644\u064A\u0627",
      "\u0625\u064A\u0637\u0627\u0644\u064A\u0627",
      "\u0625\u0633\u0628\u0627\u0646\u064A\u0627",
      "\u062A\u0631\u0643\u064A\u0627",
      "\u0625\u064A\u0631\u0627\u0646",
      "\u0627\u0644\u0639\u0631\u0627\u0642",
      "\u0627\u0644\u0645\u0643\u0633\u064A\u0643",
      "\u0627\u0644\u0623\u0631\u062C\u0646\u062A\u064A\u0646",
      "\u062C\u0646\u0648\u0628 \u0623\u0641\u0631\u064A\u0642\u064A\u0627",
      "\u0646\u064A\u062C\u064A\u0631\u064A\u0627",
      "\u0643\u064A\u0646\u064A\u0627",
      "\u0625\u062B\u064A\u0648\u0628\u064A\u0627",
      "\u063A\u0627\u0646\u0627",
      "\u0627\u0644\u062C\u0632\u0627\u0626\u0631",
      "\u062A\u0648\u0646\u0633",
      "\u0644\u064A\u0628\u064A\u0627",
      "\u0627\u0644\u0623\u0631\u062F\u0646",
      "\u0644\u0628\u0646\u0627\u0646",
      "\u0633\u0648\u0631\u064A\u0627",
      "\u0627\u0644\u064A\u0645\u0646",
      "\u0639\u0645\u0627\u0646",
      "\u0642\u0637\u0631",
      "\u0627\u0644\u0628\u062D\u0631\u064A\u0646",
      "\u0627\u0644\u0643\u0648\u064A\u062A",
      "\u0627\u0644\u0633\u0648\u062F\u0627\u0646",
      "\u0627\u0644\u0635\u0648\u0645\u0627\u0644",
      "\u0628\u0627\u0643\u0633\u062A\u0627\u0646",
      "\u0628\u0646\u063A\u0644\u0627\u062F\u064A\u0634",
      "\u0625\u0646\u062F\u0648\u0646\u064A\u0633\u064A\u0627",
      "\u0645\u0627\u0644\u064A\u0632\u064A\u0627",
      "\u062A\u0627\u064A\u0644\u0627\u0646\u062F",
      "\u0641\u064A\u062A\u0646\u0627\u0645",
      "\u0627\u0644\u0641\u0644\u0628\u064A\u0646",
      "\u0643\u0648\u0631\u064A\u0627 \u0627\u0644\u062C\u0646\u0648\u0628\u064A\u0629",
      "\u0643\u0648\u0631\u064A\u0627 \u0627\u0644\u0634\u0645\u0627\u0644\u064A\u0629",
      "\u062A\u0627\u064A\u0648\u0627\u0646",
      "\u0628\u0627\u0631\u064A\u0633",
      "\u0644\u0646\u062F\u0646",
      "\u0637\u0648\u0643\u064A\u0648",
      "\u0627\u0644\u0642\u0627\u0647\u0631\u0629",
      "\u062F\u0628\u064A",
      "\u0627\u0644\u0631\u064A\u0627\u0636",
      "\u0625\u0633\u0637\u0646\u0628\u0648\u0644",
      "\u0645\u0648\u0633\u0643\u0648",
      "\u0628\u0643\u064A\u0646",
      "\u0628\u0631\u0644\u064A\u0646"
    ];
    FACT_PATTERNS_EN = [
      // Capital: "Paris is the capital of France"
      { relation: "capital", regex: /([A-Z][\w\s]+?)\s+is\s+the\s+capital\s+of\s+([A-Z][\w\s]+)/g, swap: true },
      // Population: "France has a population of 67 million"
      { relation: "population", regex: /population\s+of\s+(?:about\s+|approximately\s+|around\s+)?([\d,.]+)\s*(?:million|billion|thousand)?/gi, extract: (m) => m[1] },
      // Founded: "founded in 1840" / "established in 1840"
      { relation: "founded", regex: /(?:founded|established|created|incorporated)\s+in\s+(\d{3,4})/gi, extract: (m) => m[1] },
      // Area: "with an area of 551695 square kilometres"
      { relation: "area", regex: /area\s+of\s+([\d,.]+)\s*(?:square\s+)?(?:kilomet|kilometer)/gi, extract: (m) => m[1] },
      // Currency: "The currency of France is the euro"
      { relation: "currency", regex: /currency\s+(?:of\s+\w+\s+is|is)\s+the\s+(\w+)/gi, extract: (m) => m[1] },
      // Official language: "The official language is French"
      { relation: "language", regex: /official\s+language\s+(?:is|of)\s+(\w+)/gi, extract: (m) => m[1] },
      // Continent: "located in Europe" / "situated in Asia"
      { relation: "continent", regex: /(?:located|situated)\s+in\s+(Europe|Asia|Africa|North America|South America|Oceania|Antarctica)/gi, extract: (m) => m[1] }
    ];
    FACT_PATTERNS_AR = [
      // العاصمة: "عاصمتها باريس"
      { relation: "\u0639\u0627\u0635\u0645\u0629", regex: /عاصمت?ها?\s+([\u0600-\u06FF]+)/g, extract: (m) => m[1] },
      // السكان: "يبلغ عدد سكانها 67 مليون نسمة"
      { relation: "\u0633\u0643\u0627\u0646", regex: /(?:عدد\s+)?سكان?ها?\s+([\d,.]+)\s*(?:مليون|ألف|بليون)?/g, extract: (m) => m[1] },
      // التأسيس: "تأسست عام 1840"
      { relation: "\u062A\u0623\u0633\u0633\u062A", regex: /تأسس(?:ت|)\s+عام\s+(\d{3,4})/g, extract: (m) => m[1] },
      // المساحة: "تبلغ مساحتها 551695 كم"
      { relation: "\u0645\u0633\u0627\u062D\u0629", regex: /مساحت?ها?\s+([\d,.]+)\s*(?:كم|كيلومتر)/g, extract: (m) => m[1] },
      // العملة: "عملتها اليورو"
      { relation: "\u0639\u0645\u0644\u0629", regex: /عملت?ها?\s+([\u0600-\u06FF]+)/g, extract: (m) => m[1] },
      // اللغة: "اللغة الرسمية هي العربية"
      { relation: "\u0644\u063A\u0629", regex: /اللغة?\s+الرسمية?\s+(?:هي|:)\s+([\u0600-\u06FF]+)/g, extract: (m) => m[1] }
    ];
  }
});

// synora-v5/version.mjs
var version_exports = {};
__export(version_exports, {
  ARCHIVE_ROOT: () => ARCHIVE_ROOT,
  DSL_RELEASE: () => DSL_RELEASE,
  RELEASE_ARCHIVE: () => RELEASE_ARCHIVE,
  RELEASE_STATUS: () => RELEASE_STATUS,
  VERSION: () => VERSION
});
var VERSION, RELEASE_ARCHIVE, ARCHIVE_ROOT, RELEASE_STATUS, DSL_RELEASE;
var init_version = __esm({
  "synora-v5/version.mjs"() {
    VERSION = "1.5.0";
    RELEASE_ARCHIVE = `Synora_WAR_v${VERSION.replace(/\./g, "_")}_FINAL.zip`;
    ARCHIVE_ROOT = `Synora_WAR_v${VERSION.replace(/\./g, "_")}`;
    RELEASE_STATUS = "FINAL";
    DSL_RELEASE = "synora-dsl/1.1.0";
  }
});

// worker/worker.mjs
var rateLimit = /* @__PURE__ */ new Map();
var RATE_LIMIT_PER_HOUR = 50;
function checkRateLimit(ip) {
  const now = Date.now();
  const entries = rateLimit.get(ip) || [];
  const recent = entries.filter((t) => t > now - 36e5);
  if (recent.length >= RATE_LIMIT_PER_HOUR) return false;
  recent.push(now);
  rateLimit.set(ip, recent);
  return true;
}
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};
var _engine = null;
async function getEngine() {
  if (_engine) return _engine;
  const { KnowledgeStore: KnowledgeStore2 } = await Promise.resolve().then(() => (init_store(), store_exports));
  const { AgentBrain: AgentBrain2 } = await Promise.resolve().then(() => (init_brain(), brain_exports));
  const { FailureMemory: FailureMemory2 } = await Promise.resolve().then(() => (init_failure_memory(), failure_memory_exports));
  const { SYNTHETIC_WIKIPEDIA: SYNTHETIC_WIKIPEDIA2 } = await Promise.resolve().then(() => (init_synthetic_wikipedia(), synthetic_wikipedia_exports));
  const { ingestWikipediaBatch: ingestWikipediaBatch2 } = await Promise.resolve().then(() => (init_wikipedia_ingestion(), wikipedia_ingestion_exports));
  const { VERSION: VERSION2 } = await Promise.resolve().then(() => (init_version(), version_exports));
  const store = new KnowledgeStore2();
  const mockFetch = async (url) => {
    const title = decodeURIComponent(url.split("/").pop().replace(/_/g, " "));
    const entry = SYNTHETIC_WIKIPEDIA2.find((e) => e.title === title);
    if (entry) return { ok: true, json: async () => ({ type: "standard", title: entry.title, extract: entry.extract }) };
    return { ok: false, status: 404 };
  };
  await ingestWikipediaBatch2(SYNTHETIC_WIKIPEDIA2.map((e) => e.title), "en", store, mockFetch);
  const brain = new AgentBrain2({ store, failureMemory: new FailureMemory2() });
  _engine = { store, brain, version: VERSION2 };
  return _engine;
}
var worker_default = {
  async fetch(request) {
    const url = new URL(request.url);
    const ip = request.headers.get("CF-Connecting-IP") || "unknown";
    if (request.method === "OPTIONS") return new Response(null, { headers: CORS });
    if (url.pathname === "/health") return new Response(JSON.stringify({ status: "ok", engine: "synora-symbolic" }), { headers: CORS });
    if (!checkRateLimit(ip)) return new Response(JSON.stringify({ error: "rate_limit" }), { status: 429, headers: CORS });
    if (request.method !== "POST") return new Response(JSON.stringify({ name: "Synora API", endpoints: ["/ask", "/agent", "/synthesize", "/health"] }), { headers: CORS });
    let body;
    try {
      body = await request.json();
    } catch {
      return new Response(JSON.stringify({ error: "invalid_json" }), { status: 400, headers: CORS });
    }
    try {
      const { brain, version } = await getEngine();
      if (url.pathname === "/ask") {
        const result = await brain.execute(body.question || "", { lang: body.lang });
        return new Response(JSON.stringify(result), { headers: CORS });
      }
      if (url.pathname === "/agent") {
        const result = await brain.execute(body.task || "", { testCases: body.testCases, training: body.training, development: body.development, lang: body.lang });
        return new Response(JSON.stringify(result), { headers: CORS });
      }
      if (url.pathname === "/synthesize") {
        const { synthesize: synthesize2 } = await Promise.resolve().then(() => (init_synthesize(), synthesize_exports));
        const r = synthesize2({ training: body.training, development: body.development || [], maxSize: body.maxSize || 8, maxExpressions: body.maxExpressions || 4e5, deterministicBudget: true, safetyTimeoutMs: 3e4 });
        return new Response(JSON.stringify({ found: r.found, reason: r.reason, explored: r.explored, alternativeBehaviours: r.alternativeBehaviours, ambiguityCheck: r.ambiguityCheck }), { headers: CORS });
      }
      return new Response(JSON.stringify({ error: "unknown_endpoint" }), { status: 404, headers: CORS });
    } catch (err) {
      return new Response(JSON.stringify({ error: "engine_error", message: err.message }), { status: 500, headers: CORS });
    }
  }
};
export {
  worker_default as default
};
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @license SPDX-License-Identifier: Apache-2.0
 */
/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synora Agent Planner — deterministic task planning.
 *
 * Takes a natural language task and breaks it into a deterministic sequence
 * of steps. Each step has: operation, input type, expected output type.
 * The same task always produces the same plan (deterministic, auditable).
 *
 * This is NOT a neural planner — it uses symbolic pattern matching on the
 * task description to identify the required operations.
 */
/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synora Agent Verifier — verifies that a step's output matches expectations.
 *
 * For programming tasks: executes the synthesized code in the sandbox and
 * checks the output against test cases.
 * For knowledge tasks: checks that the answer has a valid span + provenance.
 *
 * The verifier is the LAST line of defense against hallucination: if the
 * output doesn't pass verification, the agent reports failure honestly.
 */
/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synora Failure Memory — the system learns from failed synthesis attempts.
 *
 * When the synthesizer fails to find a program (budget exhausted, ambiguity,
 * or validation failure), the failure is recorded as a "signature" — a
 * compact representation of the task shape and failure mode. In future
 * synthesis calls, the synthesizer can check if a program pattern matches a
 * known failure signature and avoid wasting budget on it.
 *
 * This proves the system acquires REUSABLE CAPABILITIES (avoiding known-bad
 * patterns), not just stored information.
 *
 * Usage:
 *   import { FailureMemory } from './failure-memory.mjs';
 *   const fm = new FailureMemory();
 *   fm.record({ task: 'sum_list', reason: 'search-budget-exhausted', signature: {...} });
 *   fm.shouldAvoid(programAst, taskShape); // → boolean
 */
/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synora Agent Brain — the orchestrator for the Agent SDK.
 *
 * Flow:
 *   1. planTask(task) → deterministic steps
 *   2. For each step:
 *      a. synthesize → generate + execute code
 *      b. query → answer from knowledge store
 *      c. abstain → honest refusal
 *   3. verifyStep → check result
 *   4. Report with provenance
 *
 * The brain NEVER hallucinates:
 * - If synthesis fails → reports "could not solve"
 * - If verification fails → reports "solution failed verification"
 * - If knowledge is missing → apologizes + offers to search
 *
 * Usage:
 *   import { AgentBrain } from './brain.mjs';
 *   const brain = new AgentBrain({ store, synthesizer });
 *   const result = await brain.execute('sum of [1,2,3,4]', { testCases: [...] });
 */
/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synthetic knowledge base — mimics Wikipedia summaries for 70+ entities.
 * Used when internet is unavailable. Each entry has the same structure as
 * the Wikipedia REST API response: { type, title, extract }.
 *
 * The facts in this file are REAL world facts (capitals, populations, founding
 * years) — they are just stored locally instead of fetched live.
 */
/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synora Wikipedia Ingestion Pipeline
 *
 * Downloads Wikipedia article summaries via the free REST API, extracts typed
 * facts (entity, relation, value) using symbolic patterns, and stores them as
 * compact relation tables — NOT as individual triples. This implements the
 * "understand not store" principle: one table per relation type, not one
 * triple per fact.
 *
 * API: https://{lang}.wikipedia.org/api/rest_v1/page/summary/{title}
 * - Free, no API key, CORS-enabled
 * - Rate limit: 200 req/s
 * - Returns: title, extract (plain text summary)
 *
 * Usage:
 *   import { ingestWikipediaBatch } from './wikipedia-ingestion.mjs';
 *   const store = new KnowledgeStore();
 *   const count = await ingestWikipediaBatch(ENTITIES_EN, 'en', store);
 *   console.log(`Ingested ${count} facts`);
 */
