# Synora outbound connection policy

## Default runtime

- Outbound network connections: **none**.
- Telemetry, analytics beacons, remote model APIs, and automatic downloads: disabled/not implemented.
- The HTTP API binds to `127.0.0.1` by default. The service does not initiate outbound requests merely by starting.

## Explicit opt-in web learning

The only network-capable extension in this package is `WebLearningPipeline`. It is disabled unless constructed with `enabled: true`, and it refuses to run without both an injected fetcher and an injected robots checker. It accepts only HTTP(S) URLs, requires two distinct hostnames, checks robots policy before fetching, enforces a byte cap, requires a captured allowlisted content licence, and marks fetched content tainted/quarantined. Each robots check and fetch decision is recorded in the returned `connectionLog`.

The actual transport is supplied by the embedding application. Synora does not provide a hidden fetch fallback, DNS resolver, or remote endpoint.

## Separate teacher notebook

`teacher/generate.py` runs only when manually invoked in a separate notebook or workstation. It uses a locally cached exact model by default; downloading weights requires the explicit `--allow-download` flag. It is not imported by runtime code.

## Audit

No live external network request was made during the round-2 tests. All web-learning tests use mocked HTTP/fetcher and robots-checker functions.
