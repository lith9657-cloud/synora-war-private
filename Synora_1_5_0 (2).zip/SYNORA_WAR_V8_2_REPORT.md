# Synora WAR V8.2.0-synthesis — report

Base: V8.1 RENDER_PREP package (original ZIP untouched) -> V8.1.1 intent guard -> V8.2.0 program synthesis.
All numbers below were produced by `npm run bench`, `npm run bench:synth` and `npm test` on Node v22 in a separate copy.

## What is new
1. `synora-v5/synthesis/dsl.mjs` - typed, non-neural program DSL (45 primitives), structural validator for untrusted ASTs,
   step-bounded interpreter, JavaScript emitter that shares primitive text with the interpreter (parity-tested).
2. `synora-v5/synthesis/synthesize.mjs` - bounded bottom-up enumeration with observational-equivalence pruning.
   Search uses training examples; the smallest consistent program must pass every held-out development example.
   **Ambiguity gate:** the search continues 2 size levels past the first fit; if a differently-behaving program also fits,
   nothing is returned - the caller receives inputs where candidates disagree (`disambiguatingQueries`). Out-of-range
   options are rejected with RangeError (no silent clamping).
3. `DigitalObjectLearner.learnProgram` (skill kind `program`), `/v1/skills/learn-program`, and chat support for
   `examples` (language-independent: the examples define the task, the request text is not interpreted).
4. Tests: `tests/stage6` (16 tests). Bench track 4: `bench/synth.mjs`.

## Measured (programming by example, 12 operations V8.1 could not do; protocol: realistic user, <=3 rounds, <=3 answers per round)
| Result | Count |
|---|---|
| solved (hidden tests pass) | 9 (min, average, count-even, reverse-string, palindrome, unique, flatten, second-largest, word-count) |
| wrong | 0 |
| not found | 3 (is-prime, fibonacci, gcd) - need iteration/recursion primitives the DSL does not have |
| solved without any question | 1 (word-count); 27 questions asked in total |
| time | 83 s total; average 16 s and second-largest 15 s are too slow |
Earlier tracks: see `bench/` results (known-op prompts, held-out paraphrases, false-success traps, affine skill acquisition).

## Honest limits
- Correctness is established **on the supplied examples**; behaviour elsewhere is not proven. Ambiguity detection looks only
  2 levels past the first fit and uses random probe inputs - it can miss differences (`ambiguityCheck: partial`).
- DSL cannot express loops/recursion: gcd, fibonacci, is-prime unsolved. Search is slow for size >= 5 with lambdas.
- Still no real isolation (`vm` is not a security boundary), no durable storage (JSON files; `/tmp` on Render),
  no web learning, no agent tools, no local packaging, no teacher pipeline. Benchmarks are small and self-authored.

## Provenance note (read this)
While this version was being finished, the working copy contained modules, tests and bench results that were not written
in the same session (`tests/stage6/synthesis.test.mjs`, `bench/synth.mjs`, learner/API/chat integration, an older
`synthesize.mjs`). `synthesize.mjs` was upgraded here to satisfy those tests. Two test example sets were made MORE
discriminating (count-even: added a duplicate-evens example; palindrome: added a whitespace example) because the gate found
genuine ambiguity in them (rival programs `filter(unique(a0))` and `eq(a0, join(words(reverse(a0))))`). No assertion was
weakened. The previous `bench/results-synth-v8.2.json` came from code that is not in this package and was replaced.
