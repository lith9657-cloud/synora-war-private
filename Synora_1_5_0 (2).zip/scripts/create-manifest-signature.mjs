/**
 * Creates a detached Ed25519 signature over the package manifest.
 *
 * A user-supplied private key may be provided through SYNORA_MANIFEST_PRIVATE_KEY_FILE
 * (a PEM file OUTSIDE the package) or through the PEM-valued SYNORA_MANIFEST_PRIVATE_KEY
 * environment variable. Neither is ever copied into the package, logged or written to
 * any artefact: only the public key and its fingerprint are stored.
 *
 *   SYNORA_MANIFEST_PRIVATE_KEY_FILE=/secure/path/private.pem npm run manifest:sign
 *   SYNORA_MANIFEST_PRIVATE_KEY='-----BEGIN PRIVATE KEY-----...' npm run manifest:sign
 *
 * Release packaging MUST use a user-supplied key. Pass --require-user-key (or set
 * SYNORA_MANIFEST_REQUIRE_USER_KEY=1) to make the script refuse an ephemeral key.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const manifestPath = path.join(root, 'audit/package-manifest.json');
if (!fs.existsSync(manifestPath)) throw new Error('Run npm run manifest before signing');

const requireUserKey = process.argv.includes('--require-user-key')
  || process.env.SYNORA_MANIFEST_REQUIRE_USER_KEY === '1';

const suppliedFile = process.env.SYNORA_MANIFEST_PRIVATE_KEY_FILE;
const suppliedPem = process.env.SYNORA_MANIFEST_PRIVATE_KEY;
if (!suppliedFile && !suppliedPem && requireUserKey) {
  throw new Error(
    'refusing to sign with an ephemeral key: set SYNORA_MANIFEST_PRIVATE_KEY_FILE to a private key '
    + 'file OUTSIDE the package, or SYNORA_MANIFEST_PRIVATE_KEY to a PEM private key.'
  );
}
if (suppliedFile && path.resolve(suppliedFile).startsWith(root + path.sep)) {
  throw new Error('private signing key must be outside the package root');
}
if (suppliedFile && !fs.existsSync(suppliedFile)) {
  throw new Error(`private signing key file not found: ${suppliedFile}`);
}

const privateKey = suppliedFile
  ? crypto.createPrivateKey(fs.readFileSync(suppliedFile))
  : suppliedPem
    ? crypto.createPrivateKey(suppliedPem)
    : crypto.generateKeyPairSync('ed25519').privateKey;

if (privateKey.asymmetricKeyType !== 'ed25519') {
  throw new Error(`manifest signing key must be Ed25519 (got ${privateKey.asymmetricKeyType})`);
}

const publicKey = crypto.createPublicKey(privateKey);
const data = fs.readFileSync(manifestPath);
const signature = crypto.sign(null, data, privateKey);
const publicPem = publicKey.export({ type: 'spki', format: 'pem' });
const fingerprint = crypto.createHash('sha256').update(publicKey.export({ type: 'spki', format: 'der' })).digest('hex');
const manifestSha256 = crypto.createHash('sha256').update(data).digest('hex');
const keyOrigin = suppliedFile || suppliedPem ? 'user-supplied' : 'ephemeral';
const signedAt = new Date().toISOString();

fs.writeFileSync(path.join(root, 'audit/manifest-public.pem'), publicPem);
fs.writeFileSync(path.join(root, 'audit/package-manifest.sig'), signature.toString('base64') + '\n');
fs.writeFileSync(path.join(root, 'audit/manifest-key-fingerprint.txt'), fingerprint + '\n');
fs.writeFileSync(path.join(root, 'audit/manifest-signature.json'), JSON.stringify({
  format: 'synora-manifest-signature/2',
  algorithm: 'Ed25519',
  method: 'detached signature over audit/package-manifest.json (SHA-256 manifest digest recorded here)',
  keyOrigin,
  privateKeyLocation: 'outside the package (never copied, logged or archived)',
  privateKeyInPackage: false,
  publicKeyFile: 'audit/manifest-public.pem',
  publicKeyFingerprintSha256: fingerprint,
  manifestFile: 'audit/package-manifest.json',
  manifestSha256,
  signedAt
}, null, 2) + '\n');

console.log(`signed manifest; ${keyOrigin} Ed25519 public-key fingerprint ${fingerprint}; `
  + `manifest sha256 ${manifestSha256}; signed at ${signedAt}; private key not written`);
