/**
 * Verifies the detached Ed25519 signature over the package manifest and checks the
 * recorded public metadata (fingerprint, manifest digest, signing time).
 *
 * A private key is never required and never read here: only the public key, the
 * signature and the manifest are used.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const manifestPath = path.join(root, 'audit/package-manifest.json');
const publicPemPath = path.join(root, 'audit/manifest-public.pem');
const sigPath = path.join(root, 'audit/package-manifest.sig');
const fingerprintPath = path.join(root, 'audit/manifest-key-fingerprint.txt');
const metaPath = path.join(root, 'audit/manifest-signature.json');

for (const file of [manifestPath, publicPemPath, sigPath, fingerprintPath]) {
  if (!fs.existsSync(file)) {
    console.error(`manifest signature verification: FAIL (missing ${path.relative(root, file)})`);
    process.exit(1);
  }
}

const manifest = fs.readFileSync(manifestPath);
const publicPem = fs.readFileSync(publicPemPath);
const signature = Buffer.from(fs.readFileSync(sigPath, 'utf8').trim(), 'base64');
const key = crypto.createPublicKey(publicPem);
if (key.asymmetricKeyType !== 'ed25519') {
  console.error('manifest signature verification: FAIL (public key is not Ed25519)');
  process.exit(1);
}
const fingerprint = crypto.createHash('sha256').update(key.export({ type: 'spki', format: 'der' })).digest('hex');
const expected = fs.readFileSync(fingerprintPath, 'utf8').trim();
const manifestSha256 = crypto.createHash('sha256').update(manifest).digest('hex');

const failures = [];
if (fingerprint !== expected) failures.push('public-key fingerprint does not match audit/manifest-key-fingerprint.txt');
if (!crypto.verify(null, manifest, key, signature)) failures.push('signature does not verify against the manifest');

let meta = null;
if (fs.existsSync(metaPath)) {
  try { meta = JSON.parse(fs.readFileSync(metaPath, 'utf8')); } catch { failures.push('audit/manifest-signature.json is not valid JSON'); }
} else {
  failures.push('audit/manifest-signature.json is missing');
}
if (meta) {
  if (meta.publicKeyFingerprintSha256 !== fingerprint) failures.push('recorded fingerprint does not match the public key');
  if (meta.manifestSha256 !== manifestSha256) failures.push('recorded manifest digest does not match the manifest file');
  if (meta.algorithm !== 'Ed25519') failures.push('recorded algorithm is not Ed25519');
  if (!meta.signedAt) failures.push('recorded signing time is missing');
}

if (failures.length) {
  console.error('manifest signature verification: FAIL');
  for (const failure of failures) console.error(` - ${failure}`);
  process.exit(1);
}
console.log(`manifest signature verification: PASS (${fingerprint}); manifest sha256 ${manifestSha256}; `
  + `signed at ${meta.signedAt}; key origin ${meta.keyOrigin}; private key outside the package`);
