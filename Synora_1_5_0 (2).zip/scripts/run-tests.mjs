/** Sequential release test runner. Every suite runs in a fresh Node process. */
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const node = process.execPath;
const commands = [
  ['baseline self-test', ['tests/self-test.mjs']],
  ['v5 integration', ['tests/v5.test.mjs']],
  ['PST', ['tests/pst.test.mjs']],
  ['Phase 3', ['tests/phase3.test.mjs']],
  ['Phase 4', ['tests/phase4.test.mjs']],
  ['adaptive engine', ['tests/adaptive-engine.test.mjs']],
  ['safe transfer ledger', ['tests/safe-transfer-ledger.test.mjs']],
  ['third domain', ['tests/third-domain.test.mjs']],
  ['release audit', ['tests/audit.test.mjs']],
  ['digital object core', ['--test', '--test-concurrency=1', 'tests/digital-object-core.test.mjs']],
  ['stage 2 experiment', ['--test', '--test-concurrency=1', 'tests/stage2-experiment.test.mjs']]
];
for (const stage of ['stage4', 'stage5', 'stage6', 'stage7']) {
  const dir = path.join(root, 'tests', stage);
  for (const file of fs.readdirSync(dir).filter(name => name.endsWith('.test.mjs')).sort()) {
    commands.push([`${stage}/${file}`, ['--test', '--test-concurrency=1', path.join('tests', stage, file)]]);
  }
}

function runOne(args, timeoutMs = 180_000) {
  return new Promise(resolve => {
    const child = spawn(node, args, { cwd: root, stdio: 'inherit' });
    let settled = false;
    const finish = result => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(result);
    };
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      finish({ status: 124, error: new Error(`suite timed out after ${timeoutMs}ms`) });
    }, timeoutMs);
    child.once('error', error => finish({ status: 1, error }));
    child.once('close', (status, signal) => finish({ status: status ?? 1, signal }));
  });
}

for (const [label, args] of commands) {
  process.stdout.write(`\n=== ${label} ===\n`);
  const run = await runOne(args);
  if (run.status !== 0) {
    process.stderr.write(`\nFAILED: ${label}; status=${run.status}; ${run.error?.message ?? run.signal ?? ''}\n`);
    process.exit(run.status);
  }
  process.stdout.write(`PASS: ${label}\n`);
}
process.stdout.write(`\nALL ${commands.length} test commands passed.\n`);
