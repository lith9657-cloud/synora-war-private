/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { VERSION, RELEASE_STATUS, ARCHIVE_ROOT } from '../synora-v5/version.mjs';

/** The release metadata that is embedded in the package manifest. */
export function buildManifest() {
  return Object.freeze({
    version: VERSION,
    status: RELEASE_STATUS,
    archiveRoot: ARCHIVE_ROOT
  });
}
