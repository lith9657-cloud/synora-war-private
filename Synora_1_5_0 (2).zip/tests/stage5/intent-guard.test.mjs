import test from 'node:test';
import assert from 'node:assert/strict';
import { parseRequest } from '../../synora-v5/dialogue/index.mjs';
import { handleDialogue } from '../../synora-v5/dialogue/agent.mjs';
import { generateSolution } from '../../synora-v5/solution-engine/index.mjs';

// Regression for the V8.1 mis-routing defect: "second largest" was routed to the max template and
// reported as tests-passed with wrong code.
test('qualifiers the parser does not model make it abstain instead of routing to the nearest template', async () => {
  for (const text of ['write a function that returns the second largest number in an array', 'write a function that sorts an array in descending order', 'write a function that sums the squares of the numbers in an array', 'write a function that returns the maximum of two numbers', 'اكتب دالة ترتب المصفوفة تنازليا']) {
    const r = parseRequest(text);
    assert.equal(r.intent, 'code.unsupported', text);
    assert.equal(r.action, 'clarify', text);
    assert.ok(r.evidence.guard.unmodelledTerms.length > 0, text);
    const answer = await handleDialogue(text, {});
    assert.equal(answer.solution?.generated, undefined, `no code may be generated for: ${text}`);
  }
  assert.ok(parseRequest('write a function that returns the second largest number in an array').evidence.guard.unmodelledTerms.includes('second'));
});

test('supported operations still resolve, including inflections and Arabic verbs', () => {
  assert.equal(parseRequest('write a function that sums an array of numbers').intent, 'code.sum');
  assert.equal(parseRequest('write a function that returns the maximum of an array').intent, 'code.max');
  assert.equal(parseRequest('write a function that reverses an array').intent, 'code.reverse');
  assert.equal(parseRequest('write a function that sorts an array ascending').intent, 'code.sort');
  assert.equal(parseRequest('write a function factorial(n)').intent, 'code.factorial');
  assert.equal(parseRequest('اكتب دالة تجمع عناصر مصفوفة').intent, 'code.sum');
  assert.equal(parseRequest('اكتب دالة تعيد أكبر قيمة في مصفوفة').intent, 'code.max');
});

test('Latin greetings match whole words only', () => {
  assert.notEqual(parseRequest('explain this please').intent, 'greeting');
  assert.notEqual(parseRequest('what is a machine which they use').intent, 'greeting');
  assert.equal(parseRequest('hello there').intent, 'greeting');
});

test('template verification states that self-tests are not independent verification', () => {
  const r = generateSolution('write a function that returns the maximum of an array');
  assert.match(r.verification.independence, /template-self-tests-only/);
});
