import test from 'node:test';
import assert from 'node:assert/strict';
import { synthesize } from '../../synora-v5/synthesis/synthesize.mjs';

const ex = rows => rows.map(([input, output]) => ({ input, output }));
const minIndex = xs => xs.indexOf(Math.min(...xs));
const maxIndex = xs => xs.indexOf(Math.max(...xs));

function makeTask(seed, mode) {
  const rows = [];
  for (let i = 0; i < 5; i++) {
    const a = [seed + i * 3, seed - 2 - i, seed + (i % 2 ? 5 : -5), seed + i];
    rows.push([[a], mode === 'min' ? minIndex(a) : maxIndex(a)]);
  }
  return rows;
}

test('Round 3: exact reported index-of-min failure is refused', () => {
  const training = ex([[[[3, 1, 2]], 1], [[[5]], 0], [[[9, 8, 7]], 2]]);
  const development = ex([[[[2, 2, 1]], 2], [[[1, 5, 1]], 0]]);
  const hidden = [
    [[[0, 0, 1]], 0], [[[4, 3, 2, 1]], 3], [[[-1, -5, -2]], 1], [[[8, 8, 3, 3]], 2]
  ];
  const result = synthesize({ training, development, budgetMs: 4000, maxSize: 9 });
  assert.equal(result.found, false, `wrong program returned: ${result.source || result.reason}`);
  assert.ok(result.disambiguatingQueries?.length || ['ambiguous-examples', 'search-budget-exhausted', 'insufficient-evidence', 'development-validation-failed'].includes(result.reason));
  assert.equal(result.source, undefined);
  for (const [input, expected] of hidden) assert.notEqual(expected, undefined, JSON.stringify(input));
});

test('Round 3: thin positional tasks never return a spurious program', () => {
  const tasks = [];
  for (let i = 0; i < 16; i++) tasks.push(makeTask(i - 8, 'min'));
  for (let i = 0; i < 15; i++) tasks.push(makeTask(i - 4, 'max'));
  assert.equal(tasks.length, 31);
  for (const rows of tasks) {
    const result = synthesize({ training: ex(rows.slice(0, 3)), development: ex(rows.slice(3)), budgetMs: 100, maxExpressions: 1000, maxSize: 9 });
    assert.equal(result.found, false, `thin positional task was accepted: ${result.source || result.reason}`);
    assert.ok(['ambiguous-examples', 'search-budget-exhausted', 'insufficient-evidence', 'development-validation-failed', 'no-program-fits-training'].includes(result.reason), result.reason);
  }
});

test('Round 3: a budget-truncated ambiguity check cannot return a solution', () => {
  const rows = makeTask(11, 'min');
  const result = synthesize({ training: ex(rows.slice(0, 3)), development: ex(rows.slice(3)), budgetMs: 100, maxExpressions: 1000, maxSize: 9 });
  assert.equal(result.found, false);
  assert.notEqual(result.ambiguityCheck, 'complete');
});
