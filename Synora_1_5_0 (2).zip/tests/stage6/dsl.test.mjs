import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { validateAst, evalAst, toSource, typeOfValue, unifyTypes, deepEqual, SIGS, SRC, IMPL } from '../../synora-v5/synthesis/dsl.mjs';

const call = (f, ...a) => ({ k: 'call', f, a });
const inp = i => ({ k: 'in', i }), num = v => ({ k: 'const', v }), lam = body => ({ k: 'lam', body }), X = { k: 'x' };
const runSource = (ast, arity, args) => {
  const code = toSource(ast, arity).replace(/^export\s+function\s+solution/, 'function solution') + '\nsolution';
  const fn = new vm.Script(code).runInContext(vm.createContext(Object.create(null), { codeGeneration: { strings: false, wasm: false } }), { timeout: 200 });
  return vm.runInNewContext('fn(...args)', { fn, args: structuredClone(args) }, { timeout: 200 });
};
const programs = [
  ['average', call('div', call('sum', inp(0)), call('len', inp(0))), 1, [[2, 4, 6]]],
  ['count-even', call('len', call('filter', inp(0), lam(call('eq', call('mod', X, num(2)), num(0))))), 1, [[1, 2, 3, 4, 6]]],
  ['second-largest', call('nth', call('reverse', call('sort', call('unique', inp(0)))), num(1)), 1, [[9, 9, 4, 1]]],
  ['palindrome', call('eq', inp(0), call('reverse', inp(0))), 1, ['level']],
  ['word-count', call('len', call('words', inp(0))), 1, ['hello  big world']],
  ['flatten', call('flatten', inp(0)), 1, [[[1], [2, 3], []]]],
  ['prime-like', call('all', call('rangeFrom', num(2), inp(0)), lam(call('not', call('eq', call('mod', inp(0), X), num(0))))), 1, [13]]
];

test('interpreter and emitted JavaScript agree on every sample program (no semantic drift)', () => {
  for (const [name, ast, arity, args] of programs) {
    validateAst(ast, arity);
    assert.deepEqual(runSource(ast, arity, args), evalAst(ast, args), name);
  }
});

test('known answers', () => {
  assert.equal(evalAst(programs[0][1], [[2, 4, 6]]), 4);
  assert.equal(evalAst(programs[1][1], [[1, 2, 3, 4, 6]]), 3);
  assert.equal(evalAst(programs[2][1], [[9, 9, 4, 1]]), 4);
  assert.equal(evalAst(programs[3][1], ['level']), true);
  assert.equal(evalAst(programs[4][1], ['hello  big world']), 3);
});

test('validator rejects unknown primitives, wrong arity, stray lambdas, bad constants and oversized programs', () => {
  assert.throws(() => validateAst(call('eval', num(1)), 1), /unknown primitive/);
  assert.throws(() => validateAst(call('constructor', inp(0)), 1), /unknown primitive/);
  assert.throws(() => validateAst(call('__proto__', inp(0)), 1), /unknown primitive/);
  assert.throws(() => validateAst(call('sum', inp(0), inp(0)), 1), /wrong arity/);
  assert.throws(() => validateAst(call('sum', lam(X)), 1), /lambda/);
  assert.throws(() => validateAst(call('map', inp(0), inp(0)), 1), /lambda required/);
  assert.throws(() => validateAst(call('sum', X), 1), /lambda variable/);
  assert.throws(() => validateAst(call('sum', inp(3)), 1), /input reference/);
  assert.throws(() => validateAst(call('add', num(1), { k: 'const', v: Infinity }), 1), /constant/);
  assert.throws(() => validateAst(call('add', num(1), { k: 'const', v: { toString: 1 } }), 1), /constant/);
  let deep = inp(0); for (let i = 0; i < 40; i++) deep = call('reverse', deep);
  assert.throws(() => validateAst(deep, 1), /too large/);
  assert.throws(() => toSource(null, 1), /invalid program node/);
});

test('runtime faults surface as RangeError, never as silent wrong answers', () => {
  assert.throws(() => evalAst(call('max', inp(0)), [[]]), RangeError);
  assert.throws(() => evalAst(call('div', num(1), num(0)), []), RangeError);
  assert.throws(() => evalAst(call('range', inp(0)), [10_000]), RangeError);
  assert.throws(() => evalAst(call('mul', num(1e7), num(1e7)), []), RangeError);
  assert.throws(() => evalAst(call('len', call('map', call('range', num(200)), lam(call('len', call('range', num(200)))))), [], { maxSteps: 50 }), /step-budget/);
});

test('every primitive has a signature, source text, and implementation', () => {
  for (const n of Object.keys(SIGS)) { assert.ok(SRC[n], n); assert.equal(typeof IMPL[n], 'function', n); }
  assert.deepEqual(Object.keys(SRC).sort(), Object.keys(SIGS).sort());
});

test('type inference and equality helpers', () => {
  assert.equal(typeOfValue(3), 'num'); assert.equal(typeOfValue('a'), 'str'); assert.equal(typeOfValue([[1], [2]]), 'L:L:num');
  assert.equal(typeOfValue([1, 'a']), null); assert.equal(typeOfValue({}), null); assert.equal(typeOfValue(NaN), null);
  assert.equal(unifyTypes(['L:?', 'L:str']), 'L:str'); assert.equal(unifyTypes(['num', 'str']), null); assert.equal(unifyTypes(['L:?']), 'L:num');
  assert.ok(deepEqual([1, [2]], [1, [2]])); assert.ok(!deepEqual([1], [2])); assert.ok(deepEqual(0.1 + 0.2, 0.3));
});
