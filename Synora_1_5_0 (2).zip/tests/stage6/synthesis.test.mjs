import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { validateAst, evalAst, toSource, conforms, deepEqual } from '../../synora-v5/synthesis/dsl.mjs';
import { synthesize } from '../../synora-v5/synthesis/synthesize.mjs';
import { DigitalObjectLearner, learningInternals } from '../../synora-v5/digital-object-learning/index.mjs';
import { DigitalObjectCore } from '../../synora-v5/digital-object-core/index.mjs';
import { syncSkillToCore } from '../../synora-v5/digital-object-learning/bridge.mjs';
import { handleDialogue } from '../../synora-v5/dialogue/agent.mjs';

const ex = pairs => pairs.map(([input, output]) => ({ input, output }));
const runSource = (source, args) => { const fn = vm.runInNewContext(source.replace(/^export\s+function\s+solution/, 'function solution') + '\nsolution', Object.create(null), { timeout: 200 }); return fn(...structuredClone(args)); };
const hiddenOk = (source, hidden) => hidden.every(([args, expected]) => deepEqual(runSource(source, args), expected));

// Example sets are deliberately natural and DISCRIMINATING; hidden tests are never shown to the synthesizer.
const TASKS = {
  min: { tr: [[[[4, 2, 8]], 2], [[[9, 3, 5, 7]], 3], [[[-1, 6]], -1], [[[8, 6, 5, 1, 7]], 1]], dv: [[[[10, 2]], 2], [[[5]], 5]], hidden: [[[[3, 9, 1, 7]], 1], [[[0, -4, 4]], -4], [[[6]], 6]] },
  average: { tr: [[[[2, 4, 6]], 4], [[[1, 2]], 1.5], [[[10, 20, 30, 40]], 25], [[[3, 3, 9, 5]], 5]], dv: [[[[7]], 7], [[[1, 1, 4]], 2]], hidden: [[[[5, 15]], 10], [[[1, 2, 3, 4]], 2.5]] },
  'count-even': { tr: [[[[1, 2, 3, 4]], 2], [[[2, 4, 6]], 3], [[[1, 3]], 0], [[[5, 6, 7, 8, 9, 10]], 3], [[[2, 2, 4]], 3]], dv: [[[[]], 0], [[[8, 9, 10, 11, 12]], 3]], hidden: [[[[0, 1]], 1], [[[11, 13, 15]], 0], [[[2, 2, 2, 2]], 4]] },
  'word-count': { tr: [[['hello big world'], 3], [['one'], 1], [['a b c d'], 4]], dv: [[[''], 0], [['  two  words '], 2]], hidden: [[['the quick brown fox'], 4], [['   '], 0]] },
  'reverse-string': { tr: [[['abc'], 'cba'], [[''], ''], [['a b'], 'b a'], [['Ab'], 'bA']], dv: [[['xyz'], 'zyx'], [['q'], 'q']], hidden: [[['stressed'], 'desserts']] },
  unique: { tr: [[[[1, 2, 2, 3, 1]], [1, 2, 3]], [[[5, 5]], [5]], [[[3, 1, 2]], [3, 1, 2]], [[[4, 5, 6, 7, 4]], [4, 5, 6, 7]]], dv: [[[[]], []], [[[2, 1, 2, 1]], [2, 1]]], hidden: [[[[7, 7, 8, 7, 9]], [7, 8, 9]]] },
  flatten: { tr: [[[[[1], [2, 3], []]], [1, 2, 3]], [[[[4, 5]]], [4, 5]], [[[[], []]], []], [[[[1, 2], [3, 4], [5, 6, 7]]], [1, 2, 3, 4, 5, 6, 7]], [[[[1, 2], [2, 3]]], [1, 2, 2, 3]]], dv: [[[[[9], [8]]], [9, 8]], [[[[1, 2], [3]]], [1, 2, 3]]], hidden: [[[[[0], [], [5, 5]]], [0, 5, 5]]] }
};

test('DSL validator rejects forged or malformed programs', () => {
  const bad = [
    { k: 'call', f: 'eval', a: [] }, { k: 'call', f: 'constructor', a: [] }, { k: 'call', f: '__proto__', a: [] },
    { k: 'call', f: 'sum', a: [] }, { k: 'call', f: 'sum', a: [{ k: 'in', i: 5 }] }, { k: 'x' },
    { k: 'const', v: { toString: 1 } }, { k: 'const', v: 1e9 }, { k: 'in', i: -1 }, null, [], { k: 'lam', body: { k: 'x' } },
    { k: 'call', f: 'map', a: [{ k: 'in', i: 0 }, { k: 'in', i: 0 }] },
    { k: 'call', f: 'sum', a: [{ k: 'lam', body: { k: 'x' } }] }
  ];
  for (const ast of bad) assert.throws(() => validateAst(ast, 1), TypeError, JSON.stringify(ast));
  let deep = { k: 'in', i: 0 }; for (let i = 0; i < 40; i++) deep = { k: 'call', f: 'sort', a: [deep] };
  assert.throws(() => validateAst(deep, 1), /too large or deep/);
});

test('interpreter is step-bounded and the emitted JavaScript is equivalent to the interpreter', () => {
  const asts = [
    { k: 'call', f: 'len', a: [{ k: 'call', f: 'filter', a: [{ k: 'in', i: 0 }, { k: 'lam', body: { k: 'call', f: 'eq', a: [{ k: 'call', f: 'mod', a: [{ k: 'x' }, { k: 'const', v: 2 }] }, { k: 'const', v: 0 }] } }] }] },
    { k: 'call', f: 'div', a: [{ k: 'call', f: 'sum', a: [{ k: 'in', i: 0 }] }, { k: 'call', f: 'len', a: [{ k: 'in', i: 0 }] }] },
    { k: 'call', f: 'reverse', a: [{ k: 'call', f: 'sort', a: [{ k: 'call', f: 'unique', a: [{ k: 'in', i: 0 }] }] }] }
  ];
  const inputs = [[[1, 2, 3, 4]], [[5]], [[]], [[2, 2, 9, -3, 0]], [[7, 7, 7]]];
  for (const ast of asts) {
    validateAst(ast, 1); const src = toSource(ast, 1);
    for (const input of inputs) {
      let a, b, ea, eb;
      try { a = evalAst(ast, input); } catch (e) { ea = e.message; }
      try { b = runSource(src, input); } catch (e) { eb = e.message; }
      assert.equal(ea, eb, `error parity for ${JSON.stringify(input)}`);
      if (!ea) assert.ok(deepEqual(a, b), `value parity for ${JSON.stringify(input)}`);
    }
  }
  const heavy = { k: 'call', f: 'sum', a: [{ k: 'call', f: 'map', a: [{ k: 'call', f: 'range', a: [{ k: 'const', v: 200 }] }, { k: 'lam', body: { k: 'call', f: 'add', a: [{ k: 'x' }, { k: 'x' }] } }] }] };
  assert.throws(() => evalAst(heavy, [], { maxSteps: 50 }), /step-budget-exceeded/);
  assert.equal(conforms([[1], [2]], 'L:L:num'), true); assert.equal(conforms('x', 'num'), false);
});

test('synthesizes new operations from examples and the programs pass hidden tests', () => {
  const solved = [];
  for (const [name, t] of Object.entries(TASKS)) {
    const r = synthesize({ training: ex(t.tr), development: ex(t.dv), maxSize: 6, budgetMs: 20_000, maxExpressions: 2_000_000 });
    assert.equal(r.found, true, `${name}: ${r.reason}`);
    assert.ok(hiddenOk(r.source, t.hidden), `${name}: hidden tests`);
    assert.equal(r.alternativeBehaviours, 0, name);
    solved.push(name);
  }
  assert.equal(solved.length, Object.keys(TASKS).length);
});

test('ambiguity gate: under-determined examples are refused with a disambiguating question, then resolved', () => {
  const ambiguous = synthesize({ training: ex([[[[4, 2, 8]], 2], [[[9, 3, 5, 7]], 3], [[[-1, 6]], -1]]), development: ex([[[[10, 2]], 2], [[[5]], 5]]) });
  assert.equal(ambiguous.found, false);
  assert.equal(ambiguous.reason, 'ambiguous-examples');
  assert.ok(ambiguous.disambiguatingQueries.length >= 1 && ambiguous.disambiguatingQueries[0].candidateOutputs.length >= 2);
  const palin = synthesize({ training: ex([[['level'], true], [['abc'], false], [['noon'], true]]), development: ex([[['ab'], false], [[''], true]]) });
  assert.equal(palin.reason, 'ambiguous-examples', 'case-sensitive and case-insensitive palindromes both fit');
  const resolved = synthesize({ training: ex([[['level'], true], [['abc'], false], [['noon'], true], [['Aa'], false], [['ab ba'], true]]), development: ex([[['ab'], false], [[''], true], [['A'], true], [[' '], true], [['é'], true], [['a '], false]]) });
  assert.equal(resolved.found, true);
  assert.ok(hiddenOk(resolved.source, [[['racecar'], true], [['Abba'], false], [['xy'], false]]));
});

test('boundary gate rejects index-of-min fits that admit modular unique/init alternatives', () => {
  const training = ex([[[[-3, -3, -3]], 0], [[[-2, -3, -3]], 1], [[[-2, 1, -3]], 2]]);
  const development = ex([[[[5, 4, 3]], 2], [[[9, 8, 7]], 2]]);
  const result = synthesize({ training, development, budgetMs: 4000, maxSize: 9 });
  assert.equal(result.found, false);
  assert.equal(result.reason, 'ambiguous-examples');
  assert.ok(result.disambiguatingQueries.length > 0);
  assert.equal(result.boundaryAgreement, false);
});

test('synthesizer has no allowAmbiguous bypass and refuses unvalidated partial searches', () => {
  const source = fs.readFileSync(new URL('../../synora-v5/synthesis/synthesize.mjs', import.meta.url), 'utf8');
  assert.doesNotMatch(source, /allowAmbiguous/);
  const result = synthesize({ training: ex(TASKS.average.tr), development: ex(TASKS.average.dv), maxExpressions: 1000 });
  assert.equal(result.found, false);
  assert.equal(result.reason, 'search-budget-exhausted');
});

test('rejections: contradictory, unreachable, and development-failing examples never produce a program', () => {
  // 'no-program-fits-training' is only claimable when the bounded space is exhausted (here: programs up to 3 nodes).
  const contradictory = synthesize({ training: ex([[[[1, 2]], 5], [[[1, 2]], 6], [[[3]], 1]]), development: ex([[[[2]], 2], [[[4]], 4]]), maxSize: 3 });
  assert.equal(contradictory.found, false); assert.equal(contradictory.reason, 'no-program-fits-training');
  const unreachable = synthesize({ training: ex([[[[1, 2]], 5], [[[1, 2]], 6], [[[3]], 1]]), development: ex([[[[2]], 2], [[[4]], 4]]), maxSize: 6, budgetMs: 500 });
  assert.equal(unreachable.found, false); assert.ok(['search-budget-exhausted', 'no-program-fits-training'].includes(unreachable.reason));
  const devFail = synthesize({ training: ex([[[[4, 2, 8]], 2], [[[9, 3, 5, 7]], 3], [[[-1, 6]], -1], [[[8, 6, 5, 1, 7]], 1]]), development: ex([[[[10, 2]], 12345], [[[5]], 5]]) });
  assert.equal(devFail.found, false); assert.equal(devFail.reason, 'development-validation-failed');
  const tiny = synthesize({ training: ex(TASKS.average.tr), development: ex(TASKS.average.dv), maxExpressions: 1000 });
  assert.equal(tiny.found, false); assert.equal(tiny.reason, 'search-budget-exhausted'); assert.ok(tiny.explored <= 1001);
});

test('input validation and determinism', () => {
  const tr = ex(TASKS.min.tr), dv = ex(TASKS.min.dv);
  assert.throws(() => synthesize({ training: tr.slice(0, 2), development: dv }), TypeError);
  assert.throws(() => synthesize({ training: tr, development: dv.slice(0, 1) }), TypeError);
  assert.throws(() => synthesize({ training: [...tr.slice(0, 2), { input: [[1], [2]], output: 1 }], development: dv }), /same number of arguments/);
  assert.throws(() => synthesize({ training: ex([[[true], 1], [[false], 2], [[true], 3]]), development: dv }), /unsupported/);
  assert.throws(() => synthesize({ training: tr, development: dv, maxSize: 99 }), RangeError);
  assert.throws(() => synthesize({ training: tr, development: dv, budgetMs: 0 }), RangeError);
  assert.throws(() => synthesize({ training: 'nope', development: dv }), TypeError);
  const a = synthesize({ training: ex(TASKS.average.tr), development: ex(TASKS.average.dv), maxSize: 6, budgetMs: 20_000, maxExpressions: 2_000_000 });
  const b = synthesize({ training: ex(TASKS.average.tr), development: ex(TASKS.average.dv), maxSize: 6, budgetMs: 20_000, maxExpressions: 2_000_000 });
  assert.deepEqual(a.ast, b.ast); assert.equal(a.source, b.source);
});

test('examples are data: hostile strings are never evaluated', () => {
  const evil = ["require('fs').rmSync('/')", '__proto__', 'constructor.constructor("return process")()', '`${process.exit(1)}`'];
  const r = synthesize({ training: ex(evil.map(s => [[s], s.length])), development: ex([[['ab'], 2], [[''], 0]]) });
  assert.equal(r.found, true);
  assert.ok(hiddenOk(r.source, [[['xyz'], 3]]));
});

test('learner: accepts, applies, abstains safely, deduplicates, persists, and rejects tampered programs', () => {
  const learner = new DigitalObjectLearner({ id: 'stage6' });
  const t = TASKS['count-even'];
  const r = learner.learnProgram({ name: 'count-even', training: ex(t.tr), development: ex(t.dv), maxSize: 6, budgetMs: 20_000, maxExpressions: 2_000_000 });
  assert.equal(r.accepted, true); assert.equal(r.skill.kind, 'program'); assert.equal(r.skill.provenance.source, 'induced-by-bounded-program-synthesis');
  assert.equal(learner.apply(r.skill.id, [[2, 4, 5]]).output, 2);
  for (const bad of [[[1, 2], [3]], 'abc', [['a']], [[1.5e13]], [[1, 2, 3], 4]]) { const a = learner.apply(r.skill.id, bad); assert.equal(a.ok, false); assert.equal(a.abstain, true); }
  const dup = learner.learnProgram({ name: 'renamed', training: ex([...t.tr].reverse()), development: ex(t.dv) });
  assert.equal(dup.duplicate, true); assert.equal(learner.skills.size, 1);
  const rej = learner.learnProgram({ name: 'min-ambiguous', training: ex([[[[4, 2, 8]], 2], [[[9, 3, 5, 7]], 3], [[[-1, 6]], -1]]), development: ex(TASKS.min.dv) });
  assert.equal(rej.accepted, false); assert.equal(learner.skills.size, 1);
  assert.equal(learner.learnProgram({ name: 'min-ambiguous', training: ex([[[[4, 2, 8]], 2], [[[9, 3, 5, 7]], 3], [[[-1, 6]], -1]]), development: ex(TASKS.min.dv) }).duplicate, true);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora6-')); const file = path.join(dir, 'l.json');
  learner.save(file);
  const loaded = DigitalObjectLearner.load(file);
  assert.equal(loaded.apply(r.skill.id, [[2, 4, 5]]).output, 2); assert.ok(loaded.synthesisExpressions > 0);
  const forge = mutate => { const env = JSON.parse(fs.readFileSync(file, 'utf8')); mutate(env.payload); env.sha256 = learningInternals.sha256(learningInternals.canonical(env.payload)); const f = path.join(dir, 'forged.json'); fs.writeFileSync(f, JSON.stringify(env)); return f; };
  assert.throws(() => DigitalObjectLearner.load(forge(p => { p.skills[0].params.ast.f = 'eval'; })), /primitive|node|program/i);
  assert.throws(() => DigitalObjectLearner.load(forge(p => { p.skills[0].params.ast = { k: 'const', v: { x: 1 } }; })), /constant|program/i);
  assert.throws(() => DigitalObjectLearner.load(forge(p => { p.skills[0].params.arity = 9; })), /program/i);
  assert.throws(() => DigitalObjectLearner.load(forge(p => { p.synthesisExpressions = -5; })), /budget/);
  const core = new DigitalObjectCore();
  assert.equal(syncSkillToCore(core, learner, learner.skills.get(r.skill.id)).skipped, false);
});

test('chat: examples define the task in any language; ambiguity returns a question and no code', async () => {
  const t = TASKS['word-count'];
  const ok = await handleDialogue('اكتب لي دالة تعطي عدد الكلمات', { examples: { training: ex(t.tr), development: ex(t.dv) } });
  assert.equal(ok.ok, true); assert.equal(ok.solution.generated.origin, 'synthesized-from-user-examples'); assert.equal(ok.solution.generated.arbitraryUserCodeExecuted, false);
  assert.ok(ok.verification.independence.startsWith('user-supplied-examples'));
  assert.ok(hiddenOk(ok.solution.generated.source, t.hidden));
  const amb = await handleDialogue('min', { examples: { training: ex([[[[4, 2, 8]], 2], [[[9, 3, 5, 7]], 3], [[[-1, 6]], -1]]), development: ex(TASKS.min.dv) } });
  assert.equal(amb.ok, false); assert.equal(amb.solution, undefined); assert.ok(amb.synthesis.disambiguatingQueries.length >= 1);
  assert.throws(() => { throw new TypeError('x'); }, TypeError);
  await assert.rejects(() => handleDialogue('x', { examples: { training: [], development: [] } }), TypeError);
});

test('plausibility gate does not return algebraic no-op wrappers when a simpler equivalent exists', () => {
  const result = synthesize({
    training: ex([[[1], 1], [[2], 2], [[-3], -3]]),
    development: ex([[[4], 4], [[0], 0]])
  });
  assert.equal(result.found, true);
  assert.equal(result.ast.k, 'in', 'the irrelevant +0 wrapper must not be returned');
});
