import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createSynoraApi } from '../../synora-v5/api/server.mjs';

const ex = pairs => pairs.map(([input, output]) => ({ input, output }));
const TASKS = {
  average: {
    tr: [[[[2, 4, 6]], 4], [[[1, 2]], 1.5], [[[10, 20, 30, 40]], 25], [[[3, 3, 9, 5]], 5]],
    dv: [[[[7]], 7], [[[1, 1, 4]], 2]]
  },
  min: {
    dv: [[[[10, 2]], 2], [[[5]], 5]]
  }
};

test('HTTP API: learn-program registers a skill, apply runs it, and bad requests are rejected cleanly', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora6-api-'));
  const api = createSynoraApi({ host: '127.0.0.1', port: 0, token: 'stage6-token-0123456789abcdef', memoryPath: path.join(dir, 'l.json'), corePath: path.join(dir, 'c.json'), applicationLedgerPath: path.join(dir, 'a.json') });
  await new Promise(r => api.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${api.server.address().port}`;
  const call = async (p, body, auth = true) => { const res = await fetch(base + p, { method: body ? 'POST' : 'GET', headers: { 'content-type': 'application/json', connection: 'close', ...(auth ? { authorization: 'Bearer stage6-token-0123456789abcdef' } : {}) }, body: body ? JSON.stringify(body) : undefined }); return { status: res.status, json: await res.json() }; };
  try {
    const t = TASKS.average;
    assert.equal((await call('/v1/skills/learn-program', { name: 'average', training: ex(t.tr), development: ex(t.dv) }, false)).status, 401);
    const learned = await call('/v1/skills/learn-program', { name: 'average', training: ex(t.tr), development: ex(t.dv) });
    assert.equal(learned.status, 200); assert.equal(learned.json.result.skill.kind, 'program');
    const applied = await call('/v1/skills/apply', { skillId: learned.json.result.skill.id, input: [[10, 20]] });
    assert.equal(applied.status, 200); assert.equal(applied.json.output, 15);
    const empty = await call('/v1/skills/apply', { skillId: learned.json.result.skill.id, input: [[]] });
    assert.equal(empty.status, 422); assert.equal(empty.json.ok, false);
    const amb = await call('/v1/skills/learn-program', { name: 'min', training: ex([[[[4, 2, 8]], 2], [[[9, 3, 5, 7]], 3], [[[-1, 6]], -1]]), development: ex(TASKS.min.dv) });
    assert.equal(amb.status, 422); assert.equal(amb.json.result.reason, 'ambiguous-examples'); assert.ok(amb.json.result.disambiguatingQueries.length >= 1);
    assert.equal((await call('/v1/skills/learn-program', { name: 'bad', training: [], development: [] })).status, 400);
  } finally { await new Promise(r => api.server.close(r)); }
});
