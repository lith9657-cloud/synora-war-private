import test from 'node:test';
import assert from 'node:assert/strict';
import { planTask } from '../../synora-v5/agent/planner.mjs';
import { verifyStep } from '../../synora-v5/agent/verifier.mjs';
import { AgentBrain } from '../../synora-v5/agent/brain.mjs';
import { KnowledgeStore } from '../../synora-v5/knowledge/store.mjs';

test('Planner: produces deterministic steps for a programming task', () => {
  const { steps, deterministic, taskType } = planTask('sum of [1,2,3]');
  assert.ok(deterministic);
  assert.equal(taskType, 'programming');
  assert.ok(steps.length >= 1);
  assert.equal(steps[0].operation, 'synthesize');
});

test('Planner: produces query step for knowledge question', () => {
  const { steps, taskType } = planTask('What is the capital of France?');
  assert.equal(taskType, 'knowledge');
  assert.equal(steps[0].operation, 'query');
});

test('Planner: same task = same plan (deterministic)', () => {
  const p1 = planTask('first four numbers');
  const p2 = planTask('first four numbers');
  assert.deepEqual(p1.steps, p2.steps);
});

test('Verifier: passes when AST output matches expected', () => {
  const step = { operation: 'synthesize', params: { ast: { k: 'call', f: 'sum', a: [{ k: 'in', i: 0 }] } } };
  const result = { answered: true, ast: step.params.ast };
  const context = { testCases: [{ input: [[1,2,3]], output: 6 }] };
  const v = verifyStep(step, result, context);
  assert.ok(v.verified);
  assert.equal(v.passes, 1);
});

test('Verifier: fails when output mismatches', () => {
  const step = { operation: 'synthesize', params: {} };
  const result = { answered: true, ast: { k: 'call', f: 'head', a: [{ k: 'in', i: 0 }] } };
  const context = { testCases: [{ input: [[1,2,3]], output: 6 }] };
  const v = verifyStep(step, result, context);
  assert.ok(!v.verified);
});

test('AgentBrain: solves a programming task with NL parser', async () => {
  const brain = new AgentBrain();
  const result = await brain.execute('first four numbers', {
    input: [[9,8,7,6,5,4,3,2,1]],
    testCases: [{ input: [[9,8,7,6,5,4,3,2,1]], output: [9,8,7,6] }]
  });
  assert.ok(result.success);
  assert.equal(result.status, 'solved');
  assert.ok(result.output);
});

test('AgentBrain: queries knowledge store', async () => {
  const store = new KnowledgeStore();
  store.ingestDocument({ id: 'test-1', title: 'France', text: 'Paris is the capital of France.', licence: 'CC0-1.0' });
  const brain = new AgentBrain({ store });
  const result = await brain.execute('Where is France located?', {});
  // Should either answer or abstain (no hallucination either way)
  assert.ok(['solved', 'abstained', 'not_found'].includes(result.status));
  if (result.success) {
    assert.ok(result.message);
  }
});

test('AgentBrain: reports honest failure on unsupported task', async () => {
  const brain = new AgentBrain();
  const result = await brain.execute('predict the stock market', {});
  assert.ok(!result.success);
  assert.equal(result.status, 'abstained');
  assert.ok(result.message); // should have an apology
});

test('AgentBrain: never hallucinates — failed synthesis = honest report', async () => {
  const brain = new AgentBrain();
  const result = await brain.execute('sum of list', {
    training: [{ input: [[1,2,3]], output: 6 }, { input: [[4,5]], output: 9 }, { input: [[0]], output: 0 }],
    development: [{ input: [[10,20]], output: 30 }, { input: [[-1,1]], output: 0 }],
    testCases: [{ input: [[100,200,300]], output: 600 }]
  });
  // Either solved (with correct output) or not_found (honest failure)
  // NEVER wrong (hallucination)
  if (result.success) {
    assert.equal(result.output, 600);
  } else {
    assert.ok(['not_found', 'abstained'].includes(result.status));
  }
});
