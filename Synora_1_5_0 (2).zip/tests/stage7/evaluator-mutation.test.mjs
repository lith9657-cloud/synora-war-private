/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Evaluator mutation tests.
 *
 * The independent evaluator is only trustworthy if it is sensitive to the data it
 * scores. These tests mutate the evaluation data (and inject contradictory
 * examples) and assert that the evaluator reports the change instead of silently
 * passing the system under test.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { runTask, computeAggregates } from '../../bench/external-eval.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const SUITE = JSON.parse(fs.readFileSync(path.join(ROOT, 'bench/external-eval/independent-set.json'), 'utf8'));
const taskById = id => {
  const task = SUITE.tasks.find(t => t.id === id);
  assert.ok(task, `sample suite must contain ${id}`);
  return JSON.parse(JSON.stringify(task));
};

test('mutation: a PBE task with a mutated hidden expectation is scored wrong', async () => {
  const original = taskById('indep-pbe-reverse');
  const clean = await runTask(original);
  assert.equal(clean.status, 'solved', 'the unmodified task must be solved');

  const mutated = taskById('indep-pbe-reverse');
  mutated.hidden = mutated.hidden.map((h, i) => (i === 0 ? { ...h, output: ['this', 'is', 'not', 'the', 'answer'] } : h));
  const broken = await runTask(mutated);
  assert.equal(broken.status, 'wrong', 'the evaluator must detect the mutated hidden expectation');
  assert.notEqual(broken.status, clean.status);
});

test('mutation: contradictory training examples can never be scored solved', async () => {
  const mutated = taskById('indep-pbe-reverse');
  // Two identical inputs with two different outputs: no program can satisfy both.
  mutated.train = [
    { input: [[1, 1]], output: [1] },
    { input: [[1, 1]], output: [2] }
  ];
  const result = await runTask(mutated);
  assert.notEqual(result.status, 'solved', 'an unsatisfiable task must never be solved');
  assert.ok(['abstained', 'wrong', 'error'].includes(result.status), `unexpected status ${result.status}`);
});

test('mutation: an NL2Code task with a mutated hidden expectation is scored wrong', async () => {
  const original = taskById('indep-nl2code-distinct-elements');
  const clean = await runTask(original);
  assert.equal(clean.status, 'solved', 'the unmodified task must be solved');

  const mutated = taskById('indep-nl2code-distinct-elements');
  mutated.hidden = mutated.hidden.map((h, i) => (i === 0 ? { ...h, output: [999] } : h));
  const broken = await runTask(mutated);
  assert.equal(broken.status, 'wrong', 'the evaluator must detect the mutated expectation');
});

test('mutation: a QA task with a mutated expected answer is scored wrong', async () => {
  const original = taskById('indep-qa-person');
  const clean = await runTask(original);
  assert.equal(clean.status, 'solved', 'the unmodified task must be solved');

  const mutated = taskById('indep-qa-person');
  mutated.expectedAnswers = ['Someone Else Entirely'];
  const broken = await runTask(mutated);
  assert.equal(broken.status, 'wrong', 'the evaluator must detect the mutated expected answer');
});

test('mutation: an unanswerable QA task is only solved when the system abstains', async () => {
  const task = taskById('indep-qa-unanswerable-director');
  const result = await runTask(task);
  assert.equal(result.status, 'solved', 'a correct abstention counts as solved');
  assert.equal(result.outcome, 'abstained_correct');
});

test('mutation: the aggregate score changes when a task is mutated', async () => {
  const clean = await runTask(taskById('indep-pbe-length'));
  const mutated = taskById('indep-pbe-length');
  mutated.hidden = mutated.hidden.map(h => ({ ...h, output: ['mutated'] }));
  const broken = await runTask(mutated);
  const agg = computeAggregates([clean, broken]);
  assert.equal(agg.overall.total, 2);
  assert.equal(agg.overall.solved, 1);
  assert.equal(agg.overall.wrong, 1);
  assert.ok(agg.overall.coverage < 1, 'a mutated task must lower the coverage');
});
