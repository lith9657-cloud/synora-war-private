/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { AbuseProtection } from '../../synora-v5/security/abuse.mjs';
import { WebLearningPipeline } from '../../synora-v5/knowledge/web-learning.mjs';

test('Abuse Protection: Blocks requests exceeding window rate limit', () => {
  const abuse = new AbuseProtection({ maxRequestsPerWindow: 3, rateLimitWindowMs: 1000 });
  const client = 'client-123';

  assert.equal(abuse.checkRateLimit(client).allowed, true);
  assert.equal(abuse.checkRateLimit(client).allowed, true);
  assert.equal(abuse.checkRateLimit(client).allowed, true);
  assert.equal(abuse.checkRateLimit(client).allowed, false, 'Fourth request should be blocked');
});

test('Abuse Protection: Blocks oversized payloads', () => {
  const abuse = new AbuseProtection({ maxPayloadBytes: 100 });
  assert.equal(abuse.checkPayloadSize('short').allowed, true);
  assert.equal(abuse.checkPayloadSize('a'.repeat(200)).allowed, false);
});

test('Abuse Protection: Anonymous tool gate blocks dangerous actions', () => {
  const abuse = new AbuseProtection();
  assert.equal(abuse.isToolAllowed('fs.read', true).allowed, true);
  assert.equal(abuse.isToolAllowed('shell.run', true).allowed, false);
  assert.equal(abuse.isToolAllowed('fs.delete', true).allowed, false);
  assert.equal(abuse.isToolAllowed('shell.run', false).allowed, true); // Authenticated allowed
});

test('Web Learning: Off by default and enforces >= 2 independent sources with tainted data flag', async () => {
  const pipeline = new WebLearningPipeline({ enabled: false });
  const res = await pipeline.learnUnknownFact('quantum computing', [{ url: 'http://a' }, { url: 'http://b' }]);
  assert.equal(res.status, 'disabled');

  // Opt-in with mocked fetcher
  const mockFetcher = async (url) => ({ text: `Grounded content from ${url}`, license: 'CC-BY-SA-4.0' });
  const mockRobots = async () => true;
  const enabledPipeline = new WebLearningPipeline({ enabled: true, fetcher: mockFetcher, robotsChecker: mockRobots });

  // Single source rejection
  const single = await enabledPipeline.learnUnknownFact('quantum computing', [{ url: 'http://a' }]);
  assert.equal(single.status, 'abstain');

  // Two independent sources accepted and marked tainted
  const multi = await enabledPipeline.learnUnknownFact('quantum computing', [{ url: 'http://a' }, { url: 'http://b' }]);
  assert.equal(multi.status, 'extracted');
  assert.equal(multi.documents.length, 2);
  assert.ok(multi.documents.every(d => d.isTainted === true && d.licenceCaptured === true && d.status === 'quarantined'));
  assert.equal(multi.requiresSymbolicVerification, true);
  assert.equal(multi.connectionLog.filter(x => x.action === 'fetch').length, 2);

  const noRobots = new WebLearningPipeline({ enabled: true, fetcher: mockFetcher });
  assert.equal((await noRobots.learnUnknownFact('q', [{ url: 'https://a.example' }, { url: 'https://b.example' }])).reason, 'robots_checker_required');
  const denied = new WebLearningPipeline({ enabled: true, fetcher: mockFetcher, robotsChecker: async () => false });
  assert.equal((await denied.learnUnknownFact('q', [{ url: 'https://a.example' }, { url: 'https://b.example' }])).reason, 'robots_disallowed_or_unverified');
  const noLicense = new WebLearningPipeline({ enabled: true, fetcher: async url => ({ text: 'text' }), robotsChecker: mockRobots });
  assert.equal((await noLicense.learnUnknownFact('q', [{ url: 'https://a.example' }, { url: 'https://b.example' }])).reason, 'missing_or_unapproved_license');
});
