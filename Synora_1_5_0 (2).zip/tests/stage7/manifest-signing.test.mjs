/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Release signing policy.
 *
 * A release must be signed with a user-supplied Ed25519 key that lives outside
 * the package. Ephemeral keys are only allowed for local verification, a
 * non-Ed25519 key is refused, and a tampered manifest must not verify.
 */
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const SIGN = path.join(ROOT, 'scripts/create-manifest-signature.mjs');
const VERIFY = path.join(ROOT, 'scripts/verify-manifest-signature.mjs');

const AUDIT = path.join(ROOT, 'audit');
const MANIFEST = path.join(AUDIT, 'package-manifest.json');
const PUBLIC_KEY = path.join(AUDIT, 'manifest-public.pem');
const SIGNATURE = path.join(AUDIT, 'package-manifest.sig');
const FINGERPRINT = path.join(AUDIT, 'manifest-key-fingerprint.txt');
const META = path.join(AUDIT, 'manifest-signature.json');

// The signing tests replace the release artefacts in audit/. They are restored
// afterwards so that running the test suite never invalidates the release signature.
const RELEASE_ARTEFACTS = [MANIFEST, PUBLIC_KEY, SIGNATURE, FINGERPRINT, META];
let backup = null;

before(() => {
  backup = new Map();
  for (const file of RELEASE_ARTEFACTS) {
    backup.set(file, fs.existsSync(file) ? fs.readFileSync(file) : null);
  }
});

after(() => {
  for (const file of RELEASE_ARTEFACTS) {
    const saved = backup.get(file);
    if (saved === null) { if (fs.existsSync(file)) fs.rmSync(file, { force: true }); }
    else fs.writeFileSync(file, saved);
  }
});

function run(script, args = [], env = {}) {
  return spawnSync(process.execPath, [script, ...args], {
    encoding: 'utf8',
    cwd: ROOT,
    env: { ...process.env, ...env }
  });
}

function withTempKey(fn) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-key-'));
  const keyFile = path.join(dir, 'private.pem');
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ed25519');
  fs.writeFileSync(keyFile, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  try {
    return fn({ dir, keyFile, publicKey });
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

function withTempRsaKey(fn) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-rsa-'));
  const keyFile = path.join(dir, 'private.pem');
  const { privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  fs.writeFileSync(keyFile, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  try {
    return fn({ dir, keyFile });
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

test('signing: a user-supplied Ed25519 key signs and verifies the manifest', () => {
  withTempKey(({ keyFile, publicKey }) => {
    const signed = run(SIGN, [], { SYNORA_MANIFEST_PRIVATE_KEY_FILE: keyFile });
    assert.equal(signed.status, 0, signed.stderr);
    assert.ok(fs.existsSync(SIGNATURE));
    assert.ok(fs.existsSync(PUBLIC_KEY));
    assert.ok(fs.existsSync(FINGERPRINT));
    assert.ok(fs.existsSync(META));

    const meta = JSON.parse(fs.readFileSync(META, 'utf8'));
    assert.equal(meta.algorithm, 'Ed25519');
    assert.equal(meta.keyOrigin, 'user-supplied');
    assert.equal(meta.privateKeyInPackage, false);
    assert.equal(
      meta.publicKeyFingerprintSha256,
      crypto.createHash('sha256').update(publicKey.export({ type: 'spki', format: 'der' })).digest('hex')
    );
    assert.equal(
      meta.manifestSha256,
      crypto.createHash('sha256').update(fs.readFileSync(MANIFEST)).digest('hex')
    );

    const verified = run(VERIFY);
    assert.equal(verified.status, 0, verified.stderr);
  });
});

test('signing: a non-Ed25519 key is refused', () => {
  withTempRsaKey(({ keyFile }) => {
    const signed = run(SIGN, [], { SYNORA_MANIFEST_PRIVATE_KEY_FILE: keyFile });
    assert.notEqual(signed.status, 0, 'an RSA key must be refused');
    assert.match(signed.stderr + signed.stdout, /Ed25519/);
  });
});

test('signing: a private key inside the package is refused', () => {
  const insideKey = path.join(ROOT, 'audit', 'test-only-private-key.pem');
  const { privateKey } = crypto.generateKeyPairSync('ed25519');
  fs.writeFileSync(insideKey, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  try {
    const signed = run(SIGN, [], { SYNORA_MANIFEST_PRIVATE_KEY_FILE: insideKey });
    assert.notEqual(signed.status, 0, 'a package-internal key must be refused');
    assert.match(signed.stderr + signed.stdout, /must be outside the package root/);
  } finally {
    fs.rmSync(insideKey, { force: true });
  }
});

test('signing: the release refuses to sign with an ephemeral key', () => {
  const signed = run(SIGN, ['--require-user-key'], { SYNORA_MANIFEST_PRIVATE_KEY_FILE: '', SYNORA_MANIFEST_PRIVATE_KEY: '' });
  assert.notEqual(signed.status, 0, 'a release must not be signed with an ephemeral key');
  assert.match(signed.stderr + signed.stdout, /refusing to sign with an ephemeral key/);
});

test('signing: the private key never reaches the package or the recorded metadata', () => {
  withTempKey(({ keyFile, publicKey }) => {
    const pem = fs.readFileSync(keyFile, 'utf8');
    const signed = run(SIGN, [], { SYNORA_MANIFEST_PRIVATE_KEY_FILE: keyFile });
    assert.equal(signed.status, 0, signed.stderr);
    for (const file of [META, PUBLIC_KEY, FINGERPRINT, SIGNATURE, MANIFEST]) {
      const content = fs.readFileSync(file, 'utf8');
      assert.equal(content.includes('PRIVATE KEY'), false, `${path.basename(file)} must not contain a private key`);
      assert.equal(content.includes(pem.split('\n')[1]), false, `${path.basename(file)} must not contain key material`);
    }
    const meta = JSON.parse(fs.readFileSync(META, 'utf8'));
    assert.equal(meta.keyOrigin, 'user-supplied');
    assert.equal(meta.publicKeyFile, 'audit/manifest-public.pem');
    assert.ok(fs.readFileSync(path.join(ROOT, meta.publicKeyFile), 'utf8').includes('BEGIN PUBLIC KEY'));
  });
});

test('signing: verification fails after the manifest is modified', () => {
  withTempKey(({ keyFile }) => {
    const signed = run(SIGN, [], { SYNORA_MANIFEST_PRIVATE_KEY_FILE: keyFile });
    assert.equal(signed.status, 0, signed.stderr);
    const original = fs.readFileSync(MANIFEST);
    try {
      const tampered = JSON.parse(original.toString('utf8'));
      tampered.__tampered = true;
      fs.writeFileSync(MANIFEST, JSON.stringify(tampered, null, 2) + '\n');
      const verified = run(VERIFY);
      assert.notEqual(verified.status, 0, 'a tampered manifest must not verify');
      assert.match(verified.stderr + verified.stdout, /FAIL/);
    } finally {
      fs.writeFileSync(MANIFEST, original);
    }
  });
});
