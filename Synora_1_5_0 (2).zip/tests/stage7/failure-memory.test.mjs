import test from 'node:test';
import assert from 'node:assert/strict';
import { FailureMemory, extractFailureSignature } from '../../synora-v5/synthesis/failure-memory.mjs';

test('FailureMemory: records a failure signature with correct fields', () => {
  const fm = new FailureMemory();
  const sig = fm.record({
    training: [{ input: [[1, 2, 3]], output: 6 }],
    development: [{ input: [[4, 5]], output: 9 }],
    result: { reason: 'search-budget-exhausted', explored: 80001 },
    operation: 'sum_list'
  });
  assert.equal(sig.operation, 'sum_list');
  assert.equal(sig.arity, 1);
  assert.equal(sig.reason, 'search-budget-exhausted');
  assert.equal(sig.explored, 80001);
  assert.ok(sig.examplesHash);
  assert.equal(fm.size, 1);
});

test('FailureMemory: increases confidence on repeated failures of same task', () => {
  const fm = new FailureMemory();
  const data = {
    training: [{ input: [[1, 2]], output: 3 }],
    development: [{ input: [[4]], output: 4 }],
    result: { reason: 'search-budget-exhausted', explored: 80001 },
    operation: 'add2'
  };
  fm.record(data);
  fm.record(data);
  const sigs = [...fm.signatures.values()];
  assert.equal(sigs[0].confidence, 2);
});

test('FailureMemory: adds to patternAvoid after 3 failures of same task', () => {
  const fm = new FailureMemory();
  const data = {
    training: [{ input: [[1, 2]], output: 3 }],
    development: [{ input: [[4]], output: 4 }],
    result: { reason: 'search-budget-exhausted', explored: 80001 },
    operation: 'add2'
  };
  fm.record(data);
  fm.record(data);
  fm.record(data);
  assert.equal(fm.avoidCount, 1);
});

test('FailureMemory: shouldAvoid returns true for confirmed bad patterns', () => {
  const fm = new FailureMemory();
  const data = {
    training: [{ input: [[1, 2]], output: 3 }],
    development: [{ input: [[4]], output: 4 }],
    result: { reason: 'ambiguous-examples', explored: 5000 },
    operation: 'test'
  };
  fm.record(data); fm.record(data); fm.record(data);
  const sig = extractFailureSignature(data);
  assert.ok(fm.shouldAvoid(sig));
});

test('FailureMemory: recommendBudget reduces budget for repeated failures', () => {
  const fm = new FailureMemory();
  const data = {
    training: [{ input: [[1, 2]], output: 3 }],
    development: [{ input: [[4]], output: 4 }],
    result: { reason: 'search-budget-exhausted', explored: 80001 },
    operation: 'test'
  };
  const sig = extractFailureSignature(data);
  assert.equal(fm.recommendBudget(sig, 400000), 400000); // no history → full budget
  fm.record(data);
  assert.equal(fm.recommendBudget(sig, 400000), 400000); // confidence 1 → full
  fm.record(data);
  assert.equal(fm.recommendBudget(sig, 400000), 240000); // confidence 2 → 60%
  fm.record(data);
  assert.equal(fm.recommendBudget(sig, 400000), 120000); // confidence 3 → 30%
});

test('FailureMemory: export/import roundtrips correctly', () => {
  const fm = new FailureMemory();
  for (let i = 0; i < 3; i++) {
    fm.record({
      training: [{ input: [[i, i+1]], output: i*2 }],
      development: [],
      result: { reason: 'search-budget-exhausted', explored: 100 },
      operation: 'test'
    });
  }
  const exported = fm.export();
  const fm2 = new FailureMemory();
  fm2.import(exported);
  assert.equal(fm2.size, fm.size);
});
