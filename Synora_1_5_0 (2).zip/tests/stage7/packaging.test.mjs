/** @license SPDX-License-Identifier: Apache-2.0 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');

test('Packaging: manifest file hashes and detached Ed25519 signature verify', () => {
  const verify=spawnSync(process.execPath,['scripts/build-manifest.mjs','--verify'],{cwd:ROOT,encoding:'utf8'});
  assert.equal(verify.status,0,verify.stderr||verify.stdout);
  const sig=spawnSync(process.execPath,['scripts/verify-manifest-signature.mjs'],{cwd:ROOT,encoding:'utf8'});
  assert.equal(sig.status,0,sig.stderr||sig.stdout);
  assert.match(sig.stdout,/signature verification: PASS/);
});

test('Packaging: Docker is non-root, CI covers three OS families, Render config does not persist to /tmp', () => {
  const docker=fs.readFileSync(path.join(ROOT,'Dockerfile'),'utf8');
  const ci=fs.readFileSync(path.join(ROOT,'.github/workflows/ci.yml'),'utf8');
  const render=fs.readFileSync(path.join(ROOT,'render.yaml'),'utf8');
  assert.match(docker,/^USER node$/m);
  assert.match(docker,/SYNORA_OFFLINE=1/);
  assert.match(docker,/HOST=127\.0\.0\.1/);
  for(const os of ['ubuntu-latest','windows-latest','macos-latest'])assert.ok(ci.includes(os));
  assert.doesNotMatch(render,/\/tmp\//);
});
