/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '../..');

test('Static Anti-Leak Test: Benchmark prompts, ids, and sealed outputs must not appear in synora-v5 sources', () => {
  const benchmarksDir = path.join(ROOT_DIR, 'bench');
  const sampleTasksPath = path.join(benchmarksDir, 'external-eval/sample-tasks.json');
  
  const forbiddenTaskIds = new Set();
  const forbiddenPrompts = new Set();

  if (fs.existsSync(sampleTasksPath)) {
    const data = JSON.parse(fs.readFileSync(sampleTasksPath, 'utf-8'));
    for (const task of (data.tasks || [])) {
      if (task.id) forbiddenTaskIds.add(task.id);
      if (task.prompt && task.prompt.length >= 10) forbiddenPrompts.add(task.prompt);
      if (task.description && task.description.length >= 10) forbiddenPrompts.add(task.description);
      if (task.question && task.question.length >= 10) forbiddenPrompts.add(task.question);
    }
  }

  // Also check tasks from bench/tasks.mjs or bench/synth.mjs
  const synthBenchPath = path.join(benchmarksDir, 'synth.mjs');
  if (fs.existsSync(synthBenchPath)) {
    const content = fs.readFileSync(synthBenchPath, 'utf-8');
    const nameMatches = content.match(/name:\s*['"]([^'"]+)['"]/g);
    if (nameMatches) {
      for (const m of nameMatches) {
        const name = m.split(':')[1].replace(/['"\s]/g, '');
        // Don't forbid generic words like 'sum' if used as identifiers, but specific compound names
        if (name.includes('-') || name.includes('_')) {
          forbiddenTaskIds.add(name);
        }
      }
    }
  }

  // Scan all source files in synora-v5
  const synoraSrcDir = path.join(ROOT_DIR, 'synora-v5');
  const violations = [];

  function scanDir(dir) {
    if (!fs.existsSync(dir)) return;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        scanDir(full);
      } else if (e.isFile() && (e.name.endsWith('.mjs') || e.name.endsWith('.js'))) {
        const content = fs.readFileSync(full, 'utf-8');
        for (const id of forbiddenTaskIds) {
          // Check for exact task ID occurrences as string literals or identifiers
          const literalRegex = new RegExp(`['"\`]${id}['"\`]`, 'i');
          if (literalRegex.test(content)) {
            violations.push({
              file: path.relative(ROOT_DIR, full),
              type: 'task_id',
              leaked: id
            });
          }
        }
        for (const prompt of forbiddenPrompts) {
          if (content.includes(prompt)) {
            violations.push({
              file: path.relative(ROOT_DIR, full),
              type: 'prompt',
              leaked: prompt
            });
          }
        }
      }
    }
  }

  scanDir(synoraSrcDir);
  assert.equal(violations.length, 0, `Detected benchmark leakage in source code: ${JSON.stringify(violations, null, 2)}`);
});

test('Static Anti-Leak Round 2: held-out prompts, ids, and complete expected-output records are absent from all production source and lexicons', () => {
  const benchmarkFiles = [
    'bench/nl2code-round2-corpus.json',
    'bench/pbe-round2-dataset.json',
    'bench/qa-round2-dataset.json'
  ];
  const forbidden = new Set();
  for (const rel of benchmarkFiles) {
    const data = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, rel), 'utf8'));
    for (const item of (data.items || data.tasks || data.questions || [])) {
      if (item.split && item.split !== 'test') continue;
      if (item.id) forbidden.add(item.id);
      if (item.prompt && item.prompt.length >= 10) forbidden.add(item.prompt);
      if (item.question && item.question.length >= 10) forbidden.add(item.question);
      if (item.hidden?.length) forbidden.add(JSON.stringify(item.hidden));
      if (item.expectedAnswers?.length) forbidden.add(JSON.stringify(item.expectedAnswers));
    }
  }
  const sourceRoot = path.join(ROOT_DIR, 'synora-v5');
  const files = [];
  const walk = dir => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.isFile() && /\.(?:mjs|js|json)$/.test(entry.name)) files.push(full);
    }
  };
  walk(sourceRoot);
  const violations = [];
  for (const file of files) {
    const source = fs.readFileSync(file, 'utf8');
    for (const needle of forbidden) if (needle.length > 1 && source.includes(needle)) violations.push({ file: path.relative(ROOT_DIR, file), needle: needle.slice(0, 100) });
  }
  assert.deepEqual(violations, []);
});
