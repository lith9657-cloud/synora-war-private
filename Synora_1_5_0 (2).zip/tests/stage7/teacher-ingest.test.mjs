/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { ingestTeacherFile, checkLeakage } from '../../teacher/ingest.mjs';

test('Teacher Pipeline: Enforces permitted license, anti-leak checks, and symbolic verification', () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-teacher-'));
  const testJsonl = path.join(tmpDir, 'test-teacher.jsonl');

  const candidates = [
    // 1. Valid Apache-2.0 candidate (sum numbers)
    {
      id: 'valid-candidate-01',
      license: 'Apache-2.0',
      description: 'A completely novel non-leaked task description for adding list',
      training: [
        { input: [[1, 2, 3]], output: 6 },
        { input: [[4, 5]], output: 9 },
        { input: [[10]], output: 10 },
        { input: [[2, 2, 3]], output: 7 },
        { input: [[0, 0, 0]], output: 0 }
      ],
      development: [
        { input: [[20, 30]], output: 50 },
        { input: [[-1, 1]], output: 0 },
        { input: [[1, 1]], output: 2 },
        { input: [[2, 1, 2]], output: 5 },
        { input: [[1, 2, 3, 4]], output: 10 },
        { input: [[-2, -1]], output: -3 },
        { input: [[0]], output: 0 },
        { input: [[1, 1, 1]], output: 3 }
      ],
      hidden: [
        { input: [[7, 8, 9]], output: 24 }
      ]
    },
    // 2. Rejected: Unpermitted / restrictive license
    {
      id: 'rejected-license',
      license: 'Meta-Llama-Community',
      description: 'Some task',
      training: [{ input: [[1, 2]], output: 3 }, { input: [[3, 4]], output: 7 }, { input: [[0, 0]], output: 0 }],
      development: [{ input: [[5, 5]], output: 10 }, { input: [[1, 1]], output: 2 }]
    },
    // 3. Rejected: Leaked task from external eval suite
    {
      id: 'rejected-leak',
      license: 'Apache-2.0',
      description: 'Find second largest distinct integer', // exact string in sample-tasks.json
      training: [{ input: [[1, 2]], output: 3 }, { input: [[3, 4]], output: 7 }, { input: [[0, 0]], output: 0 }],
      development: [{ input: [[5, 5]], output: 10 }, { input: [[1, 1]], output: 2 }]
    }
  ];

  fs.writeFileSync(testJsonl, candidates.map(c => JSON.stringify(c)).join('\n') + '\n', 'utf-8');

  const report = ingestTeacherFile(testJsonl, { stateDir: tmpDir });
  assert.equal(report.total, 3);
  assert.equal(report.accepted, 1);
  assert.equal(report.rejected, 2);

  const reasons = report.reasons.map(r => r.reason);
  assert.ok(reasons.includes('unpermitted_license'));
  assert.ok(reasons.includes('evaluation_set_leakage_detected'));

  fs.rmSync(tmpDir, { recursive: true, force: true });
});
