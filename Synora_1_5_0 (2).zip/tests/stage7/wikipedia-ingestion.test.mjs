import test from 'node:test';
import assert from 'node:assert/strict';
import { extractFacts, buildRelationTables, ingestWikipediaBatch, ENTITIES_EN } from '../../synora-v5/knowledge/wikipedia-ingestion.mjs';
import { KnowledgeStore } from '../../synora-v5/knowledge/store.mjs';

test('Wikipedia: extractFacts parses capital from EN text', () => {
  const text = 'France is a country in Western Europe. Paris is the capital of France. France has a population of 67 million.';
  const facts = extractFacts(text, 'en');
  assert.ok(facts.some(f => f.relation === 'capital'));
  assert.ok(facts.some(f => f.relation === 'population'));
});

test('Wikipedia: extractFacts parses founded year', () => {
  const facts = extractFacts('The city was founded in 1840 and established in 1841.', 'en');
  assert.ok(facts.some(f => f.relation === 'founded' && f.value === '1840'));
});

test('Wikipedia: extractFacts parses AR facts', () => {
  const text = 'فرنسا دولة في أوروبا. عاصمتها باريس. يبلغ عدد سكانها 67 مليون نسمة. تأسست عام 843.';
  const facts = extractFacts(text, 'ar');
  assert.ok(facts.some(f => f.relation === 'عاصمة'), 'must extract capital');
  assert.ok(facts.some(f => f.relation === 'سكان'), 'must extract population');
  assert.ok(facts.some(f => f.relation === 'تأسست'), 'must extract founding year');
});

test('Wikipedia: buildRelationTables compresses facts into tables', () => {
  const facts = [
    { predicate: 'capital', subject: 'France', object: 'Paris' },
    { predicate: 'capital', subject: 'Japan', object: 'Tokyo' },
    { predicate: 'population', subject: 'France', object: '67' }
  ];
  const tables = buildRelationTables(facts);
  assert.equal(Object.keys(tables).length, 2);
  assert.equal(tables.capital.France, 'Paris');
  assert.equal(tables.capital.Japan, 'Tokyo');
  assert.equal(tables.population.France, '67');
});

test('Wikipedia: ingestWikipediaBatch with mock fetcher', async () => {
  const mockFetch = async (url) => {
    if (url.includes('France')) {
      return { ok: true, json: async () => ({ type: 'standard', title: 'France', extract: 'France is a country. Paris is the capital of France. Founded in 843.' }) };
    }
    return { ok: false, status: 404 };
  };
  const store = new KnowledgeStore();
  const result = await ingestWikipediaBatch(['France'], 'en', store, mockFetch);
  assert.equal(result.ingested, 1);
  assert.ok(result.facts >= 2, 'should extract at least 2 facts');
  // The store should now have the Wikipedia document
  assert.ok(store.documents.has('wiki-en-France'));
});

test('Wikipedia: ENTITIES_EN has at least 70 entities', () => {
  assert.ok(ENTITIES_EN.length >= 70, `expected >= 70 entities, got ${ENTITIES_EN.length}`);
});
