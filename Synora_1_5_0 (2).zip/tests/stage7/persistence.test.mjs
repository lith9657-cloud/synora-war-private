/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { EventLedger } from '../../synora-v5/persistence/event-ledger.mjs';
import { createStorage } from '../../synora-v5/persistence/storage.mjs';

test('Persistence: Event ledger maintains hash chain integrity and detects tampering', () => {
  const tmp = path.join(os.tmpdir(), `ledger-test-${Date.now()}.jsonl`);
  const ledger = new EventLedger(tmp);

  ledger.append({ action: 'create', entity: 'skill-1' });
  ledger.append({ action: 'update', entity: 'skill-1', version: 2 });
  ledger.append({ action: 'apply', entity: 'skill-1' });

  assert.equal(ledger.events.length, 3);
  assert.ok(ledger.verify(), 'Ledger must be cryptographically valid');

  // Tampering simulation
  const content = fs.readFileSync(tmp, 'utf-8');
  const lines = content.split('\n').filter(Boolean);
  const tamperedEvent = JSON.parse(lines[1]);
  tamperedEvent.payload.version = 999; // Tampered without updating hash
  lines[1] = JSON.stringify(tamperedEvent);
  fs.writeFileSync(tmp, lines.join('\n') + '\n', 'utf-8');

  const reloaded = new EventLedger(tmp);
  // Reloading halts at corrupted line 1
  assert.equal(reloaded.events.length, 1, 'Corrupted event must be rejected');

  fs.unlinkSync(tmp);
});

test('Persistence: Backup and restore restores exact state', () => {
  const tmp = path.join(os.tmpdir(), `ledger-backup-${Date.now()}.jsonl`);
  const backupPath = tmp + '.bak';
  const ledger = new EventLedger(tmp);

  ledger.append({ msg: 'checkpoint 1' });
  ledger.append({ msg: 'checkpoint 2' });
  ledger.backup(backupPath);

  assert.ok(fs.existsSync(backupPath));

  const restoredLedger = new EventLedger(tmp + '.new');
  restoredLedger.restore(backupPath);
  assert.equal(restoredLedger.events.length, 2);
  assert.ok(restoredLedger.verify());

  fs.unlinkSync(tmp);
  fs.unlinkSync(backupPath);
  fs.unlinkSync(tmp + '.new');
});

test('Persistence: Interchangeable storage adapters (JSON, native SQLite, and injected PostgreSQL client)', async () => {
  const tmpDir = path.join(os.tmpdir(), `storage-test-${Date.now()}`);
  const jsonStore = createStorage('json', tmpDir);
  const sqliteStore = createStorage('sqlite', ':memory:');
  const pgRows = new Map();
  const pgClient = { async query(sql, params = []) {
    if (sql.startsWith('CREATE TABLE')) return { rows: [], rowCount: 0 };
    if (sql.includes('synora_schema_migrations')) return { rows: [], rowCount: 1 };
    if (sql.startsWith('INSERT')) { pgRows.set(`${params[0]}:${params[1]}`, JSON.parse(params[2])); return { rows: [], rowCount: 1 }; }
    if (sql.startsWith('SELECT value')) { const v = pgRows.get(`${params[0]}:${params[1]}`); return { rows: v === undefined ? [] : [{ value: v }] }; }
    if (sql.startsWith('SELECT id')) { return { rows: [...pgRows.keys()].filter(k => k.startsWith(`${params[0]}:`)).map(k => ({ id: k.slice(params[0].length + 1) })).sort((a,b)=>a.id.localeCompare(b.id)) }; }
    if (sql.startsWith('DELETE')) { const ok = pgRows.delete(`${params[0]}:${params[1]}`); return { rows: [], rowCount: ok ? 1 : 0 }; }
    throw new Error(`Unexpected SQL: ${sql}`);
  } };
  const pgStore = createStorage('postgres', pgClient);
  const adapters = [jsonStore, sqliteStore, pgStore];

  for (const store of adapters) {
    await store.set('skills', 'fib', { code: 'x + 1' });
    const fetched = await store.get('skills', 'fib');
    assert.equal(fetched.code, 'x + 1');
    assert.deepEqual(await store.list('skills'), ['fib']);
    await store.delete('skills', 'fib');
    assert.equal(await store.get('skills', 'fib'), null);
  }
  assert.throws(() => createStorage('postgres', 'mock://localhost'), /injected pg-compatible client/);
  sqliteStore.close();

  fs.rmSync(tmpDir, { recursive: true, force: true });
});

test('Persistence: concurrent independent Node writers preserve a single valid hash chain', async () => {
  const { spawnSync } = await import('node:child_process');
  const tmp = path.join(os.tmpdir(), `ledger-concurrent-${Date.now()}.jsonl`);
  const moduleUrl = new URL('../../synora-v5/persistence/event-ledger.mjs', import.meta.url).href;
  const code = `import { EventLedger } from ${JSON.stringify(moduleUrl)}; const l=new EventLedger(${JSON.stringify(tmp)}); for(let i=0;i<8;i++) l.append({worker:process.argv[1],i});`;
  const workers = [];
  for (let i = 0; i < 4; i++) workers.push(spawnSync(process.execPath, ['--input-type=module', '-e', code, String(i)], { encoding: 'utf8', timeout: 15000 }));
  for (const w of workers) assert.equal(w.status, 0, w.stderr || w.stdout);
  const ledger = new EventLedger(tmp);
  assert.equal(ledger.events.length, 32);
  assert.equal(ledger.verify(), true);
  fs.rmSync(tmp, { force: true });
});

test('Persistence: SIGKILL-torn final append is truncated to last valid hash-chain record', async () => {
  const { spawnSync } = await import('node:child_process');
  const tmp = path.join(os.tmpdir(), `ledger-crash-${Date.now()}.jsonl`);
  const ledger = new EventLedger(tmp);
  ledger.append({ stable: true });
  const before = fs.statSync(tmp).size;
  const code = `import fs from 'node:fs'; fs.appendFileSync(${JSON.stringify(tmp)}, '{"index":1,"prevHash":"torn'); process.kill(process.pid, 'SIGKILL');`;
  const child = spawnSync(process.execPath, ['--input-type=module', '-e', code], { encoding: 'utf8' });
  assert.equal(child.signal, 'SIGKILL');
  const recovered = new EventLedger(tmp);
  assert.equal(recovered.events.length, 1);
  assert.equal(recovered.verify(), true);
  assert.equal(fs.statSync(tmp).size, before);
  recovered.append({ afterRecovery: true });
  assert.equal(new EventLedger(tmp).events.length, 2);
  fs.rmSync(tmp, { force: true });
});
