import test from 'node:test';
import assert from 'node:assert/strict';
import { ingestDataset, ingestGitHubSkill, DATASETS, PATTERN_TYPES } from '../../synora-v5/knowledge/hf-ingestion.mjs';

test('HF: all 5 datasets are configured', () => {
  assert.ok(DATASETS.fineweb);
  assert.ok(DATASETS.pile);
  assert.ok(DATASETS.oasst2);
  assert.ok(DATASETS.marketing);
  assert.ok(DATASETS.fineinstructions);
});

test('HF: ingestDataset extracts patterns from mock records', async () => {
  const mockFetcher = async (name, max) => {
    if (name === 'fineweb') return [
      { text: 'Paris is the capital of France. Paris was founded in 259.' },
      { text: 'Tokyo is a city in Japan. Tokyo has 14 million inhabitants.' },
    ];
    if (name === 'oasst2') return [
      { text: 'How do I create a website?', role: 'prompter' },
      { text: 'You can use HTML and CSS to create a website.', role: 'assistant' },
    ];
    if (name === 'marketing') return [
      { instruction: 'Write a SEO headline for a landing page', output: '10 Best Tools for...' },
    ];
    return [];
  };
  const r1 = await ingestDataset('fineweb', mockFetcher);
  assert.ok(r1.stats.extracted > 0, 'should extract facts from text');
  assert.ok(r1.stats.compressed > 0, 'should compress patterns');

  const r2 = await ingestDataset('oasst2', mockFetcher);
  assert.ok(r2.stats.extracted > 0, 'should extract conversation patterns');

  const r3 = await ingestDataset('marketing', mockFetcher);
  assert.ok(r3.stats.extracted > 0, 'should extract marketing patterns');
});

test('HF: patterns are compact (understand not store)', async () => {
  const mockFetcher = async () => [
    { text: 'Paris is the capital of France. Paris was founded in 259.' },
    { text: 'London is the capital of England. London was founded in 47.' },
  ];
  const result = await ingestDataset('fineweb', mockFetcher);
  // The compressed tables should be much smaller than the raw text
  const tableSize = JSON.stringify(result.patterns).length;
  const rawSize = 120; // approximate raw text size
  assert.ok(tableSize < rawSize * 2, 'compressed should be compact');
});

test('HF: ingestGitHubSkill fetches and parses skill from mock', async () => {
  const mockFetch = async (url) => {
    if (url.includes('README.md')) return { ok: true, text: async () => '# Test Skill\n\n> A skill that builds landing pages.\n\n- Create HTML pages\n- Deploy to GitHub Pages\n- Phase 1: Read repo\n- Phase 2: Generate design' };
    if (url.includes('SKILL.md')) return { ok: true, text: async () => '---\nname: test\n---\n# Test\nBuild with Tailwind CSS and React.' };
    return { ok: false };
  };
  const result = await ingestGitHubSkill('https://github.com/test/test-skill', mockFetch);
  assert.ok(result.understanding);
  assert.ok(result.understanding.capabilities.length > 0, 'should extract capabilities');
  assert.ok(result.understanding.technologies.includes('Tailwind') || result.understanding.technologies.includes('React'));
});

test('HF: no fetch available returns graceful error', async () => {
  const result = await ingestDataset('fineweb', undefined);
  assert.equal(result.stats.processed, 0);
});
