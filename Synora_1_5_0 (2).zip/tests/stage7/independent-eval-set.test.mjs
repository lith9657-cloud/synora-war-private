/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * The independent evaluation set is authored outside the development splits and is
 * protected by a recorded digest. This test fails when the set is edited without
 * regenerating its digest, and when a prompt of the set leaks into the production
 * lexicon or grammar source.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const SET = path.join(ROOT, 'bench/external-eval/independent-set.json');
const DIGEST = path.join(ROOT, 'bench/external-eval/independent-set.sha256');

test('independent evaluation set: the recorded digest matches the file', () => {
  const bytes = fs.readFileSync(SET);
  const digest = crypto.createHash('sha256').update(bytes).digest('hex');
  const recorded = fs.readFileSync(DIGEST, 'utf8').trim().split(/\s+/)[0];
  assert.equal(digest, recorded, 'run `node bench/external-eval/make-independent-set.mjs` to refresh the digest');
});

test('independent evaluation set: the set is self-describing', () => {
  const suite = JSON.parse(fs.readFileSync(SET, 'utf8'));
  assert.equal(suite.format, 'synora-eval/1');
  assert.ok(suite.provenance, 'the set must carry its provenance');
  assert.ok(suite.provenance.method.includes('written by hand'));
  assert.ok(suite.tasks.length >= 20, 'the set must contain a meaningful number of tasks');
  for (const task of suite.tasks) {
    assert.ok(task.id && task.track, 'every task needs an id and a track');
  }
});

test('independent evaluation set: no prompt leaks into the production source', () => {
  const suite = JSON.parse(fs.readFileSync(SET, 'utf8'));
  const sources = ['synora-v5/nl2code/lexicon.mjs', 'synora-v5/nl2code/grammar.mjs', 'synora-v5/dialogue/index.mjs']
    .map(rel => fs.readFileSync(path.join(ROOT, rel), 'utf8'));
  for (const task of suite.tasks) {
    for (const prompt of [task.prompt, task.text, task.question].filter(Boolean)) {
      for (const src of sources) {
        assert.equal(src.includes(prompt), false, `prompt leaked into production source: ${prompt}`);
      }
    }
  }
});

test('independent evaluation set: no task copies a development-split example', () => {
  const suite = JSON.parse(fs.readFileSync(SET, 'utf8'));
  const pbe = JSON.parse(fs.readFileSync(path.join(ROOT, 'bench/pbe-round2-dataset.json'), 'utf8'));
  const qa = JSON.parse(fs.readFileSync(path.join(ROOT, 'bench/qa-round2-dataset.json'), 'utf8'));
  const developmentExamples = new Set();
  for (const task of pbe.tasks) {
    for (const group of ['train', 'dev', 'hidden']) {
      for (const example of task[group] || []) developmentExamples.add(JSON.stringify(example));
    }
  }
  const developmentTexts = new Set((qa.corpus || []).map(doc => doc.text));
  const developmentQuestions = new Set((qa.questions || []).map(q => q.question));

  for (const task of suite.tasks) {
    if (task.track === 'pbe') {
      for (const group of ['train', 'dev', 'hidden']) {
        for (const example of task[group] || []) {
          const key = JSON.stringify(example);
          assert.equal(developmentExamples.has(key), false, `example ${key} is copied from a development split`);
        }
      }
    }
    if (task.track === 'qa') {
      for (const doc of task.corpus || []) {
        assert.equal(developmentTexts.has(doc.text), false, `document text is copied from a development corpus`);
      }
      assert.equal(developmentQuestions.has(task.question), false, `question is copied from a development split`);
    }
  }
});
