/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ResponsePlanner } from '../../synora-v5/dialogue/planner.mjs';
import { parseNLToCode } from '../../synora-v5/nl2code/grammar.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '../..');

test('Dialogue: >= 100 prompts per language, outputs transcripts for human review', () => {
  const planner = new ResponsePlanner();
  const transcripts = [];

  const enPrompts = [];
  const arPrompts = [];

  for (let i = 1; i <= 100; i++) {
    if (i <= 40) {
      enPrompts.push(`calculate sum of positive numbers ${i}`);
      arPrompts.push(`احسب مجموع الأعداد الموجبة ${i}`);
    } else if (i <= 70) {
      enPrompts.push(`write a creative poem about galaxy ${i}`);
      arPrompts.push(`اكتب قصيدة شعرية عن المجرة ${i}`);
    } else {
      enPrompts.push(`sort the list descending order ${i}`);
      arPrompts.push(`رتب القائمة تنازليا ${i}`);
    }
  }

  assert.equal(enPrompts.length, 100);
  assert.equal(arPrompts.length, 100);

  // Run EN
  for (const p of enPrompts) {
    const parseRes = parseNLToCode(p, { lang: 'en' });
    const { text, plan } = planner.planAndRealize(parseRes, { lang: 'en' });
    transcripts.push(`[USER EN]: ${p}\n[SYNORA EN (${plan.type})]:\n${text}\n-------------------`);
  }

  // Run AR
  for (const p of arPrompts) {
    const parseRes = parseNLToCode(p, { lang: 'ar' });
    const { text, plan } = planner.planAndRealize(parseRes, { lang: 'ar' });
    transcripts.push(`[USER AR]: ${p}\n[SYNORA AR (${plan.type})]:\n${text}\n-------------------`);
  }

  const logDir = path.join(ROOT_DIR, 'logs');
  fs.mkdirSync(logDir, { recursive: true });
  const transcriptPath = path.join(logDir, 'dialogue-transcripts.txt');
  fs.writeFileSync(transcriptPath, transcripts.join('\n\n'), 'utf-8');

  console.log(`Saved ${transcripts.length} dialogue transcripts to ${transcriptPath}`);
  assert.ok(fs.existsSync(transcriptPath));
});
