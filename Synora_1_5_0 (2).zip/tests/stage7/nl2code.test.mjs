/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseNLToCode } from '../../synora-v5/nl2code/grammar.mjs';
import { executeAST } from '../../synora-v5/nl2code/sanity-checks.mjs';
import { deepEqual } from '../../synora-v5/synthesis/dsl.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '../..');

test('NL2Code: Static verification that no test prompt string occurs in lexicon source', () => {
  const corpusPath = path.join(ROOT_DIR, 'bench/paraphrase-corpus.json');
  const lexiconPath = path.join(ROOT_DIR, 'synora-v5/nl2code/lexicon.mjs');

  assert.ok(fs.existsSync(corpusPath), 'Corpus file must exist');
  assert.ok(fs.existsSync(lexiconPath), 'Lexicon file must exist');

  const corpus = JSON.parse(fs.readFileSync(corpusPath, 'utf-8'));
  const lexiconSrc = fs.readFileSync(lexiconPath, 'utf-8');

  const testPrompts = corpus.items.filter(item => item.split === 'test');
  assert.ok(testPrompts.length >= 240, 'Must have at least 240 held-out test prompts (>=30%)');

  for (const item of testPrompts) {
    assert.equal(
      lexiconSrc.includes(item.prompt),
      false,
      `Leakage detected: test prompt "${item.prompt}" was found in lexicon source!`
    );
  }
});

test('NL2Code: Evaluation on held-out test split (EN and AR)', () => {
  const corpusPath = path.join(ROOT_DIR, 'bench/paraphrase-corpus.json');
  const corpus = JSON.parse(fs.readFileSync(corpusPath, 'utf-8'));
  const testPrompts = corpus.items.filter(item => item.split === 'test');

  const stats = {
    en: { total: 0, solved: 0, wrong: 0, abstained: 0 },
    ar: { total: 0, solved: 0, wrong: 0, abstained: 0 }
  };

  for (const item of testPrompts) {
    const lang = item.lang;
    const bucket = stats[lang];
    bucket.total++;

    const res = parseNLToCode(item.prompt, { lang });
    if (res.status === 'abstain') {
      bucket.abstained++;
    } else if (res.status === 'ok' && res.ast) {
      let passes = true;
      for (const t of item.hidden) {
        try {
          const actual = executeAST(res.ast, t.input);
          if (!deepEqual(actual, t.output)) {
            passes = false;
            break;
          }
        } catch {
          passes = false;
          break;
        }
      }

      if (passes) {
        bucket.solved++;
      } else {
        bucket.wrong++;
      }
    } else {
      bucket.abstained++;
    }
  }

  // EN stats
  const enSolvedRate = stats.en.solved / stats.en.total;
  const enAttempts = stats.en.solved + stats.en.wrong;
  const enWrongRate = enAttempts > 0 ? (stats.en.wrong / enAttempts) : 0;

  // AR stats
  const arSolvedRate = stats.ar.solved / stats.ar.total;
  const arAttempts = stats.ar.solved + stats.ar.wrong;
  const arWrongRate = arAttempts > 0 ? (stats.ar.wrong / arAttempts) : 0;

  console.log('NL2Code Held-Out Evaluation Results:');
  console.log(`EN: Solved=${(enSolvedRate * 100).toFixed(1)}%, WrongRate=${(enWrongRate * 100).toFixed(1)}%, Abstained=${((stats.en.abstained / stats.en.total) * 100).toFixed(1)}%`);
  console.log(`AR: Solved=${(arSolvedRate * 100).toFixed(1)}%, WrongRate=${(arWrongRate * 100).toFixed(1)}%, Abstained=${((stats.ar.abstained / stats.ar.total) * 100).toFixed(1)}%`);

  // Assertions based on Phase 2 requirements:
  // Required: wrong-with-confidence <= 2% of attempts
  assert.ok(enWrongRate <= 0.02, `EN wrong rate must be <= 2%, got ${(enWrongRate * 100).toFixed(2)}%`);
  assert.ok(arWrongRate <= 0.02, `AR wrong rate must be <= 2%, got ${(arWrongRate * 100).toFixed(2)}%`);

  // Target: >= 60% solved in EN, >= 45% in AR
  assert.ok(enSolvedRate >= 0.60, `EN solved rate must be >= 60%, got ${(enSolvedRate * 100).toFixed(2)}%`);
  assert.ok(arSolvedRate >= 0.45, `AR solved rate must be >= 45%, got ${(arSolvedRate * 100).toFixed(2)}%`);
});

test('NL2Code Round 2: qualifiers compose with aggregations instead of being silently dropped', () => {
  const cases = [
    ['average of the even numbers', 'en', [1, 2, 3, 4, 6], 4],
    ['number of distinct values', 'en', [2, 2, 5, 5, 7], 3],
    ['smallest even number', 'en', [9, 4, 3, 2, 7], 2],
    ['sum of numbers greater than five', 'en', [1, 5, 6, 8], 14],
    ['اجمع الاعداد الاكبر من خمسة', 'ar', [1, 5, 6, 8], 14],
    ['عدد القيم الزوجية', 'ar', [1, 2, 3, 4, 6], 3],
    ['اصغر عدد زوجي', 'ar', [9, 4, 3, 2, 7], 2],
    ['احسب عدد القيم المميزة', 'ar', [2, 2, 5, 5, 7], 3]
  ];
  for (const [prompt, lang, input, expected] of cases) {
    const parsed = parseNLToCode(prompt, { lang });
    assert.equal(parsed.status, 'ok', `${prompt}: ${parsed.reason} ${parsed.unmodelled || ''}`);
    assert.deepEqual(executeAST(parsed.ast, [input]), expected, prompt);
  }
});

test('NL2Code: Arabic quantifiers, clitic forms, and zero threshold parse without losing intent', () => {
  const cases = [
    ['قم بـ أوجد كل قيمة موجبة شكرا', 'ar', [-2, 0, 1, 4], [1, 4]],
    ['قم بـ أوجد حاصل جمع العناصر الأكبر من الصفر شكرا', 'ar', [-2, 0, 1, 4], 5],
    ['من فضلك احتفظ بالقيم الفردية من فضلك', 'ar', [1, 2, 3, 4], [1, 3]],
    ['من فضلك احسب مجموع الأعداد في القائمة من فضلك', 'ar', [1, 2, 3], 6],
    ['please get the arithmetic mean of the list please', 'en', [2, 4, 6], 4]
  ];
  for (const [prompt, lang, input, expected] of cases) {
    const parsed = parseNLToCode(prompt, { lang });
    assert.equal(parsed.status, 'ok', `${prompt}: ${parsed.reason} ${parsed.unmodelled || ''}`);
    assert.deepEqual(executeAST(parsed.ast, [input]), expected, prompt);
  }
});

test('NL2Code Round 2: unsupported compositions abstain and cardinal selections are exact', () => {
  for (const prompt of ['sum of numbers between one and five', 'sum of each number without zero']) {
    const result = parseNLToCode(prompt, { lang: 'en' });
    assert.equal(result.status, 'abstain', `${prompt} must not be approximated`);
    assert.ok(result.unmodelled?.length || result.reason, `${prompt} must report the unsupported phrase`);
  }
  const firstThree = parseNLToCode('first 3 numbers', { lang: 'en' });
  assert.equal(firstThree.status, 'ok');
  assert.deepEqual(executeAST(firstThree.ast, [[9, 8, 7, 6]]), [9, 8, 7]);
});

test('NL2Code Round 2: 840-prompt corpus holds out 20 complete operations and evaluates in both languages', () => {
  const file = path.join(ROOT_DIR, 'bench/nl2code-round2-corpus.json');
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  assert.equal(data.items.length, 840);
  assert.equal(data.operationCount, 60);
  assert.equal(data.heldOutOperationCount, 20);
  const trainOps = new Set(data.items.filter(x => x.split === 'train' || x.split === 'dev').map(x => x.operation));
  const testOps = new Set(data.items.filter(x => x.split === 'test').map(x => x.operation));
  assert.equal(testOps.size, 20);
  assert.equal([...testOps].some(x => trainOps.has(x)), false);
  const stats = { en: { total: 0, solved: 0, wrong: 0, abstained: 0 }, ar: { total: 0, solved: 0, wrong: 0, abstained: 0 } };
  for (const item of data.items.filter(x => x.split === 'test')) {
    const bucket = stats[item.lang]; bucket.total++;
    const result = parseNLToCode(item.prompt, { lang: item.lang });
    if (result.status !== 'ok') { bucket.abstained++; continue; }
    const pass = item.hidden.every(h => {
      try { return deepEqual(executeAST(result.ast, h.input), h.output); } catch { return false; }
    });
    if (pass) bucket.solved++; else bucket.wrong++;
  }
  console.log('Round 2 held-out NL2Code:', JSON.stringify(stats));
  for (const lang of ['en', 'ar']) {
    const b = stats[lang], attempts = b.solved + b.wrong;
    assert.ok(attempts === 0 || b.wrong / attempts <= 0.02, `${lang} wrong-with-confidence must be <=2%`);
  }
  assert.ok(stats.en.solved / stats.en.total >= 0.40);
  assert.ok(stats.ar.solved / stats.ar.total >= 0.30);
});

test('NL2Code post-freeze set is evaluated after a recorded production-code freeze', () => {
  const freeze = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'bench/results/round2-code-freeze.json'), 'utf8'));
  const digestInput = freeze.entries.map(x => `${x.path} ${x.sha256}`).join('\n');
  assert.equal(crypto.createHash('sha256').update(digestInput).digest('hex'), freeze.digest);
  for (const entry of freeze.entries) {
    const bytes = fs.readFileSync(path.join(ROOT_DIR, entry.path));
    assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'), entry.sha256, `frozen file changed: ${entry.path}`);
  }
  const dataset = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'bench/nl2code-postfreeze-set.json'), 'utf8'));
  const result = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'bench/results/nl2code-postfreeze-eval.json'), 'utf8'));
  assert.equal(dataset.codeFreezeDigest, freeze.digest);
  assert.equal(result.codeFreezeDigest, freeze.digest);
  assert.equal(result.metrics.en.total, 10);
  assert.equal(result.metrics.ar.total, 10);
  assert.ok(result.metrics.en.solved / 10 >= 0.40);
  assert.ok(result.metrics.ar.solved / 10 >= 0.30);
  assert.equal(result.metrics.en.wrong + result.metrics.ar.wrong, 0);
});
