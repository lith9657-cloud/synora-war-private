/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * CLI export destination policy.
 *
 * The export may never write inside the package - not into the package root, not
 * into the source tree, not through a relative path or a `..` traversal, and not
 * into the live state directory.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const CLI = path.join(ROOT, 'bin/synora');

function runCli(args, opts = {}) {
  return spawnSync(process.execPath, [CLI, ...args], {
    encoding: 'utf8',
    cwd: opts.cwd || os.tmpdir(),
    env: { ...process.env, ...(opts.env || {}) }
  });
}

function packageDigest() {
  const hash = crypto.createHash('sha256');
  const walk = dir => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.isFile()) hash.update(path.relative(ROOT, full)).update(fs.readFileSync(full));
    }
  };
  walk(ROOT);
  return hash.digest('hex');
}

test('CLI export: --out writes to an absolute path outside the package', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-export-'));
  const dest = path.join(dir, 'export.json');
  const result = runCli(['export', '--out', dest]);
  assert.equal(result.status, 0, result.stderr);
  assert.ok(fs.existsSync(dest), 'the export file must exist');
  const payload = JSON.parse(fs.readFileSync(dest, 'utf8'));
  assert.ok(typeof payload.exportedAt === 'string');
  assert.ok(Array.isArray(payload.skills));
});

test('CLI export: a positional destination is accepted', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-export-'));
  const dest = path.join(dir, 'positional.json');
  const result = runCli(['export', dest]);
  assert.equal(result.status, 0, result.stderr);
  assert.ok(fs.existsSync(dest));
});

test('CLI export: a relative path is resolved and never lands inside the package', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-export-'));
  const result = runCli(['export', 'relative-export.json'], { cwd: dir });
  assert.equal(result.status, 0, result.stderr);
  assert.ok(fs.existsSync(path.join(dir, 'relative-export.json')));
  assert.equal(fs.existsSync(path.join(ROOT, 'relative-export.json')), false);
});

test('CLI export: writing inside the package root is refused', () => {
  const dest = path.join(ROOT, 'export-should-not-exist.json');
  const result = runCli(['export', '--out', dest]);
  assert.notEqual(result.status, 0, 'the export must fail');
  assert.match(result.stderr + result.stdout, /refusing to write the export inside the package root/);
  assert.equal(fs.existsSync(dest), false);
});

test('CLI export: a traversal path that resolves back into the package is refused', () => {
  const dest = path.join(ROOT, '..', path.basename(ROOT), 'traversal-export.json');
  const result = runCli(['export', '--out', dest]);
  assert.notEqual(result.status, 0, 'the export must fail');
  assert.match(result.stderr + result.stdout, /refusing to write the export inside the package root/);
  assert.equal(fs.existsSync(dest), false);
});

test('CLI export: writing into an audited package directory is refused', () => {
  const dest = path.join(ROOT, 'audit', 'export-should-not-exist.json');
  const result = runCli(['export', '--out', dest]);
  assert.notEqual(result.status, 0, 'the export must fail');
  assert.match(result.stderr + result.stdout, /refusing to write the export/);
  assert.equal(fs.existsSync(dest), false);
});

test('CLI export: an existing destination is not overwritten unless --force is given', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-export-'));
  const dest = path.join(dir, 'existing.json');
  fs.writeFileSync(dest, '{"sentinel":true}');
  const refused = runCli(['export', '--out', dest]);
  assert.notEqual(refused.status, 0, 'an existing destination must be refused');
  assert.match(refused.stderr + refused.stdout, /already exists/);
  assert.equal(fs.readFileSync(dest, 'utf8'), '{"sentinel":true}');

  const forced = runCli(['export', '--out', dest, '--force']);
  assert.equal(forced.status, 0, forced.stderr);
  assert.notEqual(fs.readFileSync(dest, 'utf8'), '{"sentinel":true}');
});

test('CLI export: a failed export leaves every package file unchanged', () => {
  const before = packageDigest();
  runCli(['export', '--out', path.join(ROOT, 'must-not-appear.json')]);
  runCli(['export', '--out', path.join(ROOT, 'audit', 'must-not-appear.json')]);
  const after = packageDigest();
  assert.equal(after, before, 'a refused export must not modify the package');
});
