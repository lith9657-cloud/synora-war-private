/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Typed-span extraction tests.
 *
 * Every corpus text in this file is written for this test suite only. None of it
 * comes from `bench/qa-round2-dataset.json` or from any other benchmark file, so a
 * regression cannot be hidden by the benchmark text.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { KnowledgeStore } from '../../synora-v5/knowledge/store.mjs';
import { detectQuestionType, extractTypedSpan } from '../../synora-v5/knowledge/answer-extractor.mjs';

const CORPUS = [
  {
    id: 't-en-1',
    title: 'Harbour Ledger',
    text: 'The Greywater Ledger was founded by Ada Renwick in 1873. The Greywater Ledger is located in Port Alder. The Greywater Ledger is run by the Alder Trust. The Greywater Ledger holds 412 volumes.'
  },
  {
    id: 't-en-2',
    title: 'Tramway Register',
    text: 'Tramway number 9 was established by the Harbour Board in 1902. The journey from the quay to the northern depot takes 45 minutes.'
  },
  {
    id: 't-ar-1',
    title: 'سجل الميناء',
    text: 'تأسس سجل الميناء على يد ليلى منصور عام 1911. سجل الميناء يقع في مرفأ الشمال. تدار سجل الميناء مؤسسة المرفأ.'
  },
  {
    id: 't-ar-2',
    title: 'سجل الترامواي',
    text: 'تأسس الترامواي رقم 9 على يد مجلس الميناء عام 1902. تستغرق الرحلة من الرصيف إلى المحطة الشمالية 45 دقيقة.'
  },
  {
    id: 't-ar-3',
    title: 'أرشيف قديم',
    text: 'أنشأ سالم حداد أرشيف قاسم عام 1955.'
  },
  {
    id: 't-en-3',
    title: 'Silent Record',
    text: 'The Silent Record was founded by an unknown hand. Nothing else is known about its founder.'
  },
  {
    id: 't-en-4',
    title: 'Founders Register',
    text: 'Elias Marlow created the Thornbury Index in 1921. The Thornbury Index is located in Thornbury.'
  }
];

const store = new KnowledgeStore();
for (const doc of CORPUS) store.ingestDocument(doc);

function spanOf(question, docId) {
  const doc = CORPUS.find(d => d.id === docId);
  const text = doc.text;
  const re = /[^.!?؟\n]+(?:[.!?؟]+|$)/gu;
  const found = [];
  let m;
  while ((m = re.exec(text))) {
    const sentence = m[0].trim();
    const offset = m.index + m[0].search(/\S|$/);
    const span = extractTypedSpan(question, sentence, offset);
    if (span) found.push({ span, sentence, doc });
  }
  if (!found.length) return null;
  const numeric = ['duration', 'quantity', 'height', 'date'].includes(detectQuestionType(question));
  found.sort((a, b) => (numeric ? b.span.text.length - a.span.text.length : a.span.start - b.span.start));
  return found[0];
}

function assertSpan(text, expected) {
  assert.ok(text, 'a span must be produced');
  assert.equal(text.text, expected);
  assert.ok(text.end > text.start);
  assert.equal(text.start + text.text.length, text.end, 'offsets must match the span text');
  return text;
}

test('question typing covers the documented English and Arabic categories', () => {
  assert.equal(detectQuestionType('Who established the Greywater Ledger?'), 'person');
  assert.equal(detectQuestionType('Who founded the Greywater Ledger?'), 'person');
  assert.equal(detectQuestionType('Name the founder of the Greywater Ledger.'), 'person');
  assert.equal(detectQuestionType('In which year was the Greywater Ledger founded?'), 'date');
  assert.equal(detectQuestionType('What year was the Greywater Ledger founded?'), 'date');
  assert.equal(detectQuestionType('When was the Greywater Ledger established?'), 'date');
  assert.equal(detectQuestionType('How long does the journey take?'), 'duration');
  assert.equal(detectQuestionType('How much time does the journey take?'), 'duration');
  assert.equal(detectQuestionType('Where is the Greywater Ledger located?'), 'place');
  assert.equal(detectQuestionType('Which organization runs the Greywater Ledger?'), 'organization');
  assert.equal(detectQuestionType('How many volumes does the Greywater Ledger hold?'), 'quantity');

  assert.equal(detectQuestionType('من أسس سجل الميناء؟'), 'person');
  assert.equal(detectQuestionType('على يد من تأسس سجل الميناء؟'), 'person');
  assert.equal(detectQuestionType('في أي عام تأسس سجل الميناء؟'), 'date');
  assert.equal(detectQuestionType('متى تأسس سجل الميناء؟'), 'date');
  assert.equal(detectQuestionType('كم تستغرق الرحلة؟'), 'duration');
  assert.equal(detectQuestionType('أين يقع سجل الميناء؟'), 'place');
  assert.equal(detectQuestionType('أي منظمة تدار سجل الميناء؟'), 'organization');
  assert.equal(detectQuestionType('كم orphان record there are?'), 'quantity');
});

test('English passive voice: the agent follows the marker, not the entity', () => {
  const s = spanOf('Who established the Greywater Ledger?', 't-en-1');
  assertSpan(s.span, 'Ada Renwick');
  assert.equal(s.span.type, 'person');
  assert.equal(s.doc.text.slice(s.span.start, s.span.end), 'Ada Renwick');
});

test('English active voice: the agent precedes the verb', () => {
  const s = spanOf('Who created the Thornbury Index?', 't-en-4');
  assertSpan(s.span, 'Elias Marlow');
  assert.equal(s.span.type, 'person');
});

test('Arabic passive voice with an agent marker never answers with the entity', () => {
  const s = spanOf('على يد من تأسس سجل الميناء؟', 't-ar-1');
  assertSpan(s.span, 'ليلى منصور');
  assert.notEqual(s.span.text, 'سجل');
  assert.equal(s.doc.text.slice(s.span.start, s.span.end), 'ليلى منصور');
});

test('Arabic active voice answers with the person, not the archive', () => {
  const s = spanOf('من أنشأ أرشيف قاسم؟', 't-ar-3');
  assertSpan(s.span, 'سالم حداد');
});

test('dates are typed spans in English and Arabic', () => {
  const en = spanOf('In which year was the Greywater Ledger founded?', 't-en-1');
  assertSpan(en.span, '1873');
  assert.equal(en.span.type, 'date');

  const ar = spanOf('في أي عام تأسس سجل الميناء؟', 't-ar-1');
  assertSpan(ar.span, '1911');
  assert.equal(ar.span.type, 'date');
});

test('durations are typed spans, including numbers written as words', () => {
  const en = spanOf('How long does the journey take?', 't-en-2');
  assertSpan(en.span, '45 minutes');
  assert.equal(en.span.type, 'duration');

  const ar = spanOf('كم تستغرق الرحلة؟', 't-ar-2');
  assertSpan(ar.span, '45 دقيقة');
  assert.equal(ar.span.type, 'duration');
});

test('quantities and organizations are typed spans', () => {
  const qty = spanOf('How many volumes does the Greywater Ledger hold?', 't-en-1');
  assertSpan(qty.span, '412 volumes');
  assert.equal(qty.span.type, 'quantity');

  const org = spanOf('Which organization runs the Greywater Ledger?', 't-en-1');
  assertSpan(org.span, 'Alder Trust');
  assert.equal(org.span.type, 'organization');
});

test('the store answers from the corpus and never invents an entity', () => {
  const who = store.answerQuestion('Who established the Greywater Ledger?');
  assert.equal(who.status, 'answered');
  assert.equal(who.answer, 'Ada Renwick');
  assert.equal(CORPUS.find(d => d.id === who.span.sourceId).text.slice(who.span.start, who.span.end), 'Ada Renwick');

  const year = store.answerQuestion('In which year was the Greywater Ledger founded?');
  assert.equal(year.status, 'answered');
  assert.equal(year.answer, '1873');

  const ar = store.answerQuestion('على يد من تأسس سجل الميناء؟');
  assert.equal(ar.status, 'answered');
  assert.equal(ar.answer, 'ليلى منصور');
  assert.equal(CORPUS.find(d => d.id === ar.span.sourceId).text.slice(ar.span.start, ar.span.end), 'ليلى منصور');

  const duration = store.answerQuestion('How long does the journey take?');
  assert.equal(duration.status, 'answered');
  assert.equal(duration.answer, '45 minutes');
});

test('a question without evidence abstains instead of hallucinating', () => {
  const unknown = store.answerQuestion('Who established the Midnight Lighthouse?');
  assert.equal(unknown.status, 'abstain');
  assert.equal(unknown.answer, undefined);

  const unknownYear = store.answerQuestion('In which year was the Midnight Lighthouse founded?');
  assert.equal(unknownYear.status, 'abstain');
});

test('a sentence without a named agent does not produce a person', () => {
  const s = spanOf('Who established the Silent Record?', 't-en-3');
  assert.ok(!s || s.span.text !== 'Silent Record', 'the entity must never be returned as the person');
});
