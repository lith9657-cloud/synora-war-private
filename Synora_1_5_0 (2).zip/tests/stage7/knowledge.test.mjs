/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { KnowledgeStore } from '../../synora-v5/knowledge/store.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '../..');

test('Knowledge Store: 0 Hallucination Rate by construction & grounded QA evaluation', () => {
  const qaFile = path.join(ROOT_DIR, 'bench/qa-dataset.json');
  assert.ok(fs.existsSync(qaFile), 'QA dataset must exist');

  const dataset = JSON.parse(fs.readFileSync(qaFile, 'utf-8'));
  const store = new KnowledgeStore();

  for (const doc of dataset.corpus) {
    store.ingestDocument(doc);
  }

  let answerableCount = 0;
  let answerableCorrect = 0;
  let unanswerableCount = 0;
  let unanswerableAbstained = 0;
  let conflictCount = 0;
  let conflictDetected = 0;
  let hallucinations = 0;

  for (const q of dataset.questions) {
    const res = store.answerQuestion(q.question);

    // Rule: Any answer produced MUST have a non-empty sourceId that exists in the ingested corpus
    if (res.status === 'answered') {
      const hasValidSource = Array.isArray(res.sourceIds) &&
        res.sourceIds.length > 0 &&
        res.sourceIds.every(id => dataset.corpus.some(c => c.id === id));

      if (!hasValidSource) {
        hallucinations++;
      }
    }

    if (q.type === 'answerable') {
      answerableCount++;
      if (res.status === 'answered') {
        const matches = q.expectedAnswers.some(exp => res.answer.includes(exp));
        if (matches) answerableCorrect++;
      }
    } else if (q.type === 'unanswerable') {
      unanswerableCount++;
      if (res.status === 'abstain') {
        unanswerableAbstained++;
      } else {
        // Answered an unanswerable question = hallucination / ungrounded
        hallucinations++;
      }
    } else if (q.type === 'conflict') {
      conflictCount++;
      if (res.status === 'conflict') {
        conflictDetected++;
      }
    }
  }

  console.log(`Knowledge Evaluation:`);
  console.log(`Answerable Accuracy: ${answerableCorrect}/${answerableCount} (${((answerableCorrect / answerableCount) * 100).toFixed(1)}%)`);
  console.log(`Unanswerable Abstention: ${unanswerableAbstained}/${unanswerableCount} (${((unanswerableAbstained / unanswerableCount) * 100).toFixed(1)}%)`);
  console.log(`Conflict Detection: ${conflictDetected}/${conflictCount} (${((conflictDetected / conflictCount) * 100).toFixed(1)}%)`);
  console.log(`Hallucinations: ${hallucinations}`);

  // Strict acceptance criteria from §6:
  // 1. Hallucination rate MUST BE 0 by construction
  assert.equal(hallucinations, 0, 'Hallucination rate must be 0 by construction');

  // 2. High exact/contains accuracy on answerable
  assert.ok(answerableCorrect / answerableCount >= 0.85, 'Answerable accuracy must be >= 85%');

  // 3. High abstention recall on unanswerable
  assert.ok(unanswerableAbstained / unanswerableCount >= 0.90, 'Unanswerable abstention recall must be >= 90%');
});

test('Round 2 QA: 400 fictional questions require minimal source spans, abstention, and conflict reporting', () => {
  const dataset = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'bench/qa-round2-dataset.json'), 'utf8'));
  assert.equal(dataset.questions.length, 400);
  assert.ok(dataset.questions.filter(q => q.type === 'unanswerable').length / 400 >= 0.25);
  assert.ok(dataset.questions.filter(q => q.type === 'conflict').length / 400 >= 0.10);
  const store = new KnowledgeStore();
  dataset.corpus.forEach(doc => store.ingestDocument(doc));
  const metrics = { correct: 0, wrong: 0, hallucinated: 0, abstainedCorrect: 0, abstainedWrong: 0, conflicts: 0 };
  for (const q of dataset.questions) {
    const result = store.answerQuestion(q.question);
    if (q.type === 'answerable') {
      const validSpan = result.span && dataset.corpus.some(doc => doc.id === result.span.sourceId && doc.text.slice(result.span.start, result.span.end) === result.answer);
      if (result.status === 'answered' && validSpan && q.expectedAnswers.some(x => result.answer.toLowerCase().includes(x.toLowerCase()))) metrics.correct++;
      else if (result.status === 'answered') { metrics.wrong++; metrics.hallucinated++; }
      else metrics.abstainedWrong++;
    } else if (q.type === 'unanswerable') {
      if (result.status === 'abstain') metrics.abstainedCorrect++;
      else { metrics.wrong++; metrics.hallucinated++; }
    } else if (result.status === 'conflict' && result.answers.length >= 2 && result.sourceIds.length >= 2) metrics.conflicts++;
    else if (result.status === 'abstain') metrics.abstainedCorrect++;
    else metrics.wrong++;
  }
  assert.deepEqual(metrics, { correct: 240, wrong: 0, hallucinated: 0, abstainedCorrect: 120, abstainedWrong: 0, conflicts: 40 });
});

test('Round 2 QA: who-established synonym returns a minimal exact span with offsets', () => {
  const store = new KnowledgeStore();
  const text = 'The fictional Meridian Archive was founded by Mira Vale in 1842.';
  store.ingestDocument({ id: 'fiction-1', text });
  const result = store.answerQuestion('Who established the Meridian Archive?');
  assert.equal(result.status, 'answered');
  assert.equal(result.answer, 'Mira Vale');
  assert.equal(text.slice(result.span.start, result.span.end), result.answer);
});
