/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Release versioning is single sourced. A conflicting version string anywhere in the
 * release surfaces must fail the build.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { VERSION, RELEASE_ARCHIVE, ARCHIVE_ROOT, RELEASE_STATUS } from '../../synora-v5/version.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const read = rel => fs.readFileSync(path.join(ROOT, rel), 'utf8');

test('the release version is a unique semantic version', () => {
  assert.match(VERSION, /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/);
  assert.equal(RELEASE_ARCHIVE, `Synora_WAR_v${VERSION.replace(/\./g, '_')}_FINAL.zip`);
  assert.equal(ARCHIVE_ROOT, `Synora_WAR_v${VERSION.replace(/\./g, '_')}`);
  assert.ok(['FINAL', 'CHECKPOINT'].includes(RELEASE_STATUS));
});

test('package.json carries exactly the release version', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.version, VERSION);
});

test('the release documents carry the release version as their headline', () => {
  for (const doc of ['REPORT.md', 'PROGRESS.md']) {
    const text = read(doc);
    const headline = text.split('\n').find(line => line.startsWith('# '));
    assert.ok(headline && headline.includes(VERSION), `${doc} must start with version ${VERSION}`);
  }
  // The changelog keeps the history of the older releases, but its newest heading
  // must be the current release.
  const changelog = read('CHANGELOG.md');
  const heading = changelog.split('\n').find(line => line.startsWith('# '));
  assert.ok(heading && heading.includes(VERSION), `CHANGELOG.md must start with version ${VERSION}`);
});

test('the CLI reports the release version', () => {
  const text = read('bin/synora');
  assert.ok(text.includes('synora-v5/version.mjs'), 'the CLI must read the single version source');
  assert.ok(text.includes("case 'version'"), 'the CLI must expose a version command');
});

test('the package manifest records the release version', async () => {
  const { buildManifest } = await import('../../scripts/manifest-metadata.mjs');
  const meta = buildManifest();
  assert.equal(meta.version, VERSION);
  assert.equal(meta.status, RELEASE_STATUS);
  assert.equal(meta.archiveRoot, ARCHIVE_ROOT);
  const manifest = JSON.parse(read('audit/package-manifest.json'));
  assert.equal(manifest.release.version, VERSION, 'the built manifest must carry the release version');
  assert.equal(manifest.release.status, RELEASE_STATUS);
});

test('no conflicting version string survives in the release surfaces', () => {
  // Machine surfaces must carry exactly one version.
  for (const surface of ['package.json', 'bin/synora', 'scripts/build-manifest.mjs',
    'scripts/manifest-metadata.mjs', 'synora-v5/version.mjs']) {
    const text = read(surface);
    for (const match of text.matchAll(/Synora[_ ]WAR[_ ]v?(\d+\.\d+\.\d+)/gi)) {
      assert.equal(match[1], VERSION, `${surface} advertises version ${match[1]} but the release is ${VERSION}`);
    }
  }
  // Documents may mention earlier releases, but only in an explicitly historical line.
  for (const doc of ['REPORT.md', 'PROGRESS.md']) {
    for (const line of read(doc).split('\n')) {
      for (const match of line.matchAll(/Synora[_ ]WAR[_ ]v?(\d+\.\d+\.\d+)/gi)) {
        if (match[1] === VERSION) continue;
        assert.match(line, /previous|prior|earlier|up from|released/i,
          `${doc} mentions version ${match[1]} without marking it as an earlier release`);
      }
    }
  }
});

test('the benchmark and evaluation artifacts carry the release version', () => {
  for (const artifact of ['bench/results/pbe-round2-eval.json', 'bench/results/external-final.json']) {
    const data = JSON.parse(read(artifact));
    const version = data.releaseVersion || data.environment?.releaseVersion;
    assert.equal(version, VERSION, `${artifact} must carry the release version`);
  }
});
