/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { runInWorkerSandbox } from '../../synora-v5/security/sandbox.mjs';

test('Hostile Sandbox: Infinite loop is terminated cleanly with SIGKILL timeout', async () => {
  const code = 'while(true) {}';
  const res = await runInWorkerSandbox(code, [], { timeoutMs: 500 });
  assert.ok(res.status === 'timeout' || res.status === 'killed', `Expected timeout/killed, got ${res.status}`);
});

test('Hostile Sandbox: Memory bomb is stopped by memory cap', async () => {
  const code = 'const a = []; while(true) a.push(new Array(1000000).fill("A"));';
  const res = await runInWorkerSandbox(code, [], { timeoutMs: 1500, memoryCapMb: 32 });
  assert.ok(res.status === 'killed' || res.status === 'timeout' || res.status === 'crash', `Expected termination, got ${res.status}`);
});

test('Hostile Sandbox: Deep recursion stack overflow fails safely', async () => {
  const code = 'function f() { return f(); } return f();';
  const res = await runInWorkerSandbox(code, [], { timeoutMs: 1000 });
  assert.equal(res.status, 'error');
  assert.match(res.error, /Maximum call stack size exceeded|stack/i);
});

test('Hostile Sandbox: Prototype pollution does not escape into main process', async () => {
  const code = 'Object.prototype.polluted = "YES"; return Object.prototype.polluted;';
  const res = await runInWorkerSandbox(code, [], { timeoutMs: 1000 });
  // Main process prototype must remain unpolluted
  assert.equal({}.polluted, undefined, 'Main process prototype must NOT be polluted');
});

test('Hostile Sandbox: Direct require/fs/process access attempts are forbidden', async () => {
  const code = 'return typeof fs;';
  const res = await runInWorkerSandbox(code, [], { timeoutMs: 1000 });
  assert.equal(res.status, 'ok');
  assert.equal(res.result, 'undefined');
});

test('Hostile Sandbox: Safe computation succeeds normally', async () => {
  const code = 'return args[0] * 2 + 10;';
  const res = await runInWorkerSandbox(code, [5], { timeoutMs: 1000 });
  assert.equal(res.status, 'ok');
  assert.equal(res.result, 20);
});

test('Hostile Sandbox: process, constructor escape, filesystem and dynamic imports are unavailable', async () => {
  const hiddenProcess = await runInWorkerSandbox('return typeof process;', [5], { timeoutMs: 1000 });
  assert.equal(hiddenProcess.status, 'ok');
  assert.equal(hiddenProcess.result, 'undefined');
  for (const code of [
    'return args.constructor.constructor("return process")();',
    'return await import("node:fs").then(m => m.readFileSync("/etc/passwd", "utf8"));'
  ]) {
    const res = await runInWorkerSandbox(code, [5], { timeoutMs: 1000 });
    assert.notEqual(res.status, 'ok', `Hostile probe unexpectedly succeeded: ${code}`);
  }
});

test('Hostile Sandbox: Function, AsyncFunction, and GeneratorFunction constructor paths cannot evaluate code', async () => {
  const probes = [
    'return Function("return process")();',
    'return Object.getPrototypeOf(async function(){}).constructor("return process")();',
    'return Object.getPrototypeOf(function*(){}).constructor("return process")().next().value;'
  ];
  for (const code of probes) {
    const result = await runInWorkerSandbox(code, [], { timeoutMs: 1000 });
    assert.notEqual(result.status, 'ok', `constructor escape succeeded: ${code}`);
  }
});

test('Hostile Sandbox: globalThis introspection and accessor/proxy abuse cannot reach host process', async () => {
  for (const code of [
    'return typeof globalThis.process;',
    'const x = new Proxy({}, { get(){ return process; } }); return x.secret;',
    'const x = {}; Object.defineProperty(x, "boom", { get(){ return process; } }); return x.boom;'
  ]) {
    const result = await runInWorkerSandbox(code, [], { timeoutMs: 1000 });
    assert.ok(result.status === 'ok' || result.status === 'error');
    if (result.status === 'ok') assert.equal(result.result, 'undefined');
  }
});

test('Hostile Sandbox: catastrophic regular-expression work is terminated within its budget', async () => {
  const result = await runInWorkerSandbox('const re = /(a+)+$/; return re.test("a".repeat(200000) + "!");', [], { timeoutMs: 250 });
  assert.ok(['timeout', 'killed', 'crash'].includes(result.status), `expected bounded termination, got ${result.status}`);
});
