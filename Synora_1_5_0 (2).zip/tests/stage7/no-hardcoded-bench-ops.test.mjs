import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const productionFiles = [
  'synora-v5/synthesis/synthesize.mjs',
  'synora-v5/nl2code/grammar.mjs'
];
const forbidden = [
  /\bprime(?:s|ness)?\b/i,
  /\bfibonacci\b/i,
  /\bgcd\b/i,
  /\bcollatz\b/i,
  /\bhumanEval\b/i,
  /\bmbpp\b/i
];

test('synthesizer and NL2Code contain no benchmark-operation reference implementations', () => {
  for (const file of productionFiles) {
    const source = fs.readFileSync(new URL(`../../${file}`, import.meta.url), 'utf8');
    for (const pattern of forbidden) assert.doesNotMatch(source, pattern, `${file} contains forbidden benchmark operation marker ${pattern}`);
  }
});
