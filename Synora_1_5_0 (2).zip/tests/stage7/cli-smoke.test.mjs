/** @license SPDX-License-Identifier: Apache-2.0 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const CLI = path.join(ROOT, 'bin/synora');

test('CLI smoke: ask, learn, ingest, export, import, doctor, eval, backup, restore, and start are spawned', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-cli-smoke-'));
  const dataDir = path.join(dir, 'data');
  const env = { ...process.env, SYNORA_DATA_DIR: dataDir, SYNORA_API_HOST: '127.0.0.1', SYNORA_API_PORT: '0', SYNORA_LEARNING_MEMORY: path.join(dataDir, 'memory.json'), SYNORA_DIGITAL_OBJECT_CORE: path.join(dataDir, 'core.json'), SYNORA_SKILL_APPLICATION_LEDGER: path.join(dataDir, 'applications.json') };
  const run = (args, timeout = 30000) => spawnSync(process.execPath, [CLI, ...args], { cwd: ROOT, env, encoding: 'utf8', timeout });

  const ask = run(['ask', 'sum of numbers']);
  assert.equal(ask.status, 0, ask.stderr);
  assert.match(ask.stdout, /"status": "ok"/);

  const doctor = run(['doctor']);
  assert.equal(doctor.status, 0, doctor.stderr);
  assert.match(doctor.stdout, /127\.0\.0\.1/);

  const examples = path.join(dir, 'examples.json');
  fs.writeFileSync(examples, JSON.stringify({
    training: [
      { input: [[1, 2, 3]], output: 6 }, { input: [[4, 5]], output: 9 },
      { input: [[10]], output: 10 }, { input: [[2, 2, 3]], output: 7 }, { input: [[0, 0, 0]], output: 0 }
    ],
    development: [
      { input: [[20, 30]], output: 50 }, { input: [[-1, 1]], output: 0 },
      { input: [[1, 1]], output: 2 }, { input: [[2, 1, 2]], output: 5 },
      { input: [[1, 2, 3, 4]], output: 10 }, { input: [[-2, -1]], output: -3 },
      { input: [[0]], output: 0 }, { input: [[1, 1, 1]], output: 3 }
    ]
  }));
  const learn = run(['learn', examples], 20000);
  assert.equal(learn.status, 0, learn.stderr || learn.stdout);
  assert.match(learn.stdout, /"found": true/);

  const corpus = path.join(dir, 'corpus.jsonl');
  fs.writeFileSync(corpus, JSON.stringify({ id: 'cli-doc', text: 'The Meridian Archive was founded by Mira Vale in 1842.' }) + '\n');
  const ingest = run(['ingest', corpus]);
  assert.equal(ingest.status, 0, ingest.stderr || ingest.stdout);
  assert.match(ingest.stdout, /Ingested 1 documents/);

  const exportFile = path.join(dir, 'export.json');
  const exp = run(['export', exportFile]);
  assert.equal(exp.status, 0, exp.stderr || exp.stdout);
  assert.ok(fs.existsSync(exportFile));
  const imp = run(['import', exportFile]);
  assert.equal(imp.status, 0, imp.stderr || imp.stdout);

  const evalFile = path.join(dir, 'eval.json');
  fs.writeFileSync(evalFile, JSON.stringify({ format: 'synora-eval/1', tasks: [{ id: 'cli-dialogue', track: 'dialogue', text: 'Explain an array.' }] }));
  const ev = run(['eval', evalFile]);
  assert.equal(ev.status, 0, ev.stderr || ev.stdout);
  assert.match(ev.stdout, /dialogue/);

  const backup = path.join(dir, 'backup');
  const bk = run(['backup', backup]);
  assert.equal(bk.status, 0, bk.stderr || bk.stdout);
  fs.writeFileSync(path.join(dataDir, 'marker.txt'), 'restore-test');
  const restore = run(['restore', backup, '--confirm']);
  assert.equal(restore.status, 0, restore.stderr || restore.stdout);
  assert.equal(fs.existsSync(path.join(dataDir, 'marker.txt')), false);

  const child = spawn(process.execPath, [CLI, 'start'], { cwd: ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] });
  let stdout = '';
  const ready = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error(`start did not become ready: ${stdout}`)); }, 8000);
    child.stdout.on('data', chunk => {
      stdout += chunk.toString();
      if (/Synora server running on http:\/\/127\.0\.0\.1:/.test(stdout)) { clearTimeout(timer); resolve(true); }
    });
    child.once('error', err => { clearTimeout(timer); reject(err); });
    child.once('exit', code => { if (code !== null && code !== 0) { clearTimeout(timer); reject(new Error(`start exited ${code}: ${stdout}`)); } });
  });
  assert.equal(ready, true);
  child.kill('SIGTERM');
  await new Promise(resolve => child.once('close', resolve));
  fs.rmSync(dir, { recursive: true, force: true });
});
