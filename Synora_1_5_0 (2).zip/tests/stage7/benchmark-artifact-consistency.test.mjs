import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseNLToCode } from '../../synora-v5/nl2code/grammar.mjs';
import { executeAST } from '../../synora-v5/nl2code/sanity-checks.mjs';
import { deepEqual } from '../../synora-v5/synthesis/dsl.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const readJson = rel => JSON.parse(fs.readFileSync(path.join(ROOT, rel), 'utf8'));

function score(items) {
  const out = { en: { total: 0, solved: 0, wrong: 0, abstained: 0 }, ar: { total: 0, solved: 0, wrong: 0, abstained: 0 } };
  for (const item of items) {
    const bucket = out[item.lang];
    bucket.total++;
    const result = parseNLToCode(item.prompt, { lang: item.lang });
    if (result.status !== 'ok' || !result.ast) { bucket.abstained++; continue; }
    let pass = true;
    for (const hidden of item.hidden) {
      try {
        if (!deepEqual(executeAST(result.ast, hidden.input), hidden.output)) { pass = false; break; }
      } catch { pass = false; break; }
    }
    if (pass) bucket.solved++; else bucket.wrong++;
  }
  return out;
}

test('Benchmark artifacts match the current evaluator exactly', () => {
  const corpus = readJson('bench/nl2code-round2-corpus.json');
  const heldout = score(corpus.items.filter(item => item.split === 'test'));
  const saved = readJson('bench/results/nl2code-round2-heldout.json').langs;
  assert.deepEqual(saved, heldout, 'saved held-out NL2Code result is stale or was produced by another evaluator');

  const postfreeze = readJson('bench/results/nl2code-postfreeze-eval.json');
  const dataset = readJson('bench/nl2code-postfreeze-set.json');
  const actual = score(dataset.tasks);
  assert.deepEqual(postfreeze.metrics, actual, 'saved post-freeze NL2Code result is stale or was produced by another evaluator');
  assert.equal(postfreeze.codeFreezeDigest, dataset.codeFreezeDigest);
});
