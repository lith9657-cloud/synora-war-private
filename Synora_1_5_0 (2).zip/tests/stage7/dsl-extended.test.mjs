/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { validateAst, evalAst, toSource, typeOfValue, deepEqual, conforms } from '../../synora-v5/synthesis/dsl.mjs';

const call = (f, ...a) => ({ k: 'call', f, a });
const inp = i => ({ k: 'in', i }), num = v => ({ k: 'const', v }), lam = body => ({ k: 'lam', body }), X = { k: 'x' };

const runSource = (ast, arity, args) => {
  const code = toSource(ast, arity).replace(/^export\s+function\s+solution/, 'function solution') + '\nsolution';
  const fn = new vm.Script(code).runInContext(vm.createContext(Object.create(null), { codeGeneration: { strings: false, wasm: false } }), { timeout: 200 });
  return vm.runInNewContext('fn(...args)', { fn, args: structuredClone(args) }, { timeout: 200 });
};

test('DSL Extended: Bounded iterate on pair computes fibonacci with parity', () => {
  // fst(iterate(a0, pair(0, 1), λ: pair(snd(x), add(fst(x), snd(x)))))
  const fibAst = call('fst', call('iterate', inp(0), call('pair', num(0), num(1)), lam(
    call('pair', call('snd', X), call('add', call('fst', X), call('snd', X)))
  )));

  validateAst(fibAst, 1);
  const src = toSource(fibAst, 1);

  const expectedFib = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
  for (let n = 0; n < expectedFib.length; n++) {
    const valInterp = evalAst(fibAst, [n]);
    const valCode = runSource(fibAst, 1, [n]);
    assert.equal(valInterp, expectedFib[n]);
    assert.equal(valCode, expectedFib[n]);
  }
});

test('DSL Extended: Bounded iterate computes GCD with Euclidean algorithm', () => {
  // gcd of pair using iteration
  // fst(iterate(15, pair(max2(a0, a1), min2(a0, a1)), λ: ite(eq(snd(x), 0), x, pair(snd(x), mod(fst(x), snd(x))))))
  const gcdAst = call('fst', call('iterate', num(15), call('pair', call('max2', inp(0), inp(1)), call('min2', inp(0), inp(1))), lam(
    call('ite', call('eq', call('snd', X), num(0)), X, call('pair', call('snd', X), call('mod', call('fst', X), call('snd', X))))
  )));

  validateAst(gcdAst, 2);
  const testCases = [
    [[12, 18], 6],
    [[7, 13], 1],
    [[100, 75], 25],
    [[9, 3], 3],
    [[8, 12], 4],
    [[20, 100], 20],
    [[6, 6], 6]
  ];

  for (const [[a, b], exp] of testCases) {
    const resInterp = evalAst(gcdAst, [a, b]);
    const resCode = runSource(gcdAst, 2, [a, b]);
    assert.equal(resInterp, exp, `GCD(${a}, ${b})`);
    assert.equal(resCode, exp, `GCD(${a}, ${b}) code`);
  }
});

test('DSL Extended: Numeric helpers parity (isqrt, pow, abs, cumsum)', () => {
  const ast = call('cumsum', inp(0));
  validateAst(ast, 1);
  assert.ok(deepEqual(evalAst(ast, [[1, 2, 3, 4]]), [1, 3, 6, 10]));
  assert.ok(deepEqual(runSource(ast, 1, [[1, 2, 3, 4]]), [1, 3, 6, 10]));

  const sqrtAst = call('isqrt', inp(0));
  validateAst(sqrtAst, 1);
  assert.equal(evalAst(sqrtAst, [25]), 5);
  assert.equal(evalAst(sqrtAst, [26]), 5);
  assert.equal(runSource(sqrtAst, 1, [25]), 5);
});
