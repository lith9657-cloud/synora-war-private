/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { runTask, computeAggregates } from '../../bench/external-eval.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

test('External Eval: Survives malformed task definition without crashing', async () => {
  const malformed = { id: 'malformed-01' };
  const res = await runTask(malformed);
  assert.equal(res.status, 'error');
  assert.ok(res.metrics.wallMs >= 0);
  assert.ok(res.metrics.cpuSeconds >= 0);
});

test('External Eval: Survives invalid null/string inputs', async () => {
  const res = await runTask(null);
  assert.equal(res.status, 'error');
});

test('External Eval: Computes aggregate metrics accurately', () => {
  const mockResults = [
    { track: 'pbe', status: 'solved', metrics: { wallMs: 10, cpuSeconds: 0.01, peakRssMb: 50 } },
    { track: 'pbe', status: 'wrong', metrics: { wallMs: 20, cpuSeconds: 0.02, peakRssMb: 55 } },
    { track: 'pbe', status: 'abstained', metrics: { wallMs: 5, cpuSeconds: 0.005, peakRssMb: 52 } }
  ];

  const agg = computeAggregates(mockResults);
  assert.equal(agg.overall.total, 3);
  assert.equal(agg.overall.solved, 1);
  assert.equal(agg.overall.wrong, 1);
  assert.equal(agg.overall.abstained, 1);
  assert.equal(agg.overall.coverage, 0.3333);
  assert.equal(agg.overall.selectiveAccuracy, 0.5);
  assert.equal(agg.overall.wrongWithConfidenceRate, 0.5);
  assert.equal(agg.byTrack.pbe.total, 3);
});

test('External Eval synora-eval/1: scores emitted JavaScript against args and catches a deliberately wrong expected result', async () => {
  const res = await runTask({
    id: 'fault-injection-wrong-solver', track: 'nl2code', lang: 'en',
    prompt: 'sum the numbers',
    hidden: [{ args: [[2, 3]], output: 999 }]
  });
  assert.equal(res.status, 'wrong');
  assert.equal(res.outcome, 'wrong_with_confidence');
  assert.match(res.details.emittedJavaScript, /function solution/);
});

test('External Eval synora-eval/1: dialogue is recorded for human review and excluded from automatic quality scores', async () => {
  const res = await runTask({ id: 'dialogue-review-only', track: 'dialogue', text: 'Please explain what a list is.' });
  assert.equal(res.status, 'recorded');
  const agg = computeAggregates([res]);
  assert.equal(agg.byTrack.dialogue.recorded, 1);
  assert.equal(agg.overall.total, 0);
});

test('External Eval synora-eval/1: answer pool arrays and object maps are both accepted', async () => {
  const { answerPoolEntries, isAcceptedPbeResult } = await import('../../bench/external-eval.mjs');
  assert.deepEqual(answerPoolEntries([{ input: [[1, 2]], output: 3 }]), [{ input: [[1, 2]], output: 3 }]);
  assert.deepEqual(answerPoolEntries({ '[[1,2]]': 3 }), [{ input: [[1, 2]], output: 3 }]);
  assert.deepEqual(answerPoolEntries([{ query: [[2, 3]], expected: 5 }]), [{ input: [[2, 3]], output: 5 }]);
  assert.equal(isAcceptedPbeResult({ found: false, candidateAst: { k: 'const', v: 7 } }), false);
  assert.equal(isAcceptedPbeResult({ found: true, ast: { k: 'const', v: 7 } }), true);
});

test('External Eval synora-eval/1: skill sequence requires explicit learn/apply and rejects supplied code', async () => {
  const res = await runTask({ id: 'skill-seq-code-injection', track: 'skill-seq', sequence: [
    { op: 'learn', id: 'fake', code: 'return 7', train: [{ input: [[1]], output: [1] }], dev: [{ input: [[2]], output: [2] }, { input: [[3]], output: [3] }] }
  ] });
  assert.equal(res.status, 'abstained');
});

test('External Eval synora-eval/1: shipped sample suite has at least 40 unique tasks across every track', async () => {
  const fs = await import('node:fs');
  const path = await import('node:path');
  const { fileURLToPath } = await import('node:url');
  const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
  const suite = JSON.parse(fs.readFileSync(path.join(root, 'bench/external-eval/sample-tasks.json'), 'utf8'));
  assert.equal(suite.format, 'synora-eval/1');
  assert.ok(suite.tasks.length >= 40);
  assert.deepEqual(new Set(suite.tasks.map(t => t.track)), new Set(['pbe','nl2code','abstain','qa','skill-seq','agent','dialogue']));
  assert.equal(new Set(suite.tasks.map(t => t.id)).size, suite.tasks.length);
});

test('External Eval CLI: --tasks consumes a synora-eval/1 file and writes the requested report path', async () => {
  const fs = await import('node:fs');
  const os = await import('node:os');
  const path = await import('node:path');
  const { spawnSync } = await import('node:child_process');
  const { fileURLToPath } = await import('node:url');
  const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-eval-cli-'));
  const tasks = path.join(dir, 'tasks.json');
  const out = path.join(dir, 'report.json');
  fs.writeFileSync(tasks, JSON.stringify({ format: 'synora-eval/1', suite: 'cli-smoke', tasks: [{ id: 'dialogue-smoke', track: 'dialogue', text: 'Explain a function.' }] }));
  const run = spawnSync(process.execPath, ['bench/external-eval.mjs', '--tasks', tasks, '--out', out], { cwd: root, encoding: 'utf8', timeout: 30000 });
  assert.equal(run.status, 0, run.stderr || run.stdout);
  assert.equal(JSON.parse(fs.readFileSync(out, 'utf8')).results[0].status, 'recorded');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('External Eval production scoring path contains no allowAmbiguous bypass or candidateAst acceptance', async () => {
  const fs = await import('node:fs');
  const path = await import('node:path');
  const { fileURLToPath } = await import('node:url');
  const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
  const source = fs.readFileSync(path.join(root, 'bench/external-eval.mjs'), 'utf8');
  assert.doesNotMatch(source, /allowAmbiguous/);
  assert.doesNotMatch(source, /synthRes\.candidateAst/);
});

test('External Eval PBE: ambiguous candidates never score as solved; only three pool queries are asked per round', async () => {
  const res = await runTask({
    id: 'pbe-ambiguous-identity', track: 'pbe',
    train: [
      { input: [[1, 2]], output: [1, 2] },
      { input: [[2, 3]], output: [2, 3] },
      { input: [[4, 5]], output: [4, 5] }
    ],
    dev: [
      { input: [[3, 4]], output: [3, 4] },
      { input: [[5, 6]], output: [5, 6] }
    ],
    answers: [], hidden: [{ input: [[8, 7]], output: [8, 7] }]
  }, { timeBudgetMs: 10000 });
  assert.equal(res.status, 'abstained');
  assert.ok(res.details.questionsAsked <= 9);
  assert.ok(res.details.rounds <= 3);
  assert.ok(res.details.questionsPerRound.length <= 3);
  assert.ok(res.details.questionsPerRound.every(n => n <= 3));
  assert.equal(res.details.questionsUnanswered, res.details.questionsAsked);
  assert.equal(res.details.ast, undefined);
});

test('External Eval QA: conflicting facts pass only when both minimal spans and distinct sources are verified', async () => {
  const corpus = [
    { id: 'lab-a', text: 'Distance Q1 is exactly 101 meters according to Survey Laboratory Alpha.' },
    { id: 'lab-b', text: 'Distance Q1 is exactly 203 meters according to Survey Laboratory Beta.' }
  ];
  const { runTask } = await import('../../bench/external-eval.mjs');
  const { KnowledgeStore } = await import('../../synora-v5/knowledge/store.mjs');
  const store = new KnowledgeStore(); corpus.forEach(d => store.ingestDocument(d));
  const extracted = store.answerQuestion('What is Distance Q1?');
  assert.equal(extracted.status, 'conflict');
  assert.ok(extracted.answers.every(x => x.span && corpus.some(d => d.id === x.span.sourceId && d.text.slice(x.span.start, x.span.end) === x.object)));
  const valid = await runTask({ id: 'conflict-valid', track: 'qa', conflicting: true, corpus, question: 'What is Distance Q1?' });
  assert.equal(valid.status, 'solved');
  assert.equal(valid.outcome, 'conflict_reported');
  assert.ok(new Set(extracted.answers.map(x => x.span.sourceId)).size >= 2);
});
