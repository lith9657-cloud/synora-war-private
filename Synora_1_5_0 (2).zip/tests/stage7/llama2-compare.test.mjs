/** @license SPDX-License-Identifier: Apache-2.0 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { scoreOutputs } from '../../bench/llama2-compare/score-outputs.mjs';

test('Llama comparison scorer executes generated JS in worker and requires exact QA spans', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-llama-score-'));
  const tasks = path.join(dir, 'tasks.json');
  const outputs = path.join(dir, 'outputs.jsonl');
  const corpus = [{ id: 'fiction', text: 'The fictional archive was founded by Mira Vale in 1842.' }];
  const start = corpus[0].text.indexOf('Mira Vale');
  const suite = { format: 'synora-eval/1', tasks: [
    { id: 'code-1', track: 'nl2code', hidden: [{ args: [[2, 3]], output: 5 }] },
    { id: 'qa-1', track: 'qa', corpus, question: 'Who founded the archive?', expectedAnswers: ['Mira Vale'] },
    { id: 'qa-2', track: 'qa', corpus, question: 'What colour is the tower?', unanswerable: true }
  ] };
  fs.writeFileSync(tasks, JSON.stringify(suite));
  fs.writeFileSync(outputs, [
    JSON.stringify({ id: 'code-1', output: 'function solution(a0) { return a0[0] + a0[1]; }' }),
    JSON.stringify({ id: 'qa-1', output: { status: 'answered', answer: 'Mira Vale', span: { source_id: 'fiction', start, end: start + 9 } } }),
    JSON.stringify({ id: 'qa-2', output: { status: 'abstain' } })
  ].join('\n') + '\n');
  const result = await scoreOutputs(tasks, outputs);
  assert.equal(result.scored, 3);
  assert.equal(result.solved, 3);
  assert.equal(result.wrong, 0);
  assert.equal(result.abstainedCorrect, 1);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('Llama comparison scorer rejects substring-only QA answers and unsupported code', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'synora-llama-reject-'));
  const tasks = path.join(dir, 'tasks.json');
  const outputs = path.join(dir, 'outputs.jsonl');
  const corpus = [{ id: 'd', text: 'The archive was founded by Mira Vale.' }];
  fs.writeFileSync(tasks, JSON.stringify({ tasks: [
    { id: 'q', track: 'qa', corpus, expectedAnswers: ['Mira Vale'] },
    { id: 'c', track: 'nl2code', hidden: [{ args: [[1, 2]], output: 3 }] }
  ] }));
  fs.writeFileSync(outputs, [
    JSON.stringify({ id: 'q', output: 'Mira Vale is the person mentioned.' }),
    JSON.stringify({ id: 'c', output: 'function solution(a0) { return 0; }' })
  ].join('\n') + '\n');
  const result = await scoreOutputs(tasks, outputs);
  assert.equal(result.wrong, 2);
  assert.equal(result.solved, 0);
  fs.rmSync(dir, { recursive: true, force: true });
});
