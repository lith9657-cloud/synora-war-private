/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * NL2Code Round 3: general compositions, held-out prompts, and fail-closed
 * behaviour for compositions the grammar does not model.
 *
 * Every prompt in this file is held out: the test below proves that none of
 * them occurs in the production lexicon or grammar source.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseNLToCode } from '../../synora-v5/nl2code/grammar.mjs';
import { executeAST } from '../../synora-v5/nl2code/sanity-checks.mjs';
import { deepEqual } from '../../synora-v5/synthesis/dsl.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');

const HELD_OUT = [
  // compound filters (two predicates, conjunctive)
  ['en', 'sum of the positive even numbers', [1, 2, 3, 4, 6], 12],
  ['en', 'total of the negative odd numbers', [-3, -2, -1, 1, 2], -4],
  ['ar', 'مجموع الأعداد الموجبة الزوجية', [1, 2, 3, 4, 6], 12],
  ['ar', 'حاصل جمع الأعداد السالبة الفردية', [-3, -2, -1, 1, 2], -4],
  // chained thresholds (two numeric constraints)
  ['en', 'count the numbers greater than three and less than ten', [1, 3, 5, 7, 12], 2],
  ['en', 'sum of the values at least two and at most eight', [1, 2, 5, 8, 9], 15],
  ['ar', 'عد الأعداد الأكبر من ثلاثة والأصغر من عشرة', [1, 3, 5, 7, 12], 2],
  // average over a filtered subset
  ['en', 'average of the even numbers', [1, 2, 3, 4, 6], 4],
  ['ar', 'متوسط الأعداد الزوجية', [1, 2, 3, 4, 6], 4],
  // distinct counts
  ['en', 'number of distinct values', [2, 2, 5, 5, 7], 3],
  ['ar', 'عدد القيم المميزة', [2, 2, 5, 5, 7], 3],
  // first / last after filtering
  ['en', 'first of the even numbers', [1, 2, 3, 4, 6], 2],
  ['en', 'last of the even numbers', [1, 2, 3, 4, 6], 6],
  ['ar', 'أول عنصر زوجي', [1, 2, 3, 4, 6], 2],
  // number words, zero and negative thresholds
  ['en', 'sum of the numbers greater than five', [1, 5, 6, 8], 14],
  ['en', 'sum of the numbers greater than negative five', [-9, -5, 0, 3], 3],
  ['en', 'count of the numbers less than zero', [-3, 0, 2], 1],
  ['ar', 'اجمع الاعداد الاكبر من خمسة', [1, 5, 6, 8], 14],
  ['ar', 'اجمع الاعداد الاكبر من سالب خمسة', [-9, -5, 0, 3], 3]
];

const MUST_ABSTAIN = [
  ['en', 'now sort them', 'contextual_followup_requires_state'],
  ['en', 'sum of those numbers', 'contextual_followup_requires_state'],
  ['en', 'and the average of it', 'contextual_followup_requires_state'],
  ['en', 'sum of the number of positive values', 'unsupported_nested_aggregation'],
  ['en', 'count the even or odd numbers', 'unsupported_disjunction'],
  ['ar', 'عد القيم الزوجية أو الفردية', 'unsupported_disjunction'],
  ['ar', 'الآن رتبهم', 'contextual_followup_requires_state']
];

test('NL2Code Round 3: held-out prompts do not leak into the production source', () => {
  const sources = ['synora-v5/nl2code/lexicon.mjs', 'synora-v5/nl2code/grammar.mjs']
    .map(rel => fs.readFileSync(path.join(ROOT, rel), 'utf8'));
  for (const [, prompt] of HELD_OUT) {
    for (const src of sources) {
      assert.equal(src.includes(prompt), false, `held-out prompt leaked into production source: ${prompt}`);
    }
  }
});

test('NL2Code Round 3: general compositions are parsed and executed correctly', () => {
  for (const [lang, prompt, input, expected] of HELD_OUT) {
    const parsed = parseNLToCode(prompt, { lang });
    assert.equal(parsed.status, 'ok', `${prompt}: ${parsed.reason} ${JSON.stringify(parsed.unmodelled || [])}`);
    let actual;
    try {
      actual = executeAST(parsed.ast, [input]);
    } catch (err) {
      assert.fail(`${prompt}: execution threw ${err.message}`);
    }
    assert.deepEqual(actual, expected, `${prompt} produced ${JSON.stringify(actual)}`);
  }
});

test('NL2Code Round 3: unsupported compositions abstain explicitly instead of guessing', () => {
  for (const [lang, prompt, reason] of MUST_ABSTAIN) {
    const parsed = parseNLToCode(prompt, { lang });
    assert.equal(parsed.status, 'abstain', `${prompt} must not produce a program`);
    assert.equal(parsed.reason, reason, `${prompt} must report ${reason}, got ${parsed.reason}`);
    assert.ok(Array.isArray(parsed.unmodelled) ? parsed.unmodelled.length > 0 : true);
  }
});

test('NL2Code Round 3: no qualifier is silently dropped in either language', () => {
  // Every Arabic and English qualifier phrase must survive into the program.
  const cases = [
    ['en', 'sum of the numbers less than five', [1, 2, 9], 3],
    ['en', 'sum of the numbers greater than five', [1, 2, 9], 9],
    ['ar', 'اجمع الأعداد الأقل من خمسة', [1, 2, 9], 3],
    ['ar', 'اجمع الأعداد الاكبر من خمسة', [1, 2, 9], 9]
  ];
  for (const [lang, prompt, input, expected] of cases) {
    const parsed = parseNLToCode(prompt, { lang });
    assert.equal(parsed.status, 'ok', `${prompt}: ${parsed.reason}`);
    assert.deepEqual(executeAST(parsed.ast, [input]), expected, prompt);
  }
});

test('NL2Code Round 3: the full 840-prompt corpus has no wrong-with-confidence answers', () => {
  const data = JSON.parse(fs.readFileSync(path.join(ROOT, 'bench/nl2code-round2-corpus.json'), 'utf8'));
  const stats = { en: { total: 0, solved: 0, wrong: 0, abstained: 0 }, ar: { total: 0, solved: 0, wrong: 0, abstained: 0 } };
  for (const item of data.items) {
    const bucket = stats[item.lang];
    bucket.total++;
    const parsed = parseNLToCode(item.prompt, { lang: item.lang });
    if (parsed.status !== 'ok') { bucket.abstained++; continue; }
    const pass = item.hidden.every(h => {
      try { return deepEqual(executeAST(parsed.ast, h.input), h.output); } catch { return false; }
    });
    if (pass) bucket.solved++; else bucket.wrong++;
  }
  assert.equal(stats.en.wrong, 0, 'EN wrong-with-confidence must be 0');
  assert.equal(stats.ar.wrong, 0, 'AR wrong-with-confidence must be 0');
  assert.ok(stats.en.solved / stats.en.total >= 0.80, `EN solved rate ${stats.en.solved}/${stats.en.total}`);
  assert.ok(stats.ar.solved / stats.ar.total >= 0.70, `AR solved rate ${stats.ar.solved}/${stats.ar.total}`);
});
