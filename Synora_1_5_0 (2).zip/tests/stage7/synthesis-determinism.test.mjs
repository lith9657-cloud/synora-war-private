/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * The synthesis budget is deterministic: the same (dataset, maxExpressions,
 * maxSize, seed) always yields the same status, reason, source and explored
 * count, and the wall clock never decides an outcome.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { synthesize } from '../../synora-v5/synthesis/synthesize.mjs';
import { DSL_VERSION } from '../../synora-v5/synthesis/dsl.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const DATASET = JSON.parse(fs.readFileSync(path.join(ROOT, 'bench/pbe-round2-dataset.json'), 'utf8'));

const OPERATIONS = ['reverse_list', 'unique_list', 'sort_list', 'length_list', 'reverse_string', 'lower_string', 'sum_list'];

function taskFor(operation) {
  const task = DATASET.tasks.find(t => t.operation === operation);
  assert.ok(task, `dataset must contain ${operation}`);
  return task;
}

function run(task, overrides = {}) {
  return synthesize({
    training: task.train,
    development: task.dev,
    maxExpressions: 60000,
    maxSize: 6,
    deterministicBudget: true,
    safetyTimeoutMs: 600000,
    ...overrides
  });
}

test('determinism: the same budget produces an identical result on every run', () => {
  for (const operation of OPERATIONS) {
    const task = taskFor(operation);
    const first = run(task);
    const second = run(task);
    assert.equal(second.found, first.found, `${operation}: found differs`);
    assert.equal(second.reason ?? null, first.reason ?? null, `${operation}: reason differs`);
    assert.equal(second.source ?? null, first.source ?? null, `${operation}: source differs`);
    assert.equal(second.explored, first.explored, `${operation}: explored count differs`);
    assert.equal(second.alternativeBehaviours ?? 0, first.alternativeBehaviours ?? 0, `${operation}: rival count differs`);
  }
});

test('determinism: the budget metadata records the full provenance of the search', () => {
  const task = taskFor('sort_list');
  const result = run(task);
  const budget = result.budget;
  assert.ok(budget, 'the result must carry the budget record');
  assert.equal(budget.mode, 'deterministic');
  assert.equal(budget.deterministic, true);
  assert.equal(budget.maxExpressions, 60000);
  assert.equal(budget.maxSize, 6);
  assert.equal(budget.seed, 1);
  assert.equal(budget.dslVersion, DSL_VERSION);
  assert.equal(budget.safetyTimeoutFired, false);
  assert.ok(Array.isArray(budget.lanes) && budget.lanes.length > 0, 'the lane allocation must be recorded');
  for (const lane of budget.lanes) {
    assert.ok(lane.tier, 'a lane must name its tier');
    assert.equal(typeof lane.maxExpressions, 'number');
    assert.equal(typeof lane.explored, 'number');
    assert.ok(lane.stoppedBy, 'a lane must record why it stopped');
  }
});

test('determinism: the wall clock does not decide the outcome', () => {
  const task = taskFor('unique_list');
  const generous = run(task, { safetyTimeoutMs: 600000 });
  const tight = run(task, { safetyTimeoutMs: 120000 });
  assert.equal(tight.budget.safetyTimeoutFired, false);
  assert.equal(tight.found, generous.found);
  assert.equal(tight.source, generous.source);
  assert.equal(tight.explored, generous.explored);
});

test('determinism: the expression budget is the binding constraint', () => {
  const task = taskFor('sum_list');
  const small = run(task, { maxExpressions: 5000 });
  const large = run(task, { maxExpressions: 60000 });
  assert.ok(small.explored <= large.explored, 'a smaller budget must not explore more');
  assert.equal(small.budget.maxExpressions, 5000);
  assert.equal(large.budget.maxExpressions, 60000);
});

test('determinism: the dataset digest is part of the reproducibility contract', () => {
  const bytes = fs.readFileSync(path.join(ROOT, 'bench/pbe-round2-dataset.json'));
  const digest = crypto.createHash('sha256').update(bytes).digest('hex');
  assert.match(digest, /^[0-9a-f]{64}$/);
  assert.equal(DATASET.tasks.length, 150);
});
