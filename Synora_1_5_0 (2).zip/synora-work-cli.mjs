#!/usr/bin/env node
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

const command = process.argv[2];
const args = process.argv.slice(3);

function printHelp() {
  console.log(`
Synora Local CLI - Private, Local-First Symbolic Agent
Usage: synora <command> [options]

Commands:
  start               Start the local HTTP API server (127.0.0.1 only)
  ask "<prompt>"      Run semantic NLU query or question answering
  learn <data.json>   Synthesize digital skill from input/output examples
  ingest <corpus>     Ingest JSONL knowledge corpus with BM25 indexing
  eval [suite.json]   Run external evaluation harness
  doctor              Verify local Node environment and security checks
  export <dest.json>  Export digital objects and event ledger
  import <src.json>   Import digital objects and event ledger
`);
}

async function main() {
  switch (command) {
    case 'start': {
      process.env.SYNORA_API_HOST = process.env.SYNORA_API_HOST || '127.0.0.1';
      const { createSynoraApi } = await import('./api/server.mjs');
      const server = createSynoraApi();
      const port = Number(process.env.PORT) || 3000;
      server.listen(port, '127.0.0.1', () => {
        console.log(`Synora server running on http://127.0.0.1:${port}`);
      });
      break;
    }

    case 'ask': {
      const prompt = args.join(' ');
      if (!prompt) {
        console.error('Error: Please provide a prompt. Example: synora ask "calculate sum of [1, 2, 3]"');
        process.exit(1);
      }
      const { parseNLToCode } = await import('./nl2code/grammar.mjs');
      const res = parseNLToCode(prompt);
      console.log(JSON.stringify(res, null, 2));
      break;
    }

    case 'learn': {
      const file = args[0];
      if (!file || !fs.existsSync(file)) {
        console.error('Error: Please provide a valid JSON examples file.');
        process.exit(1);
      }
      const data = JSON.parse(fs.readFileSync(file, 'utf-8'));
      const { synthesize } = await import('./synthesis/synthesize.mjs');
      const res = synthesize({ training: data.training, development: data.development });
      console.log(JSON.stringify(res, null, 2));
      break;
    }

    case 'ingest': {
      const file = args[0];
      if (!file || !fs.existsSync(file)) {
        console.error('Error: Please provide a valid JSONL corpus file.');
        process.exit(1);
      }
      const { runIngest } = await import('./knowledge/ingest.mjs');
      runIngest(file, path.join(ROOT_DIR, 'data'));
      break;
    }

    case 'eval': {
      const suiteFile = args[0] || path.join(ROOT_DIR, 'bench/external-eval/sample-tasks.json');
      const { runSuiteFile } = await import('../bench/external-eval.mjs');
      const report = await runSuiteFile(suiteFile);
      console.log('Evaluation Summary:');
      console.table(report.aggregates.byTrack);
      console.table([report.aggregates.overall]);
      break;
    }

    case 'doctor': {
      console.log('Synora Environment Doctor:');
      console.log(`- Node version: ${process.version} (>=20: ${Number(process.version.slice(1).split('.')[0]) >= 20 ? 'OK' : 'FAIL'})`);
      console.log(`- Operating System: ${process.platform} ${process.arch}`);
      console.log(`- Telemetry: Disabled (0 outbound calls by construction)`);
      console.log(`- Default Bind Host: 127.0.0.1 (Loopback only)`);
      break;
    }

    case 'export': {
      const dest = args[0] || 'synora-export.json';
      const { createStorage } = await import('./persistence/storage.mjs');
      const store = createStorage('json', path.join(ROOT_DIR, 'data'));
      const exported = {
        exportedAt: new Date().toISOString(),
        skills: await Promise.all((await store.list('skills')).map(id => store.get('skills', id)))
      };
      fs.writeFileSync(dest, JSON.stringify(exported, null, 2), 'utf-8');
      console.log(`Exported state to ${dest}`);
      break;
    }

    case 'import': {
      const src = args[0];
      if (!src || !fs.existsSync(src)) {
        console.error('Error: Please provide a valid export file to import.');
        process.exit(1);
      }
      const imported = JSON.parse(fs.readFileSync(src, 'utf-8'));
      const { createStorage } = await import('./persistence/storage.mjs');
      const store = createStorage('json', path.join(ROOT_DIR, 'data'));
      for (const sk of (imported.skills || [])) {
        if (sk && sk.id) await store.set('skills', sk.id, sk);
      }
      console.log(`Imported ${imported.skills ? imported.skills.length : 0} skills into storage.`);
      break;
    }

    default:
      printHelp();
      break;
  }
}

main().catch(err => {
  console.error('CLI error:', err);
  process.exit(1);
});
