# Synora WAR v8.5.2 — Round 2 Acceptance Matrix

**Release disposition: NOT FULLY ACCEPTED.** This matrix deliberately separates implemented/tested engineering from external validation and remaining acceptance blockers. Do not describe this package as satisfying every Round-2 requirement.

## Measured tracks

| Requirement | Implemented artifact / command | Measured result | Disposition |
|---|---|---|---|
| A — synthesis ambiguity/safety gate | `synora-v5/synthesis/synthesize.mjs`; `bench/eval-pbe-round2.mjs`; `bench/pbe-round2-dataset.json` | 150 developer-authored tasks, 54 new-operation tasks (36%); 78 solved, 0 wrong, 72 not found; 102 clarification questions; wrong-with-confidence 0/78 answered | Safety target met on this finite set; coverage is only 52%. |
| A — compatibility coverage | `bench/results/v8.4.0-vs-round2-comparison.json` | Shared 39-task sample: PBE solved fell from 7/10 to 1/10; both 0 wrong | **Regression / acceptance blocker.** |
| B — compositional NL→Code | `synora-v5/nl2code/`; `bench/nl2code-round2-corpus.json`; `bench/results/nl2code-round2-heldout.json` | 840 prompts, 60 operation IDs, 20 whole operation IDs held out (33.3%). Held-out EN 140/140 solved; AR 140/140 solved; 0 wrong. Post-freeze EN 9/10, AR 10/10, 0 wrong. | Wrong-answer rate target met on tested set; Arabic coverage 45.7%, and parser is a bounded grammar, not general compositional language understanding. |
| C — extractive QA | `synora-v5/knowledge/`; `bench/qa-round2-dataset.json`; `bench/results/qa-round2-eval.json` | 400 synthetic fictional-corpus questions: 240 exact-span correct, 0 wrong/hallucinated, 120 correct abstentions, 40 conflicts reported | Synthetic benchmark passed; no real-world corpus generalisation or confidence calibration. |
| D — evaluation harness | `bench/external-eval.mjs`; `bench/external-eval/sample-tasks.json`; `bench/results/round2-full-sample-eval.json` | 40 tasks: 27 solved, 0 wrong, 10 abstained, 3 dialogue transcripts recorded for human review | Harness/sample run complete; dialogue is not auto-scored. |
| E — persistence / CLI / sandbox | `synora-v5/persistence/`; `synora-v5/security/`; `tests/stage7/persistence.test.mjs`; `tests/stage7/cli-smoke.test.mjs`; `tests/stage7/hostile-sandbox.test.mjs` | JSON and SQLite tests; PostgreSQL injected-client tests (not a live server); 4 writer processes / 32 ledger events; SIGKILL torn-record recovery; CLI smoke; hostile-input tests | Local tests pass. Live PostgreSQL and cross-platform execution remain unverified. |
| E — web learning / teacher | `synora-v5/knowledge/web-learning.mjs`; teacher-ingest tests | Mocked fetch/robots/licence path and symbolic teacher-ingest checks | No live web fetch and no teacher-model inference. |
| E — packaging / CI | `Dockerfile`; `.github/workflows/ci.yml`; signed manifest | Docker declares non-root `node`; CI matrix configured for Ubuntu/Windows/macOS and Node 20/22; manifest and detached signature verify | Workflow configuration present; remote matrix has not run here. |
| F — Llama 2 comparison kit | `bench/llama2-compare/`; `tests/stage7/llama2-compare.test.mjs` | Prompt builder and isolated scorer fault-injection tests pass | Kit exists; no Llama 2 inference or model score is included. |

## T1–T6 verification

- **T1:** The included clean-extraction log records `npm test` exit 0 and all 33 test commands passing. A separate fresh re-run in this execution window timed out while entering `stage6/synthesis.test.mjs`; it did not produce a new exit status. The recorded clean-extraction result is retained; the later timeout is also retained and not hidden.
- **T2:** Static anti-leak and no-hardcoded-benchmark-operation tests pass.
- **T3:** Developer-authored operation-disjoint development sets and a post-freeze set are present. No sealed independent-reviewer set was accessed.
- **T4:** Fault-injection tests reject wrong emitted JavaScript and substring-only QA answers.
- **T5:** CLI, concurrent persistence, SIGKILL recovery, and hostile sandbox tests pass locally.
- **T6:** Same-task v8.4.0 comparison is included; PBE coverage regression is disclosed above.

## Additional verification performed during finalization

- Runtime: Node `v22.16.0`, npm `10.9.2`, Linux x86_64.
- `npm run manifest`: passed; 783 package files / 72.40 MB represented by the manifest (logs and manifest self/signature files are intentionally excluded by the manifest builder).
- `npm run manifest:sign`: passed; ephemeral Ed25519 key generated; private key discarded.
- `npm run manifest:verify`: passed; 783 file hashes and detached signature verified.
- `node --test --test-concurrency=1 tests/stage7/*.test.mjs`: passed, 73 tests, 0 failures.
- `npm run bench`: passed. The 35-prompt paraphrase set solved 7/12, abstained 5/12, wrong 0; all 12 trap prompts abstained, wrong 0.
- `npm run bench:synth`: exceeded the 600-second execution window in this environment; partial log retained; no complete benchmark result is claimed.

## Explicit remaining blockers — no claim of completion

1. Recover PBE coverage without reintroducing confident wrong answers; shared compatibility PBE regressed 7/10 → 1/10.
2. Extend the deliberately bounded grammar with additional qualifiers only through new sealed tests; the current 280-prompt artifact is internally consistent and records 140/140 in both languages.
3. Evaluate QA on a real external corpus and calibrate confidence; current 400-question benchmark is synthetic.
4. Run a live PostgreSQL integration suite; complete and test delete/restore TOCTOU protection; run CI on Windows/macOS as well as Linux.
5. Execute an actual permitted teacher-model inference and a live, policy-compliant web-learning fetch.
6. Run the Llama 2 comparison kit against an available, pinned Llama 2 model/runtime and report same-task results. No model scores exist in this archive.
7. Obtain an independent sealed evaluation set and run it without exposing it to development/tuning.
8. Complete `npm run bench:synth`; the full run timed out twice previously and again in this finalization window.

A finite local test suite passing is not proof of absence of all bugs. The package is a reproducible engineering checkpoint with explicit blockers, not a fully accepted release.
