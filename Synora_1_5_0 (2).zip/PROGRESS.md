# Synora WAR v1.5.0 — Progress

## Current deliverable
`Synora_WAR_v8_8_0_CHECKPOINT.zip` is the checkpoint build of the v1.5.0 line. The previous
release (`Synora_WAR_v8_6_0_FINAL.zip`, source SHA-256
`363bf7d98d6bada4495fa674be037c62d7eef8255a362cb3a7e2f96e787433e8`) was left untouched;
all work happened in a fresh extraction of it.

## Verified in this release

**Program synthesis.** The budget is deterministic and explicit
(`deterministicBudget: true`), the wall clock is only a fail-closed safety valve, and
each of the four search stages records its own expression share, its explored count and
why it stopped. The universe is chosen by type reachability, never by operation name.
PBE Round 2 over 150 tasks: **71 solved, 0 wrong, 79 not-found, 218 questions**
(v8.6.0: 36 / 0 / 114 / 216), coverage 36 % → 47.33 %, wall 989,910 ms, CPU 945 s, peak RSS
507,301,888 B, dataset SHA-256
`cb649f4d6e6f2a1b25bf40a7edb200af8517c80fe86844e5a3076512958b7e94`.

**Why the rest is refused, with proof.** `bench/results/pbe-rival-evidence.json` stores,
for every refused operation, the rival programs that fit the examples as well as the
intended one and the first input on which they disagree. 14 of the 16 refused
operations are genuine ambiguities; **no refusal is caused by an exhausted budget**
(`budgetExhausted: 0`). The two remaining refusals are `development-validation-failed`
(`iterate_add`) and `insufficient-evidence` (`range_count`).

**Safety regressions stay closed.** The exact index-of-min regression
(`mod(sum(unique(init(a0))),3)`) is still rejected, the stage6 boundary gate still
refuses, and the stage6 suite passes 15/15.

**QA.** 240 correct, 0 wrong, 0 hallucinated, 120 correctly abstained, 40 conflicts over
400 questions. Typed spans now cover person, date, duration, place, organization,
quantity, attribute and height in English and Arabic, with active/passive disambiguation
and correct document offsets. 14/14 typed-span tests pass on an own corpus.

**NL→Code.** 840-prompt corpus: EN 360 solved / 0 wrong, AR 324 solved / 0 wrong — the
Arabic wrong-answer count fell from 52 to 0. Held-out split EN 140/140, AR 140/140;
paraphrase test split EN 120/120, AR 120/120; post-freeze EN 10/10, AR 10/10; 20 new
held-out composition prompts 10/10 EN and 10/10 AR.
Unsupported compositions and conversational follow-ups abstain with a precise reason.

**Independent evaluation.** 28 hand-authored tasks, 26 scored: 24 solved, 0 wrong, 2
abstentions (the deliberately ambiguous ones), coverage 92.3 %, selective accuracy 100 %.

**Release engineering.** One version (`8.8.0`) across `package.json`, the CLI, the
manifest metadata, the benchmark reports and the documents, enforced by a test. The CLI
export resolves to an absolute path and refuses the package, the audited directories and
the live state directory. Release signing is Ed25519-only, needs a user key outside the
package (`--require-user-key`), and never writes the private key. Licensing
(Apache-2.0), third-party notices (no runtime dependencies) and the release runbook are
in place.

**Test suites.** `npm test` runs 43 suites in fresh processes and exits 0. New suites:
versioning, CLI export, manifest signing, synthesis determinism, NL2Code round 3,
evaluator mutation, independent evaluation set. Existing suites (stage6, persistence,
abuse protection, hostile sandbox, anti-leak, no-hardcoded-bench-ops, dialogue) stay
green.

## Open items that are not part of this release

* PBE coverage is 36 %; the ambiguity gate is the binding constraint. No refusal is
  budget-caused, so the next gain has to come from better task examples or from a
  deliberate decision to relax the gate — the latter was rejected.
* **Comparison not run**: no Llama 2 inference was executed. The protocol and the scorer
  exist; no parity claim is made.
* The dialogue track records transcripts for human review instead of scoring them.
* Windows/macOS, live PostgreSQL, Docker and remote CI are untested in this environment.

## Cycle 1 result and remaining gates

The checkpoint adds general cardinal `first/last K` selection, passive-agent extraction across intervening text, selector-safe probes, and a measured plausibility prior for generic PBE rivals. The five required direct QA prompts and the required EN/AR cardinal-selection prompts pass with offsets or exact list outputs. PBE improved from 54/150 to 71/150 with zero wrong answers. G1/G2, the 100k expressions/s profile, the sealed post-freeze gate, and clean-room packaging remain open; general-language parity with Llama 2 is explicitly not established.

## Next cycle (suggested)
1. Extend the independent evaluation set with an external reviewer and seal it before
   the next code freeze.
2. Attack the ambiguity gate with richer example sets rather than a weaker rule:
   the `bench/results/pbe-rival-evidence.json` file names, for every refused operation,
   the exact rival program, which is the shortest path to a smaller rival set.
3. Extend the bounded dialogue grammar so that the two recorded dialogue prompts can be
   scored rather than only recorded.
