/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * SINGLE SOURCE OF TRUTH for the release version.
 *
 * Every surface that carries a version string - package.json, the CLI, the package
 * manifest, the benchmark reports and the release documents - must agree with this
 * file. `tests/stage7/versioning.test.mjs` fails the build when they do not.
 */

/** Semantic version of this release. */
export const VERSION = '1.5.0';

/** Name of the released archive, e.g. Synora_WAR_v8_7_0_FINAL.zip */
export const RELEASE_ARCHIVE = `Synora_WAR_v${VERSION.replace(/\./g, '_')}_FINAL.zip`;

/** Name of the directory at the root of the released archive. */
export const ARCHIVE_ROOT = `Synora_WAR_v${VERSION.replace(/\./g, '_')}`;

/** Release channel of this build. */
export const RELEASE_STATUS = 'FINAL';

/** Version of the DSL, which is part of the synthesis reproducibility contract. */
export const DSL_RELEASE = 'synora-dsl/1.1.0';
