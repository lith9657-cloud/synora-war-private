/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Realizer } from './realizer.mjs';

export class ResponsePlanner {
  constructor() {
    this.realizer = new Realizer();
  }

  planAndRealize(intentResult, options = {}) {
    const lang = options.lang || 'en';

    if (intentResult.status === 'abstain') {
      const plan = {
        type: 'refusal',
        reason: intentResult.reason || 'unmodelled_intent',
        unmodelled: intentResult.unmodelled || []
      };
      return {
        plan,
        text: this.realizer.realize(plan, { lang })
      };
    }

    if (intentResult.status === 'ambiguous' && intentResult.disambiguatingQueries) {
      const plan = {
        type: 'clarification',
        question: lang === 'ar' ? 'حدد السلوك المطلوب للمدخلات الآتية:' : 'Please clarify the expected behavior for these inputs:',
        options: intentResult.disambiguatingQueries.map(q => JSON.stringify(q.input))
      };
      return {
        plan,
        text: this.realizer.realize(plan, { lang })
      };
    }

    if (intentResult.status === 'conflict') {
      const plan = {
        type: 'conflict',
        conflictSubject: intentResult.conflictSubject,
        answers: intentResult.answers
      };
      return {
        plan,
        text: this.realizer.realize(plan, { lang })
      };
    }

    if (intentResult.status === 'ok' && intentResult.source) {
      const plan = {
        type: 'solution',
        source: intentResult.source
      };
      return {
        plan,
        text: this.realizer.realize(plan, { lang })
      };
    }

    const defaultPlan = { type: 'unknown' };
    return {
      plan: defaultPlan,
      text: this.realizer.realize(defaultPlan, { lang })
    };
  }
}
