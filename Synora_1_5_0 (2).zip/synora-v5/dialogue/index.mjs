/**
 * Bounded, inspectable non-neural request parser. This is a small intent/slot parser,
 * not a general natural-language understanding model. It never executes user text.
 */
const normalise = value => String(value ?? '').normalize('NFKC').toLowerCase().replace(/[\u064B-\u065F\u0670]/g, '').replace(/[إأآ]/g, 'ا').replace(/ى/g, 'ي').replace(/[^\p{L}\p{N}_+*/().,=\-\s]/gu, ' ').replace(/\s+/g, ' ').trim();
const includesAny = (s, terms) => terms.some(t => s.includes(normalise(t)));
const hasWord = (s, words) => { const set = new Set(s.match(/[a-z]+/g) ?? []); return words.some(w => set.has(w)); };
const ARR = /(\barrays?\b|\blists?\b|\bnumbers?\b|\belements?\b|\bvalues?\b|مصفوف|قائم|ارقام|عناصر|اعداد)/;

// Closed-world vocabulary guard. A code intent is only accepted when EVERY content word of the
// request is understood by the parser. Unknown words ("second", "descending", "squares", "string"...)
// change the meaning of the task, so the parser abstains instead of routing to the nearest template.
const COMMON_EN = new Set('write a an the function functions code javascript js implement implementation give me please that which to of in for from return returns returning and find compute calculate calculates get make create program method input numbers number elements element items item values value array arrays list lists i want need can you show all my is are by it test tests named called takes take given as on'.split(' '));
const COMMON_AR = new Set('اكتب دالة دالا تقوم تعيد ترجع تحسب من في لي مصفوفة المصفوفة قائمة القائمة ارقام الارقام اعداد الاعداد عناصر العناصر عدد قيمة رقم برمج كود برنامج و ما التي الذي ان علي'.split(' '));
const INTENT_EN = { 'code.sum': 'sum sums summing total add adds up together', 'code.max': 'maximum max largest biggest greatest highest', 'code.factorial': 'factorial', 'code.reverse': 'reverse reverses reversed order backwards', 'code.sort': 'sort sorts sorted order ascending numeric numerically smallest largest increasing' };
const INTENT_AR = { 'code.sum': 'تجمع اجمع مجموع المجموع جمع', 'code.max': 'اكبر الاكبر اعلي الاعلي', 'code.factorial': 'مضروب المضروب عاملي', 'code.reverse': 'تعكس اعكس عكس ترتيب معكوس', 'code.sort': 'ترتب رتب ترتيب تصاعديا تصاعدي اصغر الاصغر الاكبر' };
function unmodelledTerms(normalized, intent) {
  const en = new Set([...COMMON_EN, ...(INTENT_EN[intent] ?? '').split(' ')]), ar = new Set([...COMMON_AR, ...(INTENT_AR[intent] ?? '').split(' ')]);
  const strip = t => [t, t.replace(/^(لل|ال|و|ب|ل)/, '')];
  const bad = [];
  for (const t of normalized.match(/[a-z]+/g) ?? []) if (t.length > 1 && !en.has(t)) bad.push(t);
  for (const t of normalized.match(/[\u0600-\u06FF]+/g) ?? []) if (!strip(t).some(x => ar.has(x))) bad.push(t);
  return bad;
}

function parseArithmetic(s) {
  const m = s.match(/(?:calculate|compute|what is|احسب|كم يساوي|ناتج)\s*(-?\d+(?:\.\d+)?)\s*([+*/-])\s*(-?\d+(?:\.\d+)?)/i);
  if (!m) return null;
  const left = Number(m[1]), right = Number(m[3]), op = m[2];
  if (!Number.isFinite(left) || !Number.isFinite(right) || (op === '/' && right === 0)) return { valid: false, reason: 'invalid-arithmetic-input' };
  const value = op === '+' ? left + right : op === '-' ? left - right : op === '*' ? left * right : left / right;
  return { valid: true, expression: `${left} ${op} ${right}`, value };
}

export function parseRequest(text, { history = [] } = {}) {
  if (typeof text !== 'string' || !text.trim()) throw new TypeError('request text must be a non-empty string');
  if (text.length > 16_000) throw new RangeError('request exceeds 16000 characters');
  const normalized = normalise(text);
  const followUp = includesAny(normalized, ['and test it', 'test it', 'continue that', 'اختبره', 'واختبره', 'كمل عليه', 'اكمل عليه']);
  if (followUp && Array.isArray(history) && history.length <= 20) {
    const priorUser = [...history].reverse().find(turn => turn && turn.role === 'user' && typeof turn.content === 'string' && turn.content.trim());
    if (priorUser) {
      const prior = parseRequest(priorUser.content);
      if (prior.intent.startsWith('code.') && prior.intent !== 'code.unsupported') return { ...prior, originalText: text, followUp: true, slots: { ...prior.slots, contextTurns: history.length }, evidence: { ...prior.evidence, contextResolution: 'latest-user-turn-for-explicit-code-follow-up', matchedIntent: prior.intent } };
    }
  }
  const language = /[\u0600-\u06FF]/.test(text) ? 'ar' : 'en';
  const slots = { constraints: [], inputs: [], contextTurns: Array.isArray(history) ? Math.min(history.length, 20) : 0 };
  const arithmetic = parseArithmetic(normalized);
  let intent = 'unknown', action = 'clarify', confidence = 0.2, requiredInfo = [], entities = {};

  if (hasWord(normalized, ['hello', 'hi', 'hey']) || includesAny(normalized, ['مرحبا', 'السلام عليكم', 'اهلا', 'هلا'])) {
    intent = 'greeting'; action = 'answer'; confidence = 0.98;
  } else if (arithmetic?.valid) {
    intent = 'calculate'; action = 'use_tool'; confidence = 0.99; entities = { arithmetic };
  } else if (arithmetic && !arithmetic.valid) {
    intent = 'calculate'; action = 'clarify'; confidence = 0.95; requiredInfo = ['valid arithmetic expression'];
  } else if ((includesAny(normalized, ['reverse array', 'reverse an array', 'reverse list', 'reverse a list', 'اعكس المصفوفة', 'اعكس ترتيب المصفوفة', 'اعكس عناصر']) || (/\brevers\w*/.test(normalized) && ARR.test(normalized)) || (/(تعكس|اعكس|يعكس)/.test(normalized) && ARR.test(normalized)))) {
    intent = 'code.reverse'; action = 'generate_and_test'; confidence = 0.88;
    slots.inputs.push('array of finite numbers');
  } else if ((includesAny(normalized, ['sort array', 'sort an array', 'sort numbers', 'sort a list', 'رتب المصفوفة', 'رتب الارقام', 'رتب الأرقام', 'رتب عناصر المصفوفة']) || (/\bsort\w*/.test(normalized) && ARR.test(normalized)) || (/\border\w*/.test(normalized) && /(smallest|ascending|increasing)/.test(normalized) && ARR.test(normalized)) || (/(ترتب|رتب)/.test(normalized) && ARR.test(normalized)))) {
    intent = 'code.sort'; action = 'generate_and_test'; confidence = 0.88;
    slots.inputs.push('array of finite numbers; ascending numeric order');
  } else if (includesAny(normalized, ['factorial', 'factorial function', 'مضروب', 'دالة المضروب'])) {
    intent = 'code.factorial'; action = 'generate_and_test'; confidence = 0.88;
    const n = normalized.match(/(?:factorial|مضروب|المضروب)\s*(?:of|ل)?\s*(\d+)/);
    if (n) entities.n = Number(n[1]);
    slots.constraints.push('non-negative safe integer input');
  } else if ((includesAny(normalized, ['sum array', 'sum an array', 'sum a list', 'sum of array', 'sum numbers', 'sum all elements', 'مجموع المصفوفة', 'اجمع عناصر', 'مجموع الارقام']) || ((/\bsum\w*/.test(normalized) || /\btotal\b/.test(normalized) || /\badds? up\b/.test(normalized)) && ARR.test(normalized)) || (/(تجمع|اجمع|مجموع)/.test(normalized) && ARR.test(normalized)))) {
    intent = 'code.sum'; action = 'generate_and_test'; confidence = 0.9;
    slots.inputs.push('array of finite numbers');
  } else if ((includesAny(normalized, ['maximum', 'max of array', 'largest number', 'اكبر عنصر', 'اكبر رقم', 'اعلى قيمة']) || (/\b(max|largest|biggest|greatest|highest)\b/.test(normalized) && ARR.test(normalized)) || (/(اكبر|اعلي)/.test(normalized) && ARR.test(normalized)))) {
    intent = 'code.max'; action = 'generate_and_test'; confidence = 0.88;
    slots.inputs.push('non-empty array of finite numbers');
  } else if (includesAny(normalized, ['learn rule', 'learn mapping', 'تعلم قاعدة', 'تعلم العلاقة', 'استنتج القاعدة'])) {
    intent = 'skill.learn-affine'; action = 'learn_skill'; confidence = 0.72;
    requiredInfo = ['modulus', 'at least two input/output examples'];
  } else if (includesAny(normalized, ['explain', 'اشرح', 'ما معنى', 'ما هو', 'what is'])) {
    intent = 'explain'; action = 'answer_with_scope'; confidence = 0.58;
  } else if (includesAny(normalized, ['code', 'function', 'write a program', 'اكتب كود', 'اكتب برنامج', 'برمج'])) {
    intent = 'code.unsupported'; action = 'clarify'; confidence = 0.48;
    requiredInfo = ['supported operation: sum array, maximum array value, factorial, reverse array, or sort array'];
  }

  let guard = null;
  if (intent.startsWith('code.') && intent !== 'code.unsupported') {
    const unknown = unmodelledTerms(normalized, intent);
    if (unknown.length) {
      guard = { matchedBeforeGuard: intent, unmodelledTerms: [...new Set(unknown)] };
      intent = 'code.unsupported'; action = 'clarify'; confidence = 0.45; entities = {}; slots.inputs = []; slots.constraints = [];
      requiredInfo = [`terms not modelled for ${guard.matchedBeforeGuard}: ${guard.unmodelledTerms.join(', ')}`];
    }
  }
  if (requiredInfo.length) slots.missing = [...requiredInfo];
  return {
    schema: 'synora.request/1', originalText: text, normalizedText: normalized, language,
    intent, action, confidence, entities, slots,
    evidence: { parser: 'bounded-lexical-intent-rules/2+vocabulary-guard', matchedIntent: intent, ...(guard ? { guard } : {}), historyTurnsAvailable: slots.contextTurns },
    limitations: ['Intent classification is rule-based and bounded; it is not general language understanding.']
  };
}
