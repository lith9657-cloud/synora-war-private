/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Honest Surface Realizer for Synora (Rule-based, Non-Neural).
 * Translates structured intents into exact English and Arabic text
 * with morphological agreement, structured clarification questions,
 * and transparent refusal wording without hallucinations.
 */

export class Realizer {
  realize(intentObj, options = {}) {
    const lang = options.lang || 'en';
    const type = intentObj ? intentObj.type : 'unknown';

    if (lang === 'ar') {
      return this.realizeArabic(type, intentObj);
    }
    return this.realizeEnglish(type, intentObj);
  }

  realizeEnglish(type, obj) {
    switch (type) {
      case 'clarification': {
        const question = obj.question || 'Please clarify your request:';
        const options = (obj.options || []).map((o, i) => `  ${i + 1}. ${o}`).join('\n');
        return `${question}\n${options}`;
      }

      case 'refusal': {
        const reason = obj.reason || 'unsupported';
        const unmodelled = (obj.unmodelled || []).join(', ');
        if (reason === 'out_of_domain') {
          return `I must decline this request. The domain is out of scope for Synora's verified symbolic runtime. Unmodelled terms: [${unmodelled}].`;
        }
        return `I cannot execute this request because it contains terms or requirements outside the supported symbolic grammar. Unmodelled: [${unmodelled}].`;
      }

      case 'solution': {
        return `Task solved successfully. Generated verifiable code:\n\n${obj.source || ''}`;
      }

      case 'conflict': {
        const subj = obj.conflictSubject || 'the requested subject';
        const items = (obj.answers || []).map(a => `  - ${a.object} (Source: ${a.sourceId})`).join('\n');
        return `Conflicting verified sources were found for ${subj}:\n${items}\nBoth sources are displayed above without guessing.`;
      }

      default:
        return 'Request processed with no further action required.';
    }
  }

  realizeArabic(type, obj) {
    switch (type) {
      case 'clarification': {
        const question = obj.question || 'يرجى توضيح طلبك بالاختيار من الآتي:';
        const options = (obj.options || []).map((o, i) => `  ${i + 1}. ${o}`).join('\n');
        return `${question}\n${options}`;
      }

      case 'refusal': {
        const unmodelled = (obj.unmodelled || []).join('، ');
        return `أعتذر، لا يمكنني تنفيذ هذا الطلب لأنه يحتوي على مصطلحات خارج النطاق الرمزي المدعوم: [${unmodelled}].`;
      }

      case 'solution': {
        return `تم حل المسألة بنجاح. الكود المصدري المبرهن:\n\n${obj.source || ''}`;
      }

      case 'conflict': {
        const subj = obj.conflictSubject || 'الموضوع المطلوب';
        const items = (obj.answers || []).map(a => `  - ${a.object} (المصدر: ${a.sourceId})`).join('\n');
        return `تم العثور على مصادر موثقة متضاربة بخصوص ${subj}:\n${items}\nتم عرض كلا المصدرين بشفافية دون تخمين.`;
      }

      default:
        return 'تمت معالجة الطلب بنجاح.';
    }
  }
}
