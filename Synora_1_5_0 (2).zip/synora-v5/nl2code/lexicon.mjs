/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { stemArabicWord, normalizeArabicText } from './arabic-morphology.mjs';

export const NUMERALS = {
  // English
  'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
  'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
  'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15,
  'twenty': 20, 'thirty': 30, 'hundred': 100,
  // Arabic (normalized/stemmed)
  'صفر': 0, 'الصفر': 0, 'واحد': 1, 'اثنين': 2, 'اثنان': 2, 'ثلاث': 3, 'ثلاثه': 3,
  'اربع': 4, 'اربعه': 4, 'خمس': 5, 'خمسه': 5, 'ست': 6, 'سته': 6,
  'سبع': 7, 'سبعه': 7, 'ثمان': 8, 'ثمانيه': 8, 'تسع': 9, 'تسعه': 9,
  'عشر': 10, 'عشره': 10, 'مئه': 100, 'مائه': 100
};

export const ORD_MAP = {
  'first': 0, 'second': 1, 'third': 2, 'fourth': 3, 'fifth': 4,
  'last': -1,
  // Arabic
  'اول': 0, 'ثاني': 1, 'ثالث': 2, 'رابع': 3, 'خامس': 4,
  'اخير': -1, 'اخر': -1
};

export const OPERATION_CONCEPTS = {
  sum: ['sum', 'total', 'add all', 'مجموع', 'جمع', 'اجمع', 'حاصل جمع'],
  average: ['average', 'mean', 'متوسط', 'معدل', 'المتوسط الحسابي'],
  max: ['maximum', 'max', 'largest', 'biggest', 'greatest', 'highest', 'اكبر', 'اعظم', 'اقصي', 'اعلي', 'العظمي', 'القيمه العظمي', 'اكبر عدد', 'اكبر عنصر'],
  min: ['minimum', 'min', 'smallest', 'least', 'lowest', 'اصغر', 'ادني', 'الصغري', 'القيمه الصغري', 'اقل عدد', 'اقل قيمه', 'اقل من', 'الحد الادني'],
  count: ['count', 'number of', 'how many', 'عدد', 'كم', 'احسب عدد', 'عد '],
  sort: ['sort', 'order', 'arrange', 'رتب', 'ترتيب', 'فرز'],
  reverse: ['reverse', 'invert', 'اعكس', 'عكس', 'مقلوب', 'اقلب', 'بالعكس'],
  unique: ['unique', 'distinct', 'deduplicate', 'remove duplicates', 'فريد', 'مميز', 'مميزه', 'بدون تكرار', 'دون تكرار', 'غير مكرر'],
  flatten: ['flatten', 'merge nested', 'تسطيح', 'دمج القوائم'],
  length: ['length', 'size', 'طول', 'حجم'],
  product: ['product', 'multiply all', 'حاصل ضرب', 'جداء']
};

export const FILTER_PREDICATES = {
  positive: ['positive', 'greater than zero', 'موجب', 'موجبه', 'اكبر من الصفر'],
  negative: ['negative', 'less than zero', 'سالب', 'سالبه', 'اقل من الصفر', 'اصغر من الصفر'],
  even: ['even', 'زوجي', 'زوجيه'],
  odd: ['odd', 'فردي', 'فرديه']
};

export const DIRECTION_QUALIFIERS = {
  descending: ['descending', 'decreasing', 'largest to smallest', 'تنازلي', 'تنازليا', 'من الاكبر الي الاصغر'],
  ascending: ['ascending', 'increasing', 'smallest to largest', 'تصاعدي', 'تصاعديا', 'من الاصغر الي الاكبر']
};
