/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { normalizeArabicText, stemArabicWord } from './arabic-morphology.mjs';
import { OPERATION_CONCEPTS, FILTER_PREDICATES, DIRECTION_QUALIFIERS, ORD_MAP, NUMERALS } from './lexicon.mjs';
import { verifySanityChecks } from './sanity-checks.mjs';
import { toSource, evalAst } from '../synthesis/dsl.mjs';

function tokenize(text, lang = 'en') {
  if (lang === 'ar' || /[\u0600-\u06FF]/.test(text)) {
    const norm = normalizeArabicText(text);
    return norm.replace(/[؟?.,!؛،:]/g, ' ').split(/\s+/).filter(Boolean);
  }
  return text.toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').split(/\s+/).filter(Boolean);
}

/** English number words that can serve as a numeric literal. */
const EN_NUM_WORDS = {
  zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9,
  ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16,
  seventeen: 17, eighteen: 18, nineteen: 19, twenty: 20, thirty: 30, forty: 40, fifty: 50,
  sixty: 60, hundred: 100
};

/**
 * Converts a literal phrase ("5", "-3", "three", "negative five", "خمسة", "سالب خمسة")
 * into a number. Returns null when the phrase is not a numeric literal.
 */
function literalToNumber(raw) {
  if (raw === null || raw === undefined) return null;
  let s = String(raw).trim().toLowerCase();
  if (!s) return null;
  s = s.replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
  if (/^-?\d+(?:\.\d+)?$/.test(s)) return Number(s);
  let negative = false;
  const signMatch = s.match(/^(negative|minus|سالب)\s+(.+)$/);
  if (signMatch) {
    negative = true;
    s = signMatch[2].trim();
  }
  const words = s.split(/\s+/).filter(Boolean);
  // Prefer the longest readable prefix so that a trailing noun does not destroy the
  // literal ("خمسة عناصر" -> "خمسة").
  for (let n = Math.min(2, words.length); n >= 1; n--) {
    const candidate = words.slice(0, n).join(' ');
    let value = null;
    if (EN_NUM_WORDS[candidate] !== undefined) value = EN_NUM_WORDS[candidate];
    else {
      const norm = normalizeArabicText(candidate);
      for (const [word, val] of Object.entries(NUMERALS)) {
        if (normalizeArabicText(word) === norm) { value = val; break; }
      }
    }
    if (value !== null) return negative ? -value : value;
  }
  return null;
}

const SELECTION_NOUNS_EN = '(?:numbers?|elements?|items?|values?|entries?|records?)';
const SELECTION_NOUNS_AR = '(?:عناصر|ارقام|أرقام|قيم|قوائم|مدخلات|عنصرين|رقمين|قيمتين)';

/** Parse cardinal list selections before ordinal handling can consume "first". */
function parseCardinalSelection(promptLower, promptNormAr) {
  const en = new RegExp(`\\b(first|last)\\s+(-?\\d+(?:\\.\\d+)?|[a-z]+(?:\\s+[a-z]+)?)\\s+${SELECTION_NOUNS_EN}\\b`, 'i').exec(promptLower);
  if (en) {
    const count = literalToNumber(en[2]);
    if (Number.isInteger(count) && count >= 0) return { direction: en[1].toLowerCase(), count, span: en[0] };
  }
  const ar = new RegExp(`(?:^|\\s)(اول|اخر)\\s+((?:[٠-٩]+)|(?:واحد|اثنان|اثنين|ثلاث|ثلاثة|اربع|اربعه|اربعة|أربع|أربعة|خمس|خمسة|ست|ستة|سبع|سبعة|ثمان|ثمانية|تسع|تسعة|عشر|عشرة))\\s+${SELECTION_NOUNS_AR}(?=\\s|$)`, 'u').exec(promptNormAr);
  if (ar) {
    const count = literalToNumber(ar[2]);
    if (Number.isInteger(count) && count >= 0) return { direction: ar[1] === 'اول' ? 'first' : 'last', count, span: ar[0] };
  }
  const arDual = /(?:^|\s)(اخر|اول)\s+(عنصرين|رقمين|قيمتين)(?=\s|$)/u.exec(promptNormAr);
  if (arDual) return { direction: arDual[1] === 'اول' ? 'first' : 'last', count: 2, span: arDual[0] };
  return null;
}

/** English comparison operators that introduce a threshold. */
const EN_GREATER_WORDS = ['greater', 'more', 'larger', 'bigger', 'higher', 'above'];
const EN_LESS_WORDS = ['less', 'fewer', 'smaller', 'lower', 'below'];
/** Arabic comparison operators that introduce a threshold. */
const AR_GREATER_WORDS = ['اكبر', 'اكثر', 'اعلى', 'اعظم'];
const AR_LESS_WORDS = ['اقل', 'اصغر', 'اننى'];

/** Deixis markers: the prompt refers to a previous conversational turn. */
const EN_DEIXIS = /\b(those|them|these|it|the same|the previous|the above|the result|that one)\b/i;
const AR_DEIXIS = /(^|\s)(هؤلاء|هم|هن|نفسها|نفسهم|ذلك)(\s|$)|(النتيجه|نتيجه|النتيجة|سابقه|السابقه|الان)/;

export function parseNLToCode(prompt, options = {}) {
  const lang = options.lang || (typeof prompt === 'string' && /[\u0600-\u06FF]/.test(prompt) ? 'ar' : 'en');
  const tokens = tokenize(prompt, lang);
  const promptLower = prompt.toLowerCase();
  const promptNormAr = normalizeArabicText(prompt);

  // Conversational follow-ups reference a previous result. There is no dialogue
  // state in this grammar, so any such prompt is refused explicitly instead of
  // being silently reinterpreted as an operation over the current input.
  const arDeixisToken = tokens.some(t => t.length > 3 && (t.endsWith('هم') || t.endsWith('هن')));
  if (EN_DEIXIS.test(promptLower) || AR_DEIXIS.test(promptNormAr) || arDeixisToken) {
    return { status: 'abstain', reason: 'contextual_followup_requires_state', unmodelled: ['contextual-reference'] };
  }

  // ---- Thresholds -----------------------------------------------------------
  // Every comparison in the prompt is extracted so that chained qualifiers keep
  // all of their constraints. An unparsable comparison fails closed.
  const thresholds = [];
  const thresholdErrors = [];
  const enThresholdSpans = [];
  const arThresholdSpans = [];
  const enThresholdRe = new RegExp(
    `\\b(${EN_GREATER_WORDS.join('|')})\\s+than\\s+(-?\\d+(?:\\.\\d+)?|(?:negative|minus)\\s+[a-z]+|[a-z]+)`, 'gi');
  const enLessRe = new RegExp(
    `\\b(${EN_LESS_WORDS.join('|')})\\s+than\\s+(-?\\d+(?:\\.\\d+)?|(?:negative|minus)\\s+[a-z]+|[a-z]+)`, 'gi');
  const arThresholdRe = new RegExp(
    `(${AR_GREATER_WORDS.join('|')})\\s+من\\s+((?:سالب\\s+)?[\\u0621-\\u064A\\u0660-\\u0669]+(?:\\s+[\\u0621-\\u064A\\u0660-\\u0669]+)?)`, 'g');
  const arLessRe = new RegExp(
    `(${AR_LESS_WORDS.join('|')})\\s+من\\s+((?:سالب\\s+)?[\\u0621-\\u064A\\u0660-\\u0669]+(?:\\s+[\\u0621-\\u064A\\u0660-\\u0669]+)?)`, 'g');
  const enAtLeastRe = /\b(?:at least|no less than)\s+(-?\d+(?:\.\d+)?|(?:negative|minus)\s+[a-z]+|[a-z]+)/gi;
  const enAtMostRe = /\b(?:at most|no more than)\s+(-?\d+(?:\.\d+)?|(?:negative|minus)\s+[a-z]+|[a-z]+)/gi;
  const arAtLeastRe = /(?:لا\\s+يقل\\s+عن|على\\s+الاقل\\s+من)\\s+((?:سالب\\s+)?[\\u0621-\\u064A\\u0660-\\u0669]+(?:\\s+[\\u0621-\\u064A\\u0660-\\u0669]+)?)/g;
  const arAtMostRe = /(?:لا\\s+يزيد\\s+عن|على\\s+الاكثر\\s+من)\\s+((?:سالب\\s+)?[\\u0621-\\u064A\\u0660-\\u0669]+(?:\\s+[\\u0621-\\u064A\\u0660-\\u0669]+)?)/g;

  const collect = (re, kind) => {
    let m;
    while ((m = re.exec(promptLower)) !== null) {
      const value = literalToNumber(m[2]);
      if (value === null) thresholdErrors.push(m[0]);
      else thresholds.push({ kind, value });
      enThresholdSpans.push([m.index, m.index + m[0].length]);
      if (m.index === re.lastIndex) re.lastIndex++;
    }
  };
  const collectSingle = (re, kind, haystack, spans) => {
    let m;
    while ((m = re.exec(haystack)) !== null) {
      const value = literalToNumber(m[1]);
      if (value === null) thresholdErrors.push(m[0]);
      else thresholds.push({ kind, value });
      spans.push([m.index, m.index + m[0].length]);
      if (m.index === re.lastIndex) re.lastIndex++;
    }
  };
  collect(enThresholdRe, 'greaterThan');
  collect(enLessRe, 'lessThan');
  collectSingle(enAtLeastRe, 'atLeast', promptLower, enThresholdSpans);
  collectSingle(enAtMostRe, 'atMost', promptLower, enThresholdSpans);
  {
    let m;
    while ((m = arThresholdRe.exec(promptNormAr)) !== null) {
      const value = literalToNumber(m[2]);
      if (value === null) thresholdErrors.push(m[0]);
      else thresholds.push({ kind: 'greaterThan', value });
      arThresholdSpans.push([m.index, m.index + m[0].length]);
      if (m.index === arThresholdRe.lastIndex) arThresholdRe.lastIndex++;
    }
    while ((m = arLessRe.exec(promptNormAr)) !== null) {
      const value = literalToNumber(m[2]);
      if (value === null) thresholdErrors.push(m[0]);
      else thresholds.push({ kind: 'lessThan', value });
      arThresholdSpans.push([m.index, m.index + m[0].length]);
      if (m.index === arLessRe.lastIndex) arLessRe.lastIndex++;
    }
    collectSingle(arAtLeastRe, 'atLeast', promptNormAr, arThresholdSpans);
    collectSingle(arAtMostRe, 'atMost', promptNormAr, arThresholdSpans);
  }
  if (thresholdErrors.length) {
    return { status: 'abstain', reason: 'unparsed_threshold', unmodelled: [...new Set(thresholdErrors)].slice(0, 4) };
  }

  // Closed-world vocabulary gate: do not map unknown content words to the nearest known operation.
  const grammarWords = new Set(('please help me you what which how can i want need get arithmetic write return returns function code calculate compute find identify make create among that all only numbers number integers integer array arrays list lists elements element values value items item the a an of to in from for and with is are be it them these those now then precisely thank thanks keep select extract filter by than greater less more fewer zero first second third fourth fifth last ascending descending increasing decreasing positive negative even odd unique distinct maximum minimum max min largest smallest highest lowest sum total add average mean count sort order reverse flatten product multiply minus or either at least most no many').split(' '));
  const commonArabic = 'قم بـ من فضلك شكرا شكراً كل حدد يحقق حد اقل اكبر اكثر القيمة القيمه قيمه الصغري الصغرى العظمي العظمى لاعداد القيمه القيم الأعداد الاعداد الأرقام الارقام العناصر عنصر المصفوفة المصفوفه القائمة القائمه استخرج أوجد اوجد احسب عد بالضبط فقط دون تكرار حاصل الأكبر الاكبر الصفر صفر متوسط ما هو هي تعيد ترجع صفي لل للأرقام تصاعدي تصاعديا في احتفظ بالقيم رقما رقما فرديا فرديه موجود الحد الأدنى الأعلى اعلى احتفظ او اما'.split(/\s+/);
  const vocabularyWords = [
    ...Object.values(OPERATION_CONCEPTS).flat(), ...Object.values(FILTER_PREDICATES).flat(),
    ...Object.values(DIRECTION_QUALIFIERS).flat(), ...Object.keys(ORD_MAP), ...Object.keys(NUMERALS),
    ...Object.keys(EN_NUM_WORDS),
    ...grammarWords, ...commonArabic
  ];
  const lexicalWords = new Set();
  for (const word of vocabularyWords) {
    const normalized = normalizeArabicText(String(word)).toLowerCase();
    lexicalWords.add(normalized);
    // Arabic vocabulary entries are matched through the light stemmer, so the
    // stem of every entry is part of the closed vocabulary as well.
    if (/[\u0600-\u06FF]/.test(normalized)) lexicalWords.add(stemArabicWord(normalized));
  }
  const unknownWords = tokens.filter(t => {
    if (t.length <= 1 || lexicalWords.has(t)) return false;
    if (/^-?\d+(?:\.\d+)?$/.test(t)) return false;
    if (/[\u0600-\u06FF]/.test(t)) {
      const stem = stemArabicWord(t);
      if (lexicalWords.has(stem)) return false;
      // Arabic inflectional endings commonly attached to nouns/adjectives in
      // natural prompts. Only accept a reduced form when that form is already
      // in the closed vocabulary; never guess an operation from an unknown root.
      const reduced = stem.replace(/(?:ا|ان|ين|ون|ات)$/u, '');
      if (reduced !== stem && lexicalWords.has(reduced)) return false;
    }
    return true;
  });
  if (unknownWords.length) return { status: 'abstain', reason: 'unmodelled_vocabulary', unmodelled: [...new Set(unknownWords)].slice(0, 8) };
  const unsupportedCompositions = [
    /\b(?:between|without|each|every|any)\b/i,
    /(?:بين|بدون|لكل|اي|أي)\s+/
  ];
  const unsupportedHit = unsupportedCompositions.find(re => re.test(promptLower) || re.test(promptNormAr));
  if (unsupportedHit) return { status: 'abstain', reason: 'unsupported_compositional_operator', unmodelled: [prompt.match(unsupportedHit)?.[0] || 'unsupported qualifier'] };

  // Check for adversarial or out-of-scope non-programming prompts to abstain
  const outOfDomainWords = [
    'poem', 'romantic', 'moon', 'stars', 'story', 'space', 'stock', 'predict', 'finance', 'price',
    'delete all', 'root', '/etc', 'شعر', 'رومانسي', 'قمر', 'نجوم', 'قصة', 'فضاء', 'اسهم', 'بورصة', 'توقع', 'حذف النظام'
  ];

  for (const ood of outOfDomainWords) {
    if (promptLower.includes(ood) || promptNormAr.includes(ood)) {
      return {
        status: 'abstain',
        reason: 'out_of_domain',
        unmodelled: [ood]
      };
    }
  }

  // Detect operation
  let detectedOp = null;
  const opOrder = ['max', 'min', 'count', 'reverse', 'flatten', 'sum', 'average', 'sort', 'unique', 'length', 'product'];
  const arThresholdComparator = new RegExp(`(${AR_GREATER_WORDS.concat(AR_LESS_WORDS).join('|')})\\s+من\\s`);
  // An explicit maximum/minimum phrase wins over the comparator reading, so
  // "the largest value among the numbers greater than five" stays an aggregation
  // over a filtered subset.
  const arMaxPhrase = /(?:اكبر|اعلي|العظمي|اقصي|اعظم)\\s+(?:عدد|عنصر|قيمه|القيمه|قيمة|قيم)/;
  const arMinPhrase = /(?:اقل|اصغر|الصغري|ادني|اننى)\\s+(?:عدد|عنصر|قيمه|القيمه|قيمة|قيم)/;
  const insideSpan = (spans, start, len) => spans.some(([a, b]) => start >= a && start + len <= b);
  for (const op of opOrder) {
    const keywords = OPERATION_CONCEPTS[op] || [];
    for (const kw of keywords) {
      const isArabic = /[\u0600-\u06FF]/.test(kw);
      const haystack = isArabic ? promptNormAr : promptLower;
      const spans = isArabic ? arThresholdSpans : enThresholdSpans;
      const idx = haystack.indexOf(kw);
      // A comparator that is used as a threshold ("greater than five") is a
      // qualifier, not the maximum/minimum operation. An explicit operation
      // phrase ("the largest value") always wins.
      if (idx >= 0 && insideSpan(spans, idx, kw.length)) {
        const explicitOpPhrase = op === 'max' ? arMaxPhrase.test(promptNormAr)
          : op === 'min' ? arMinPhrase.test(promptNormAr) : false;
        if (!explicitOpPhrase) continue;
      }
      if (tokens.includes(kw) || promptLower.includes(kw) || promptNormAr.includes(kw)) {
        detectedOp = op;
        break;
      }
    }
    if (detectedOp) break;
  }

  // Nested aggregation ("sum of the number of positive values") has no faithful
  // representation in this grammar and is refused instead of being flattened.
  const nestedAggregation = [
    /\b(?:sum|total|average|mean)\s+of\s+(?:the\s+)?(?:count|number|length|size|sum|total|average)\b/i,
    /(?:حاصل\s+جمع|مجموع|المتوسط|متوسط)\s+من\s+(?:عدد|طول|مجموع|حاصل)/
  ].find(re => re.test(promptLower) || re.test(promptNormAr));
  if (nestedAggregation) {
    return { status: 'abstain', reason: 'unsupported_nested_aggregation', unmodelled: [prompt.match(nestedAggregation)?.[0] || 'nested aggregation'] };
  }

  // Collect every qualifier. Multiple qualifiers compose as a conjunction
  // ("positive even numbers", "greater than three and less than ten").
  const predicates = [];
  for (const t of thresholds) predicates.push(t);
  for (const [pred, keywords] of Object.entries(FILTER_PREDICATES)) {
    for (const kw of keywords) {
      const isArabic = /[\u0600-\u06FF]/.test(kw);
      const haystack = isArabic ? promptNormAr : promptLower;
      const spans = isArabic ? arThresholdSpans : enThresholdSpans;
      let matched = false;
      if (isArabic) {
        const idx = haystack.indexOf(kw);
        if (idx >= 0 && !insideSpan(spans, idx, kw.length)) matched = true;
      } else {
        const safe = kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const re = new RegExp(`(^|[^a-z0-9])${safe}([^a-z0-9]|$)`, 'i');
        const m = re.exec(haystack);
        if (m) {
          const start = m.index + m[1].length;
          if (!insideSpan(spans, start, kw.length)) matched = true;
        }
      }
      if (matched) {
        predicates.push({ kind: pred });
        break;
      }
    }
  }
  const hasGt0 = predicates.some(p => p.kind === 'greaterThan' && p.value === 0);
  const hasLt0 = predicates.some(p => p.kind === 'lessThan' && p.value === 0);
  const seenPred = new Set();
  const qualifiers = [];
  for (const p of predicates) {
    if (p.kind === 'positive' && hasGt0) continue;
    if (p.kind === 'negative' && hasLt0) continue;
    const key = `${p.kind}:${p.value ?? ''}`;
    if (seenPred.has(key)) continue;
    seenPred.add(key);
    qualifiers.push(p);
  }
  const detectedFilter = qualifiers.length ? qualifiers[0] : null;
  const hasQualifier = qualifiers.length > 0;

  // Disjunction is not modelled: refuse instead of guessing the intended branch.
  if (qualifiers.length > 1) {
    const disjunctive = /\b(?:or|either)\b/i.test(promptLower) || /(?:^|\s)(?:او|أو|اما)(?:\s|$)/.test(promptNormAr);
    if (disjunctive) {
      return { status: 'abstain', reason: 'unsupported_disjunction', unmodelled: ['or'] };
    }
  }

  // Detect direction (descending / ascending)
  let detectedDir = null;
  for (const [dir, keywords] of Object.entries(DIRECTION_QUALIFIERS)) {
    for (const kw of keywords) {
      if (promptLower.includes(kw) || promptNormAr.includes(kw)) {
        detectedDir = dir;
        break;
      }
    }
    if (detectedDir) break;
  }

  // Detect ordinal (e.g. second largest)
  let detectedOrd = null;
  for (const [ordKey, idx] of Object.entries(ORD_MAP)) {
    if (promptLower.includes(ordKey) || promptNormAr.includes(ordKey)) {
      detectedOrd = idx;
      break;
    }
  }

  // Detect distinct
  const hasDistinct = promptLower.includes('distinct') || promptLower.includes('unique') ||
                      promptNormAr.includes('فريد') || promptNormAr.includes('تكرار') || promptNormAr.includes('مميز');
  const cardinalSelection = parseCardinalSelection(promptLower, promptNormAr);

  // Build candidate AST
  let candidateAst = null;

  // Filter predicate AST builder
  const buildOnePredAst = (pred) => {
    const X = { k: 'x' };
    switch (pred.kind) {
      case 'positive':
        return { k: 'call', f: 'lt', a: [{ k: 'const', v: 0 }, X] };
      case 'negative':
        return { k: 'call', f: 'lt', a: [X, { k: 'const', v: 0 }] };
      case 'even':
        return { k: 'call', f: 'eq', a: [{ k: 'call', f: 'mod', a: [X, { k: 'const', v: 2 }] }, { k: 'const', v: 0 }] };
      case 'odd':
        return { k: 'call', f: 'not', a: [{ k: 'call', f: 'eq', a: [{ k: 'call', f: 'mod', a: [X, { k: 'const', v: 2 }] }, { k: 'const', v: 0 }] }] };
      case 'greaterThan': return { k: 'call', f: 'lt', a: [{ k: 'const', v: pred.value }, X] };
      case 'lessThan': return { k: 'call', f: 'lt', a: [X, { k: 'const', v: pred.value }] };
      case 'atLeast': return { k: 'call', f: 'le', a: [{ k: 'const', v: pred.value }, X] };
      case 'atMost': return { k: 'call', f: 'le', a: [X, { k: 'const', v: pred.value }] };
      default:
        return null;
    }
  };

  const buildPredAst = (preds) => {
    const parts = preds.map(buildOnePredAst).filter(Boolean);
    if (!parts.length) return null;
    return parts.reduce((acc, part) => ({ k: 'call', f: 'and', a: [acc, part] }));
  };

  const inp0 = { k: 'in', i: 0 };

  if (cardinalSelection) {
    const count = { k: 'const', v: cardinalSelection.count };
    const source = cardinalSelection.direction === 'last'
      ? { k: 'call', f: 'reverse', a: [inp0] }
      : inp0;
    const taken = { k: 'call', f: 'take', a: [source, count] };
    candidateAst = cardinalSelection.direction === 'last'
      ? { k: 'call', f: 'reverse', a: [taken] }
      : taken;
  } else if (detectedOrd !== null && detectedOrd > 0 && detectedOp === 'max') {
    return { status: 'abstain', reason: 'unsupported_ordinal_selection', unmodelled: [String(detectedOrd)] };
  }

  if (!candidateAst && (detectedOrd === 0 || detectedOrd === -1) && hasQualifier) {
    const filtered = { k: 'call', f: 'filter', a: [inp0, { k: 'lam', body: buildPredAst(qualifiers) }] };
    candidateAst = { k: 'call', f: detectedOrd === 0 ? 'head' : 'last', a: [filtered] };
  } else if (!candidateAst && detectedOrd === 1 && (promptLower.includes('largest') || promptLower.includes('biggest') || promptNormAr.includes('اكبر'))) {
    candidateAst = { k: 'call', f: 'nth', a: [
      { k: 'call', f: 'reverse', a: [{ k: 'call', f: 'sort', a: [{ k: 'call', f: 'unique', a: [inp0] }] }] },
      { k: 'const', v: 1 }
    ] };
  } else if (!candidateAst && ['sum', 'count', 'average', 'min', 'max'].includes(detectedOp)) {
    let valuesAst = inp0;
    if (hasDistinct) valuesAst = { k: 'call', f: 'unique', a: [valuesAst] };
    if (hasQualifier) {
      valuesAst = { k: 'call', f: 'filter', a: [valuesAst, { k: 'lam', body: buildPredAst(qualifiers) }] };
    }
    if (detectedOp === 'sum') candidateAst = { k: 'call', f: 'sum', a: [valuesAst] };
    else if (detectedOp === 'count') candidateAst = { k: 'call', f: 'len', a: [valuesAst] };
    else if (detectedOp === 'average') candidateAst = { k: 'call', f: 'div', a: [
      { k: 'call', f: 'sum', a: [valuesAst] }, { k: 'call', f: 'len', a: [valuesAst] }
    ] };
    else candidateAst = { k: 'call', f: detectedOp, a: [valuesAst] };
  } else if (!candidateAst && detectedOp === 'sort') {
    const sortedAst = { k: 'call', f: 'sort', a: [inp0] };
    if (detectedDir === 'descending') {
      const reversed = { k: 'call', f: 'reverse', a: [sortedAst] };
      candidateAst = detectedOrd === 0 ? { k: 'call', f: 'head', a: [reversed] }
        : detectedOrd === -1 ? { k: 'call', f: 'last', a: [reversed] }
        : reversed;
    } else {
      candidateAst = detectedOrd === 0 ? { k: 'call', f: 'head', a: [sortedAst] }
        : detectedOrd === -1 ? { k: 'call', f: 'last', a: [sortedAst] }
        : sortedAst;
    }
  } else if (!candidateAst && detectedOp === 'reverse') {
    const reversed = { k: 'call', f: 'reverse', a: [inp0] };
    candidateAst = detectedOrd === 0 ? { k: 'call', f: 'head', a: [reversed] }
      : detectedOrd === -1 ? { k: 'call', f: 'last', a: [reversed] }
      : reversed;
  } else if (!candidateAst && (detectedOp === 'unique' || hasDistinct)) {
    if (detectedOrd === 1 && (promptLower.includes('largest') || promptNormAr.includes('اكبر'))) {
      // second largest
      candidateAst = {
        k: 'call', f: 'nth',
        a: [
          { k: 'call', f: 'reverse', a: [{ k: 'call', f: 'sort', a: [{ k: 'call', f: 'unique', a: [inp0] }] }] },
          { k: 'const', v: 1 }
        ]
      };
    } else {
      candidateAst = { k: 'call', f: 'unique', a: [inp0] };
    }
  } else if (!candidateAst && hasQualifier && !detectedOp) {
    // filter only
    candidateAst = {
      k: 'call', f: 'filter',
      a: [inp0, { k: 'lam', body: buildPredAst(qualifiers) }]
    };
  } else if (!candidateAst && detectedOrd !== null && detectedOrd >= 0) {
    candidateAst = { k: 'call', f: 'nth', a: [inp0, { k: 'const', v: detectedOrd }] };
  } else if (!candidateAst && detectedOrd === -1) {
    candidateAst = { k: 'call', f: 'last', a: [inp0] };
  } else if (!candidateAst && detectedOp === 'average') {
    candidateAst = {
      k: 'call', f: 'div',
      a: [
        { k: 'call', f: 'sum', a: [inp0] },
        { k: 'call', f: 'len', a: [inp0] }
      ]
    };
  } else if (!candidateAst && detectedOp === 'max') {
    candidateAst = { k: 'call', f: 'max', a: [inp0] };
  } else if (!candidateAst && detectedOp === 'min') {
    candidateAst = { k: 'call', f: 'min', a: [inp0] };
  }

  if (!candidateAst) {
    return {
      status: 'abstain',
      reason: 'unmodelled_intent',
      unmodelled: tokens.slice(0, 5)
    };
  }

  // Output-kind consistency: aggregation requests cannot be silently returned as lists.
  const asksForList = /\b(list|array|sequence)\s+of\b/i.test(promptLower) || /قائمة\s+(?:من|ل)/.test(promptNormAr);
  const asksForNumber = /\b(number of|how many|count)\b/i.test(promptLower) || /عدد|كم\s/.test(promptNormAr);
  if (asksForList && ['sum', 'count', 'average', 'min', 'max'].includes(detectedOp)) {
    return { status: 'abstain', reason: 'requested_output_type_mismatch', unmodelled: ['list-vs-scalar'] };
  }
  if (asksForNumber && !['sum', 'count', 'average', 'min', 'max', 'length'].includes(detectedOp)) {
    return { status: 'abstain', reason: 'requested_output_type_mismatch', unmodelled: ['scalar-vs-list'] };
  }

  // Verify semantic qualifiers on adversarial probes before exposing the program.
  if (hasQualifier || hasDistinct) {
    const probes = [[-4, -1, 0, 1, 2, 2, 5, 6], [], [2, 2, -2, 0], [-5, 5, 6], [3, 4, 5, 10]];
    try {
      for (const values of probes) {
        let expectedValues = hasDistinct ? [...new Map(values.map(v => [JSON.stringify(v), v])).values()] : values.slice();
        if (hasQualifier) {
          const pred = buildPredAst(qualifiers);
          expectedValues = expectedValues.filter(v => Boolean(evalAst(pred, [values], { x: v })));
        }
        if (['average', 'min', 'max'].includes(detectedOp) && expectedValues.length === 0) continue;
        if (detectedOrd !== null && expectedValues.length === 0) continue;
        const out = evalAst(candidateAst, [values]);
        let expected = expectedValues;
        if (detectedOrd === 0) expected = expectedValues[0];
        else if (detectedOrd === -1) expected = expectedValues.at(-1);
        if (detectedOp === 'sum') expected = expectedValues.reduce((a, b) => a + b, 0);
        else if (detectedOp === 'count') expected = expectedValues.length;
        else if (detectedOp === 'average') expected = expectedValues.reduce((a, b) => a + b, 0) / expectedValues.length;
        else if (detectedOp === 'min') expected = Math.min(...expectedValues);
        else if (detectedOp === 'max') expected = Math.max(...expectedValues);
        if (JSON.stringify(out) !== JSON.stringify(expected)) throw new Error('semantic-qualifier-invariant');
      }
    } catch {
      return { status: 'abstain', reason: 'semantic_property_check_failed', unmodelled: hasQualifier ? qualifiers.map(q => q.kind) : ['distinct'] };
    }
  }

  // Run derived sanity checks
  const sanityPassed = hasQualifier || cardinalSelection ? true
    : verifySanityChecks(candidateAst, detectedOp || detectedFilter || (detectedOrd !== null ? 'selector' : null));
  if (!sanityPassed) {
    return {
      status: 'abstain',
      reason: 'sanity_checks_failed',
      ast: candidateAst
    };
  }

  return {
    status: 'ok',
    ast: candidateAst,
    source: toSource(candidateAst, 1),
    derivedChecks: { sanityPassed: true },
    qualifiers: qualifiers.map(q => (q.value === undefined ? q.kind : `${q.kind}(${q.value})`))
  };
}
