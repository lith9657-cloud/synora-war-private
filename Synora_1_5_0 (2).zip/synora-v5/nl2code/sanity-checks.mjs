/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { evalAst, deepEqual } from '../synthesis/dsl.mjs';

export function executeAST(ast, input) {
  const args = (Array.isArray(input) && input.length === 1 && Array.isArray(input[0])) ? input : [input];
  return evalAst(ast, args);
}

/**
 * Runs automated sanity checks and invariant verification on a candidate AST
 */
export function verifySanityChecks(ast, opConcept) {
  try {
    // 1. Singleton check
    const single = opConcept === 'selector' ? [42, 43, 44] : [42];
    const singleOut = executeAST(ast, [single]);

    // 2. Empty list check (should either return 0, [], or throw clean RangeError)
    try {
      executeAST(ast, [[]]);
    } catch (e) {
      if (!(e instanceof RangeError)) return false;
    }

    // 3. Permutation check for sort
    if (opConcept === 'sort') {
      const sample = [5, 2, 8, 1, 9];
      const sorted = executeAST(ast, [sample]);
      if (!Array.isArray(sorted) || sorted.length !== sample.length) return false;
      // Elements must match multiset
      const s1 = [...sample].sort((a, b) => a - b);
      const s2 = [...sorted].sort((a, b) => a - b);
      if (!deepEqual(s1, s2)) return false;
    }

    // 4. Subsequence / size bound check for filter
    if (opConcept === 'filter' || opConcept === 'unique') {
      const sample = [1, 2, 2, 3, 1];
      const out = executeAST(ast, [sample]);
      if (!Array.isArray(out) || out.length > sample.length) return false;
    }

    // Ordinal selectors must be checked on a list long enough to contain the
    // requested index; a singleton probe rejects valid second/third selectors.
    if (opConcept === 'selector') {
      const selected = executeAST(ast, [[10, 20, 30, 40]]);
      if (Array.isArray(selected) || selected === undefined) return false;
    }

    return true;
  } catch {
    return false;
  }
}
