/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Arabic morphological analyzer and normalizer (rule-based, non-neural).
 * Performs diacritics removal, alef/hamza normalization, taa-marbuta normalization,
 * clitic stripping (prefixed waw, baa, kaf, faa, lam, definite article 'al-'),
 * and light stemming for dual/plural suffixes (-oon, -een, -aat, -aan, -ayn).
 */

const DIACRITICS = /[\u064B-\u0652\u0670\u0640]/g; // Fatha, Damma, Kasra, Sukun, Shadda, Tatweel
const ALEF_VARIANTS = /[إأآٱ]/g;

export function normalizeArabicText(text) {
  if (typeof text !== 'string') return '';
  return text
    .replace(DIACRITICS, '')
    .replace(ALEF_VARIANTS, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[ـ]/g, '')
    .trim()
    .toLowerCase();
}

/**
 * Light stemmer for Arabic words
 */
export function stemArabicWord(word) {
  let norm = normalizeArabicText(word);
  if (norm.length <= 2) return norm;

  // Strip prefixes (waw, faa, baa, kaf, lam, al-)
  if (norm.startsWith('ال') && norm.length > 4) {
    norm = norm.slice(2);
  } else if ((norm.startsWith('و') || norm.startsWith('ف')) && norm.length > 3) {
    norm = norm.slice(1);
    if (norm.startsWith('ال') && norm.length > 4) {
      norm = norm.slice(2);
    }
  } else if ((norm.startsWith('ب') || norm.startsWith('ك') || norm.startsWith('ل')) && norm.length > 3) {
    norm = norm.slice(1);
    if (norm.startsWith('ال') && norm.length > 4) {
      norm = norm.slice(2);
    }
  }

  // Strip suffixes: dual/plural (-oon, -een, -aat, -aan, -ayn, -ha, -hum, -na, -ya)
  const suffixes = ['ون', 'ين', 'ات', 'ان', 'ها', 'هم', 'نا', 'كم', 'ه'];
  for (const suf of suffixes) {
    if (norm.endsWith(suf) && norm.length > suf.length + 2) {
      norm = norm.slice(0, -suf.length);
      break;
    }
  }

  return norm;
}
