import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { validateAst, evalAst, VALUE_TYPES, conforms } from '../synthesis/dsl.mjs';
import { synthesize } from '../synthesis/synthesize.mjs';

export const LEARNING_SCHEMA_VERSION = 1;
const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
const canonical = value => {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;
  return JSON.stringify(value);
};
const clone = value => JSON.parse(JSON.stringify(value));
const isInt = n => Number.isSafeInteger(n);
const mod = (n, m) => ((n % m) + m) % m;

function validateExamples(examples, modulus, label) {
  if (!Array.isArray(examples) || examples.length < 2 || examples.length > 200) throw new TypeError(`${label} must contain 2..200 examples`);
  const ids = new Set();
  for (const [i, ex] of examples.entries()) {
    if (!ex || typeof ex !== 'object' || typeof ex.id !== 'string' || !ex.id || ids.has(ex.id)) throw new TypeError(`${label}[${i}] needs a unique non-empty id`);
    ids.add(ex.id);
    if (!isInt(ex.input) || ex.input < 0 || ex.input >= modulus || !isInt(ex.output) || ex.output < 0 || ex.output >= modulus) throw new TypeError(`${label}[${i}] values must be integers in [0, modulus)`);
  }
  return examples;
}

function evalAffine(input, params) {
  const { modulus, a, b } = params;
  const one = x => mod(a * x + b, modulus);
  if (isInt(input)) {
    if (input < 0 || input >= modulus) return { ok: false, reason: 'input-out-of-domain' };
    return { ok: true, output: one(input), trace: [{ op: 'affine-mod', input, output: one(input), modulus, a, b }] };
  }
  if (Array.isArray(input) && input.length <= 1000 && input.every(x => isInt(x) && x >= 0 && x < modulus)) {
    const output = input.map(one);
    return { ok: true, output, trace: input.map((x, i) => ({ op: 'affine-mod', input: x, output: output[i], modulus, a, b })) };
  }
  return { ok: false, reason: 'input-shape-or-domain-not-supported' };
}

function validateAffineParams(p) {
  if (!p || !Number.isInteger(p.modulus) || p.modulus < 2 || p.modulus > 97 || !Number.isInteger(p.a) || p.a < 0 || p.a >= p.modulus || !Number.isInteger(p.b) || p.b < 0 || p.b >= p.modulus) throw new TypeError('invalid affine-mod parameters');
  return true;
}

const SYNTHESIS_LIFETIME_EXPRESSIONS = 50_000_000;
function validateProgramParams(p) {
  if (!p || !Number.isInteger(p.arity) || p.arity < 1 || p.arity > 3 || !Array.isArray(p.argTypes) || p.argTypes.length !== p.arity || !p.argTypes.every(t => VALUE_TYPES.includes(t) && t !== 'bool') || !VALUE_TYPES.includes(p.outType) || !Number.isInteger(p.size) || p.size < 1) throw new TypeError('invalid program parameters');
  validateAst(p.ast, p.arity);
  return true;
}

function evalProgram(input, params) {
  if (!Array.isArray(input) || input.length !== params.arity) return { ok: false, reason: 'input-must-be-array-of-arguments' };
  for (let i = 0; i < params.arity; i++) if (!conforms(input[i], params.argTypes[i])) return { ok: false, reason: 'input-type-mismatch' };
  let output;
  try { output = evalAst(params.ast, input); } catch (err) { return { ok: false, reason: `program-runtime-error:${err.message}` }; }
  if (!conforms(output, params.outType) && !(Array.isArray(output) && params.outType.startsWith('L:'))) return { ok: false, reason: 'output-type-mismatch' };
  return { ok: true, output, trace: [{ op: 'program', size: params.size, arity: params.arity }] };
}

function validateSkill(skill) {
  if (!skill || typeof skill !== 'object' || typeof skill.id !== 'string' || !skill.id || !Number.isInteger(skill.version) || skill.version < 1) throw new TypeError('invalid skill identity/version');
  if (!['affine-mod', 'composition', 'program'].includes(skill.kind)) throw new TypeError('skill kind is not in the allowed DSL');
  if (skill.kind === 'program') validateProgramParams(skill.params);
  else if (skill.kind === 'affine-mod') validateAffineParams(skill.params);
  else {
    if (!Array.isArray(skill.steps) || skill.steps.length < 2 || skill.steps.length > 8 || !skill.steps.every(s => s && s.kind === 'affine-mod')) throw new TypeError('composition must contain 2..8 affine-mod steps');
    for (const step of skill.steps) validateAffineParams(step.params);
    const m = skill.steps[0].params.modulus;
    if (!skill.steps.every(s => s.params.modulus === m)) throw new TypeError('composition modulus mismatch');
  }
  if (!['accepted', 'rejected'].includes(skill.status)) throw new TypeError('invalid skill status');
  if (skill.active !== undefined && typeof skill.active !== 'boolean') throw new TypeError('invalid skill active flag');
  return true;
}

export class DigitalObjectLearner {
  constructor({ id = `learner-${crypto.randomUUID()}`, maxOperations = 2_000_000, maxModulus = 97 } = {}) {
    if (typeof id !== 'string' || !id.trim()) throw new TypeError('learner id is required');
    if (!Number.isSafeInteger(maxOperations) || maxOperations < 1 || maxOperations > 10_000_000) throw new RangeError('maxOperations must be 1..10000000');
    if (!Number.isInteger(maxModulus) || maxModulus < 2 || maxModulus > 97) throw new RangeError('maxModulus must be 2..97');
    this.id = id;
    this.type = 'digital-object-learning-agent';
    this.version = 1;
    this.state = 'active';
    this.limits = { maxOperations, maxModulus };
    this.skills = new Map();
    this.events = [];
    this.seenTrainingDigests = new Map();
    this.operations = 0;
    this.synthesisExpressions = 0;
  }

  snapshot() {
    return {
      schemaVersion: LEARNING_SCHEMA_VERSION,
      object: { id: this.id, type: this.type, version: this.version, state: this.state, limits: clone(this.limits) },
      skills: [...this.skills.values()].map(clone),
      events: clone(this.events),
      seenTrainingDigests: [...this.seenTrainingDigests.entries()].sort((a, b) => a[0].localeCompare(b[0])),
      operations: this.operations,
      ...(this.synthesisExpressions ? { synthesisExpressions: this.synthesisExpressions } : {})
    };
  }

  learnAffine({ name, modulus, training, development = [] }) {
    if (typeof name !== 'string' || !name.trim()) throw new TypeError('skill name is required');
    if (!Number.isInteger(modulus) || modulus < 2 || modulus > this.limits.maxModulus) throw new RangeError(`modulus must be 2..${this.limits.maxModulus}`);
    validateExamples(training, modulus, 'training');
    if (development.length) validateExamples(development, modulus, 'development');
    // Digest the semantic examples, not their caller-chosen IDs or ordering. This prevents
    // the same experience being induced again just by renaming/reordering the examples.
    const semanticExamples = training.map(e => ({ input: e.input, output: e.output })).sort((a, b) => a.input - b.input || a.output - b.output);
    const trainingDigest = sha256(canonical({ modulus, examples: semanticExamples }));
    const knownId = this.seenTrainingDigests.get(trainingDigest);
    if (knownId) {
      if (this.skills.has(knownId)) return { accepted: this.skills.get(knownId).status === 'accepted', duplicate: true, skill: clone(this.skills.get(knownId)), reason: 'training-experience-already-processed' };
      return { accepted: false, duplicate: true, reason: 'training-experience-already-rejected' };
    }

    const candidates = [];
    // Each (a,b) candidate costs one candidate visit plus at most training.length
    // comparisons. Reserve the worst case before starting; never exceed the declared budget.
    const estimated = modulus * modulus * (training.length + 1);
    if (estimated > this.limits.maxOperations - this.operations) {
      this.events.push({ type: 'skill-learning-rejected', reason: 'operation-budget-exceeded', name, estimatedOperations: estimated });
      return { accepted: false, reason: 'operation-budget-exceeded', estimatedOperations: estimated };
    }
    for (let a = 0; a < modulus; a++) {
      for (let b = 0; b < modulus; b++) {
        this.operations++;
        let matches = true;
        for (const ex of training) {
          this.operations++;
          if (mod(a * ex.input + b, modulus) !== ex.output) { matches = false; break; }
        }
        if (matches) candidates.push({ a, b });
      }
    }
    if (candidates.length !== 1) {
      const event = { type: 'skill-learning-rejected', name, trainingDigest, reason: candidates.length === 0 ? 'no-dsl-candidate-fits-training' : 'ambiguous-induction', candidateCount: candidates.length };
      this.events.push(event);
      this.seenTrainingDigests.set(trainingDigest, `rejected-${trainingDigest.slice(0, 12)}`);
      return { accepted: false, reason: event.reason, candidateCount: candidates.length };
    }

    const params = { modulus, ...candidates[0] };
    const devPassed = development.filter(ex => mod(params.a * ex.input + params.b, modulus) === ex.output).length;
    const devTotal = development.length;
    const devAccuracy = devTotal ? devPassed / devTotal : null;
    if (devTotal > 0 && devPassed !== devTotal) {
      const event = { type: 'skill-learning-rejected', name, trainingDigest, reason: 'development-validation-failed', developmentPassed: devPassed, developmentCount: devTotal };
      this.events.push(event);
      this.seenTrainingDigests.set(trainingDigest, `rejected-${trainingDigest.slice(0, 12)}`);
      return { accepted: false, reason: event.reason, developmentPassed: devPassed, developmentCount: devTotal };
    }
    const skillId = `skill-${sha256(canonical({ name, trainingDigest, params })).slice(0, 16)}`;
    const skill = {
      id: skillId, name, kind: 'affine-mod', version: 1, status: 'accepted', active: true,
      params, conditions: { input: 'integer-or-array-of-integers', domain: `[0, ${modulus})`, maxArrayLength: 1000 },
      procedure: 'output[i] = ((a * input[i] + b) mod modulus + modulus) mod modulus',
      provenance: { source: 'induced-by-bounded-dsl-enumeration', trainingDigest, trainingExampleIds: training.map(e => e.id).sort(), trainingExampleCount: training.length, trainingExamples: semanticExamples, candidateCount: candidates.length },
      validation: { developmentCount: devTotal, developmentPassed: devPassed, developmentAccuracy: devAccuracy, developmentExampleIds: development.map(e => e.id).sort() },
      outcomes: { successes: 0, failures: 0, unsupportedInputs: 0 },
      history: [{ version: 1, action: 'induced-and-accepted', reason: 'unique candidate satisfies all training examples and all supplied development checks', priorSkillId: null }]
    };
    validateSkill(skill);
    this.skills.set(skill.id, skill);
    this.seenTrainingDigests.set(trainingDigest, skill.id);
    this.events.push({ type: 'skill-accepted', skillId: skill.id, trainingDigest, source: skill.provenance.source, params: clone(params) });
    return { accepted: true, duplicate: false, skill: clone(skill), candidateCount: candidates.length, operationsUsed: this.operations };
  }

  /**
   * Induce a skill from input/output examples with bounded program synthesis. Search uses the training
   * examples only; the result must also satisfy held-out development examples, and a program is refused
   * when other programs fit the same examples but behave differently (the examples under-determine it).
   */
  learnProgram({ name, training, development, maxSize, budgetMs, maxExpressions } = {}) {
    if (typeof name !== 'string' || !name.trim()) throw new TypeError('skill name is required');
    const opts = { training, development, ...(maxSize !== undefined ? { maxSize } : {}), ...(budgetMs !== undefined ? { budgetMs } : {}), ...(maxExpressions !== undefined ? { maxExpressions } : {}) };
    const semantic = (Array.isArray(training) ? training : []).map(e => ({ input: e?.input, output: e?.output })).sort((a, b) => canonical(a).localeCompare(canonical(b)));
    const trainingDigest = sha256(canonical({ kind: 'program', examples: semantic }));
    const knownId = this.seenTrainingDigests.get(trainingDigest);
    if (knownId) {
      if (this.skills.has(knownId)) return { accepted: this.skills.get(knownId).status === 'accepted', duplicate: true, skill: clone(this.skills.get(knownId)), reason: 'training-experience-already-processed' };
      return { accepted: false, duplicate: true, reason: 'training-experience-already-rejected' };
    }
    const reserve = maxExpressions ?? 300_000;
    if (reserve > SYNTHESIS_LIFETIME_EXPRESSIONS - this.synthesisExpressions) {
      this.events.push({ type: 'skill-learning-rejected', reason: 'synthesis-budget-exceeded', name });
      return { accepted: false, reason: 'synthesis-budget-exceeded' };
    }
    const result = synthesize(opts);
    this.synthesisExpressions += result.explored;
    if (!result.found) {
      const event = { type: 'skill-learning-rejected', name, trainingDigest, reason: result.reason, explored: result.explored, ...(result.alternativeBehaviours !== undefined ? { alternativeBehaviours: result.alternativeBehaviours } : {}) };
      this.events.push(event);
      if (['no-program-fits-training', 'development-validation-failed', 'ambiguous-examples'].includes(result.reason)) this.seenTrainingDigests.set(trainingDigest, `rejected-${trainingDigest.slice(0, 12)}`);
      return { accepted: false, reason: result.reason, explored: result.explored, ...(result.disambiguatingQueries ? { disambiguatingQueries: result.disambiguatingQueries } : {}), ...(result.devRejected ? { devRejected: result.devRejected } : {}), ...(result.stoppedBy ? { stoppedBy: result.stoppedBy } : {}) };
    }
    const params = { ast: result.ast, arity: result.arity, argTypes: result.argTypes, outType: result.outType, size: result.size };
    const skill = {
      id: `skill-${sha256(canonical({ name, trainingDigest, ast: result.ast })).slice(0, 16)}`, name, kind: 'program', version: 1, status: 'accepted', active: true,
      params, conditions: { input: `${params.arity} argument(s): ${params.argTypes.join(', ')}`, output: params.outType, limits: 'step-bounded interpreter; lists up to 1000 items' },
      procedure: result.source,
      provenance: { source: 'induced-by-bounded-program-synthesis', trainingDigest, trainingExampleCount: training.length, trainingExamples: semantic, candidateCount: result.candidateCount, alternativeBehaviours: result.alternativeBehaviours, ambiguityCheck: result.ambiguityCheck, search: { explored: result.explored, maxSizeReached: result.maxSizeReached, programSize: result.size } },
      validation: { developmentCount: development.length, developmentPassed: development.length, developmentAccuracy: 1 },
      outcomes: { successes: 0, failures: 0, unsupportedInputs: 0 },
      history: [{ version: 1, action: 'induced-and-accepted', reason: 'smallest program fits all training examples, passes all held-out development examples, and no differently-behaving program fit the examples', priorSkillId: null }]
    };
    validateSkill(skill);
    this.skills.set(skill.id, skill);
    this.seenTrainingDigests.set(trainingDigest, skill.id);
    this.events.push({ type: 'skill-accepted', skillId: skill.id, trainingDigest, source: skill.provenance.source, programSize: params.size, arity: params.arity });
    return { accepted: true, duplicate: false, skill: clone(skill), explored: result.explored };
  }

  apply(skillId, input) {
    const skill = this.skills.get(skillId);
    if (!skill || skill.status !== 'accepted' || skill.active === false) return { ok: false, abstain: true, reason: 'skill-unavailable-or-superseded', skillId };
    validateSkill(skill);
    let result;
    if (skill.kind === 'affine-mod') result = evalAffine(input, skill.params);
    else if (skill.kind === 'program') result = evalProgram(input, skill.params);
    else {
      let value = input;
      const trace = [];
      for (const step of skill.steps) {
        const r = evalAffine(value, step.params);
        if (!r.ok) return { ok: false, abstain: true, reason: r.reason, skillId, trace };
        value = r.output; trace.push(...r.trace);
      }
      result = { ok: true, output: value, trace };
    }
    if (!result.ok) {
      skill.outcomes.unsupportedInputs++;
      this.events.push({ type: 'skill-abstention', skillId, reason: result.reason });
      return { ...result, abstain: true, skillId };
    }
    return { ...result, skillId, skillVersion: skill.version, provenance: clone(skill.provenance ?? { source: 'composition' }) };
  }

  recordEvaluation(skillId, { success, evidenceId }) {
    const skill = this.skills.get(skillId);
    if (!skill || skill.status !== 'accepted') throw new Error('cannot evaluate unknown or rejected skill');
    if (typeof success !== 'boolean' || typeof evidenceId !== 'string' || !evidenceId) throw new TypeError('success and evidenceId are required');
    const eventKey = `eval:${skillId}:${evidenceId}`;
    const prior = this.events.find(e => e.eventKey === eventKey);
    if (prior) {
      if (prior.success !== success) throw new Error('evaluation evidence ID conflict');
      return { duplicate: true };
    }
    if (success) skill.outcomes.successes++; else skill.outcomes.failures++;
    this.events.push({ type: 'skill-evaluation', eventKey, skillId, success, evidenceId });
    return { duplicate: false, outcomes: clone(skill.outcomes) };
  }

  proposeMutation(skillId, { param, value, development, regression = [] }) {
    const original = this.skills.get(skillId);
    if (!original || original.status !== 'accepted' || original.active === false || original.kind !== 'affine-mod') throw new Error('mutation requires an active accepted affine-mod skill');
    if (!['a', 'b'].includes(param) || !Number.isInteger(value) || value < 0 || value >= original.params.modulus) throw new TypeError('only bounded a/b parameter mutations are allowed');
    validateExamples(development, original.params.modulus, 'development');
    if (regression.length) validateExamples(regression, original.params.modulus, 'regression');
    const score = (skill, examples) => examples.filter(e => mod(skill.params.a * e.input + skill.params.b, skill.params.modulus) === e.output).length;
    const trainingRegression = (original.provenance?.trainingExamples ?? []).map((e, i) => ({ id: `training-${i}`, ...e }));
    const allRegression = [...trainingRegression, ...regression];
    const beforeDev = score(original, development), beforeRegression = score(original, allRegression);
    const candidate = clone(original);
    candidate.params[param] = value;
    candidate.version = original.version + 1;
    const afterDev = score(candidate, development), afterRegression = score(candidate, allRegression);
    const accepted = afterDev > beforeDev && afterRegression >= beforeRegression;
    const decision = {
      type: 'skill-mutation-decision', skillId, fromVersion: original.version, candidateVersion: candidate.version,
      diff: { [param]: { before: original.params[param], after: value } },
      metrics: { development: { before: beforeDev, after: afterDev, total: development.length }, regression: { before: beforeRegression, after: afterRegression, total: allRegression.length, trainingIncluded: trainingRegression.length } },
      accepted, reason: accepted ? 'strict-development-improvement-without-regression-loss' : 'acceptance-criterion-not-met', rollback: !accepted
    };
    if (accepted) {
      candidate.id = `skill-${sha256(canonical({ parent: skillId, version: candidate.version, params: candidate.params })).slice(0, 16)}`;
      candidate.active = true;
      candidate.provenance = { ...clone(original.provenance), source: 'bounded-mutation-of-accepted-skill', parentSkillId: original.id };
      candidate.history = [...original.history, { version: candidate.version, action: 'mutation-accepted', reason: decision.reason, priorSkillId: original.id, diff: clone(decision.diff) }];
      original.active = false;
      original.history.push({ version: original.version, action: 'superseded-by-accepted-mutation', reason: decision.reason, nextSkillId: candidate.id });
      this.skills.set(candidate.id, candidate);
      decision.newSkillId = candidate.id;
    } else {
      original.history.push({ version: original.version, action: 'mutation-rejected', reason: decision.reason, candidateVersion: candidate.version, diff: clone(decision.diff) });
      original.active = true;
      decision.activeSkillId = original.id;
    }
    this.events.push(decision);
    return clone(decision);
  }

  compose(skillIds, { name = 'composed-skill' } = {}) {
    if (!Array.isArray(skillIds) || skillIds.length < 2 || skillIds.length > 8) throw new TypeError('composition requires 2..8 skill IDs');
    const steps = skillIds.map(id => this.skills.get(id));
    if (steps.some(s => !s || s.status !== 'accepted' || s.active === false || s.kind !== 'affine-mod')) throw new Error('composition includes an unavailable, superseded, or non-affine skill');
    const m = steps[0].params.modulus;
    if (!steps.every(s => s.params.modulus === m)) throw new Error('composition requires matching domains/moduli');
    const skill = {
      id: `composition-${sha256(canonical(skillIds)).slice(0, 16)}`, name, kind: 'composition', version: 1, status: 'accepted', active: true,
      steps: steps.map(s => ({ kind: 'affine-mod', params: clone(s.params), sourceSkillId: s.id, sourceVersion: s.version })),
      conditions: { input: 'integer-or-array-of-integers', domain: `[0, ${m})`, maxArrayLength: 1000 },
      provenance: { source: 'composed-from-accepted-skills', componentSkillIds: [...skillIds] },
      outcomes: { successes: 0, failures: 0, unsupportedInputs: 0 },
      history: [{ version: 1, action: 'composition-created', reason: 'compatible DSL signatures and shared domain', componentSkillIds: [...skillIds] }]
    };
    validateSkill(skill);
    if (!this.skills.has(skill.id)) {
      this.skills.set(skill.id, skill);
      this.events.push({ type: 'skill-composed', skillId: skill.id, componentSkillIds: [...skillIds] });
    }
    return clone(this.skills.get(skill.id));
  }

  save(filePath) {
    const target = path.resolve(filePath), dir = path.dirname(target), lockPath = `${target}.lock`;
    fs.mkdirSync(dir, { recursive: true });
    let lockFd;
    let lockAcquired = false;
    try {
      lockFd = fs.openSync(lockPath, 'wx', 0o600);
      lockAcquired = true;
      fs.writeFileSync(lockFd, JSON.stringify({ pid: process.pid, startedAt: new Date().toISOString() }));
      if (fs.existsSync(target)) {
        try { DigitalObjectLearner.load(target); }
        catch (err) { throw new Error(`existing target is invalid; refusing to replace it: ${err.message}`); }
        fs.copyFileSync(target, `${target}.bak`);
        const bakFd = fs.openSync(`${target}.bak`, 'r'); try { fs.fsyncSync(bakFd); } finally { fs.closeSync(bakFd); }
      }
      const payload = this.snapshot();
      const envelope = { payload, sha256: sha256(canonical(payload)) };
      const tmp = `${target}.tmp-${process.pid}-${crypto.randomBytes(6).toString('hex')}`;
      let fd;
      try {
        fd = fs.openSync(tmp, 'wx', 0o600);
        fs.writeFileSync(fd, JSON.stringify(envelope)); fs.fsyncSync(fd); fs.closeSync(fd); fd = undefined;
        fs.renameSync(tmp, target);
        const dirFd = fs.openSync(dir, 'r'); try { fs.fsyncSync(dirFd); } finally { fs.closeSync(dirFd); }
      } finally {
        if (fd !== undefined) fs.closeSync(fd);
        try { fs.unlinkSync(tmp); } catch {}
      }
      return { path: target, sha256: envelope.sha256, bytes: fs.statSync(target).size };
    } catch (err) {
      throw new Error(`learning persistence write failed: ${err.message}`, { cause: err });
    } finally {
      if (lockFd !== undefined) fs.closeSync(lockFd);
      // Never remove a lock owned by another writer when exclusive acquisition failed.
      if (lockAcquired) { try { fs.unlinkSync(lockPath); } catch {} }
    }
  }

  static load(filePath) {
    let envelope;
    try { envelope = JSON.parse(fs.readFileSync(filePath, 'utf8')); }
    catch (err) { throw new Error(`learning persistence read/parse failed: ${err.message}`, { cause: err }); }
    if (!envelope || !envelope.payload || typeof envelope.sha256 !== 'string' || sha256(canonical(envelope.payload)) !== envelope.sha256) throw new Error('learning persistence integrity check failed');
    const p = envelope.payload;
    if (p.schemaVersion !== LEARNING_SCHEMA_VERSION) throw new Error(`learning schema/version invalid: ${p.schemaVersion}`);
    if (!p.object || typeof p.object.id !== 'string' || !p.object.id.trim() || p.object.type !== 'digital-object-learning-agent' || !Number.isSafeInteger(p.object.version) || p.object.version < 1 || !['active', 'inactive'].includes(p.object.state) || !Array.isArray(p.skills) || !Array.isArray(p.events) || !Array.isArray(p.seenTrainingDigests) || !Number.isSafeInteger(p.operations) || p.operations < 0) throw new Error('learning persistence payload invalid');
    const learner = new DigitalObjectLearner({ id: p.object.id, maxOperations: p.object.limits?.maxOperations, maxModulus: p.object.limits?.maxModulus });
    if (p.operations > learner.limits.maxOperations) throw new Error('learning persistence operation count exceeds configured budget');
    if (p.synthesisExpressions !== undefined && (!Number.isSafeInteger(p.synthesisExpressions) || p.synthesisExpressions < 0 || p.synthesisExpressions > SYNTHESIS_LIFETIME_EXPRESSIONS)) throw new Error('learning persistence synthesis budget invalid');
    learner.version = p.object.version; learner.state = p.object.state; learner.operations = p.operations; learner.synthesisExpressions = p.synthesisExpressions ?? 0;
    for (const skill of p.skills) { validateSkill(skill); if (learner.skills.has(skill.id)) throw new Error(`duplicate skill id: ${skill.id}`); learner.skills.set(skill.id, clone(skill)); }
    learner.events = clone(p.events);
    if (!learner.events.every(e => e && typeof e === 'object' && typeof e.type === 'string')) throw new Error('invalid learning event history');
    learner.seenTrainingDigests = new Map();
    for (const pair of p.seenTrainingDigests) {
      if (!Array.isArray(pair) || pair.length !== 2) throw new Error('invalid training deduplication entry');
      const [digest, id] = pair;
      if (!/^[a-f0-9]{64}$/.test(digest) || typeof id !== 'string' || learner.seenTrainingDigests.has(digest)) throw new Error('invalid training deduplication index');
      if (!id.startsWith('rejected-') && !learner.skills.has(id)) throw new Error('training deduplication index points to missing skill');
      learner.seenTrainingDigests.set(digest, id);
    }
    for (const skill of learner.skills.values()) {
      if (skill.kind === 'composition') for (const step of skill.steps) {
        const source = learner.skills.get(step.sourceSkillId);
        if (!source || source.version !== step.sourceVersion || source.kind !== 'affine-mod') throw new Error('composition references missing/incompatible source skill');
      }
    }
    return learner;
  }
}

export const learningInternals = Object.freeze({ canonical, sha256, mod });
