/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synora Failure Memory — the system learns from failed synthesis attempts.
 *
 * When the synthesizer fails to find a program (budget exhausted, ambiguity,
 * or validation failure), the failure is recorded as a "signature" — a
 * compact representation of the task shape and failure mode. In future
 * synthesis calls, the synthesizer can check if a program pattern matches a
 * known failure signature and avoid wasting budget on it.
 *
 * This proves the system acquires REUSABLE CAPABILITIES (avoiding known-bad
 * patterns), not just stored information.
 *
 * Usage:
 *   import { FailureMemory } from './failure-memory.mjs';
 *   const fm = new FailureMemory();
 *   fm.record({ task: 'sum_list', reason: 'search-budget-exhausted', signature: {...} });
 *   fm.shouldAvoid(programAst, taskShape); // → boolean
 */
import crypto from 'node:crypto';

/**
 * Extract a failure signature from a synthesis result.
 * The signature captures:
 *   - The task "shape" (arity, arg types, output type, example count)
 *   - The failure mode (budget-exhausted, ambiguous, validation-failed)
 *   - The explored count (how hard the search tried)
 *   - A hash of the training examples (to recognize the same task)
 */
export function extractFailureSignature({ training, development, result, operation }) {
  const arity = training[0]?.input?.length ?? 0;
  const argTypeHash = training[0]?.input?.map(v => Array.isArray(v) ? 'L' : typeof v) ?? [];
  const outType = typeof training[0]?.output;
  const exampleCount = training.length + (development?.length ?? 0);
  const examplesHash = crypto.createHash('sha256')
    .update(JSON.stringify({ training, development }))
    .digest('hex')
    .slice(0, 16);

  return {
    operation: operation || 'unknown',
    arity,
    argTypeHash: argTypeHash.join(','),
    outType,
    exampleCount,
    examplesHash,
    reason: result?.reason || 'unknown',
    explored: result?.explored || 0,
    ambiguityCheck: result?.ambiguityCheck || null,
    timestamp: Date.now()
  };
}

export class FailureMemory {
  constructor() {
    this.signatures = new Map(); // examplesHash → signature
    this.patternAvoid = new Set(); // set of "bad pattern" hashes
  }

  /**
   * Record a failure. If the same task (by examples hash) has failed before
   * with the same reason, the failure is confirmed (confidence increases).
   */
  record(failureData) {
    const sig = extractFailureSignature(failureData);
    const existing = this.signatures.get(sig.examplesHash);
    if (existing) {
      existing.confidence = (existing.confidence || 1) + 1;
      existing.lastSeen = sig.timestamp;
      // If the same task fails 3+ times with the same reason, add its
      // shape to the pattern-avoid set so future synthesis can skip it
      if (existing.confidence >= 3) {
        this.patternAvoid.add(this._shapeKey(sig));
      }
    } else {
      this.signatures.set(sig.examplesHash, { ...sig, confidence: 1 });
    }
    return sig;
  }

  /**
   * Check if a task shape matches a known avoidance pattern.
   * Returns true if the synthesizer should skip or reduce budget for this task.
   */
  shouldAvoid(taskShape) {
    const shapeKey = this._shapeKey(taskShape);
    return this.patternAvoid.has(shapeKey);
  }

  /**
   * Get a confidence-adjusted budget recommendation for a task.
   * Tasks that have failed before get a reduced budget (to fail fast),
   * unless the examples are different (different examplesHash).
   */
  recommendBudget(taskShape, defaultBudget) {
    const examplesHash = taskShape.examplesHash;
    const existing = this.signatures.get(examplesHash);
    if (!existing) return defaultBudget;
    // Same task failed before — reduce budget to fail fast
    if (existing.confidence >= 3) return Math.floor(defaultBudget * 0.3);
    if (existing.confidence >= 2) return Math.floor(defaultBudget * 0.6);
    return defaultBudget;
  }

  /**
   * Export the failure memory as a compact JSON object for persistence.
   */
  export() {
    return {
      version: 1,
      signatures: [...this.signatures.values()],
      patternAvoid: [...this.patternAvoid],
      totalFailures: this.signatures.size,
      confirmedAvoidances: this.patternAvoid.size
    };
  }

  /**
   * Import a previously exported failure memory.
   */
  import(data) {
    if (data.version !== 1) throw new Error('incompatible failure memory version');
    for (const sig of data.signatures || []) {
      this.signatures.set(sig.examplesHash, sig);
    }
    for (const key of data.patternAvoid || []) {
      this.patternAvoid.add(key);
    }
  }

  _shapeKey(sig) {
    return `${sig.arity}|${sig.argTypeHash}|${sig.outType}|${sig.reason}`;
  }

  get size() { return this.signatures.size; }
  get avoidCount() { return this.patternAvoid.size; }
}
