/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Synora program DSL (non-neural). A program is a small typed expression tree built ONLY from the
 * primitives below. Nothing here evaluates user-supplied source: persisted/untrusted ASTs are
 * validated structurally and run by a step-bounded interpreter. Primitive bodies are trusted
 * constants of this module; the interpreter and the emitted JavaScript share the same text.
 */
export const ERR = Symbol('synora-dsl-error');
/**
 * Version of the primitive set and the type signatures. It is part of the
 * reproducibility contract: a synthesis result depends on (seed, maxExpressions,
 * maxSize, examples, DSL_VERSION) and on nothing else.
 */
export const DSL_VERSION = 'synora-dsl/1.1.0';
const N2 = body => `(a,b)=>{const r=${body};if(!Number.isFinite(r)||Math.abs(r)>1e12)throw new RangeError("number-out-of-range");return r}`;
const NZ = body => `(a,b)=>{if(b===0)throw new RangeError("division-by-zero");const r=${body};if(!Number.isFinite(r)||Math.abs(r)>1e12)throw new RangeError("number-out-of-range");return r}`;
const EMPTY = 'throw new RangeError("empty-list")';

export const SRC = Object.freeze({
  add: N2('a+b'), sub: N2('a-b'), mul: N2('a*b'), div: NZ('a/b'), idiv: NZ('Math.floor(a/b)'), mod: NZ('((a%b)+b)%b'),
  abs: 'a=>Math.abs(a)', pow: `(a,b)=>{if(!Number.isFinite(a)||!Number.isFinite(b)||b<0||b>20)throw new RangeError("number-out-of-range");const r=Math.pow(a,b);if(!Number.isFinite(r)||Math.abs(r)>1e12)throw new RangeError("number-out-of-range");return r}`,
  sqrt: 'a=>{if(a<0)throw new RangeError("negative-sqrt");return Math.sqrt(a)}',
  isqrt: 'a=>{if(a<0||!Number.isInteger(a))throw new RangeError("negative-isqrt");return Math.floor(Math.sqrt(a))}',
  floor: 'a=>Math.floor(a)', ceil: 'a=>Math.ceil(a)', round: 'a=>Math.round(a)',
  min2: '(a,b)=>Math.min(a,b)', max2: '(a,b)=>Math.max(a,b)', sign: 'a=>Math.sign(a)',
  eq: '(a,b)=>typeof a==="number"&&typeof b==="number"?a===b:JSON.stringify(a)===JSON.stringify(b)',
  lt: '(a,b)=>a<b', le: '(a,b)=>a<=b', not: 'a=>!a', and: '(a,b)=>a&&b', or: '(a,b)=>a||b', ite: '(c,a,b)=>c?a:b',
  len: 'a=>a.length',
  sum: `a=>{let s=0;for(const v of a)s+=v;if(!Number.isFinite(s)||Math.abs(s)>1e12)throw new RangeError("number-out-of-range");return s}`,
  max: `a=>{if(a.length===0)${EMPTY};let m=a[0];for(const v of a)if(v>m)m=v;return m}`,
  min: `a=>{if(a.length===0)${EMPTY};let m=a[0];for(const v of a)if(v<m)m=v;return m}`,
  head: `a=>{if(a.length===0)${EMPTY};return a[0]}`,
  last: `a=>{if(a.length===0)${EMPTY};return a[a.length-1]}`,
  nth: '(a,i)=>{if(!Number.isInteger(i)||i<0||i>=a.length)throw new RangeError("index-out-of-range");return a[i]}',
  reverse: 'a=>typeof a==="string"?[...a].reverse().join(""):[...a].reverse()',
  sort: 'a=>[...a].sort((x,y)=>typeof x==="number"?x-y:(x<y?-1:x>y?1:0))',
  sortBy: '(a,f)=>{if(!Array.isArray(a))throw new RangeError("bad-list");return [...a].sort((x,y)=>{const kx=f(x),ky=f(y);return typeof kx==="number"?kx-ky:(kx<ky?-1:kx>ky?1:0);})}',
  unique: 'a=>{const s=new Set(),o=[];for(const v of a){const k=JSON.stringify(v);if(!s.has(k)){s.add(k);o.push(v)}}return o}',
  tail: 'a=>a.slice(1)', init: 'a=>a.slice(0,-1)',
  take: '(a,n)=>{if(!Number.isInteger(n)||n<0)throw new RangeError("bad-count");return a.slice(0,n)}',
  drop: '(a,n)=>{if(!Number.isInteger(n)||n<0)throw new RangeError("bad-count");return a.slice(n)}',
  takeWhile: '(a,f)=>{if(!Array.isArray(a))throw new RangeError("bad-list");const o=[];for(const v of a){if(!f(v))break;o.push(v);}return o;}',
  dropWhile: '(a,f)=>{if(!Array.isArray(a))throw new RangeError("bad-list");let i=0;while(i<a.length&&f(a[i]))i++;return a.slice(i);}',
  zip: '(a,b)=>{if(!Array.isArray(a)||!Array.isArray(b))throw new RangeError("bad-list");const len=Math.min(a.length,b.length);const o=new Array(len);for(let i=0;i<len;i++)o[i]=[a[i],b[i]];return o;}',
  enumerate: 'a=>{if(!Array.isArray(a))throw new RangeError("bad-list");return a.map((v,i)=>[i,v]);}',
  slidingWindow: '(a,k)=>{if(!Array.isArray(a)||!Number.isInteger(k)||k<=0||k>a.length)throw new RangeError("bad-window");const o=[];for(let i=0;i<=a.length-k;i++)o.push(a.slice(i,i+k));return o;}',
  cumsum: 'a=>{if(!Array.isArray(a))throw new RangeError("bad-list");let s=0;const o=new Array(a.length);for(let i=0;i<a.length;i++){s+=a[i];if(!Number.isFinite(s)||Math.abs(s)>1e12)throw new RangeError("number-out-of-range");o[i]=s;}return o;}',
  transpose: 'a=>{if(!Array.isArray(a)||a.length===0||!Array.isArray(a[0]))throw new RangeError("bad-matrix");const w=a[0].length;for(let r of a)if(!Array.isArray(r)||r.length!==w)throw new RangeError("non-rectangular");return Array.from({length:w},(_,c)=>a.map(r=>r[c]));}',
  pair: '(a,b)=>[a,b]',
  fst: 'p=>{if(!Array.isArray(p)||p.length<2)throw new RangeError("bad-pair");return p[0];}',
  snd: 'p=>{if(!Array.isArray(p)||p.length<2)throw new RangeError("bad-pair");return p[1];}',
  concat: '(a,b)=>[...a,...b]', flatten: 'a=>a.flat(1)',
  map: '(a,f)=>a.map(v=>f(v))', filter: '(a,f)=>a.filter(v=>f(v))', all: '(a,f)=>a.every(v=>f(v))', any: '(a,f)=>a.some(v=>f(v))',
  iterate: '(k,init,f)=>{if(!Number.isInteger(k)||k<0||k>500)throw new RangeError("bad-count");let cur=init;for(let i=0;i<k;i++){cur=f(cur);}return cur;}',
  range: 'n=>{if(!Number.isInteger(n)||n<0||n>200)throw new RangeError("bad-range");return Array.from({length:n},(_,i)=>i)}',
  rangeFrom: '(a,b)=>{if(!Number.isInteger(a)||!Number.isInteger(b)||b-a>200)throw new RangeError("bad-range");const o=[];for(let i=a;i<b;i++)o.push(i);return o}',
  split: '(s,sep)=>s.split(sep)', join: 'a=>a.join("")', joinSep: '(a,sep)=>a.join(sep)',
  replace: '(s,a,b)=>s.replaceAll(a,b)', startsWith: '(s,sub)=>s.startsWith(sub)', endsWith: '(s,sub)=>s.endsWith(sub)', contains: '(s,sub)=>s.includes(sub)',
  slice: '(s,a,b)=>s.slice(a,b)', charAt: '(s,i)=>{if(i<0||i>=s.length)throw new RangeError("index-out-of-range");return s[i];}',
  chars: 's=>[...s]', words: 's=>s.split(/\\s+/).filter(Boolean)', lower: 's=>s.toLowerCase()', upper: 's=>s.toUpperCase()', trim: 's=>s.trim()',
  isDigit: 's=>s.length===1&&s>="0"&&s<="9"', isAlpha: 's=>s.length===1&&((s>="a"&&s<="z")||(s>="A"&&s<="Z"))',
  toNumber: 's=>{const n=Number(s);if(!Number.isFinite(n)||s.trim()==="")throw new RangeError("bad-number");return n;}',
  toString: 'a=>String(a)'
});
export const IMPL = Object.freeze(Object.fromEntries(Object.entries(SRC).map(([k, v]) => [k, (0, eval)(`(${v})`)])));

const S = (args, ret) => ({ args, ret });
const LISTS = ['L:num', 'L:str'];
export const SIGS = Object.freeze({
  add: [S(['num', 'num'], 'num')], sub: [S(['num', 'num'], 'num')], mul: [S(['num', 'num'], 'num')],
  div: [S(['num', 'num'], 'num')], idiv: [S(['num', 'num'], 'num')], mod: [S(['num', 'num'], 'num')],
  abs: [S(['num'], 'num')], pow: [S(['num', 'num'], 'num')], sqrt: [S(['num'], 'num')], isqrt: [S(['num'], 'num')],
  floor: [S(['num'], 'num')], ceil: [S(['num'], 'num')], round: [S(['num'], 'num')],
  min2: [S(['num', 'num'], 'num')], max2: [S(['num', 'num'], 'num')], sign: [S(['num'], 'num')],
  eq: [S(['num', 'num'], 'bool'), S(['str', 'str'], 'bool'), S(['bool', 'bool'], 'bool'), S(['L:num', 'L:num'], 'bool')],
  lt: [S(['num', 'num'], 'bool')], le: [S(['num', 'num'], 'bool')], not: [S(['bool'], 'bool')],
  and: [S(['bool', 'bool'], 'bool')], or: [S(['bool', 'bool'], 'bool')],
  ite: [S(['bool', 'num', 'num'], 'num'), S(['bool', 'bool', 'bool'], 'bool'), S(['bool', 'str', 'str'], 'str'), S(['bool', 'L:num', 'L:num'], 'L:num')],
  len: [S(['L:num'], 'num'), S(['L:str'], 'num'), S(['L:L:num'], 'num'), S(['str'], 'num')],
  sum: [S(['L:num'], 'num')], max: [S(['L:num'], 'num')], min: [S(['L:num'], 'num')],
  head: [S(['L:num'], 'num'), S(['L:str'], 'str'), S(['L:L:num'], 'L:num')],
  last: [S(['L:num'], 'num'), S(['L:str'], 'str'), S(['L:L:num'], 'L:num')],
  nth: [S(['L:num', 'num'], 'num'), S(['L:str', 'num'], 'str')],
  reverse: [S(['L:num'], 'L:num'), S(['L:str'], 'L:str'), S(['str'], 'str')],
  sort: [S(['L:num'], 'L:num'), S(['L:str'], 'L:str')],
  sortBy: [S(['L:num', 'λnum'], 'L:num'), S(['L:str', 'λnum'], 'L:str')],
  unique: [S(['L:num'], 'L:num'), S(['L:str'], 'L:str')],
  tail: LISTS.map(t => S([t], t)), init: LISTS.map(t => S([t], t)),
  take: [S(['L:num', 'num'], 'L:num')], drop: [S(['L:num', 'num'], 'L:num')],
  takeWhile: [S(['L:num', 'λbool'], 'L:num')], dropWhile: [S(['L:num', 'λbool'], 'L:num')],
  zip: [S(['L:num', 'L:num'], 'L:L:num')], enumerate: [S(['L:num'], 'L:L:num')],
  slidingWindow: [S(['L:num', 'num'], 'L:L:num')], cumsum: [S(['L:num'], 'L:num')],
  transpose: [S(['L:L:num'], 'L:L:num')],
  pair: [S(['num', 'num'], 'L:num')], fst: [S(['L:num'], 'num')], snd: [S(['L:num'], 'num')],
  concat: LISTS.map(t => S([t, t], t)),
  flatten: [S(['L:L:num'], 'L:num')],
  map: [S(['L:num', 'λnum'], 'L:num')], filter: [S(['L:num', 'λbool'], 'L:num')],
  all: [S(['L:num', 'λbool'], 'bool')], any: [S(['L:num', 'λbool'], 'bool')],
  iterate: [S(['num', 'L:num', 'λL:num'], 'L:num'), S(['num', 'num', 'λnum'], 'num')],
  range: [S(['num'], 'L:num')], rangeFrom: [S(['num', 'num'], 'L:num')],
  split: [S(['str', 'str'], 'L:str')], join: [S(['L:str'], 'str')], joinSep: [S(['L:str', 'str'], 'str')],
  replace: [S(['str', 'str', 'str'], 'str')], startsWith: [S(['str', 'str'], 'bool')], endsWith: [S(['str', 'str'], 'bool')],
  contains: [S(['str', 'str'], 'bool')], slice: [S(['str', 'num', 'num'], 'str')], charAt: [S(['str', 'num'], 'str')],
  chars: [S(['str'], 'L:str')], words: [S(['str'], 'L:str')], lower: [S(['str'], 'str')], upper: [S(['str'], 'str')],
  trim: [S(['str'], 'str')], isDigit: [S(['str'], 'bool')], isAlpha: [S(['str'], 'bool')],
  toNumber: [S(['str'], 'num')], toString: [S(['num'], 'str')]
});
export const PRIM_NAMES = Object.freeze(Object.keys(SIGS).sort());
const ARITY = Object.freeze(Object.fromEntries(PRIM_NAMES.map(n => [n, SIGS[n][0].args.length])));
export const LAMBDA_PRIMS = new Set(['map', 'filter', 'all', 'any', 'iterate', 'takeWhile', 'dropWhile', 'sortBy']);
export const VALUE_TYPES = Object.freeze(['num', 'str', 'bool', 'pair', 'L:num', 'L:str', 'L:bool', 'L:pair', 'L:L:num']);
const MAX_NODES = 250, MAX_DEPTH = 20;

/** Structural validation for ASTs that come from outside (persistence, API). Throws TypeError. */
export function validateAst(root, arity) {
  let nodes = 0;
  const go = (n, depth, inLam) => {
    if (++nodes > MAX_NODES || depth > MAX_DEPTH) throw new TypeError('program too large or deep');
    if (!n || typeof n !== 'object' || Array.isArray(n)) throw new TypeError('invalid program node');
    switch (n.k) {
      case 'in': if (!Number.isInteger(n.i) || n.i < 0 || n.i >= arity) throw new TypeError('invalid input reference'); return;
      case 'x': if (!inLam) throw new TypeError('lambda variable outside lambda'); return;
      case 'const': if (!(typeof n.v === 'number' && Number.isFinite(n.v) && Math.abs(n.v) <= 1e6) && !(typeof n.v === 'string' && n.v.length <= 64) && typeof n.v !== 'boolean') throw new TypeError('invalid constant'); return;
      case 'call': {
        if (typeof n.f !== 'string' || !Object.hasOwn(SIGS, n.f)) throw new TypeError('unknown primitive');
        if (!Array.isArray(n.a) || n.a.length !== ARITY[n.f]) throw new TypeError('wrong arity');
        n.a.forEach((c, i) => {
          if (c && c.k === 'lam') {
            if (!LAMBDA_PRIMS.has(n.f) || i !== n.a.length - 1 || inLam) throw new TypeError('lambda not allowed here');
            go(c.body, depth + 1, true);
          } else {
            if (LAMBDA_PRIMS.has(n.f) && i === n.a.length - 1) throw new TypeError('lambda required');
            go(c, depth + 1, inLam);
          }
        });
        return;
      }
      default: throw new TypeError('unknown node kind');
    }
  };
  go(root, 0, false);
  return nodes;
}

/** Step-bounded interpreter. Throws RangeError on runtime faults (callers convert to abstention). */
export function evalAst(root, inputs, { maxSteps = 200_000, x } = {}) {
  let steps = 0;
  const go = (n, xv) => {
    if (++steps > maxSteps) throw new RangeError('step-budget-exceeded');
    if (n.k === 'in') return inputs[n.i];
    if (n.k === 'const') return n.v;
    if (n.k === 'x') return xv;
    if (n.f === 'ite') {
      const cond = go(n.a[0], xv);
      return cond ? go(n.a[1], xv) : go(n.a[2], xv);
    }
    const args = n.a.map(c => c.k === 'lam' ? (v => go(c.body, v)) : go(c, xv));
    return IMPL[n.f](...args);
  };
  return go(root, x);
}

/** Emit a self-contained JavaScript function equivalent to the AST (validated first). */
export function toSource(root, arity) {
  validateAst(root, arity);
  const used = new Set();
  const emit = n => {
    if (n.k === 'in') return `a${n.i}`;
    if (n.k === 'const') return JSON.stringify(n.v);
    if (n.k === 'x') return 'x';
    if (n.f === 'ite') {
      return `(${emit(n.a[0])}?${emit(n.a[1])}:${emit(n.a[2])})`;
    }
    used.add(n.f);
    return `${n.f}(${n.a.map(c => c.k === 'lam' ? `(x)=>${emit(c.body)}` : emit(c)).join(',')})`;
  };
  const body = emit(root);
  const helpers = [...used].sort().map(f => `const ${f}=${SRC[f]};`).join('\n  ');
  const params = Array.from({ length: arity }, (_, i) => `a${i}`).join(', ');
  return `export function solution(${params}) {\n${helpers ? `  ${helpers}\n` : ''}  return ${body};\n}`;
}

export function typeOfValue(v, depth = 0) {
  if (typeof v === 'number') return Number.isFinite(v) && Math.abs(v) <= 1e9 ? 'num' : null;
  if (typeof v === 'string') return v.length <= 200 ? 'str' : null;
  if (typeof v === 'boolean') return 'bool';
  if (Array.isArray(v) && depth < 2 && v.length <= (depth === 0 ? 100 : 50)) {
    if (v.length === 0) return 'L:?';
    const ts = v.map(e => typeOfValue(e, depth + 1));
    if (ts.includes(null)) return null;
    const concrete = new Set(ts.filter(t => !t.includes('?'))), wild = ts.filter(t => t.includes('?'));
    if (concrete.size > 1) return null;
    const prefix = w => 'L:'.repeat(w.split('L:').length - 1);
    let t;
    if (concrete.size === 1) { t = [...concrete][0]; if (!wild.every(w => t.startsWith(prefix(w)))) return null; }
    else { t = wild.reduce((a, b) => b.length > a.length ? b : a); if (!wild.every(w => t.startsWith(prefix(w)))) return null; }
    return t === 'num' || t === 'str' || t === 'bool' || t === 'L:num' || t === 'L:?' ? `L:${t}` : null;
  }
  return null;
}

/**
 * Resolve one type from many observed values.
 */
export function unifyTypes(types) {
  if (types.some(t => t === null)) return null;
  const wild = types.filter(t => t.includes('?')), concrete = new Set(types.filter(t => !t.includes('?')));
  if (concrete.size > 1) return null;
  const depthPrefix = w => 'L:'.repeat(w.split('L:').length - 1);
  if (concrete.size === 1) { const t = [...concrete][0]; return wild.every(w => t.startsWith(depthPrefix(w))) ? t : null; }
  if (!wild.length) return null;
  const deepest = wild.reduce((a, b) => b.length > a.length ? b : a);
  if (!wild.every(w => deepest.startsWith(depthPrefix(w)))) return null;
  return deepest.replace('?', 'num');
}

export function deepEqual(a, b) {
  if (typeof a === 'number' && typeof b === 'number') return a === b || Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(a), Math.abs(b));
  if (Array.isArray(a) && Array.isArray(b)) return a.length === b.length && a.every((v, i) => deepEqual(v, b[i]));
  return a === b;
}

/** Runtime shape check for apply-time inputs/outputs. */
export function conforms(v, type, depth = 0) {
  if (type === 'num') return typeof v === 'number' && Number.isFinite(v) && Math.abs(v) <= 1e12;
  if (type === 'str') return typeof v === 'string' && v.length <= 10_000;
  if (type === 'bool') return typeof v === 'boolean';
  if (type === 'pair') return Array.isArray(v) && v.length === 2 && typeof v[0] === 'number' && typeof v[1] === 'number';
  if (typeof type !== 'string' || !type.startsWith('L:') || !Array.isArray(v) || v.length > (depth === 0 ? 1000 : 200)) return false;
  return v.every(e => conforms(e, type.slice(2), depth + 1));
}
