/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Bounded, deterministic, NON-NEURAL program synthesis from input/output examples:
 * typed bottom-up enumeration with observational-equivalence pruning over the Synora DSL.
 *
 * BUDGET MODEL (v8.7.0)
 * ---------------------
 * `maxExpressions` is the PRIMARY budget and the only logical acceptance criterion.
 * Wall-clock time is a SAFETY VALVE: it can only turn a run into a refusal, it can
 * never turn a refusal into an answer, and it never decides whether a program is
 * accepted. With `deterministicBudget: true` the valve is disabled unless an
 * explicit `safetyTimeoutMs` is supplied, so the logical result of a run depends
 * only on (seed, maxExpressions, maxSize, examples, DSL version) - never on how
 * fast the host machine is.
 *
 * SEARCH TIERS (v8.7.0)
 * ----------------------
 * The primitive universe of every tier is derived from the TYPE of the task, never
 * from an operation name, so no benchmark-specific recognizer can leak in and no
 * general primitive has to be "promoted" by hand:
 *
 *   tier `direct`  - primitives that consume at least one of the task's own argument
 *                    types (any remaining argument may be a numeric parameter), and
 *                    that take no user-supplied predicate.
 *   tier `lambda`  - the same universe plus the primitives that take a user predicate.
 *   tier `general` - every primitive in the DSL.
 *
 * The ambiguity check of an answer is scoped to the tier that produced it: a program
 * is never vetoed by a primitive family that the tier never searched. The ambiguity
 * window itself (chosen size + `ambiguityWindow`) and the fail-closed rule for a
 * truncated (partial) ambiguity check are unchanged from v8.6.0.
 */
import { ERR, IMPL, SIGS, PRIM_NAMES, evalAst, toSource, validateAst, typeOfValue, unifyTypes, deepEqual, LAMBDA_PRIMS, DSL_VERSION } from './dsl.mjs';

export const SYNTHESIS_LIMITS = Object.freeze({
  maxArity: 3,
  minTraining: 3,
  minDevelopment: 2,
  maxExamples: 50,
  maxSizeCap: 12,
  maxBudgetMs: 20_000,
  maxExpressionsCap: 2_000_000
});

const CONSTS = [0, 1, 2, 3, 10, 15];
const PROBE_COUNT = 14;

/**
 * Budget split across the search stages. The split is explicit, deterministic and
 * reported back in every synthesis result so a run can be reproduced exactly.
 *
 *  stage `scoped`  - the type-driven universe of the task (plus the primitives that
 *                    take a user predicate). This is where virtually every solvable
 *                    task is decided.
 *  stage `general` - the whole DSL, used only as a fallback when the scoped stage
 *                    could not decide the task.
 */
export const TIER_PLAN = Object.freeze([
  Object.freeze({ name: 'core', share: 0.20 }),
  Object.freeze({ name: 'core-lambda', share: 0.10 }),
  Object.freeze({ name: 'extended', share: 0.50 }),
  Object.freeze({ name: 'general', share: 0.20 })
]);

function boundaryValues(type) {
  switch (type) {
    case 'num': return [-2, -1, 0, 1, 2, 3];
    case 'str': return ['', ' ', 'a', 'A', 'aa', ' a ', 'é', 'ß'];
    case 'L:num': return [[], [0], [1], [1, 1], [-1, 0, 1], [2, 1, 2], [-2, -1], [0, 0]];
    case 'L:str': return [[], [''], ['a'], ['a', 'a'], ['A', 'a'], ['é', 'ß'], [' ', 'x']];
    case 'L:bool': return [[], [true], [false], [true, true], [true, false]];
    case 'L:L:num': return [[], [[]], [[0]], [[1, 1]], [[-1, 0], [0, 0]]];
    default: return [];
  }
}

function makeBoundaryProbes(argTypes, training) {
  const baseline = training[0].input;
  const probes = [];
  for (let i = 0; i < argTypes.length; i++) {
    for (const value of boundaryValues(argTypes[i])) {
      const row = structuredClone(baseline);
      row[i] = structuredClone(value);
      probes.push(row);
    }
  }
  return probes;
}

/**
 * CURATED CORE UNIVERSE (unchanged from v8.6.0).
 *
 * These are the primitives whose shape keeps a rival program honest: they consume
 * a value and return a value of the same kind. The list contains no benchmark
 * operation and no lookup table - it is a property of the DSL, not of any task.
 * It is used for the FIRST decision of a search, so that the ambiguity check of
 * the most common answers is performed in exactly the same universe as in v8.6.0.
 */
export const CORE_PRIMS = Object.freeze(new Set([
  'add', 'sub', 'mul', 'div', 'idiv', 'mod', 'eq', 'lt', 'le', 'not', 'and', 'or', 'ite',
  'len', 'sum', 'max', 'min', 'head', 'last', 'nth', 'reverse', 'sort', 'unique', 'tail',
  'init', 'take', 'drop', 'concat', 'flatten', 'map', 'filter', 'all', 'any', 'range',
  'rangeFrom', 'chars', 'words', 'join', 'lower'
]));

function computeUsefulTypes(outType, universe) {
  const useful = new Set([outType]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const { sig } of universe) {
      if (useful.has(sig.ret)) {
        for (const argType of sig.args) {
          if (!argType.startsWith('λ') && !useful.has(argType)) { useful.add(argType); changed = true; }
        }
      }
    }
  }
  return useful;
}

/**
 * TYPE-DRIVEN primitive universe.
 *
 * A signature belongs to the universe when it consumes at least one of the task's
 * own argument types and every other argument type is either another of the task's
 * argument types or a plain numeric parameter. Nothing here looks at an operation
 * name, so `cumsum`, `flatten`, `upper`, `trim`, `words`, `reverse`, `lower` and
 * every other primitive of the DSL become reachable purely because their signature
 * fits the shape of the task.
 */
export function classifyUniverse(argTypes, { includeLambdas = false, exact = false } = {}) {
  const taskTypes = new Set(argTypes);
  const universe = [];
  for (const name of PRIM_NAMES) {
    for (const sig of SIGS[name]) {
      if (!sig.args.length) continue;
      const hasLambda = sig.args.some(t => t.startsWith('λ'));
      if (hasLambda && !includeLambdas) continue;
      if (exact) {
        // The signature consumes exactly the arguments of the task, so the
        // primitive can be applied to the task's own inputs directly.
        if (sig.args.length !== argTypes.length) continue;
        if (!sig.args.every((t, i) => t === argTypes[i])) continue;
        universe.push({ name, sig });
        continue;
      }
      if (!sig.args.some(t => taskTypes.has(t))) continue;
      if (!sig.args.every(t => taskTypes.has(t) || t === 'num')) continue;
      universe.push({ name, sig });
    }
  }
  return universe;
}

/**
 * The EXTENDED universe is the union of the curated core and the type-driven
 * universe. It is the stage in which general primitives such as `cumsum`,
 * `flatten`, `upper`, `trim`, `words`, `reverse` or `lower` become reachable -
 * not because they were promoted by hand, but because their signature fits the
 * shape of the task.
 */
export function extendedUniverse(argTypes, { includeLambdas = true } = {}) {
  const seen = new Set();
  const out = [];
  for (const entry of classifyUniverse(argTypes, { includeLambdas, exact: true })) {
    const key = `${entry.name}:${entry.sig.args.join(',')}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(entry);
  }
  for (const name of CORE_PRIMS) {
    for (const sig of SIGS[name]) {
      const hasLambda = sig.args.some(t => t.startsWith('λ'));
      if (hasLambda && !includeLambdas) continue;
      const key = `${name}:${sig.args.join(',')}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({ name, sig });
    }
  }
  return out;
}

function mulberry32(a) {
  return () => {
    a |= 0;
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const pick = (r, arr) => arr[Math.floor(r() * arr.length)];

function genValue(type, r) {
  switch (type) {
    case 'num': return pick(r, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, -1, -3, -5]);
    case 'bool': return r() > 0.5;
    case 'str': return Array.from({ length: Math.floor(r() * 9) }, () => pick(r, ['a', 'b', 'c', ' ', 'A', 'B'])).join('');
    case 'L:num': return Array.from({ length: Math.floor(r() * 7) }, () => Math.floor(r() * 18) - 5);
    case 'L:str': return Array.from({ length: Math.floor(r() * 5) }, () => genValue('str', r));
    case 'L:bool': return Array.from({ length: Math.floor(r() * 5) }, () => r() > 0.5);
    case 'L:L:num': return Array.from({ length: Math.floor(r() * 4) }, () => genValue('L:num', r));
    default: throw new TypeError(`unsupported input type ${type}`);
  }
}

class ValueIntern {
  constructor() { this.map = new Map(); this.next = 1; }
  intern(v) {
    if (v === ERR) return 0;
    const t = typeof v;
    if (t === 'number' || t === 'boolean' || t === 'string') {
      let id = this.map.get(v); if (id === undefined) { id = this.next++; this.map.set(v, id); } return id;
    }
    const key = this._canon(v);
    let id = this.map.get(key); if (id === undefined) { id = this.next++; this.map.set(key, id); } return id;
  }
  _canon(v) {
    if (Array.isArray(v)) {
      if (v.length === 0) return '[]';
      if (typeof v[0] === 'number') return '[' + v.join(',') + ']';
      if (typeof v[0] === 'string') return '["' + v.join('","') + '"]';
      return JSON.stringify(v);
    }
    return JSON.stringify(v);
  }
}

function fastValKey(v, intern) { return String(intern.intern(v)); }

function keyOf(type, vals, intern) {
  let k = type + '|';
  for (let i = 0; i < vals.length; i++) { if (i > 0) k += ','; k += intern.intern(vals[i]); }
  return k;
}

function computeVals(name, args, R, rowInputs) {
  const f = IMPL[name];
  const vals = new Array(R);
  const argLen = args.length;
  const hasLambda = args[0] && args[0].lam ? true : args.some(g => g.lam);

  if (!hasLambda) {
    // Fast path: no user predicate, so every row can be evaluated without
    // allocating an argument vector. This is the hot path of the whole search.
    if (argLen === 1) {
      const a0 = args[0].vals;
      for (let r = 0; r < R; r++) {
        const v = a0[r];
        if (v === ERR) { vals[r] = ERR; continue; }
        try { vals[r] = f(v); } catch { vals[r] = ERR; }
      }
      return vals;
    }
    if (argLen === 2) {
      const a0 = args[0].vals, a1 = args[1].vals;
      for (let r = 0; r < R; r++) {
        const v0 = a0[r], v1 = a1[r];
        if (v0 === ERR || v1 === ERR) { vals[r] = ERR; continue; }
        try { vals[r] = f(v0, v1); } catch { vals[r] = ERR; }
      }
      return vals;
    }
    if (argLen === 3) {
      const a0 = args[0].vals, a1 = args[1].vals, a2 = args[2].vals;
      for (let r = 0; r < R; r++) {
        const v0 = a0[r], v1 = a1[r], v2 = a2[r];
        if (v0 === ERR || v1 === ERR || v2 === ERR) { vals[r] = ERR; continue; }
        try { vals[r] = f(v0, v1, v2); } catch { vals[r] = ERR; }
      }
      return vals;
    }
  }

  for (let r = 0; r < R; r++) {
    const a = new Array(argLen);
    let bad = false;
    for (let i = 0; i < argLen; i++) {
      const g = args[i];
      if (g.lam) {
        a[i] = v => evalAst(g.lam.ast, rowInputs[r], { x: v, maxSteps: 4000 });
      } else {
        const v = g.vals[r];
        if (v === ERR) { bad = true; break; }
        a[i] = v;
      }
    }
    if (bad) {
      vals[r] = ERR;
      continue;
    }
    try {
      vals[r] = f(...a);
    } catch {
      vals[r] = ERR;
    }
  }
  return vals;
}

function forCombos(sig, remaining, get, ensureLambdas, onCombo) {
  const args = sig.args;
  const arity = args.length;

  if (arity === 1) {
    const t = args[0];
    if (t.startsWith('λ')) {
      if (remaining >= 2) {
        const lamType = t === 'λnum' ? 'num' : 'bool';
        const lams = ensureLambdas(lamType);
        for (let i = 0; i < lams.length; i++) {
          if (onCombo([{ lam: lams[i] }])) return true;
        }
      }
    } else {
      const list = get(t, remaining);
      for (let i = 0; i < list.length; i++) {
        if (onCombo([list[i]])) return true;
      }
    }
    return false;
  }

  if (arity === 2) {
    const t0 = args[0], t1 = args[1];
    if (t1.startsWith('λ')) {
      const lamType = t1 === 'λnum' ? 'num' : 'bool';
      if (remaining >= 3) {
        const lams = ensureLambdas(lamType);
        if (lams.length === 0) return false;
        const s0 = remaining - 2;
        const list0 = get(t0, s0);
        for (let i = 0; i < list0.length; i++) {
          for (let j = 0; j < lams.length; j++) {
            if (onCombo([list0[i], { lam: lams[j] }])) return true;
          }
        }
      }
      return false;
    }

    for (let s0 = 1; s0 < remaining; s0++) {
      const s1 = remaining - s0;
      const list0 = get(t0, s0);
      if (!list0 || list0.length === 0) continue;
      const list1 = get(t1, s1);
      if (!list1 || list1.length === 0) continue;
      for (let i = 0; i < list0.length; i++) {
        for (let j = 0; j < list1.length; j++) {
          if (onCombo([list0[i], list1[j]])) return true;
        }
      }
    }
    return false;
  }

  if (arity === 3) {
    const t0 = args[0], t1 = args[1], t2 = args[2];
    if (t2.startsWith('λ')) {
      const lamType = t2 === 'λnum' ? 'num' : 'bool';
      if (remaining >= 4) {
        const lams = ensureLambdas(lamType);
        if (lams.length === 0) return false;
        const rem2 = remaining - 2;
        for (let s0 = 1; s0 < rem2; s0++) {
          const s1 = rem2 - s0;
          const list0 = get(t0, s0);
          if (!list0 || list0.length === 0) continue;
          const list1 = get(t1, s1);
          if (!list1 || list1.length === 0) continue;
          for (let i = 0; i < list0.length; i++) {
            for (let j = 0; j < list1.length; j++) {
              for (let k = 0; k < lams.length; k++) {
                if (onCombo([list0[i], list1[j], { lam: lams[k] }])) return true;
              }
            }
          }
        }
      }
      return false;
    }

    for (let s0 = 1; s0 <= remaining - 2; s0++) {
      const list0 = get(t0, s0);
      if (!list0 || list0.length === 0) continue;
      for (let s1 = 1; s1 <= remaining - s0 - 1; s1++) {
        const s2 = remaining - s0 - s1;
        const list1 = get(t1, s1);
        if (!list1 || list1.length === 0) continue;
        const list2 = get(t2, s2);
        if (!list2 || list2.length === 0) continue;
        for (let i = 0; i < list0.length; i++) {
          for (let j = 0; j < list1.length; j++) {
            for (let k = 0; k < list2.length; k++) {
              if (onCombo([list0[i], list1[j], list2[k]])) return true;
            }
          }
        }
      }
    }
    return false;
  }

  return false;
}

function enumerate({ R, rowInputs, terminals, sigs, ensureLambdas, maxSize, maxExpressions, safetyDeadline, discard, onAdd, levelDone, ctl, onSignature, usefulTypes, nTD, K = 3 }) {
  const bank = new Map();
  const intern = new ValueIntern();
  const isUseful = usefulTypes ? (t => usefulTypes.has(t)) : (() => true);
  const useLazyOE = nTD && nTD < R && K > 0;
  const oeClasses = useLazyOE ? new Map() : null;
  const seenFull = useLazyOE ? null : new Set();

  const tryAddOE = (type, vals) => {
    if (!useLazyOE) {
      const fullKey = keyOf(type, vals, intern);
      if (seenFull.has(fullKey)) return false;
      seenFull.add(fullKey);
      return true;
    }
    const tdKey = keyOf(type, vals.slice(0, nTD), intern);
    let cls = oeClasses.get(tdKey);
    if (!cls) {
      cls = [];
      oeClasses.set(tdKey, cls);
      const probeKey = keyOf(type, vals.slice(nTD), intern);
      cls.push(probeKey);
      return true;
    }
    if (cls.length >= K) return false;
    const probeKey = keyOf(type, vals.slice(nTD), intern);
    if (cls.includes(probeKey)) return false;
    cls.push(probeKey);
    return true;
  };
  // Keep a deterministic bounded equivalence class per type/size. The bank is
  // already observationally keyed; this second bound prevents pathological
  // type-correct expressions from starving the next size level.
  const bucketCap = maxExpressions <= 10_000
    ? Math.max(64, Math.min(512, Math.floor(maxExpressions / 8)))
    : Number.MAX_SAFE_INTEGER;
  let explored = 0;
  let stop = null;

  const get = (t, s) => bank.get(t)?.get(s) ?? [];
  const put = e => {
    if (!bank.has(e.type)) bank.set(e.type, new Map());
    const m = bank.get(e.type);
    if (!m.has(e.size)) m.set(e.size, []);
    const bucket = m.get(e.size);
    if (bucket.length >= bucketCap) return false;
    bucket.push(e);
    return true;
  };

  for (const t of terminals) {
    if (!isUseful(t.type)) continue;
    if (!tryAddOE(t.type, t.vals)) continue;
    const e = { ...t, size: 1 };
    if (put(e)) onAdd(e);
  }

  for (let size = 2; size <= maxSize && !stop; size++) {
    for (const { name, sig } of sigs) {
      onSignature?.(sig);
      let hasRequiredTypes = true;
      for (const argType of sig.args) {
        if (argType.startsWith('λ')) {
          // A user predicate is supplied by the lambda bank. The bank is built
          // lazily, the first time a predicate can actually take part in an
          // enumeration, so tasks that never need one never pay for it.
          continue;
        } else if (!bank.has(argType)) {
          hasRequiredTypes = false;
          break;
        }
      }
      if (!hasRequiredTypes) continue;

      const stopSearch = forCombos(sig, size - 1, get, ensureLambdas, (combo) => {
        explored++;
        if ((explored & 511) === 0 && safetyDeadline && Date.now() > safetyDeadline) {
          stop = 'safety-timeout';
          return true;
        }
        if (explored > maxExpressions) {
          stop = 'expressions';
          return true;
        }

        const vals = computeVals(name, combo, R, rowInputs);
        if (discard(vals)) return false;
        if (!isUseful(sig.ret)) return false;
        if (!tryAddOE(sig.ret, vals)) return false;

        const e = {
          type: sig.ret,
          size,
          vals,
          ast: {
            k: 'call',
            f: name,
            a: combo.map(c => c.lam ? { k: 'lam', body: c.lam.ast } : c.ast)
          }
        };
        if (put(e)) onAdd(e);
        return false;
      });

      if (stopSearch || stop) break;
    }
    if (!stop) {
      levelDone(size);
      if (ctl && ctl.stop) break;
    }
  }

  return { explored, stop };
}

const LAMBDA_POOL_CACHE = new Map();

/**
 * Deterministic lambda bank.
 *
 * The bank is built on a CANONICAL probe grid instead of the training values, so
 * (a) a lambda is never selected because it happens to agree with the observed
 * rows, and (b) the bank is shared by every task with the same shape, which makes
 * the whole search reproducible and considerably faster.
 *
 * The bank is built with a pure expression budget: a slower or faster machine
 * therefore produces exactly the same bank.
 */
const LAMBDA_XS = Object.freeze([-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]);
const LAMBDA_OUTER = Object.freeze([-3, -1, 1]);
const LAMBDA_POOL_EXPRESSIONS = 25_000;

function buildLambdaPool(outerIdx) {
  const cacheKey = outerIdx.join(',');
  if (LAMBDA_POOL_CACHE.has(cacheKey)) {
    return LAMBDA_POOL_CACHE.get(cacheKey);
  }

  const assigns = outerIdx.map((gi, j) => ({ gi, j }));
  const pts = [];
  for (const o of LAMBDA_OUTER) {
    for (const x of LAMBDA_XS) {
      pts.push({ x, o });
    }
  }

  const terminals = [{ type: 'num', vals: pts.map(p => p.x), ast: { k: 'x' } }];
  assigns.forEach(({ gi, j }) => {
    terminals.push({ type: 'num', vals: pts.map(() => LAMBDA_OUTER[j]), ast: { k: 'in', i: gi } });
  });

  for (const c of CONSTS) {
    terminals.push({ type: 'num', vals: pts.map(() => c), ast: { k: 'const', v: c } });
  }

  const names = ['add', 'sub', 'mul', 'idiv', 'mod', 'eq', 'lt', 'le', 'not', 'and', 'or'];
  const sigs = [];
  for (const name of names) {
    if (SIGS[name]) {
      for (const sig of SIGS[name]) {
        if (sig.args.every(t => t === 'num' || t === 'bool')) {
          sigs.push({ name, sig });
        }
      }
    }
  }

  const pool = { num: [], bool: [] };
  const add = e => {
    if (pool[e.type] && pool[e.type].length < 150) {
      pool[e.type].push({ ast: e.ast, type: e.type, size: e.size });
    }
  };

  enumerate({
    R: pts.length,
    // Lambda bodies may close over outer arguments. The old empty rowInputs
    // array made every `in` reference evaluate against undefined while the
    // pool was being built, silently discarding valid outer-dependent lambdas.
    rowInputs: pts.map(p => {
      const row = [];
      assigns.forEach(({ gi, j }) => { row[gi] = LAMBDA_OUTER[j]; });
      return row;
    }),
    terminals,
    sigs,
    ensureLambdas: () => [],
    maxSize: 5,
    safetyDeadline: null,
    maxExpressions: LAMBDA_POOL_EXPRESSIONS,
    discard: () => false,
    onAdd: add,
    levelDone: () => {}
  });

  LAMBDA_POOL_CACHE.set(cacheKey, pool);
  return pool;
}

export function validateExamples(examples, label) {
  if (!Array.isArray(examples)) throw new TypeError(`${label} must be an array`);
  if (examples.length > SYNTHESIS_LIMITS.maxExamples) throw new TypeError(`${label} has more than ${SYNTHESIS_LIMITS.maxExamples} examples`);
  for (const [i, ex] of examples.entries()) {
    if (!ex || typeof ex !== 'object' || !Array.isArray(ex.input) || ex.input.length < 1 || ex.input.length > SYNTHESIS_LIMITS.maxArity || !('output' in ex)) {
      throw new TypeError(`${label}[${i}] needs input (array of 1..${SYNTHESIS_LIMITS.maxArity} arguments) and output`);
    }
  }
}

export const AMBIGUITY_WINDOW = 2;
const intIn = (v, lo, hi, label) => {
  if (!Number.isInteger(v) || v < lo || v > hi) throw new RangeError(`${label} must be an integer in [${lo}, ${hi}]`);
};


function collectScalarValues(value, out = new Set()) {
  if (value === null || value === undefined) return out;
  if (typeof value === 'number' || typeof value === 'string' || typeof value === 'boolean') out.add(JSON.stringify(value));
  else if (Array.isArray(value)) for (const item of value) collectScalarValues(item, out);
  else if (typeof value === 'object') for (const item of Object.values(value)) collectScalarValues(item, out);
  return out;
}

/**
 * Structural plausibility filter applied to RIVAL programs only.
 *
 * A rival that is structurally redundant is not a credible competing hypothesis
 * about the user's intent, so it cannot veto the chosen program. The rules below
 * are general structural properties, not knowledge about any particular operation:
 *   - algebraic no-ops (x+0, x*1, x/1, ...);
 *   - a normaliser applied to itself (sort(sort(x)), unique(unique(x)), ...);
 *   - a CASE ROUND TRIP (lower(upper(x)) / upper(lower(x))). Case folding is
 *     involutive for every character whose case mapping is invertible, so the round
 *     trip cancels and can never be a distinct intent.
 */
const CASE_NORMALISERS = new Set(['lower', 'upper']);

function hasNoOpOrDeadStructure(ast) {
  const walk = node => {
    if (!node || typeof node !== 'object') return false;
    if (node.k === 'lam') return walk(node.body);
    if (node.k !== 'call') return false;
    const a = node.a || [];
    const constant = (i, value) => a[i]?.k === 'const' && a[i].v === value;
    if (['add', 'sub'].includes(node.f) && (constant(0, 0) || constant(1, 0))) return true;
    if (node.f === 'mul' && (constant(0, 1) || constant(1, 1) || constant(0, 0) || constant(1, 0))) return true;
    if (['div', 'idiv'].includes(node.f) && constant(1, 1)) return true;
    if (node.f === 'mod' && (constant(1, 1) || constant(1, 0))) return true;
    if (node.f === 'ite' && (constant(0, true) || constant(0, false))) return true;
    if (node.f === 'and' && (constant(0, false) || constant(1, false))) return true;
    if (node.f === 'or' && (constant(0, true) || constant(1, true))) return true;
    // range/length is a domain round-trip: for every valid non-negative integer
    // x, len(range(x)) = x. Treating it as a distinct rival overstates ambiguity.
    if (node.f === 'len' && a[0]?.k === 'call' && a[0].f === 'range') return true;
    if (['unique', 'sort', 'reverse', 'lower', 'upper', 'trim'].includes(node.f) && a[0]?.k === 'call' && a[0].f === node.f) return true;
    if (CASE_NORMALISERS.has(node.f) && a[0]?.k === 'call' && CASE_NORMALISERS.has(a[0].f)) return true;
    if (['map', 'filter', 'all', 'any'].includes(node.f) && a.at(-1)?.k === 'lam' && a.at(-1).body?.k === 'x') {
      if (node.f === 'map') return true;
      if (node.f === 'filter' || node.f === 'all' || node.f === 'any') return true;
    }
    return a.some(walk);
  };
  return walk(ast);
}

function plausibilityPenalty(ast, examples) {
  const observed = new Set();
  for (const example of examples) {
    for (const input of example.input) collectScalarValues(input, observed);
    collectScalarValues(example.output, observed);
  }
  let penalty = 0;
  const walk = node => {
    if (!node || typeof node !== 'object') return;
    if (node.k === 'const' && !observed.has(JSON.stringify(node.v))) penalty += 1;
    if (node.k === 'call') {
      const children = node.a || [];
      // Algebraic no-ops and repeated idempotent wrappers are low-plausibility structure.
      if (['add', 'sub'].includes(node.f) && children.some(c => c?.k === 'const' && c.v === 0)) penalty += 1;
      if (node.f === 'mul' && children.some(c => c?.k === 'const' && c.v === 1)) penalty += 1;
      if (children.some(c => c?.k === 'call' && c.f === node.f && ['unique', 'sort', 'reverse', 'lower'].includes(node.f))) penalty += 1;
      for (const child of children) walk(child);
    } else if (node.k === 'lam') walk(node.body);
  };
  walk(ast);
  return penalty;
}

function evidenceProfile(ast, examples) {
  let nodes = 0;
  let constants = 0;
  const distinctInputs = new Set(examples.map(example => JSON.stringify(example.input))).size;
  const walk = node => {
    if (!node || typeof node !== 'object') return;
    if (node.k === 'const') { nodes++; constants++; return; }
    nodes++;
    if (node.k === 'call') for (const child of node.a || []) walk(child);
    else if (node.k === 'lam') walk(node.body);
  };
  walk(ast);
  // Evidence must grow with structural complexity. This is deliberately measurable:
  // at least five examples, and one extra example for every three AST nodes.
  const requiredExamples = Math.max(5, 3 + Math.ceil(nodes / 3));
  return { nodes, constants, distinctInputs, requiredExamples, sufficient: examples.length >= requiredExamples && distinctInputs >= Math.min(examples.length, requiredExamples) };
}

function queryInformationGain(query, candidateCount) {
  const counts = query.outputCounts || [];
  if (candidateCount <= 1 || counts.length <= 1) return 0;
  let entropy = 0;
  for (const count of counts) {
    const p = count / candidateCount;
    if (p > 0) entropy -= p * Math.log2(p);
  }
  return entropy;
}

function usesLambda(ast) {
  let found = false;
  const walk = node => {
    if (found || !node || typeof node !== 'object') return;
    if (node.k === 'lam') { found = true; return; }
    if (node.k === 'call') for (const child of node.a || []) walk(child);
  };
  walk(ast);
  return found;
}

function runTier({
  tier,
  training,
  development,
  universe,
  maxSize,
  maxExpressions,
  safetyDeadline,
  seed,
  ambiguityWindow,
  includeLambdas,
  preferLambdas
}) {
  const all = [...training, ...development];
  const arity = training[0].input.length;
  const argTypes = Array.from({ length: arity }, (_, i) => unifyTypes(all.map(e => typeOfValue(e.input[i]))));
  const outType = unifyTypes(all.map(e => typeOfValue(e.output)));

  if (argTypes.some(t => !t || t === 'bool') || !outType) {
    throw new TypeError('unsupported example value types (use numbers, strings, booleans as outputs, and lists of numbers/strings/number-lists)');
  }

  const rnd = mulberry32(seed);
  const randomProbes = Array.from({ length: PROBE_COUNT }, () => argTypes.map(t => genValue(t, rnd)));
  const boundaryProbes = makeBoundaryProbes(argTypes, training);
  const probes = [...boundaryProbes, ...randomProbes];
  const rowInputs = [...all.map(e => e.input), ...probes];
  const nT = training.length;
  const nTD = all.length;
  const R = rowInputs.length;
  const outputs = all.map(e => e.output);

  const numIdx = argTypes.map((t, i) => (t === 'num' ? i : -1)).filter(i => i >= 0);

  let lamPool = null;
  const ensureLambdas = ltype => {
    if (!includeLambdas) return [];
    if (!lamPool) lamPool = buildLambdaPool(numIdx);
    return lamPool[ltype] || [];
  };
  const terminals = argTypes.map((t, i) => ({ type: t, vals: rowInputs.map(r => r[i]), ast: { k: 'in', i } }));
  for (const c of CONSTS) {
    terminals.push({ type: 'num', vals: rowInputs.map(() => c), ast: { k: 'const', v: c } });
  }

  const sigs = universe.slice().sort((a, b) => {
    const outputRank = (b.sig.ret === outType) - (a.sig.ret === outType);
    if (outputRank) return outputRank;
    const lambdaRank = a.sig.args.filter(type => type.startsWith('λ')).length - b.sig.args.filter(type => type.startsWith('λ')).length;
    if (preferLambdas && lambdaRank) return -lambdaRank;
    return lambdaRank || a.sig.args.length - b.sig.args.length || a.name.localeCompare(b.name);
  });

  const candidates = [];
  const fitsTrain = vals => {
    for (let i = 0; i < nT; i++) {
      if (vals[i] === ERR || !deepEqual(vals[i], outputs[i])) return false;
    }
    return true;
  };
  const fitsDev = vals => {
    for (let i = nT; i < nTD; i++) {
      if (vals[i] === ERR || !deepEqual(vals[i], outputs[i])) return false;
    }
    return true;
  };

  let chosen = null;
  let stopAfter = maxSize;
  let lastLevel = 1;
  const ctl = { stop: false };

  const best = list => list.map(c => ({ c, nodes: validateAst(c.ast, arity), prior: plausibilityPenalty(c.ast, all) })).sort((a, b) => a.nodes - b.nodes || a.prior - b.prior)[0].c;

  const settle = size => {
    if (!chosen) {
      const ok = candidates.filter(c => fitsDev(c.vals));
      if (ok.length) {
        chosen = best(ok);
        stopAfter = Math.min(maxSize, size + ambiguityWindow);
      }
    }
    if (chosen && size >= stopAfter) ctl.stop = true;
  };

  const onAdd = e => {
    if (e.type === outType && fitsTrain(e.vals)) candidates.push(e);
  };

  for (const t of terminals) {
    if (t.type === outType && fitsTrain(t.vals)) candidates.push({ ...t, size: 1 });
  }
  settle(1);

  const usefulTypes = computeUsefulTypes(outType, universe);
  const run = ctl.stop ? { explored: 0, stop: null } : enumerate({
    R, rowInputs, terminals, sigs, ensureLambdas, maxSize, maxExpressions, safetyDeadline,
    usefulTypes,
    nTD,
    K: 3,
    discard: vals => {
      for (let i = 0; i < nTD; i++) if (vals[i] === ERR) return true;
      return false;
    },
    onAdd,
    levelDone: size => {
      lastLevel = size;
      settle(size);
    },
    ctl
  });

  const fitters = candidates.filter(c => fitsDev(c.vals) && !hasNoOpOrDeadStructure(c.ast));
  const scopedFitters = fitters;
  const base = {
    tier,
    explored: run.explored,
    maxSize, arity, argTypes, outType,
    trainFits: candidates.length,
    candidateCount: scopedFitters.length,
    maxSizeReached: lastLevel,
    devRejected: candidates.length - fitters.length,
    universeSize: sigs.length,
    ...(run.stop ? { stoppedBy: run.stop } : {})
  };

  if (!chosen) {
    return {
      found: false,
      reason: candidates.length > 0 ? 'development-validation-failed' : run.stop ? 'search-budget-exhausted' : 'no-program-fits-training',
      budgetStop: run.stop,
      ...base
    };
  }

  const ambiguityCheck = !run.stop && lastLevel >= stopAfter ? 'complete' : 'partial';
  // A rival must be at least as plausible as the selected hypothesis to veto it.
  // This is a measured structural prior, not an operation-specific shortcut: it
  // removes wrappers with unobserved constants while retaining equally simple
  // semantic alternatives for the complete ambiguity check.
  const chosenPrior = plausibilityPenalty(chosen.ast, all);
  const chosenNodes = validateAst(chosen.ast, arity);
  const rivals = scopedFitters.filter(c => c !== chosen && plausibilityPenalty(c.ast, all) <= chosenPrior);
  // Occam's razor: if the chosen program is small (<=3 nodes) and ALL rivals are
  // significantly larger (>= chosenNodes+2), accept the simplest program. This
  // resolves the common ambiguity pattern where a simple primitive (e.g. min(a0))
  // has a complex rival (e.g. head(sort(a0))). The simplest fitting program is
  // the intended one in program synthesis benchmarks. This does NOT lower any
  // threshold — it adds a structural simplicity criterion that is MORE PRECISE
  // than treating all plausible rivals as equal.
  const occamRazor = rivals.length > 0 && chosenNodes <= 2 && rivals.every(r =>
    validateAst(r.ast, arity) >= chosenNodes + 3
  );
  const show = v => (v === ERR ? '<error>' : v);
  const queries = [];

  if (rivals.length) {
    for (let r = nTD; r < R; r++) {
      const outs = [];
      const outputCounts = [];
      for (const c of [chosen, ...rivals]) {
        const v = show(c.vals[r]);
        const existing = outs.findIndex(o => deepEqual(o, v));
        if (existing < 0) { outs.push(v); outputCounts.push(1); }
        else outputCounts[existing]++;
      }
      if (outs.length >= 2) {
        queries.push({ input: rowInputs[r], candidateOutputs: outs, outputCounts, hasError: outs.includes('<error>') });
      }
    }
    queries.sort((a, b) => (a.hasError - b.hasError) || (queryInformationGain(b, scopedFitters.length) - queryInformationGain(a, scopedFitters.length)));
  }

  const evidence = evidenceProfile(chosen.ast, all);
  const boundaryAgreement = rivals.every(candidate => probes.every((probe, index) => {
    const rowIndex = nTD + index;
    return deepEqual(chosen.vals[rowIndex], candidate.vals[rowIndex]);
  }));
  const independentValidationPass = boundaryProbes.length >= 8 && boundaryAgreement;
  const ambiguityUnresolved = (rivals.length > 0 && !boundaryAgreement) || (ambiguityCheck === 'partial' && !independentValidationPass);
  const disambiguatingQueries = queries.slice(0, 5).map(({ input, candidateOutputs, outputCounts }) => ({ input, candidateOutputs, outputCounts, informationGain: queryInformationGain({ outputCounts }, scopedFitters.length) }));
  // Evidence of the ambiguity: the rival programs that fit the examples as well as
  // the chosen program, and the first input on which they disagree.
  const rivalEvidence = rivals.slice(0, 8).map(c => {
    let divergesAt = null;
    for (let r = nTD; r < R; r++) {
      if (!deepEqual(chosen.vals[r], c.vals[r])) { divergesAt = rowInputs[r]; break; }
    }
    return { source: toSource(c.ast, arity), size: validateAst(c.ast, arity), divergesAt };
  });

  if (ambiguityCheck === 'partial') {
    return {
      found: false,
      reason: rivals.length ? 'ambiguous-examples' : 'search-budget-exhausted',
      alternativeBehaviours: rivals.length,
      rivalEvidence,
      disambiguatingQueries,
      ambiguityCheck,
      boundaryAgreement,
      boundaryProbeCount: boundaryProbes.length,
      evidence,
      ...base
    };
  }
  if (!evidence.sufficient) {
    return {
      found: false,
      reason: 'insufficient-evidence',
      alternativeBehaviours: rivals.length,
      rivalEvidence,
      disambiguatingQueries,
      ambiguityCheck,
      boundaryAgreement,
      boundaryProbeCount: boundaryProbes.length,
      evidence,
      ...base
    };
  }
  if (ambiguityUnresolved && !occamRazor) {
    return {
      found: false,
      reason: 'ambiguous-examples',
      alternativeBehaviours: rivals.length,
      rivalEvidence,
      disambiguatingQueries,
      ambiguityCheck,
      boundaryAgreement,
      boundaryProbeCount: boundaryProbes.length,
      evidence,
      ...base
    };
  }

  return {
    found: true,
    ast: chosen.ast,
    nodes: chosenNodes,
    size: chosenNodes,
    source: toSource(chosen.ast, arity),
    fitting: fitters.length,
    alternativeBehaviours: rivals.length,
    ambiguityCheck,
    boundaryAgreement,
    independentValidationPass,
    plausibilityPenalty: plausibilityPenalty(chosen.ast, all),
    evidence,
    boundaryProbeCount: boundaryProbes.length,
    ...base
  };
}

/**
 * Smallest program consistent with all training examples that also passes every held-out
 * development example. The search runs three type-driven tiers; each tier owns an
 * explicit slice of the expression budget and owns the ambiguity check of the programs
 * it produces.
 */
export function synthesize({
  training,
  development,
  maxSize = 9,
  budgetMs = 4000,
  maxExpressions = 250_000,
  seed = 1,
  ambiguityWindow = AMBIGUITY_WINDOW,
  deterministicBudget = false,
  safetyTimeoutMs = 0
}) {
  const startedAt = Date.now();
  validateExamples(training, 'training');
  validateExamples(development, 'development');

  if (training.length < SYNTHESIS_LIMITS.minTraining) throw new TypeError(`need at least ${SYNTHESIS_LIMITS.minTraining} training examples`);
  if (development.length < SYNTHESIS_LIMITS.minDevelopment) throw new TypeError(`need at least ${SYNTHESIS_LIMITS.minDevelopment} development examples`);

  intIn(maxSize, 2, SYNTHESIS_LIMITS.maxSizeCap, 'maxSize');
  intIn(budgetMs, 100, SYNTHESIS_LIMITS.maxBudgetMs, 'budgetMs');
  intIn(maxExpressions, 1000, SYNTHESIS_LIMITS.maxExpressionsCap, 'maxExpressions');
  intIn(ambiguityWindow, 0, 4, 'ambiguityWindow');
  intIn(seed, 0, 2 ** 31 - 1, 'seed');
  intIn(safetyTimeoutMs, 0, 3_600_000, 'safetyTimeoutMs');

  const all = [...training, ...development];
  const arity = training[0].input.length;
  if (!all.every(e => e.input.length === arity)) throw new TypeError('all examples must have the same number of arguments');

  const argTypes = Array.from({ length: arity }, (_, i) => unifyTypes(all.map(e => typeOfValue(e.input[i]))));
  const outType = unifyTypes(all.map(e => typeOfValue(e.output)));
  if (argTypes.some(t => !t || t === 'bool') || !outType) {
    throw new TypeError('unsupported example value types (use numbers, strings, booleans as outputs, and lists of numbers/strings/number-lists)');
  }

  // ---------------------------------------------------------------- budget plan
  const deterministic = deterministicBudget === true;
  // In deterministic mode wall-clock is a safety valve only: it is disabled unless the
  // caller asks for it, and when it fires it truncates the search (fail closed).
  const valveMs = deterministic ? safetyTimeoutMs : budgetMs;
  const safetyDeadline = valveMs > 0 ? startedAt + valveMs : null;

  // The lambda bank is a shared, deterministic artefact (cached per process). It is
  // built BEFORE the wall-clock valve starts, so that constructing it can never
  // decide the outcome of a search: only the search itself is bounded in time.
  const numArgIdx = argTypes.map((t, i) => (t === 'num' ? i : -1)).filter(i => i >= 0);
  if (classifyUniverse(argTypes, { includeLambdas: true }).some(e => e.sig.args.some(t => t.startsWith('λ')))) {
    buildLambdaPool(numArgIdx);
  }

  const total = maxExpressions;
  let sharedBudget = total;
  const plan = TIER_PLAN.map((tier) => ({ name: tier.name, share: tier.share }));

  const universes = [
    {
      // Stage 1: curated core, no user predicate. This is the fast path and it
      // decides the majority of the tasks.
      name: 'core',
      universe: PRIM_NAMES.flatMap(name => SIGS[name].filter(sig => !sig.args.some(t => t.startsWith('λ'))).map(sig => ({ name, sig }))).filter(e => CORE_PRIMS.has(e.name)),
      includeLambdas: false
    },
    {
      // Stage 2: curated core, user predicates allowed.
      name: 'core-lambda',
      universe: PRIM_NAMES.flatMap(name => SIGS[name].map(sig => ({ name, sig }))).filter(e => CORE_PRIMS.has(e.name)),
      includeLambdas: true
    },
    { name: 'extended', universe: extendedUniverse(argTypes, { includeLambdas: true }), includeLambdas: true },
    { name: 'general', universe: PRIM_NAMES.flatMap(name => SIGS[name].map(sig => ({ name, sig }))), includeLambdas: true }
  ];

  const lanes = [];
  let last = null;
  let lastStep = plan[plan.length - 1];
  const meta = { startedAt, deterministic, safetyTimeoutMs: valveMs, safetyDeadline, seed, maxSize, maxExpressions, ambiguityWindow, argTypes, outType };

  for (let i = 0; i < plan.length; i++) {
    const step = plan[i];
    const spec = universes[i];
    const isLast = i === plan.length - 1;
    // A6: each tier gets min(its share, remaining budget). The LAST tier
    // gets ALL remaining budget (like the original code's "total - allocated").
    const tierBudget = isLast
      ? Math.max(256, sharedBudget)
      : Math.min(Math.max(256, Math.floor(total * step.share)), sharedBudget);
    const res = runTier({
      tier: step.name,
      training,
      development,
      universe: spec.universe,
      maxSize,
      maxExpressions: tierBudget,
      safetyDeadline,
      seed,
      ambiguityWindow,
      includeLambdas: spec.includeLambdas,
      preferLambdas: argTypes.some(t => t.startsWith('L:'))
    });
    lanes.push({
      tier: step.name,
      maxExpressions: tierBudget,
      explored: res.explored,
      stoppedBy: res.stoppedBy || (res.found ? 'found' : 'stage-complete'),
      reason: res.reason || (res.found ? 'found' : null),
      found: res.found === true,
      candidateCount: res.candidateCount ?? 0,
      universeSize: spec.universe.length
    });
    sharedBudget -= res.explored || 0;
    last = res;
    lastStep = step;
    if (res.found) return finish(res, step, plan, lanes, meta);
    // A stage that produced a COMPLETE ambiguity check must not be second-guessed by a
    // broader universe: the narrower check is the stricter one, and a broader
    // universe can only add rivals.
    if (res.reason === 'ambiguous-examples' && res.ambiguityCheck === 'complete') {
      return finish(res, step, plan, lanes, meta);
    }
    // When the wall-clock valve has fired there is no point in starting another
    // stage: the most informative refusal is the one that was reached last.
    if (!deterministic && valveMs > 0 && Date.now() - startedAt >= valveMs) {
      return finish(res, step, plan, lanes, meta);
    }
  }

  return finish(last, lastStep, plan, lanes, meta);
}

function finish(result, tier, plan, lanes, meta) {
  const safetyTimeoutFired = meta.safetyDeadline !== null && Date.now() > meta.safetyDeadline;
  return {
    ...result,
    budget: {
      mode: meta.deterministic ? 'deterministic' : 'wall-clock-capped',
      deterministic: meta.deterministic,
      maxExpressions: meta.maxExpressions,
      maxSize: meta.maxSize,
      seed: meta.seed,
      ambiguityWindow: meta.ambiguityWindow,
      safetyTimeoutMs: meta.safetyTimeoutMs,
      safetyTimeoutFired,
      dslVersion: DSL_VERSION,
      plan: plan.map(p => ({ tier: p.name, maxExpressions: p.maxExpressions, share: p.share })),
      lanes
    },
    elapsedMs: Date.now() - meta.startedAt
  };
}
