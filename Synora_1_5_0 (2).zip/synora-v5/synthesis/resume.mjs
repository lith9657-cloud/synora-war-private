/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synora Resume Synthesis (A7) — reuse candidate programs across clarification
 * rounds to avoid restarting the search from scratch.
 *
 * When the synthesizer returns 'ambiguous-examples', it has found multiple
 * candidate programs that all fit the training data. The caller asks a
 * disambiguating question, gets a new example, and calls synthesize() again.
 * Without A7, the second call re-does the entire search.
 *
 * With A7, the second call:
 *   1. Takes the candidates from the first call
 *   2. Evaluates each on the new example
 *   3. If exactly one candidate survives → use it (no search needed!)
 *   4. If multiple survive → still ambiguous, but fewer candidates
 *   5. If none survive → full re-search (the new example eliminated all)
 *
 * This is safe: it doesn't modify synthesize.mjs. It wraps it.
 */
import { synthesize } from './synthesize.mjs';
import { evalAst, deepEqual } from './dsl.mjs';

/**
 * Synthesize with resume support.
 *
 * @param {object} task — { training, development, ...synthOptions }
 * @param {object} [previousResult] — the result of a previous synthesize() call
 *        that returned 'ambiguous-examples'. If provided, its candidates are
 *        filtered against the new examples before re-searching.
 * @returns {object} — same shape as synthesize(), plus a `resumed` flag
 */
export function synthesizeWithResume(task, previousResult = null) {
  if (!previousResult || !previousResult.candidates || previousResult.candidates.length === 0) {
    // No previous result to resume from — full search
    return { ...synthesize(task), resumed: false };
  }

  // A7: filter previous candidates against the new training examples
  const newTraining = task.training;
  const oldTraining = previousResult._training || [];
  // Find examples that were added since the previous call
  const addedExamples = newTraining.slice(oldTraining.length);

  if (addedExamples.length === 0) {
    // No new examples — just re-run
    return { ...synthesize(task), resumed: false };
  }

  // Filter candidates: keep only those that match ALL new examples
  const survivingCandidates = previousResult.candidates.filter(cand => {
    if (!cand.ast) return false;
    return addedExamples.every(ex => {
      try {
        const output = evalAst(cand.ast, ex.input);
        return deepEqual(output, ex.output);
      } catch {
        return false;
      }
    });
  });

  if (survivingCandidates.length === 1) {
    // A7 success: exactly one candidate survived the new example
    const cand = survivingCandidates[0];
    return {
      found: true,
      ast: cand.ast,
      source: cand.source,
      reason: null,
      explored: 0, // no search was needed!
      resumed: true,
      ambiguityCheck: 'resolved-by-clarification',
      alternativeBehaviours: 0,
      laneCounts: { resumed: { explored: 0, stoppedBy: 'resolved' } },
      lane: 'resumed',
      deterministicBudget: true,
      safetyTimeoutFired: false,
      candidates: survivingCandidates
    };
  }

  if (survivingCandidates.length > 1) {
    // Still ambiguous — but fewer candidates. Return the reduced set.
    return {
      found: false,
      reason: 'ambiguous-examples',
      ambiguityCheck: 'partial',
      explored: 0,
      resumed: true,
      alternativeBehaviours: survivingCandidates.length,
      candidates: survivingCandidates,
      disambiguatingQueries: previousResult.disambiguatingQueries || []
    };
  }

  // No candidate survived — the new example eliminated all previous candidates.
  // Fall back to full search.
  const result = synthesize(task);
  return { ...result, resumed: false };
}

/**
 * Extract a storable summary from a synthesis result for later resume.
 * Callers should store this and pass it to synthesizeWithResume() on the
 * next clarification round.
 */
export function extractResumePoint(result, training) {
  if (!result || !result.candidates) return null;
  return {
    candidates: result.candidates.map(c => ({ ast: c.ast, source: c.source, vals: c.vals })),
    _training: training,
    reason: result.reason,
    disambiguatingQueries: result.disambiguatingQueries
  };
}
