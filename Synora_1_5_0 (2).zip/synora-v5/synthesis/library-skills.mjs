/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'node:fs';
import path from 'node:path';
import { validateAst, evalAst, toSource, deepEqual } from './dsl.mjs';

/**
 * Normalizes an AST subtree into a canonical lambda form (substituting free input references)
 */
function normalizeSubtree(ast) {
  if (!ast || typeof ast !== 'object') return null;
  if (ast.k === 'in') return { k: 'x' };
  if (ast.k === 'const' || ast.k === 'x') return ast;
  if (ast.k === 'call') {
    return {
      k: 'call',
      f: ast.f,
      a: ast.a.map(c => normalizeSubtree(c))
    };
  }
  return null;
}

function astKey(ast) {
  return JSON.stringify(ast);
}

function astSize(ast) {
  if (!ast || typeof ast !== 'object') return 0;
  if (ast.k === 'in' || ast.k === 'const' || ast.k === 'x') return 1;
  if (ast.k === 'call') {
    return 1 + ast.a.reduce((s, c) => s + astSize(c), 0);
  }
  if (ast.k === 'lam') return 1 + astSize(ast.body);
  return 1;
}

export class SkillManager {
  constructor(options = {}) {
    this.stateDir = options.stateDir || null;
    this.library = new Map();
    this.history = [];
    this.historyFile = this.stateDir ? path.join(this.stateDir, 'skills-history.json') : null;
    this.load();
  }

  load() {
    if (this.historyFile && fs.existsSync(this.historyFile)) {
      try {
        const raw = fs.readFileSync(this.historyFile, 'utf-8');
        const data = JSON.parse(raw);
        this.history = data.history || [];
        for (const entry of (data.skills || [])) {
          this.library.set(entry.id, entry);
        }
      } catch {}
    }
  }

  save() {
    if (this.historyFile) {
      fs.mkdirSync(path.dirname(this.historyFile), { recursive: true });
      const data = {
        skills: Array.from(this.library.values()),
        history: this.history
      };
      fs.writeFileSync(this.historyFile, JSON.stringify(data, null, 2), 'utf-8');
    }
  }

  /**
   * Registers a tested skill
   */
  registerSkill(skill) {
    if (!skill || !skill.id) return false;
    this.library.set(skill.id, skill);
    this.history.push({
      action: 'register',
      timestamp: Date.now(),
      id: skill.id,
      name: skill.name || skill.id
    });
    this.save();
    return true;
  }

  /**
   * Verifies retention of all registered skills against their tests
   */
  verifyRetention() {
    for (const [id, skill] of this.library.entries()) {
      const tests = skill.tests || [];
      if (skill.ast) {
        for (const t of tests) {
          try {
            const actual = evalAst(skill.ast, t.input);
            if (!deepEqual(actual, t.output)) {
              return { passed: false, failedSkill: id };
            }
          } catch {
            return { passed: false, failedSkill: id };
          }
        }
      }
    }
    return { passed: true };
  }

  /**
   * Mines frequent sub-expressions from a list of accepted programs
   */
  mineSubexpressions(programs) {
    const counts = new Map();
    const subtrees = new Map();

    const walk = (node) => {
      if (!node || typeof node !== 'object') return;
      const size = astSize(node);
      if (size >= 2 && size <= 6 && node.k === 'call') {
        const norm = normalizeSubtree(node);
        if (norm) {
          const key = astKey(norm);
          counts.set(key, (counts.get(key) || 0) + 1);
          if (!subtrees.has(key)) subtrees.set(key, norm);
        }
      }
      if (Array.isArray(node.a)) {
        for (const child of node.a) walk(child);
      }
      if (node.k === 'lam') walk(node.body);
    };

    for (const prog of programs) {
      walk(prog);
    }

    const proposed = [];
    for (const [key, count] of counts.entries()) {
      if (count >= 2) {
        proposed.push({
          ast: subtrees.get(key),
          frequency: count,
          size: astSize(subtrees.get(key))
        });
      }
    }

    proposed.sort((a, b) => (b.frequency * b.size) - (a.frequency * a.size));
    return proposed;
  }

  /**
   * Rolls back the last proposed skill
   */
  rollback(skillId) {
    if (this.library.has(skillId)) {
      this.library.delete(skillId);
      this.history.push({
        action: 'rollback',
        timestamp: Date.now(),
        id: skillId
      });
      this.save();
      return true;
    }
    return false;
  }
}
