/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synora HuggingFace Dataset Ingestion — "يفهم لا يحفظ"
 *
 * Ingests HuggingFace datasets by extracting PATTERNS (not storing data).
 * Each dataset is analyzed for:
 *   - Q&A patterns (question→answer structure)
 *   - Code patterns (prompt→code structure)
 *   - Conversation patterns (turn→response structure)
 *   - Marketing patterns (instruction→output structure)
 *
 * The extracted patterns are compact relation tables, not raw text.
 * This keeps the model size small while expanding its understanding.
 *
 * Supported datasets:
 *   - FineWeb: web text patterns
 *   - Pile: diverse text patterns
 *   - OASST2: open conversation patterns
 *   - Marketing-instruct: marketing instruction patterns
 *
 * Usage:
 *   import { ingestDataset, extractPatterns, PATTERN_TYPES } from './hf-ingestion.mjs';
 *   const result = await ingestDataset('oasst2', mockFetcher);
 */

// Pattern types extracted from datasets
export const PATTERN_TYPES = {
  QA: 'qa',           // question → answer
  CODE: 'code',       // prompt → code
  CONVERSATION: 'conv', // turn → response
  INSTRUCTION: 'instr', // instruction → output
  FACT: 'fact',       // entity → attribute
  MARKETING: 'mktg',  // marketing instruction → output
};

// Dataset configurations
export const DATASETS = {
  fineweb: {
    url: 'https://huggingface.co/datasets/HuggingFaceFW/fineweb',
    type: PATTERN_TYPES.FACT,
    description: 'Web text — extract factual patterns',
    format: 'jsonl',
    // FineWeb has text blocks; extract entity-relation patterns
    extractor: (record) => extractFactsFromText(record.text || ''),
  },
  pile: {
    url: 'https://huggingface.co/datasets/EleutherAI/pile',
    type: PATTERN_TYPES.FACT,
    description: 'Diverse text — extract factual patterns',
    format: 'jsonl',
    extractor: (record) => extractFactsFromText(record.text || ''),
  },
  oasst2: {
    url: 'https://huggingface.co/datasets/OpenAssistant/oasst2',
    type: PATTERN_TYPES.CONVERSATION,
    description: 'Open conversation — extract dialogue patterns',
    format: 'parquet',
    // OASST2 has instruction/response pairs
    extractor: (record) => extractConversationPattern(record),
  },
  marketing: {
    url: 'https://huggingface.co/datasets/suehuynh/marketing-instruct-13k',
    type: PATTERN_TYPES.MARKETING,
    description: 'Marketing instructions — extract marketing patterns',
    format: 'parquet',
    extractor: (record) => extractMarketingPattern(record),
  },

  codestack: {
    url: 'https://huggingface.co/datasets/bigcode/the-stack-v2',
    type: PATTERN_TYPES.CODE,
    description: 'The Stack v2 — code patterns from GitHub repos',
    format: 'parquet',
    extractor: (record) => extractCodePattern(record),
  },
  starcoder: {
    url: 'https://huggingface.co/datasets/bigcode/starcoderdata',
    type: PATTERN_TYPES.CODE,
    description: 'StarCoder data — code + comment patterns',
    format: 'parquet',
    extractor: (record) => extractCodePattern(record),
  },
  opencodeinstruct: {
    url: 'https://huggingface.co/datasets/nvidia/OpenCodeInstruct',
    type: PATTERN_TYPES.INSTRUCTION,
    description: 'OpenCodeInstruct — code instruction patterns',
    format: 'parquet',
    extractor: (record) => extractInstructionPattern(record),
  },
  nemotron: {
    url: 'https://huggingface.co/datasets/nvidia/Nemotron-SFT-SWE-v3',
    type: PATTERN_TYPES.CODE,
    description: 'Nemotron SFT — software engineering code patterns',
    format: 'parquet',
    extractor: (record) => extractCodePattern(record),
  },
  denovoswe: {
    url: 'https://huggingface.co/collections/AweAI-Team/denovoswe',
    type: PATTERN_TYPES.CODE,
    description: 'DeNovo SWE — software engineering agent task patterns',
    format: 'parquet',
    extractor: (record) => extractCodePattern(record),
  },
  terminaltraj: {
    url: 'https://huggingface.co/datasets/m-a-p/TerminalTraj',
    type: PATTERN_TYPES.CODE,
    description: 'Terminal trajectory — shell command + agent execution patterns',
    format: 'parquet',
    extractor: (record) => extractTerminalPattern(record),
  },
  nemotronSWE: {
    url: 'https://huggingface.co/datasets/nvidia/Nemotron-SWE-v1',
    type: PATTERN_TYPES.CODE,
    description: 'Nemotron SWE v1 — software engineering instruction patterns',
    format: 'parquet',
    extractor: (record) => extractInstructionPattern(record),
  },
  lmsyschat: {
    url: 'https://huggingface.co/datasets/lmsys/lmsys-chat-1m',
    type: PATTERN_TYPES.CONVERSATION,
    description: 'LMSYS Chat 1M — real user conversations for open dialogue',
    format: 'parquet',
    extractor: (record) => extractConversationPattern(record),
  },
  fineinstructions: {
    url: 'https://huggingface.co/datasets/fineinstructions/fineinstructions_nemotron',
    type: PATTERN_TYPES.INSTRUCTION,
    description: 'Fine instructions — extract instruction patterns',
    format: 'parquet',
    extractor: (record) => extractInstructionPattern(record),
  },
};

/**
 * Extract factual patterns from text (entity → attribute → value).
 * Returns compact relation entries, not the full text.
 */
function extractFactsFromText(text) {
  if (!text || typeof text !== 'string') return [];
  const patterns = [];
  // Capitalized entity followed by "is/was" followed by description
  const entityMatches = text.matchAll(/([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:is|was)\s+([a-z][^.]{5,80})\./g);
  for (const m of entityMatches) {
    patterns.push({
      type: PATTERN_TYPES.FACT,
      subject: m[1],
      relation: 'is',
      object: m[2].trim().slice(0, 60),
    });
  }
  // Numbers with units (populations, dates, measurements)
  const numMatches = text.matchAll(/(\d{1,6}(?:,\d{3})*)\s+(people|inhabitants|million|billion|metres|meters|km|years?|days?|hours?|minutes?|نسمة|مليون|متر|سنة|عام)/gi);
  for (const m of numMatches) {
    patterns.push({
      type: PATTERN_TYPES.FACT,
      subject: 'numeric',
      relation: 'quantity',
      object: m[1] + ' ' + m[2],
    });
  }
  // Founded/established years
  const yearMatches = text.matchAll(/(?:founded|established|created|built)\s+in\s+(\d{3,4})/gi);
  for (const m of yearMatches) {
    patterns.push({
      type: PATTERN_TYPES.FACT,
      subject: 'entity',
      relation: 'founded',
      object: m[1],
    });
  }
  return patterns.slice(0, 5); // max 5 patterns per text block
}

/**
 * Extract conversation patterns from OASST2 records.
 * Returns dialogue structure, not full conversation.
 */
function extractConversationPattern(record) {
  const text = record.text || record.content || '';
  const role = record.role || '';
  if (!text) return [];
  // Extract the INTENT and STRUCTURE, not the content
  const intent = detectIntent(text);
  return [{
    type: PATTERN_TYPES.CONVERSATION,
    role: role,
    intent: intent,
    length: text.length,
    hasQuestion: /\?|؟/.test(text),
    hasCode: /```|function |const |import /.test(text),
    hasList: /^\s*[-*]\s/m.test(text),
  }];
}

function detectIntent(text) {
  if (/^(how|what|why|when|where|who|which|كم|ما|متى|أين|من|لماذا|كيف)/i.test(text.trim())) return 'question';
  if (/^(create|build|make|generate|write|design|ابني|أنشئ|اكتب|صمم)/i.test(text.trim())) return 'create';
  if (/^(fix|debug|resolve|solve|أصلح|حل)/i.test(text.trim())) return 'fix';
  if (/^(explain|describe|tell|اشرح|صف|أخبر)/i.test(text.trim())) return 'explain';
  if (/^(summarize|condense|لخص)/i.test(text.trim())) return 'summarize';
  if (/^(translate|convert|ترجم|حوّل)/i.test(text.trim())) return 'translate';
  if (/^(analyze|evaluate|assess|حلل|قيّم)/i.test(text.trim())) return 'analyze';
  return 'statement';
}

/**
 * Extract marketing instruction patterns.
 */
function extractMarketingPattern(record) {
  const instruction = record.instruction || record.prompt || '';
  const output = record.output || record.response || '';
  if (!instruction) return [];
  return [{
    type: PATTERN_TYPES.MARKETING,
    intent: detectIntent(instruction),
    category: detectMarketingCategory(instruction),
    outputLength: output.length,
    outputStructure: detectOutputStructure(output),
  }];
}

function detectMarketingCategory(text) {
  const t = text.toLowerCase();
  if (/seo|keyword|meta tag|بحث|كلمات مفتاحية/.test(t)) return 'seo';
  if (/email|campaign|newsletter|بريد|حملة/.test(t)) return 'email';
  if (/social|post|tweet|instagram|تويتر|انستغرام/.test(t)) return 'social';
  if (/ad|advertisement|banner|إعلان/.test(t)) return 'ads';
  if (/copy|copywriting|headline|عنوان|كتابة/.test(t)) return 'copywriting';
  if (/landing|page|صفحة هبوط/.test(t)) return 'landing';
  if (/brand|logo|identity|علامة تجارية/.test(t)) return 'branding';
  return 'general';
}

function detectOutputStructure(text) {
  if (/^#\s/m.test(text)) return 'markdown-headings';
  if (/```/.test(text)) return 'code-block';
  if (/^\s*[-*]\s/m.test(text)) return 'bullet-list';
  if (/^\d+\./m.test(text)) return 'numbered-list';
  if (/<html|<div|<p/.test(text)) return 'html';
  return 'prose';
}

/**
 * Extract instruction patterns.
 */
function extractInstructionPattern(record) {
  const instruction = record.instruction || record.input || '';
  const output = record.output || '';
  if (!instruction) return [];
  return [{
    type: PATTERN_TYPES.INSTRUCTION,
    intent: detectIntent(instruction),
    outputType: detectOutputStructure(output),
    complexity: output.length > 500 ? 'complex' : output.length > 100 ? 'medium' : 'simple',
  }];
}


/**
 * Extract code patterns from programming datasets.
 * Returns language + structure + API usage patterns, NOT the code itself.
 */
function extractCodePattern(record) {
  const content = record.content || record.code || record.text || '';
  const language = record.language || record.lang || detectLanguage(content);
  if (!content) return [];
  const patterns = [];
  // Detect code structure patterns
  const hasFunction = /function\s+\w+|const\s+\w+\s*=\s*(\(|async)/.test(content);
  const hasClass = /class\s+\w+/.test(content);
  const hasImport = /import\s+|require\(/.test(content);
  const hasExport = /export\s+/.test(content);
  const hasAsync = /async\s|await\s/.test(content);
  const hasLoop = /for\s*\(|while\s*\(|\.map\(|\.forEach\(/.test(content);
  const hasConditional = /if\s*\(|\?\s|switch\s*\(/.test(content);
  const hasTryCatch = /try\s*\{|catch\s*\(/.test(content);
  const hasAPI = /fetch\(|axios|http\.get|XMLHttpRequest/.test(content);
  const hasDOM = /document\.|querySelector|getElementById|addEventListener/.test(content);
  const hasReact = /useState|useEffect|component|jsx|tsx/.test(content);
  const hasTest = /describe\(|test\(|it\(|expect\(|assert/.test(content);
  patterns.push({
    type: PATTERN_TYPES.CODE,
    language: language,
    structure: [
      hasFunction && 'function', hasClass && 'class', hasImport && 'import',
      hasExport && 'export', hasAsync && 'async', hasLoop && 'loop',
      hasConditional && 'conditional', hasTryCatch && 'trycatch',
      hasAPI && 'api', hasDOM && 'dom', hasReact && 'react', hasTest && 'test'
    ].filter(Boolean).join(','),
    length: content.length,
    complexity: content.length > 1000 ? 'complex' : content.length > 200 ? 'medium' : 'simple',
  });
  // Extract API call patterns (function name → arity)
  const fnMatches = [...content.matchAll(/(?:function|const|def)\s+(\w+)\s*(?:\(|=)/g)];
  for (const m of fnMatches.slice(0, 3)) {
    patterns.push({ type: PATTERN_TYPES.CODE, language, fnName: m[1].slice(0, 20) });
  }
  return patterns.slice(0, 5);
}

function detectLanguage(code) {
  if (/def\s|print\(|import\s+\w/.test(code)) return 'python';
  if (/function\s|const\s|let\s|var\s|=>|require\(/.test(code)) return 'javascript';
  if (/public\s+class|System\.|using\s/.test(code)) return 'csharp';
  if (/#include|int\s+main/.test(code)) return 'cpp';
  if (/func\s|let\s|var\s/.test(code) && !/function/.test(code)) return 'swift';
  if (/fn\s|impl\s|pub\s/.test(code)) return 'rust';
  if (/package\s|func\s|type\s+struct/.test(code)) return 'go';
  if (/<\?php/.test(code)) return 'php';
  return 'unknown';
}

/**
 * Extract terminal/shell command patterns from TerminalTraj.
 */
function extractTerminalPattern(record) {
  const content = record.trajectory || record.commands || record.text || '';
  if (!content) return [];
  const patterns = [];
  // Detect shell command patterns
  const hasCd = /\bcd\b/.test(content);
  const hasLs = /\bls\b|\bdir\b/.test(content);
  const hasGrep = /\bgrep\b|\bfind\b/.test(content);
  const hasGit = /\bgit\b/.test(content);
  const hasNpm = /\bnpm\b|\byarn\b|\bpnpm\b/.test(content);
  const hasDocker = /\bdocker\b/.test(content);
  const hasPython = /\bpython\b|\bpip\b/.test(content);
  const hasNode = /\bnode\b/.test(content);
  const hasCat = /\bcat\b|\becho\b/.test(content);
  const hasMkdir = /\bmkdir\b|\btouch\b/.test(content);
  const hasRm = /\brm\b|\bcp\b|\bmv\b/.test(content);
  const hasChmod = /\bchmod\b|\bchown\b/.test(content);
  const hasSudo = /\bsudo\b/.test(content);
  const hasPipe = /\|/.test(content);
  const hasRedirect = />/.test(content);
  patterns.push({
    type: PATTERN_TYPES.CODE,
    language: 'shell',
    structure: [
      hasCd && 'cd', hasLs && 'ls', hasGrep && 'grep', hasGit && 'git',
      hasNpm && 'npm', hasDocker && 'docker', hasPython && 'python',
      hasNode && 'node', hasCat && 'cat', hasMkdir && 'mkdir',
      hasRm && 'rm', hasChmod && 'chmod', hasSudo && 'sudo',
      hasPipe && 'pipe', hasRedirect && 'redirect'
    ].filter(Boolean).join(','),
    length: content.length,
    complexity: content.length > 500 ? 'complex' : content.length > 100 ? 'medium' : 'simple',
  });
  return patterns.slice(0, 3);
}

/**
 * Ingest a dataset: fetch records, extract patterns, return compact summary.
 * Does NOT store the raw data — only the extracted patterns.
 *
 * @param {string} datasetName - key in DATASETS
 * @param {function} fetcher - injectable fetch function (for testing/offline)
 * @param {number} maxRecords - max records to process (default 1000)
 * @returns {Promise<{dataset, patterns, stats}>}
 */
export async function ingestDataset(datasetName, fetcher, maxRecords = 1000) {
  const config = DATASETS[datasetName];
  if (!config) return { error: `unknown dataset: ${datasetName}` };

  const patterns = [];
  let processed = 0;
  let skipped = 0;

  // If fetcher is provided, use it; otherwise try real fetch
  const _fetch = fetcher || (typeof fetch !== 'undefined' ? fetch : null);
  if (!_fetch && !fetcher) {
    return {
      dataset: datasetName,
      patterns: [],
      stats: { processed: 0, skipped: 0, extracted: 0, reason: 'no_fetch_available' },
    };
  }

  // Try to fetch dataset metadata
  try {
    const metaUrl = `https://huggingface.co/api/datasets/${datasetName.split('/').slice(0,2).join('/')}`;
    // Process records if fetcher provides them
    // In offline mode, the fetcher simulates records
    const records = typeof fetcher === 'function' ? await fetcher(datasetName, maxRecords) : [];

    for (const record of (records || [])) {
      processed++;
      if (processed > maxRecords) break;
      try {
        const extracted = config.extractor(record);
        if (extracted.length > 0) {
          patterns.push(...extracted);
        } else {
          skipped++;
        }
      } catch {
        skipped++;
      }
    }
  } catch (err) {
    return {
      dataset: datasetName,
      patterns: [],
      stats: { processed: 0, skipped: 0, extracted: 0, error: err.message },
    };
  }

  // Compress patterns into relation tables (understand not store)
  const tables = compressPatterns(patterns);

  return {
    dataset: datasetName,
    url: config.url,
    type: config.type,
    patterns: tables,
    stats: {
      processed,
      skipped,
      extracted: patterns.length,
      compressed: Object.values(tables).reduce((s, t) => s + Object.keys(t).length, 0),
    },
  };
}

/**
 * Compress extracted patterns into relation tables.
 * Multiple patterns with the same relation become ONE table entry.
 * This is the "understand not store" principle.
 */
function compressPatterns(patterns) {
  const tables = {};
  for (const p of patterns) {
    const key = p.type + ':' + (p.relation || p.intent || p.category || 'default');
    if (!tables[key]) tables[key] = {};
    const itemKey = p.subject || p.role || p.outputStructure || 'item';
    // Don't store the full value — just count occurrences (understanding frequency)
    if (!tables[key][itemKey]) {
      tables[key][itemKey] = { count: 0, sample: (p.object || p.outputType || p.complexity || '').slice(0, 30) };
    }
    tables[key][itemKey].count++;
  }
  return tables;
}

/**
 * GitHub Skill Ingestion — fetch and parse skill from GitHub repo.
 */
export async function ingestGitHubSkill(repoUrl, fetcher) {
  const _fetch = fetcher || (typeof fetch !== 'undefined' ? fetch : null);
  if (!_fetch) return { error: 'no_fetch' };

  const parts = repoUrl.replace('https://github.com/', '').replace(/\/$/, '');
  const [owner, repo] = parts.split('/');

  // Try to fetch README and SKILL.md
  const files = {};
  for (const path of ['README.md', 'SKILL.md', 'llms.txt']) {
    try {
      const rawUrl = `https://raw.githubusercontent.com/${owner}/${repo}/main/${path}`;
      const res = await _fetch(rawUrl);
      if (res.ok) {
        files[path] = await res.text();
      }
    } catch {}
  }

  if (Object.keys(files).length === 0) {
    return { error: 'could not fetch any files', repo: parts };
  }

  // Extract skill understanding (not storage)
  const skill = {
    repo: parts,
    name: repo.replace(/-/g, ' '),
    files: Object.keys(files),
    understanding: extractSkillUnderstanding(files),
  };

  return skill;
}

/**
 * Extract understanding from skill files — patterns, not text.
 */
function extractSkillUnderstanding(files) {
  const understanding = {
    purpose: '',
    capabilities: [],
    workflow: [],
    technologies: [],
    patterns: [],
  };

  const allText = Object.values(files).join('\n');

  // Extract purpose (first meaningful line)
  const purposeMatch = allText.match(/^>\s*(.+)/m) || allText.match(/^# (.+)/m);
  if (purposeMatch) understanding.purpose = purposeMatch[1].slice(0, 100);

  // Extract capabilities (bullet points with action verbs)
  const capMatches = allText.matchAll(/[-*]\s+(?:Create|Build|Generate|Design|Deploy|Convert|Analyze|Write|Make|Turn|Extract|Inspect|Author|Add|Enable|Commit|Push|Verify)\s+([^.\n]{5,60})/gi);
  for (const m of capMatches) {
    understanding.capabilities.push(m[1].trim().slice(0, 50));
  }

  // Extract workflow phases
  const phaseMatches = allText.matchAll(/Phase\s+\d+\s*:?\s*([^\n]{5,60})/gi);
  for (const m of phaseMatches) {
    understanding.workflow.push(m[1].trim().slice(0, 50));
  }

  // Extract technologies
  const techMatches = allText.matchAll(/\b(Tailwind|React|HTML|CSS|JavaScript|TypeScript|GitHub Pages|Stitch MCP|GSAP|Lenis|Claude|Codex|Cursor)\b/gi);
  const techs = new Set();
  for (const m of techMatches) techs.add(m[1]);
  understanding.technologies = [...techs];

  // Extract design patterns
  const patternMatches = allText.matchAll(/\b(landing page|SaaS|portfolio|hero section|CTA|navigation|footer|responsive|dark mode|light mode|grid|flexbox|animation|scroll)\b/gi);
  const pats = new Set();
  for (const m of patternMatches) pats.add(m[1].toLowerCase());
  understanding.patterns = [...pats];

  return understanding;
}
