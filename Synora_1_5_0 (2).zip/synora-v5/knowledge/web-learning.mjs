/** @license SPDX-License-Identifier: Apache-2.0 */
const PERMISSIVE_TEXT_LICENSES = new Set(['CC0-1.0', 'CC-BY-4.0', 'CC-BY-SA-4.0']);

export class WebLearningPipeline {
  constructor(options = {}) {
    this.enabled = options.enabled === true; // explicit opt-in only
    this.fetcher = options.fetcher || null;
    this.robotsChecker = options.robotsChecker || null;
    this.rateLimitMs = options.rateLimitMs || 1000;
    this.lastFetchTime = 0;
    this.maxBytes = options.maxBytes || 1_000_000;
    this.connectionLog = [];
  }

  async learnUnknownFact(query, searchResults = []) {
    if (!this.enabled) return { status: 'disabled', reason: 'web_learning_is_opt_in_only' };
    if (typeof this.fetcher !== 'function') throw new Error('No fetcher injected');
    if (typeof this.robotsChecker !== 'function') return { status: 'abstain', reason: 'robots_checker_required' };
    if (!Array.isArray(searchResults)) throw new TypeError('searchResults must be an array');
    const validSources = searchResults.filter(src => {
      try { const u = new URL(src.url); return ['http:', 'https:'].includes(u.protocol) && u.username === '' && u.password === ''; }
      catch { return false; }
    });
    const independent = new Map(validSources.map(src => [new URL(src.url).hostname.toLowerCase(), src]));
    if (independent.size < 2) return { status: 'abstain', reason: 'requires_two_independent_hosts' };
    const now = Date.now();
    if (now - this.lastFetchTime < this.rateLimitMs) return { status: 'rate_limited' };
    this.lastFetchTime = now;

    const fetchedDocs = [];
    for (const [host, src] of [...independent.entries()].slice(0, 3)) {
      const robotsAt = new Date().toISOString();
      const allowed = await this.robotsChecker(src.url, { userAgent: 'SynoraBot/1.0' });
      this.connectionLog.push({ action: 'robots-check', url: src.url, host, allowed: allowed === true, timestamp: robotsAt });
      if (allowed !== true) return { status: 'abstain', reason: 'robots_disallowed_or_unverified', host, connectionLog: this.connectionLog.slice() };
      const resp = await this.fetcher(src.url, { maxBytes: this.maxBytes, timeoutMs: 8000 });
      this.connectionLog.push({ action: 'fetch', url: src.url, host, allowed: Boolean(resp), timestamp: new Date().toISOString() });
      if (!resp || typeof resp.text !== 'string' || !resp.text.trim()) return { status: 'abstain', reason: 'empty_source', host };
      if (Buffer.byteLength(resp.text, 'utf8') > this.maxBytes) return { status: 'abstain', reason: 'source_too_large', host };
      const license = String(resp.license || resp.licence || src.license || '').trim();
      if (!PERMISSIVE_TEXT_LICENSES.has(license)) return { status: 'abstain', reason: 'missing_or_unapproved_license', host, license: license || null };
      fetchedDocs.push({
        url: src.url, host, text: resp.text, license, licenceCaptured: true,
        retrievedAt: new Date(now).toISOString(), isTainted: true,
        taintReason: 'untrusted_external_web_content', status: 'quarantined'
      });
    }
    if (fetchedDocs.length < 2) return { status: 'abstain', reason: 'insufficient_independent_sources' };
    return { status: 'extracted', query, sourcesCount: fetchedDocs.length, documents: fetchedDocs, connectionLog: this.connectionLog.slice(), requiresSymbolicVerification: true };
  }
}
