/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { KnowledgeStore } from './store.mjs';

export function runIngest(filePath, outDir) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Corpus file not found: ${filePath}`);
  }
  const store = new KnowledgeStore({ rootDir: outDir });
  store.ingestCorpusJsonl(filePath);
  console.log(`Ingested ${store.documents.size} documents, extracted ${store.facts.length} facts.`);
  return store;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const file = process.argv[2];
  if (!file) {
    console.error('Usage: node ingest.mjs <corpus.jsonl>');
    process.exit(1);
  }
  runIngest(file);
}
