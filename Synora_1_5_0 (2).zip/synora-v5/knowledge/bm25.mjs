/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Pure non-neural BM25 / TF-IDF Inverted Index with English & Arabic normalization.
 */
import { normalizeArabicText, stemArabicWord } from '../nl2code/arabic-morphology.mjs';

function tokenize(text) {
  if (typeof text !== 'string') return [];
  if (/[\u0600-\u06FF]/.test(text)) {
    const norm = normalizeArabicText(text).replace(/[؟?.,!:;()\-]/g, ' ');
    return norm.split(/\s+/).filter(w => (w.length > 1 || /\d/.test(w))).map(w => stemArabicWord(w));
  }
  return text.toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(w => (w.length > 1 || /\d/.test(w)));
}

export class InvertedIndexBM25 {
  constructor(k1 = 1.5, b = 0.75) {
    this.k1 = k1;
    this.b = b;
    this.docs = new Map(); // id -> { id, terms, length, raw }
    this.inverted = new Map(); // term -> Map(docId -> freq)
    this.totalDocLen = 0;
  }

  addDocument(id, text, metadata = {}) {
    const terms = tokenize(text);
    this.docs.set(id, {
      id,
      terms,
      length: terms.length,
      raw: text,
      metadata
    });
    this.totalDocLen += terms.length;

    const termFreqs = new Map();
    for (const t of terms) {
      termFreqs.set(t, (termFreqs.get(t) || 0) + 1);
    }

    for (const [term, freq] of termFreqs.entries()) {
      if (!this.inverted.has(term)) {
        this.inverted.set(term, new Map());
      }
      this.inverted.get(term).set(id, freq);
    }
  }

  search(query, topK = 5) {
    const qTerms = tokenize(query);
    if (qTerms.length === 0 || this.docs.size === 0) return [];

    const N = this.docs.size;
    const avgdl = this.totalDocLen / N;
    const scores = new Map();

    for (const term of qTerms) {
      const posting = this.inverted.get(term);
      if (!posting) continue;

      const df = posting.size;
      const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5));

      for (const [docId, tf] of posting.entries()) {
        const doc = this.docs.get(docId);
        const denom = tf + this.k1 * (1 - this.b + this.b * (doc.length / avgdl));
        const score = idf * ((tf * (this.k1 + 1)) / (denom || 1));
        scores.set(docId, (scores.get(docId) || 0) + score);
      }
    }

    const ranked = Array.from(scores.entries())
      .map(([id, score]) => ({
        id,
        score,
        doc: this.docs.get(id)
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, topK);

    return ranked;
  }
}
