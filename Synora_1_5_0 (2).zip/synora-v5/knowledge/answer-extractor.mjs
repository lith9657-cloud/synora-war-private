/**
 * @license SPDX-License-Identifier: Apache-2.0
 */
import { normalizeArabicText } from '../nl2code/arabic-morphology.mjs';

/**
 * Typed question detection.
 *
 * The list is ordered from the most specific marker to the least specific one,
 * because several markers can be present in the same question ("In which year was
 * the archive founded by Mira Vale?" carries both a date and a person marker and
 * must be typed as a date question).
 */
export const QUESTION_TYPES = Object.freeze([
  'duration', 'date', 'person', 'organization', 'quantity', 'place', 'attribute', 'height', 'value'
]);

const TYPE_PATTERNS = [
  ['duration', /\bhow\s+long\b|\bhow\s+much\s+time\b|\bwhat\s+is\s+the\s+duration\b|\btime\s+(?:it\s+)?takes?\b|\btime\s+of\b|\btram\s+time\b|\btravel\s+time\b|كم\s+(?:تستغرق|يستغرق|دام|تاخذ)|ما\s+مدة|مدة\s+(?:الرحلة|العمل|المهمة)|وقت\s+(?:الترام|الرحلة|السفر)/i],
  ['date', /\bwhen\b|\b(?:in\s+)?which\s+year\b|\bwhat\s+year\b|\bwhat\s+date\b|\bsince\s+when\b|\bin\s+which\s+century\b|متى|في\s+(?:اي|أي)\s+عام|في\s+(?:اي|أي)\s+سنة|منذ\s+متى/i],
  ['person', /\bwho\b|\bwhom\b|\bwhose\b|\bfounder\b|\bfounded\s+by\b|\bestablished\s+by\b|\bcreated\s+by\b|\binvented\s+by\b|\bdiscovered\s+by\b|\bauthor(?:ed)?\s+by\b|\bdesigned\s+by\b|\bdirected\s+by\b|\bled\s+by\b|\bmanaged\s+by\b|\boperated\s+by\b|\bcommissioned\s+by\b|\bname\s+the\s+founder\b|من\s+(?:اسس|أسس|اسست|أسست|انشا|أنشأ|بنى|اكتشف|اخترع|ادار|يدير)|على\s+يد\s+من|المؤسس|المؤسّس|صاحب|مؤسس/i],
  ['organization', /\bwhich\s+(?:organisation|organization|company|institution|team|agency|bank|university|museum|library)\b|\bwhat\s+(?:organisation|organization|company|institution)\b|أي\s+(?:منظمة|منشأة|شركة|مؤسسة|جامعة|بنك|متحف|مكتبة)/i],
  ['quantity', /\bhow\s+many\b|\bhow\s+much\b|\bnumber\s+of\b|\bpopulation\s+of\b|\bprice\s+of\b|\bhow\s+large\b|\bpopulation\b|كم(?:\s|$)|ما\s+عدد|عدد\s+|سكان|نسمة|عدد\s+السكان/i],
  ['place', /\bwhere\b|\bwhich\s+(?:city|country|town|region|place)\b|\blocated\s+in\b|\bsituated\b|\bcapital\b|\bheadquartered\b|اين|أين|في\s+(?:اي|أي)\s+(?:مكان|مدينة|بلد|منطقة)|عاصمه|عاصمة/i],
  ['attribute', /\b(?:colour|color)\b|لون\s+/i],
  ['height', /\bhow\s+(?:high|tall)\b|\bwhat\s+(?:is|are)\s+the\s+height\b|\bheight\b|\bvertical\s+extent\b|ما(?:\s+هو)?\s+ارتفاع|كم\s+ارتفاع|ارتفاع/i]
];

export function detectQuestionType(question) {
  const q = String(question || '');
  for (const [type, pattern] of TYPE_PATTERNS) if (pattern.test(q)) return type;
  return 'value';
}

/* ------------------------------------------------------------------ helpers */

const AR_FUNCTION_WORDS = new Set(['عام', 'سنة', 'في', 'من', 'الى', 'إلى', 'عند', 'حيث', 'او', 'أو', 'وهو', 'وهي']);

function normalizeForCompare(text) {
  return normalizeArabicText(String(text || '')).replace(/[.,;:!?؟،؛()"'\-–—]/g, ' ').replace(/\s+/g, ' ').trim();
}

/** Significant tokens of the question, used to recognise the ENTITY being asked about. */
function questionTokens(question) {
  const norm = normalizeForCompare(question);
  const tokens = norm.split(' ').filter(t => t.length > 1);
  return new Set(tokens);
}

/**
 * Trim the trailing tokens of a candidate span that also occur in the question.
 * A span that consists only of question tokens is the entity itself and is dropped.
 */
function trimEntityTokens(text, qTokens) {
  const tokens = text.split(/\s+/).filter(Boolean);
  while (tokens.length > 1 && qTokens.has(normalizeForCompare(tokens[tokens.length - 1]))) tokens.pop();
  const kept = tokens.filter(t => !qTokens.has(normalizeForCompare(t)));
  return kept.length ? tokens.join(' ') : null;
}

/* -------------------------------------------------------- span extraction */

/**
 * Agent markers: an explicit "by <PERSON>" construction. When a sentence carries
 * an agent marker the person is the span that FOLLOWS the marker, never the entity
 * that the sentence is about. This is what keeps a passive sentence such as
 * "تأسس أرشيف نيرال-1 على يد ميرا فال عام 1880" from answering with the entity.
 */
const PERSON_NAME = /((?:(?:Dr|Prof|Mr|Mrs|Ms|Eng|PhD|Sir|Lady)\.?\s+)?[A-Z][\p{L}'’-]*(?:\s+[A-Z][\p{L}'’-]*){0,4})/u;

const AGENT_PATTERNS = [
  {
    lang: 'en',
    re: /\b(?:(?:was|were|is|are|been|being)\s+)?(?:founded|established|created|invented|discovered|authored|designed|directed|led|managed|operated|commissioned|built|opened|launched|painted|composed|translated|compiled|presented|chaired|supervised|oversaw|headed|narrated|reviewed|approved|endorsed|signed)\b[^.!?؟]{0,80}?\bby\s+/gi,
    name: PERSON_NAME
  },
  {
    lang: 'ar',
    re: /(?:على\s*يد|بواسطة|بفضل|بواسطة)\s+/gu,
    name: /([\u0621-\u064A\u0660-\u0669]+(?:\s+(?!عام(?:\s|$)|سنة(?:\s|$)|في(?:\s|$)|من(?:\s|$)|إلى(?:\s|$)|عند(?:\s|$)|حيث(?:\s|$))[\u0621-\u064A\u0660-\u0669]+){0,2})/u
  }
];

/**
 * Active voice: "<PERSON> founded ...". The English form is guarded against a
 * passive auxiliary directly in front of the name, the Arabic form against the
 * passive particle that is written as a prefix of the verb.
 */
const ACTIVE_PATTERNS = [
  {
    lang: 'en',
    re: /(?<!\bwas\s)(?<!\bwere\s)(?<!\bis\s)(?<!\bare\s)(?<!\bbeen\s)(?<!\bbeing\s)(?<!\bby\s)\b([A-Z][\p{L}'’-]*(?:\s+[A-Z][\p{L}'’-]*){0,3})\s+(?:founded|established|created|invented|discovered|authored|designed|directed|led|managed|operated|commissioned|built|opened|launched|painted|composed|translated)\b/gu,
    group: 1
  },
  {
    lang: 'ar',
    re: /(?<![\u0621-\u064A])(?:أسس|اسس|أنشأ|انشا|بنى|اكتشف|اخترع|أدار|ودع|رسم|ألف)\s+([\u0621-\u064A\u0660-\u0669]+(?:\s+(?!عام(?:\s|$)|سنة(?:\s|$))[\u0621-\u064A\u0660-\u0669]+){0,2})/gu,
    group: 1
  }
];

const ROLE_PATTERNS = [
  { lang: 'en', re: /\b(?:the\s+)?founder\s+(?:of\s+[^,.;]{1,60}?\s+)?(?:is|was)\s+([A-Z][\p{L}'’-]*(?:\s+[A-Z][\p{L}'’-]*){0,3})/giu },
  { lang: 'ar', re: /المؤسس\s+(?:هو|كان)\s+([\u0621-\u064A\u0660-\u0669]+(?:\s+[\u0621-\u064A\u0660-\u0669]+){0,2})/gu }
];

const DATE_PATTERNS = [
  /\b(?:in|on|during|since)\s+((?:\d{1,2}\s+)?(?:January|February|March|April|May|June|July|August|September|October|November|December)?\s*\d{4}|\d{4})\b/i,
  /\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4})\b/,
  /(?:في\s+عام|عام|سنة|في)\s*(\d{4}|\d{1,2}\s+\S+)/
];

const DURATION_UNITS = 'years?|months?|days?|hours?|minutes?|seconds?|centuries?|أيام|ايام|سنة|سنوات|شهر|شهور|ساعة|ساعات|دقيقة|دقائق|ثانية|قرن';
const QUANTITY_UNITS = 'km|kilometers?|m|meters?|cm|centimeters?|people|inhabitants|units?|items?|people|كم|كيلومتر|مترا|متر|سم|شخص|نسمة|قطعة|عنصر';

const EN_NUMBER_WORDS = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten',
  'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen',
  'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety', 'hundred'];
const AR_NUMBER_WORDS = ['صفر', 'واحد', 'اثنان', 'اثنين', 'ثلاث', 'ثلاثة', 'اربع', 'أربع', 'خمس', 'خمسة', 'ست', 'ستة',
  'سبع', 'سبعة', 'ثمان', 'ثمانية', 'تسع', 'تسعة', 'عشر', 'عشرة', 'عشرون', 'ثلاثون', 'اربعون', 'خمسون', 'مئة', 'مئتان'];

function numericPattern(units) {
  return new RegExp(
    `(?<![\\p{L}\\d])(\\d{1,3}(?:,\\d{3})+(?:\\.\\d+)?|\\d{1,6}(?:\\.\\d+)?\\s*(?:${units})?)(?![\\p{L}\\d])`,
    'iu'
  );
}

function wordNumberPattern(units) {
  return new RegExp(
    `(?<![\\p{L}\\d])((?:${EN_NUMBER_WORDS.join('|')}|${AR_NUMBER_WORDS.join('|')})\\s+(?:${units}))(?![\\p{L}\\d])`,
    'iu'
  );
}

const NUMBER_WITH_UNIT = /(?<![\p{L}\d])((?:\d{1,3}(?:,\d{3})+|\d{1,6})(?:\.\d+)?\s+(?!was\b|were\b|is\b|are\b|has\b|have\b|had\b|and\b|or\b|the\b|a\b|an\b|in\b|on\b|at\b|to\b|of\b|for\b|by\b|with\b|from\b|that\b|this\b)(?!(?:في|من|إلى|الى|على|عند|حيث|او|أو|و|ثم|لكن|لذلك|بعد|قبل|قد|كل|بعض|هذه|هذا|تلك|ذلك)(?:\s|$))[\p{L}]{1,20})/u;

function candidatePatterns(type) {
  switch (type) {
    case 'person': return [];
    case 'date': return DATE_PATTERNS;
    case 'duration': return [numericPattern(DURATION_UNITS), wordNumberPattern(DURATION_UNITS), NUMBER_WITH_UNIT];
    case 'quantity':
    case 'height':
      return [numericPattern(QUANTITY_UNITS), wordNumberPattern(QUANTITY_UNITS), NUMBER_WITH_UNIT];
    case 'attribute':
      return [
        /\b(?:is|was|are|were)\s+(red|blue|green|yellow|black|white|orange|purple|brown|pink|grey|gray)\b/i,
        /(?:لونه|لونها|هو|هي)\s*(احمر|ازرق|اخضر|اصفر|اسود|ابيض|برتقالي|بنفسجي|بني|وردي|رمادي)/u
      ];
    case 'place':
      return [
        /([\u0621-\u064A]+)\s+هي\s+عاصم[هة]/u,
        /\bcapital\s+of\s+[\p{L}\s]+?\s+is\s+([\p{L}][\p{L}'’-]*)/iu,
        /\b(?:in|at|near|located in|based in|headquartered in|situated in)\s+([A-Z][\p{L}'’-]*(?:\s+[A-Z][\p{L}'’-]*){0,4})/u,
        /(?:تقع في|يقع في|يوجد في|موجود في|داخل|تستقر في)\s*([\u0600-\u06FF]+(?:\s+[\u0600-\u06FF]+){0,3})/u
      ];
    case 'organization':
      return [
        /\b(?:run|operated|managed|owned|administered|funded|supported|sponsored|published|organised|organized|governed|oversight|backed)\s+by\s+(?:the\s+)?([A-Z][\p{L}'’-]*(?:\s+[A-Z][\p{L}'’-]*){0,4})/u,
        /(?:يديرها|يدير|تتبع)\s*([\u0600-\u06FF]+(?:\s+[\u0600-\u06FF]+){0,3})/u
      ];
    default:
      return [
        /\b(?:classified as|defined as|known as|called|is|was|are|were|means)\s+([^,;.!?؟]{1,80})/i,
        /(?:هو|هي|تعتبر|يعتبر|تسمى|يسمى|تعرف باسم|يُعرف باسم)\s*([^،؛.!?؟]{1,80})/u,
        /برقم\s*\d+/u,
        /\bchemical element number\s+\d+\b/i
      ];
  }
}

/**
 * Extract the typed span of a sentence that answers the question.
 *
 * Returns `{ text, start, end, type }` with offsets relative to the sentence, or
 * null when the sentence carries no span of the requested type.
 */
export function extractTypedSpan(question, sentence, sentenceOffset = 0) {
  const type = detectQuestionType(question);
  const candidates = [];
  const qTokens = questionTokens(question);

  const push = (text, start, priority, kind) => {
    if (!text) return;
    const value = text.replace(/[.,;:!?؟،؛]+$/u, '').trimEnd();
    if (!value) return;
    const offset = sentenceOffset + start + (text.length - value.length);
    candidates.push({ text: value, start: offset, end: offset + value.length, type, priority, kind });
  };

  if (type === 'person') {
    // 1. explicit agent marker - the person follows the marker
    for (const agent of AGENT_PATTERNS) {
      agent.re.lastIndex = 0;
      let m;
      while ((m = agent.re.exec(sentence))) {
        const nameMatch = agent.name.exec(sentence.slice(m.index + m[0].length));
        if (!nameMatch) continue;
        const base = m.index + m[0].length + nameMatch.index;
        push(nameMatch[1], base, 0, 'agent');
      }
    }
    // 2. active voice - the person precedes the verb
    for (const active of ACTIVE_PATTERNS) {
      active.re.lastIndex = 0;
      let m;
      while ((m = active.re.exec(sentence))) {
        const raw = m[active.group];
        const base = m.index + m[0].indexOf(raw);
        push(raw, base, 1, 'active');
      }
    }
    // 3. role noun - "the founder is ..."
    for (const role of ROLE_PATTERNS) {
      role.re.lastIndex = 0;
      let m;
      while ((m = role.re.exec(sentence))) {
        const raw = m[1];
        const base = m.index + m[0].indexOf(raw);
        push(raw, base, 2, 'role');
      }
    }
  }

  for (const pattern of candidatePatterns(type)) {
    const m = pattern.exec(sentence);
    if (!m) continue;
    if (m[1]) {
      const raw = m[1];
      const lead = raw.search(/\S|$/);
      const value = raw.slice(lead).replace(/[.,;:!?؟،؛]+$/u, '').trimEnd();
      const start = sentenceOffset + m.index + m[0].indexOf(raw) + lead;
      candidates.push({ text: value, start, end: start + value.length, type, priority: 0, kind: 'typed' });
    } else {
      const raw = m[0];
      const lead = raw.search(/\S|$/);
      const value = raw.slice(lead, raw.trimEnd().length);
      const start = sentenceOffset + m.index + lead;
      candidates.push({ text: value, start, end: start + value.length, type, priority: 0, kind: 'typed' });
    }
  }

  let valid = candidates.filter(c => c.text && c.text.length <= 80 && c.end > c.start);
  if (!valid.length) return null;

  if (type === 'person') {
    // The answer must not be the entity the question is about: trailing tokens of
    // the span that repeat the question are removed, and a span that is entirely
    // made of question tokens is dropped.
    valid = valid.map(c => {
      const trimmed = trimEntityTokens(c.text, qTokens);
      if (!trimmed || trimmed === c.text) return c;
      return { ...c, text: trimmed, end: c.start + trimmed.length };
    });
    valid = valid.filter(c => {
      const tokens = c.text.split(/\s+/).filter(Boolean);
      const repeated = tokens.filter(t => qTokens.has(normalizeForCompare(t))).length;
      return !(tokens.length > 0 && repeated === tokens.length);
    });
    if (!valid.length) return null;
  }

  // For typed numeric questions keep the full grouped number and unit; for entity
  // spans prefer the most specific (lowest priority) candidate and, within one
  // priority, the longest complete span.
  if (['quantity', 'duration', 'height', 'date'].includes(type)) {
    valid.sort((a, b) => b.text.length - a.text.length || a.start - b.start);
  } else {
    valid.sort((a, b) => a.priority - b.priority || b.text.length - a.text.length || a.start - b.start);
  }
  return valid[0];
}
