/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'node:fs';
import path from 'node:path';
import { InvertedIndexBM25 } from './bm25.mjs';
import { normalizeArabicText, stemArabicWord } from '../nl2code/arabic-morphology.mjs';
import { detectQuestionType, extractTypedSpan } from './answer-extractor.mjs';

const STOPWORDS = new Set([
  'what', 'was', 'the', 'in', 'on', 'at', 'is', 'a', 'an', 'of', 'how', 'to', 'for', 'by',
  'with', 'about', 'from', 'as', 'that', 'this', 'day', 'number',
  'ما', 'هي', 'هو', 'في', 'من', 'على', 'عن', 'الى', 'الي', 'كان', 'كانت', 'كم', 'اين', 'كيف'
]);

/**
 * Irregular English verb forms. A question that names an action in the past tense
 * ("how long did the survey run") must match the corpus sentence that uses the
 * same action ("the survey ran for eighteen months").
 */
const IRREGULAR_VERB_FORMS = new Map([
  ['ran', 'run'], ['run', 'run'], ['runs', 'run'], ['running', 'run'],
  ['began', 'begin'], ['begun', 'begin'], ['begins', 'begin'],
  ['wrote', 'write'], ['written', 'write'], ['writes', 'write'],
  ['spoke', 'speak'], ['spoken', 'speak'], ['speaks', 'speak'],
  ['took', 'take'], ['taken', 'take'], ['takes', 'take'],
  ['gave', 'give'], ['given', 'give'], ['gives', 'give'],
  ['made', 'make'], ['makes', 'make'],
  ['built', 'build'], ['builds', 'build'],
  ['sent', 'send'], ['sends', 'send'],
  ['found', 'find'], ['finds', 'find'],
  ['kept', 'keep'], ['keeps', 'keep'],
  ['left', 'leave'], ['leaves', 'leave'],
  ['met', 'meet'], ['meets', 'meet'],
  ['paid', 'pay'], ['pays', 'pay'],
  ['said', 'say'], ['says', 'say'],
  ['sold', 'sell'], ['sells', 'sell'],
  ['told', 'tell'], ['tells', 'tell'],
  ['thought', 'think'], ['thinks', 'think'],
  ['understood', 'understand'], ['understands', 'understand'],
  ['broke', 'break'], ['broken', 'break'], ['breaks', 'break'],
  ['chose', 'choose'], ['chosen', 'choose'], ['chooses', 'choose'],
  ['drew', 'draw'], ['drawn', 'draw'], ['draws', 'draw'],
  ['fell', 'fall'], ['fallen', 'fall'], ['falls', 'fall'],
  ['felt', 'feel'], ['feels', 'feel'],
  ['flew', 'fly'], ['flies', 'fly'],
  ['forgot', 'forget'], ['forgets', 'forget'],
  ['grew', 'grow'], ['grown', 'grow'], ['grows', 'grow'],
  ['heard', 'hear'], ['hears', 'hear'],
  ['held', 'hold'], ['holds', 'hold'],
  ['led', 'lead'], ['leads', 'lead'],
  ['lost', 'lose'], ['loses', 'lose'],
  ['rose', 'rise'], ['risen', 'rise'], ['rises', 'rise'],
  ['sought', 'seek'], ['seeks', 'seek'],
  ['sat', 'sit'], ['sits', 'sit'],
  ['slept', 'sleep'], ['sleeps', 'sleep'],
  ['spent', 'spend'], ['spends', 'spend'],
  ['stood', 'stand'], ['stands', 'stand'],
  ['taught', 'teach'], ['teaches', 'teach'],
  ['threw', 'throw'], ['thrown', 'throw'], ['throws', 'throw'],
  ['wore', 'wear'], ['worn', 'wear'], ['wears', 'wear'],
  ['won', 'win'], ['wins', 'win'],
  ['reviewed', 'review'], ['reviews', 'review'],
  ['chaired', 'chair'], ['chairs', 'chair'],
  ['supervised', 'supervise'], ['supervises', 'supervise'],
  ['funded', 'fund'], ['funds', 'fund'],
  ['recruited', 'recruit'], ['recruits', 'recruit'],
  ['opened', 'open'], ['opens', 'open'],
  ['screened', 'screen'], ['screens', 'screen'],
  ['committed', 'commit'], ['commits', 'commit']
]);

/**
 * Minimal English normalisation so that a question term matches the inflected form
 * in the corpus ("take" matches "takes", "volume" matches "volumes", "run" matches
 * "ran").
 */
function normalizeEnglishTerm(word) {
  const irregular = IRREGULAR_VERB_FORMS.get(word);
  if (irregular) return irregular;
  if (word.length > 4 && word.endsWith('ies')) return `${word.slice(0, -3)}y`;
  if (word.length > 4 && /(?:ss|sh|ch|x|z)es$/.test(word)) return word.slice(0, -2);
  if (word.length > 3 && word.endsWith('s') && !/(ss|us|is)$/.test(word)) return word.slice(0, -1);
  return word;
}

const RELATION_SYNONYMS = Object.freeze({
  founded:['established','created','built','set','opened','inaugurated','launched'],
  establish:['founded','created','built','set','opened','inaugurated','launched'],
  established:['founded','created','built','set','opened','inaugurated','launched'],
  founder:['founded','established','created','built'],
  ride:['take','last','journey','duration','travel','tram'],
  tram:['ride','travel','journey'], last:['take','ride','duration'],
  tall:['height','high','metre','meter'], high:['height','tall','metre','meter'],
  height:['tall','high','metre','meter'],
  people:['population','inhabitant','resident'], live:['reside','inhabit','population'],
  inhabitant:['people','population','resident'], population:['people','inhabitant','resident'],
  'تأسست':['أسس','أنشأ','بنى','افتتح'], 'تأسس':['أسس','أنشأ','بنى','افتتح'],
  'أسس':['تأسست','أنشأ','بنى','افتتح'], 'سكان':['نسمة','مقيمين','ساكن'],
  'نسمة':['سكان','مقيمين'], 'ارتفاع':['طول','علو'], 'ترام':['رحلة','تستغرق']
});

function extractSignificantTerms(text) {
  if (typeof text !== 'string') return [];
  if (/[\u0600-\u06FF]/.test(text)) {
    const norm = normalizeArabicText(text).replace(/[؟?.,!:]/g, ' ');
    return norm.split(/\s+/)
      .filter(w => (w.length > 1 || /\d/.test(w)) && !STOPWORDS.has(w))
      .map(w => stemArabicWord(w));
  }
  return text.toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(w => (w.length > 2 || /\d/.test(w)) && !STOPWORDS.has(w))
    .map(normalizeEnglishTerm);
}

function extractFacts(docId, text, sourceMeta = {}) {
  const facts = [];
  const lines = text.split(/(?<=[.?!؟])\s+/).filter(Boolean);

  let factId = 1;
  for (const line of lines) {
    const isMatch = line.match(/^([A-Za-z0-9\s]+?)\s+(?:is|was|are|equals|defined as|is classified as)\s+(?:approximately|roughly|exactly)?\s*(.+)$/i);
    if (isMatch) {
      facts.push({
        id: `fact-${docId}-${factId++}`,
        subject: isMatch[1].trim(),
        predicate: 'is',
        object: isMatch[2].trim().replace(/[.?!]$/, ''),
        text: line.trim(),
        source: {
          id: docId,
          url: sourceMeta.url || '',
          licence: sourceMeta.licence || sourceMeta.license || 'CC-BY-SA-4.0',
          retrievedAt: sourceMeta.retrievedAt || new Date().toISOString()
        },
        confidence: 1.0,
        status: 'verified'
      });
      continue;
    }

    const arMatch = line.match(/^([\u0600-\u06FF0-9\s]+?)\s+(?:هو|هي|تعتبر|يبلغ|تبلغ|تقع)\s+(.+)$/);
    if (arMatch) {
      facts.push({
        id: `fact-${docId}-${factId++}`,
        subject: arMatch[1].trim(),
        predicate: 'هو',
        object: arMatch[2].trim().replace(/[.؟]$/, ''),
        text: line.trim(),
        source: {
          id: docId,
          url: sourceMeta.url || '',
          licence: sourceMeta.licence || sourceMeta.license || 'CC-BY-SA-4.0',
          retrievedAt: sourceMeta.retrievedAt || new Date().toISOString()
        },
        confidence: 1.0,
        status: 'verified'
      });
    }
  }

  return facts;
}


/**
 * Split a text into sentences.
 *
 * A period that belongs to an abbreviation ("Dr. Nadia Haddad"), to a single
 * initial ("J. Smith") or to a decimal number ("3.14") does not end a sentence.
 */
const ABBREVIATION_BEFORE_PERIOD = /(?:\b(?:Dr|Prof|Mr|Mrs|Ms|Eng|St|Rev|Jr|Sr|vs|etc|No|Fig|U)|\b[A-Z])\.$/i;

function splitSentences(text) {
  const out = [];
  let start = 0;
  const push = (raw, offset) => {
    const trimmed = raw.trim();
    if (!trimmed) return;
    const lead = raw.search(/\S|$/);
    out.push({ text: trimmed, offset: offset + lead });
  };
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch !== '.' && ch !== '!' && ch !== '?' && ch !== '؟') continue;
    if (ch === '.') {
      const before = text.slice(Math.max(0, i - 12), i + 1);
      if (ABBREVIATION_BEFORE_PERIOD.test(before)) continue;
      if (i + 1 < text.length && !/\s/.test(text[i + 1])) continue;
    }
    let end = i + 1;
    while (end < text.length && /[.!?؟]/.test(text[end])) end++;
    push(text.slice(start, end), start);
    start = end;
    i = end - 1;
  }
  push(text.slice(start), start);
  return out;
}

export class KnowledgeStore {
  constructor(options = {}) {
    this.rootDir = options.rootDir || null;
    this.index = new InvertedIndexBM25();
    this.documents = new Map();
    this.facts = [];
    this.threshold = (typeof options.threshold === 'number') ? options.threshold : 0.6;
  }

  ingestDocument(doc) {
    if (!doc || !doc.id || !doc.text) return;
    this.documents.set(doc.id, doc);
    this.index.addDocument(doc.id, (doc.title ? doc.title + '. ' : '') + doc.text, { ...doc, sourceText: doc.text });

    const docFacts = extractFacts(doc.id, doc.text, {
      url: doc.url,
      licence: doc.licence || doc.license
    });
    this.facts.push(...docFacts);
  }

  ingestCorpusJsonl(filePath) {
    const content = fs.readFileSync(filePath, 'utf-8');
    const lines = content.split('\n').filter(Boolean);
    for (const l of lines) {
      this.ingestDocument(JSON.parse(l));
    }
  }

  answerQuestion(query) {
    const qTerms = extractSignificantTerms(query);
    if (!qTerms.length) return { status: 'abstain', reason: 'empty_query', sourceIds: [] };

    const searchResults = this.index.search(query, Math.max(8, this.documents.size));
    if (!searchResults.length) return { status: 'abstain', reason: 'insufficient_evidence', sourceIds: [] };
    const qType = detectQuestionType(query);
    const qNormalized = normalizeArabicText(query).toLowerCase();
    const attributeSpec = /\b(?:colour|color)\b|لون/.test(qNormalized) ? 'color'
      : /\bpopulation\b|سكان/.test(qNormalized) ? 'population'
      : /\bmayor\b|عمده/.test(qNormalized) ? 'mayor' : null;
    const attributeEvidence = {
      color: /\b(?:red|blue|green|yellow|black|white|orange|purple|brown|pink|grey|gray|colour|color)\b|احمر|ازرق|اخضر|اصفر|اسود|ابيض|برتقالي|بنفسجي|بني|وردي|رمادي/u,
      population: /\b(?:population|inhabitants|residents|people)\b|سكان|نسمة/u,
      mayor: /\bmayor\b|عمده/u
    };
    const queryAnchors = [...String(query).matchAll(/[\p{L}]*\d+[\p{L}]*/gu)].map(m => normalizeArabicText(m[0]).toLowerCase());
    const ranked = [];
    for (const hit of searchResults) {
      const doc = hit.doc;
      const text = String(doc.metadata.sourceText ?? doc.raw);
      const normalizedDoc = normalizeArabicText(text).toLowerCase();
      if (attributeSpec && !attributeEvidence[attributeSpec].test(normalizedDoc)) continue;
      if (queryAnchors.length && !queryAnchors.every(anchor => normalizedDoc.includes(anchor))) continue;
      for (const { text: sentence, offset } of splitSentences(text)) {
        const terms = new Set(extractSignificantTerms(sentence));
        let hits = 0;
        for (const term of qTerms) {
          if (terms.has(term)) { hits++; continue; }
          const syns = RELATION_SYNONYMS[term];
          if (syns && syns.some(sy => terms.has(sy))) hits++;
        }
        const overlap = hits / Math.max(1, qTerms.length);
        if (overlap < 0.35) continue;
        const span = extractTypedSpan(query, sentence, offset);
        if (!span) continue;
        ranked.push({ ...span, sentence, doc, score: hit.score, overlap, hits: [] });
      }
    }

    if (!ranked.length) return { status: 'abstain', reason: 'no_typed_supported_span', sourceIds: [] };
    ranked.sort((a, b) => (b.score * b.overlap) - (a.score * a.overlap) || a.text.length - b.text.length);
    const best = ranked[0];

    // Entity-aware conflict detection
    const RELATION_VOCAB = new Set();
    for (const [k, vs] of Object.entries(RELATION_SYNONYMS)) { RELATION_VOCAB.add(k); for (const v of vs) RELATION_VOCAB.add(v); }
    for (const w of STOPWORDS) RELATION_VOCAB.add(w);
    const qEntityTokens = qTerms.filter(t => !RELATION_VOCAB.has(t));
    const alternatives = ranked.filter(x => {
      if (x.doc.id === best.doc.id) return false;
      if (x.overlap < Math.max(0.35, best.overlap - 0.15)) return false;
      const altTokens = new Set(extractSignificantTerms(x.sentence));
      return qEntityTokens.every(t => altTokens.has(t));
    });
    const distinct = new Map([[best.text.toLowerCase(), best]]);
    for (const alt of alternatives) distinct.set(alt.text.toLowerCase(), alt);
    if (distinct.size > 1) {
      return {
        status: 'conflict', reason: 'conflicting_supported_spans',
        answers: [...distinct.values()].map(x => ({ object: x.text, sourceId: x.doc.id, span: { sourceId: x.doc.id, start: x.start, end: x.end } })),
        sourceIds: [...new Set([...distinct.values()].map(x => x.doc.id))]
      };
    }

    // Expected type confidence is conservative. Unknown question types need stronger overlap.
    const threshold = qType === 'value' ? 0.65 : 0.45;
    if (best.overlap < threshold || best.text.length > 80) {
      return { status: 'abstain', reason: 'low_typed_span_confidence', score: best.score, sourceIds: [] };
    }

    return {
      status: 'answered', answer: best.text, sourceIds: [best.doc.id], score: best.score,
      span: { sourceId: best.doc.id, start: best.start, end: best.end },
      evidence: { questionType: qType, matchedTerms: best.hits, sentenceLevel: true, overlap: best.overlap },
      licence: best.doc.metadata.licence || best.doc.metadata.license || 'CC-BY-SA-4.0',
      attribution: best.doc.metadata.url || best.doc.id
    };
  }
}
