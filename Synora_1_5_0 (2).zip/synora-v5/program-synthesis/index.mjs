/**
 * Typed-DSL program synthesis (non-neural). Learns a small program from input/output examples by
 * size-ordered bottom-up enumeration with observational-equivalence pruning.
 *
 *  - Programs are ASTs over a fixed, typed primitive vocabulary. The vocabulary is prior knowledge;
 *    the *composition* that solves a task is induced from examples, never looked up.
 *  - Programs are evaluated by an AST interpreter with a step budget. No eval, no filesystem, no network:
 *    a program cannot do anything outside its primitives (capability-free by construction).
 *  - A JavaScript rendering is produced for the user and independently re-checked against the examples
 *    in a restricted vm context (second implementation must agree with the interpreter).
 */
import vm from 'node:vm';

export const DSL_VERSION = 'typed-dsl-v1';
const ERR = Symbol('err');
const MAX_LIST = 1000, MAX_STEPS = 20_000, MAX_NODES = 64, MAX_DEPTH = 14;

const approx = (a, b) => Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(a), Math.abs(b));
export function deepEqual(a, b) {
  if (typeof a === 'number' && typeof b === 'number') return approx(a, b);
  if (Array.isArray(a) && Array.isArray(b)) return a.length === b.length && a.every((v, i) => deepEqual(v, b[i]));
  return a === b;
}

// ---------- lambda pool (unary functions usable by higher-order primitives) ----------
const LAMBDAS = {
  sq: { type: 'fnNN', f: x => x * x, js: 'x => x * x' },
  dbl: { type: 'fnNN', f: x => x * 2, js: 'x => x * 2' },
  inc: { type: 'fnNN', f: x => x + 1, js: 'x => x + 1' },
  dec: { type: 'fnNN', f: x => x - 1, js: 'x => x - 1' },
  absf: { type: 'fnNN', f: x => Math.abs(x), js: 'x => Math.abs(x)' },
  negf: { type: 'fnNN', f: x => -x, js: 'x => -x' },
  even: { type: 'fnNB', f: x => x % 2 === 0, js: 'x => x % 2 === 0' },
  odd: { type: 'fnNB', f: x => Math.abs(x % 2) === 1, js: 'x => Math.abs(x % 2) === 1' },
  pos: { type: 'fnNB', f: x => x > 0, js: 'x => x > 0' },
  neg: { type: 'fnNB', f: x => x < 0, js: 'x => x < 0' },
  zero: { type: 'fnNB', f: x => x === 0, js: 'x => x === 0' },
  divides: { type: 'fnNB', ctx: true, f: (x, c) => x !== 0 && c % x === 0, js: 'x => x !== 0 && c % x === 0' },
  gtctx: { type: 'fnNB', ctx: true, f: (x, c) => x > c, js: 'x => x > c' }
};

// ---------- primitives: a = argument types, r = return type, f = interpreter, js = renderer ----------
const rl = l => (Array.isArray(l) && l.length <= MAX_LIST);
const PRIMS = {
  sum: { a: ['nums'], r: 'num', f: l => l.reduce((s, v) => s + v, 0), js: ([l]) => `${l}.reduce((s, v) => s + v, 0)` },
  max: { a: ['nums'], r: 'num', f: l => (l.length ? Math.max(...l) : ERR), js: ([l]) => `$max(${l})`, helper: 'max' },
  min: { a: ['nums'], r: 'num', f: l => (l.length ? Math.min(...l) : ERR), js: ([l]) => `$min(${l})`, helper: 'min' },
  lenN: { a: ['nums'], r: 'num', f: l => l.length, js: ([l]) => `${l}.length` },
  lenS: { a: ['str'], r: 'num', f: s => s.length, js: ([s]) => `${s}.length` },
  lenW: { a: ['strs'], r: 'num', f: l => l.length, js: ([l]) => `${l}.length` },
  rev: { a: ['nums'], r: 'nums', f: l => [...l].reverse(), js: ([l]) => `[...${l}].reverse()` },
  sortA: { a: ['nums'], r: 'nums', f: l => [...l].sort((x, y) => x - y), js: ([l]) => `[...${l}].sort((x, y) => x - y)` },
  uniq: { a: ['nums'], r: 'nums', f: l => [...new Set(l)], js: ([l]) => `[...new Set(${l})]` },
  flat: { a: ['numss'], r: 'nums', f: l => l.flat(), js: ([l]) => `${l}.flat()` },
  revS: { a: ['str'], r: 'str', f: s => [...s].reverse().join(''), js: ([s]) => `[...${s}].reverse().join('')` },
  words: { a: ['str'], r: 'strs', f: s => s.split(/\s+/).filter(Boolean), js: ([s]) => `${s}.split(/\\s+/).filter(Boolean)` },
  at: { a: ['nums', 'num'], r: 'num', f: (l, k) => { if (!Number.isInteger(k)) return ERR; const i = k < 0 ? l.length + k : k; return i >= 0 && i < l.length ? l[i] : ERR; }, js: ([l, k]) => `$at(${l}, ${k})`, helper: 'at' },
  add: { a: ['num', 'num'], r: 'num', f: (x, y) => x + y, js: ([x, y]) => `(${x} + ${y})` },
  sub: { a: ['num', 'num'], r: 'num', f: (x, y) => x - y, js: ([x, y]) => `(${x} - ${y})` },
  mul: { a: ['num', 'num'], r: 'num', f: (x, y) => x * y, js: ([x, y]) => `(${x} * ${y})` },
  div: { a: ['num', 'num'], r: 'num', f: (x, y) => (y === 0 ? ERR : x / y), js: ([x, y]) => `$div(${x}, ${y})`, helper: 'div' },
  mod: { a: ['num', 'num'], r: 'num', f: (x, y) => (y === 0 ? ERR : x % y), js: ([x, y]) => `$mod(${x}, ${y})`, helper: 'mod' },
  abs: { a: ['num'], r: 'num', f: x => Math.abs(x), js: ([x]) => `Math.abs(${x})` },
  neg: { a: ['num'], r: 'num', f: x => -x, js: ([x]) => `(-${x})` },
  lt: { a: ['num', 'num'], r: 'bool', f: (x, y) => x < y, js: ([x, y]) => `(${x} < ${y})` },
  gt: { a: ['num', 'num'], r: 'bool', f: (x, y) => x > y, js: ([x, y]) => `(${x} > ${y})` },
  eqN: { a: ['num', 'num'], r: 'bool', f: (x, y) => x === y, js: ([x, y]) => `(${x} === ${y})` },
  eqS: { a: ['str', 'str'], r: 'bool', f: (x, y) => x === y, js: ([x, y]) => `(${x} === ${y})` },
  eqL: { a: ['nums', 'nums'], r: 'bool', f: (x, y) => x.length === y.length && x.every((v, i) => v === y[i]), js: ([x, y]) => `$eqL(${x}, ${y})`, helper: 'eqL' },
  and: { a: ['bool', 'bool'], r: 'bool', f: (x, y) => x && y, js: ([x, y]) => `(${x} && ${y})` },
  or: { a: ['bool', 'bool'], r: 'bool', f: (x, y) => x || y, js: ([x, y]) => `(${x} || ${y})` },
  not: { a: ['bool'], r: 'bool', f: x => !x, js: ([x]) => `(!${x})` },
  range1: { a: ['num'], r: 'nums', f: n => (Number.isInteger(n) && n >= 0 && n <= MAX_LIST ? Array.from({ length: n }, (_, i) => i + 1) : ERR), js: ([n]) => `$range1(${n})`, helper: 'range1' },
  mapN: { a: ['nums', 'fnNN'], r: 'nums', f: (l, fn, c) => l.map(x => fn.f(x, c)), js: ([l, fn]) => `${l}.map(${fn})` },
  filterN: { a: ['nums', 'fnNB'], r: 'nums', f: (l, fn, c) => l.filter(x => fn.f(x, c)), js: ([l, fn]) => `${l}.filter(${fn})` },
  allN: { a: ['nums', 'fnNB'], r: 'bool', f: (l, fn, c) => l.every(x => fn.f(x, c)), js: ([l, fn]) => `${l}.every(${fn})` },
  anyN: { a: ['nums', 'fnNB'], r: 'bool', f: (l, fn, c) => l.some(x => fn.f(x, c)), js: ([l, fn]) => `${l}.some(${fn})` }
};
const HELPERS = {
  max: 'const $max = a => { if (!a.length) throw new RangeError("empty list"); return Math.max(...a); };',
  min: 'const $min = a => { if (!a.length) throw new RangeError("empty list"); return Math.min(...a); };',
  at: 'const $at = (a, k) => { const i = k < 0 ? a.length + k : k; if (!Number.isInteger(i) || i < 0 || i >= a.length) throw new RangeError("index out of range"); return a[i]; };',
  div: 'const $div = (x, y) => { if (y === 0) throw new RangeError("division by zero"); return x / y; };',
  mod: 'const $mod = (x, y) => { if (y === 0) throw new RangeError("modulo by zero"); return x % y; };',
  eqL: 'const $eqL = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);',
  range1: 'const $range1 = n => { if (!Number.isInteger(n) || n < 0 || n > 1000) throw new RangeError("n out of range"); return Array.from({ length: n }, (_, i) => i + 1); };'
};
const CONSTS = [0, 1, 2, -1];
const PRIM_NAMES = Object.keys(PRIMS);
const LAMBDA_NAMES = Object.keys(LAMBDAS);

// ---------- types ----------
const isFiniteNum = v => typeof v === 'number' && Number.isFinite(v);
function typeOfValue(v) {
  if (isFiniteNum(v)) return 'num';
  if (typeof v === 'boolean') return 'bool';
  if (typeof v === 'string') return 'str';
  if (Array.isArray(v)) {
    if (v.length === 0) return 'empty-list';
    if (v.every(isFiniteNum)) return 'nums';
    if (v.every(x => typeof x === 'string')) return 'strs';
    if (v.every(x => Array.isArray(x) && x.every(isFiniteNum))) return 'numss';
  }
  return null;
}
function resolveColumn(values) {
  const kinds = new Set(values.map(typeOfValue));
  if (kinds.has(null)) return { ok: false, reason: 'unsupported-value-type' };
  kinds.delete('empty-list');
  if (kinds.size > 1) return { ok: false, reason: 'inconsistent-types' };
  const t = [...kinds][0];
  return { ok: true, type: t ?? 'nums' };
}
export function inferSignature(examples) {
  if (!Array.isArray(examples) || !examples.length) return { ok: false, reason: 'no-examples' };
  const arity = examples[0].input?.length;
  if (!Number.isInteger(arity) || arity < 1 || arity > 3) return { ok: false, reason: 'arity-must-be-1-to-3' };
  if (!examples.every(e => Array.isArray(e.input) && e.input.length === arity)) return { ok: false, reason: 'inconsistent-arity' };
  const args = [];
  for (let i = 0; i < arity; i++) { const c = resolveColumn(examples.map(e => e.input[i])); if (!c.ok) return { ok: false, reason: `argument-${i}-${c.reason}` }; args.push(c.type); }
  const out = resolveColumn(examples.map(e => e.output));
  if (!out.ok) return { ok: false, reason: `output-${out.reason}` };
  return { ok: true, signature: { args, ret: out.type } };
}
function checkValueType(v, t) {
  switch (t) {
    case 'num': return isFiniteNum(v);
    case 'bool': return typeof v === 'boolean';
    case 'str': return typeof v === 'string' && v.length <= 10_000;
    case 'nums': return rl(v) && v.every(isFiniteNum);
    case 'strs': return rl(v) && v.every(x => typeof x === 'string');
    case 'numss': return rl(v) && v.every(x => rl(x) && x.every(isFiniteNum));
    default: return false;
  }
}

// ---------- AST validation + interpreter ----------
export function validateProgram(ast, signature) {
  let nodes = 0;
  const typeOf = (node, depth) => {
    if (!node || typeof node !== 'object' || depth > MAX_DEPTH || ++nodes > MAX_NODES) throw new TypeError('program too large or malformed');
    if (Number.isInteger(node.a)) { if (node.a < 0 || node.a >= signature.args.length) throw new TypeError('argument index out of range'); return signature.args[node.a]; }
    if (Object.hasOwn(node, 'c')) { if (!CONSTS.includes(node.c)) throw new TypeError('constant not in DSL'); return 'num'; }
    if (typeof node.l === 'string') { if (!Object.hasOwn(LAMBDAS, node.l)) throw new TypeError('unknown lambda'); if (LAMBDAS[node.l].ctx && signature.args[0] !== 'num') throw new TypeError('context lambda needs numeric first argument'); return LAMBDAS[node.l].type; }
    if (typeof node.op === 'string' && Object.hasOwn(PRIMS, node.op) && Array.isArray(node.args)) {
      const p = PRIMS[node.op];
      if (node.args.length !== p.a.length) throw new TypeError('wrong arity');
      node.args.forEach((child, i) => { if (typeOf(child, depth + 1) !== p.a[i]) throw new TypeError(`type mismatch in ${node.op}`); });
      return p.r;
    }
    throw new TypeError('unknown node');
  };
  if (!signature || !Array.isArray(signature.args) || signature.args.length < 1 || signature.args.length > 3) throw new TypeError('invalid signature');
  if (typeOf(ast, 0) !== signature.ret) throw new TypeError('program return type differs from signature');
  return true;
}
export function evaluateProgram(ast, signature, args) {
  if (!Array.isArray(args) || args.length !== signature.args.length) return { ok: false, reason: 'wrong-number-of-arguments' };
  for (let i = 0; i < args.length; i++) if (!checkValueType(args[i], signature.args[i])) return { ok: false, reason: `argument-${i}-not-of-type-${signature.args[i]}` };
  const ctx = typeof args[0] === 'number' ? args[0] : undefined;
  let steps = 0;
  const ev = node => {
    if (++steps > MAX_STEPS) throw new RangeError('step budget exceeded');
    if (Number.isInteger(node.a)) return args[node.a];
    if (Object.hasOwn(node, 'c')) return node.c;
    if (node.l) return LAMBDAS[node.l];
    const p = PRIMS[node.op];
    const out = p.f(...node.args.map(ev), ctx);
    if (out === ERR || (typeof out === 'number' && !Number.isFinite(out)) || (Array.isArray(out) && out.length > MAX_LIST)) throw new RangeError(`undefined result in ${node.op}`);
    return out;
  };
  try { return { ok: true, output: ev(ast) }; } catch (e) { return { ok: false, reason: String(e.message) }; }
}
export function programToString(node) {
  if (Number.isInteger(node.a)) return `a${node.a}`;
  if (Object.hasOwn(node, 'c')) return String(node.c);
  if (node.l) return node.l;
  return `${node.op}(${node.args.map(programToString).join(', ')})`;
}

// ---------- JavaScript rendering (second, independent implementation of the semantics) ----------
export function renderJavaScript(ast, signature) {
  const helpers = new Set(); let usesCtx = false;
  const r = node => {
    if (Number.isInteger(node.a)) return `a${node.a}`;
    if (Object.hasOwn(node, 'c')) return node.c < 0 ? `(${node.c})` : String(node.c);
    if (node.l) { if (LAMBDAS[node.l].ctx) usesCtx = true; return LAMBDAS[node.l].js; }
    const p = PRIMS[node.op]; if (p.helper) helpers.add(p.helper);
    return p.js(node.args.map(r));
  };
  const body = r(ast);
  const params = signature.args.map((_, i) => `a${i}`).join(', ');
  const guards = signature.args.map((t, i) => {
    const g = { num: `Number.isFinite(a${i})`, str: `typeof a${i} === "string"`, nums: `Array.isArray(a${i}) && a${i}.every(Number.isFinite)`, strs: `Array.isArray(a${i}) && a${i}.every(x => typeof x === "string")`, numss: `Array.isArray(a${i}) && a${i}.every(x => Array.isArray(x) && x.every(Number.isFinite))`, bool: `typeof a${i} === "boolean"` }[t];
    return `  if (!(${g})) throw new TypeError("argument ${i} must be ${t}");`;
  });
  const lines = [`export function solution(${params}) {`, ...guards, ...[...helpers].map(h => `  ${HELPERS[h]}`), ...(usesCtx ? ['  const c = a0;'] : []), `  return ${body};`, '}'];
  return lines.join('\n');
}
export function verifySourceAgainstExamples(source, examples) {
  const code = source.replace(/^export\s+function\s+solution/, 'function solution') + '\nsolution';
  let fn;
  try { fn = new vm.Script(code, { filename: 'synora-learned-program.js' }).runInContext(vm.createContext(Object.create(null), { codeGeneration: { strings: false, wasm: false } }), { timeout: 100 }); }
  catch (e) { return { passed: 0, total: examples.length, failures: [{ reason: 'does-not-compile' }] }; }
  let passed = 0; const failures = [];
  for (const [i, ex] of examples.entries()) {
    try {
      const out = vm.runInNewContext('fn(...args)', { fn, args: structuredClone(ex.input) }, { timeout: 200 });
      if (deepEqual(out, ex.output)) passed++; else failures.push({ index: i, reason: 'wrong-output' });
    } catch { failures.push({ index: i, reason: 'threw' }); }
  }
  return { passed, total: examples.length, failures };
}

// ---------- synthesis ----------
export function synthesize({ training, maxSize = 9, maxExpressions = 400_000, maxEvaluations = 4_000_000 } = {}) {
  const sg = inferSignature(training);
  if (!sg.ok) return { ok: false, reason: sg.reason, explored: { expressions: 0, evaluations: 0 } };
  const { signature } = sg, n = training.length;
  for (const ex of training) {
    if (!signature.args.every((t, i) => checkValueType(ex.input[i], t)) || !checkValueType(ex.output, signature.ret)) return { ok: false, reason: 'example-values-invalid', explored: { expressions: 0, evaluations: 0 } };
  }
  const ctxs = training.map(e => (typeof e.input[0] === 'number' ? e.input[0] : undefined));
  const expected = training.map(e => e.output);
  const hasCtx = signature.args[0] === 'num';
  const bank = new Map(), seen = new Map();
  const bucket = (type, size) => { if (!bank.has(type)) bank.set(type, []); const b = bank.get(type); while (b.length <= size) b.push([]); return b[size]; };
  const sigKey = (type, vals) => `${type}|${JSON.stringify(vals.map(v => (typeof v === 'number' ? Math.round(v * 1e9) / 1e9 : v)))}`;
  let expressions = 0, evaluations = 0;
  const explored = () => ({ expressions, evaluations });
  const isTarget = e => e.type === signature.ret && e.vals.every((v, j) => deepEqual(v, expected[j]));
  const add = (type, size, vals, ast) => {
    const key = sigKey(type, vals);
    if (seen.has(key)) return null;
    seen.set(key, true);
    const e = { type, size, vals, ast }; bucket(type, size).push(e); expressions++;
    return e;
  };
  // size 1: arguments, constants, lambdas
  for (let i = 0; i < signature.args.length; i++) { const e = add(signature.args[i], 1, training.map(t => t.input[i]), { a: i }); if (e && isTarget(e)) return done(e); }
  for (const c of CONSTS) { const e = add('num', 1, Array(n).fill(c), { c }); if (e && isTarget(e)) return done(e); }
  for (const name of LAMBDA_NAMES) { const L = LAMBDAS[name]; if (L.ctx && !hasCtx) continue; bucket(L.type, 1).push({ type: L.type, size: 1, vals: Array(n).fill(L), ast: { l: name } }); }
  function done(e) {
    const ast = JSON.parse(JSON.stringify(e.ast));
    return { ok: true, ast, signature, size: e.size, expression: programToString(ast), explored: explored() };
  }
  for (let size = 2; size <= maxSize; size++) {
    for (const name of PRIM_NAMES) {
      const p = PRIMS[name], k = p.a.length;
      const chosen = [];
      const rec = (i, remaining) => {
        if (i === k) {
          if (remaining !== 0) return null;
          if (++evaluations > maxEvaluations || expressions > maxExpressions) return 'budget';
          const vals = [];
          for (let j = 0; j < n; j++) {
            const out = p.f(...chosen.map(c => c.vals[j]), ctxs[j]);
            if (out === ERR || (typeof out === 'number' && !Number.isFinite(out)) || (Array.isArray(out) && out.length > MAX_LIST)) return null;
            vals.push(out);
          }
          const e = add(p.r, size, vals, { op: name, args: chosen.map(c => c.ast) });
          if (e && isTarget(e)) return e;
          return null;
        }
        const minRest = k - i - 1;
        for (let s = 1; s <= remaining - minRest; s++) {
          const list = bank.get(p.a[i])?.[s];
          if (!list) continue;
          for (const cand of list) {
            chosen[i] = cand;
            const res = rec(i + 1, remaining - s);
            if (res) return res;
          }
        }
        return null;
      };
      const res = rec(0, size - 1);
      if (res === 'budget') return { ok: false, reason: 'search-budget-exhausted', explored: explored() };
      if (res) return done(res);
    }
  }
  return { ok: false, reason: 'no-program-within-size-bound', maxSize, explored: explored() };
}

/** Learn from examples, then validate on examples never used for induction. */
export function learnFromExamples({ training, development, maxSize, maxExpressions, maxEvaluations }) {
  const found = synthesize({ training, maxSize, maxExpressions, maxEvaluations });
  if (!found.ok) return { accepted: false, reason: found.reason, explored: found.explored };
  validateProgram(found.ast, found.signature);
  const all = [...training, ...development];
  for (const ex of development) if (!found.signature.args.every((t, i) => checkValueType(ex.input[i], t)) || !checkValueType(ex.output, found.signature.ret)) return { accepted: false, reason: 'development-values-do-not-match-signature', explored: found.explored };
  const devPassed = development.filter(ex => { const r = evaluateProgram(found.ast, found.signature, ex.input); return r.ok && deepEqual(r.output, ex.output); }).length;
  if (devPassed !== development.length) return { accepted: false, reason: 'development-validation-failed', developmentPassed: devPassed, developmentCount: development.length, program: found.expression, explored: found.explored };
  const source = renderJavaScript(found.ast, found.signature);
  const check = verifySourceAgainstExamples(source, all);
  if (check.passed !== check.total) return { accepted: false, reason: 'rendered-source-disagrees-with-interpreter', explored: found.explored, check };
  return { accepted: true, ast: found.ast, signature: found.signature, size: found.size, expression: found.expression, source, developmentPassed: devPassed, developmentCount: development.length, renderedCheck: { passed: check.passed, total: check.total }, explored: found.explored };
}
export const dslInfo = Object.freeze({ version: DSL_VERSION, primitives: PRIM_NAMES, lambdas: LAMBDA_NAMES, constants: CONSTS });
