/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export class TaintedValue {
  constructor(value, origin = 'external') {
    this.value = value;
    this.origin = origin;
    this.isTainted = true;
  }

  static wrap(val, origin) {
    if (val instanceof TaintedValue) return val;
    return new TaintedValue(val, origin);
  }

  static unwrap(val) {
    if (val instanceof TaintedValue) return val.value;
    return val;
  }

  static isTainted(val) {
    return val instanceof TaintedValue || (val && typeof val === 'object' && val.isTainted === true);
  }
}
