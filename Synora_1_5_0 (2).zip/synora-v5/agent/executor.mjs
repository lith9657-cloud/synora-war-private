/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SafeToolRegistry } from './registry.mjs';
import { runInWorkerSandbox } from '../security/sandbox.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { TaintedValue } from './taint.mjs';
import crypto from 'node:crypto';
import { normalizeArabicText } from '../nl2code/arabic-morphology.mjs';

function fsExists(root, rel) { try { return fs.existsSync(path.resolve(root, rel)); } catch { return false; } }

export function snapshotOutsideWorkspace(workspaceRoot, options = {}) {
  const root = path.resolve(workspaceRoot);
  const parent = path.dirname(root);
  const maxEntries = options.maxEntries ?? 512;
  const maxDepth = options.maxDepth ?? 2;
  const snapshot = {};
  let count = 0;
  const walk = (target, rel, depth) => {
    if (count >= maxEntries) return;
    let stat;
    try { stat = fs.lstatSync(target); } catch { return; }
    count++;
    if (stat.isSymbolicLink()) {
      let link = ''; try { link = fs.readlinkSync(target); } catch {}
      snapshot[rel] = `symlink:${link}`;
    } else if (stat.isFile()) {
      let digest = `size:${stat.size}`;
      if (stat.size <= 2 * 1024 * 1024) {
        try { digest = crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex'); } catch {}
      }
      snapshot[rel] = `file:${stat.size}:${digest}`;
    } else if (stat.isDirectory()) {
      snapshot[rel] = 'dir';
      if (depth < maxDepth) {
        let entries = []; try { entries = fs.readdirSync(target).sort(); } catch {}
        for (const name of entries) walk(path.join(target, name), `${rel}/${name}`, depth + 1);
      }
    }
  };
  let siblings = []; try { siblings = fs.readdirSync(parent).sort(); } catch {}
  for (const name of siblings) {
    const candidate = path.resolve(parent, name);
    if (candidate === root) continue;
    walk(candidate, name, 0);
  }
  return { entries: snapshot, count, truncated: count >= maxEntries };
}

function changedSnapshotKeys(before, after) {
  const a = before?.entries || {}, b = after?.entries || {};
  return [...new Set([...Object.keys(a), ...Object.keys(b)])].filter(k => a[k] !== b[k]).sort();
}

export class AgentExecutor {
  constructor(options = {}) {
    this.workspaceRoot = options.workspaceRoot || process.cwd();
    this.tools = new SafeToolRegistry(this.workspaceRoot);
  }

  planScenario(scenario = {}) {
    let steps = Array.isArray(scenario.steps) ? scenario.steps : null;
    if (!steps && Array.isArray(scenario.instructions)) {
      steps = scenario.instructions.map(instruction => this.planInstruction(instruction));
    } else if (!steps && typeof scenario.instruction === 'string') {
      steps = [this.planInstruction(scenario.instruction)];
    }
    if (!steps) throw new TypeError('scenario requires steps, instructions, or instruction');
    const allowed = new Set(['fs.write', 'fs.read', 'fs.delete', 'fs.list', 'fs.copy', 'fs.move', 'fs.search', 'test.run', 'git.status', 'git.diff', 'git.commit', 'shell.run']);
    const plan = steps.map((step, index) => {
      if (!step || !allowed.has(step.action)) throw new Error(`Planning rejected unsupported action at step ${index}: ${String(step?.action)}`);
      if (['fs.write','fs.read','fs.delete','fs.list'].includes(step.action) && typeof step.path !== 'string') throw new Error(`Planning rejected missing path at step ${index}`);
      if (step.action === 'fs.write' && typeof step.content !== 'string') throw new Error(`Planning rejected non-text content at step ${index}`);
      if (step.action === 'shell.run' && step.cmd !== 'echo') throw new Error(`Planning rejected shell command at step ${index}`);
      if (['fs.copy','fs.move'].includes(step.action) && (typeof step.from !== 'string' || typeof step.to !== 'string')) throw new Error(`Planning rejected missing copy/move paths at step ${index}`);
      if (step.action === 'fs.search' && (typeof step.path !== 'string' || typeof step.query !== 'string')) throw new Error(`Planning rejected malformed search at step ${index}`);
      if (step.action === 'git.commit' && typeof step.message !== 'string') throw new Error(`Planning rejected missing commit message at step ${index}`);
      return { index, action: step.action, target: step.path ?? step.cmd, requiresConfirmation: ['fs.delete','fs.move','git.commit'].includes(step.action) || (step.action === 'fs.write' && Boolean(step.path && fsExists(this.workspaceRoot, step.path))) };
    });
    return { steps, plan };
  }

  planInstruction(instruction) {
    if (typeof instruction !== 'string' || !instruction.trim()) throw new TypeError('instruction must be non-empty text');
    const text = instruction.trim();
    const arabic = normalizeArabicText(text);
    let match = arabic.match(/^اكتب ملف\s+(\S+)\s+بالمحتوي\s+([\s\S]+)$/);
    if (match) return { action: 'fs.write', path: match[1], content: match[2] };
    match = arabic.match(/^اقرا(?: ملف| الملف)\s+(\S+)$/);
    if (match) return { action: 'fs.read', path: match[1] };
    match = arabic.match(/^احذف ملف\s+(\S+)(?:\s+مع تاكيد\s+([A-Z0-9_-]+))?$/);
    if (match) return { action: 'fs.delete', path: match[1], confirmToken: match[2] };
    match = arabic.match(/^اعرض محتويات المجلد\s+(\S+)$/);
    if (match) return { action: 'fs.list', path: match[1] };
    match = arabic.match(/^انسخ ملف\s+(\S+)\s+الي\s+(\S+)$/);
    if (match) return { action: 'fs.copy', from: match[1], to: match[2] };
    match = arabic.match(/^انقل ملف\s+(\S+)\s+الي\s+(\S+)(?:\s+مع تاكيد\s+([A-Z0-9_-]+))?$/);
    if (match) return { action: 'fs.move', from: match[1], to: match[2], confirmToken: match[3] };
    match = arabic.match(/^ابحث عن\s+(.+?)\s+في ملف\s+(\S+)$/);
    if (match) return { action: 'fs.search', query: match[1], path: match[2] };
    if (/^(?:شغل|نفذ) الاختبارات$/.test(arabic)) return { action: 'test.run' };
    if (/^اعرض حاله git$/.test(arabic)) return { action: 'git.status' };
    if (/^اعرض فروقات git$/.test(arabic)) return { action: 'git.diff' };
    match = arabic.match(/^git commit برساله ([\s\S]+?)(?:\s+مع تاكيد\s+([A-Z0-9_-]+))?$/);
    if (match) return { action: 'git.commit', message: match[1], confirmToken: match[2] };

    match = text.match(/^write file\s+([^\s]+)\s+with content\s+([\s\S]+)$/i);
    if (match) return { action: 'fs.write', path: match[1], content: match[2] };
    match = text.match(/^read file\s+([^\s]+)$/i);
    if (match) return { action: 'fs.read', path: match[1] };
    match = text.match(/^delete file\s+([^\s]+)(?:\s+with confirmation\s+([A-Z0-9_-]+))?$/i);
    if (match) return { action: 'fs.delete', path: match[1], confirmToken: match[2] };
    match = text.match(/^list directory\s+([^\s]+)$/i);
    if (match) return { action: 'fs.list', path: match[1] };
    match = text.match(/^copy file\s+([^\s]+)\s+to\s+([^\s]+)$/i);
    if (match) return { action: 'fs.copy', from: match[1], to: match[2] };
    match = text.match(/^move file\s+([^\s]+)\s+to\s+([^\s]+)(?:\s+with confirmation\s+([A-Z0-9_-]+))?$/i);
    if (match) return { action: 'fs.move', from: match[1], to: match[2], confirmToken: match[3] };
    match = text.match(/^search text\s+(.+?)\s+in file\s+([^\s]+)$/i);
    if (match) return { action: 'fs.search', query: match[1], path: match[2] };
    if (/^run tests$/i.test(text)) return { action: 'test.run' };
    if (/^git status$/i.test(text)) return { action: 'git.status' };
    if (/^git diff$/i.test(text)) return { action: 'git.diff' };
    match = text.match(/^git commit message\s+([\s\S]+?)(?:\s+with confirmation\s+([A-Z0-9_-]+))?$/i);
    if (match) return { action: 'git.commit', message: match[1], confirmToken: match[2] };
    throw new Error('Instruction planner abstained: unsupported or unconsumed words');
  }

  async runScenario(scenario) {
    const { steps, plan } = this.planScenario(scenario);
    const outsideBefore = snapshotOutsideWorkspace(this.workspaceRoot);
    let escapedJail = null;
    let rejectedEscapeAttempt = false;
    let unconfirmedDestructive = false;
    let success = true;
    let stdout = '';

    for (const step of steps) {
      try {
        switch (step.action) {
          case 'fs.write': {
            const res = this.tools.writeFile(step.path, step.content, {
              dryRun: step.dryRun,
              confirmToken: step.confirmToken
            });
            if (res.status === 'unconfirmed' && !step.expectBlocked) {
              unconfirmedDestructive = true;
            }
            break;
          }

          case 'fs.read': {
            const content = this.tools.readFile(step.path);
            if (step.expect && !content.value.includes(step.expect)) {
              success = false;
            }
            break;
          }

          case 'fs.delete': {
            const res = this.tools.deleteFile(step.path, {
              dryRun: step.dryRun,
              confirmToken: step.confirmToken
            });
            if ((res.status === 'dry_run_recorded' && !step.dryRun) || (res.status === 'deleted' && !step.confirmToken)) {
              unconfirmedDestructive = true;
              success = false;
            }
            break;
          }

          case 'fs.list': {
            this.tools.list(step.path || '.');
            break;
          }

          case 'fs.copy': {
            const content = this.tools.readFile(step.from);
            const written = this.tools.writeFile(step.to, content, { confirmToken: step.confirmToken });
            if (written.status !== 'written') success = false;
            break;
          }

          case 'fs.move': {
            if (!step.confirmToken) { unconfirmedDestructive = true; success = false; break; }
            const content = this.tools.readFile(step.from);
            const written = this.tools.writeFile(step.to, content, { confirmToken: step.confirmToken });
            if (written.status !== 'written') { success = false; break; }
            const removed = this.tools.deleteFile(step.from, { confirmToken: step.confirmToken });
            if (removed.status !== 'deleted') success = false;
            break;
          }

          case 'fs.search': {
            const content = TaintedValue.unwrap(this.tools.readFile(step.path));
            const found = String(content).includes(step.query);
            stdout += found ? `FOUND ${step.query} in ${step.path}\n` : `NOT FOUND ${step.query} in ${step.path}\n`;
            if (step.expectFound !== undefined && found !== Boolean(step.expectFound)) success = false;
            break;
          }

          case 'test.run': {
            const run = spawnSync('npm', ['test'], { cwd: this.workspaceRoot, shell: false, encoding: 'utf8', timeout: 120000, maxBuffer: 8 * 1024 * 1024, env: { PATH: process.env.PATH || '', NODE_ENV: 'test' } });
            stdout += run.stdout || '';
            if (run.error || run.status !== 0) success = false;
            this.tools.logAction('test.run', { exitCode: run.status, error: run.error?.message || null });
            break;
          }

          case 'git.status':
          case 'git.diff': {
            const args = step.action === 'git.status' ? ['status', '--short'] : ['diff', '--no-ext-diff', '--'];
            const run = spawnSync('git', args, { cwd: this.workspaceRoot, shell: false, encoding: 'utf8', timeout: 10000, maxBuffer: 4 * 1024 * 1024, env: { PATH: process.env.PATH || '', GIT_CONFIG_NOSYSTEM: '1', GIT_TERMINAL_PROMPT: '0' } });
            stdout += run.stdout || '';
            if (run.error || run.status !== 0) success = false;
            this.tools.logAction(step.action, { exitCode: run.status });
            break;
          }

          case 'git.commit': {
            if (!step.confirmToken) { unconfirmedDestructive = true; success = false; break; }
            const env = { PATH: process.env.PATH || '', GIT_CONFIG_NOSYSTEM: '1', GIT_TERMINAL_PROMPT: '0' };
            const add = spawnSync('git', ['-c', 'core.hooksPath=/dev/null', 'add', '-A'], { cwd: this.workspaceRoot, shell: false, encoding: 'utf8', timeout: 10000, env });
            const commit = add.status === 0 ? spawnSync('git', ['-c', 'core.hooksPath=/dev/null', 'commit', '-m', step.message], { cwd: this.workspaceRoot, shell: false, encoding: 'utf8', timeout: 15000, env }) : add;
            stdout += commit.stdout || '';
            if (commit.error || commit.status !== 0) success = false;
            this.tools.logAction('git.commit', { exitCode: commit.status, confirmed: true });
            break;
          }

          case 'shell.run': {
            const run = await this.tools.runShell(step.cmd, step.args || []);
            stdout += TaintedValue.unwrap(run.stdout);
            if (run.exitCode !== 0) success = false;
            break;
          }

          default:
            success = false;
            throw new Error(`Unknown or unsupported action: ${String(step.action)}`);
        }
      } catch (err) {
        if (!step.expectError) {
          success = false;
        }
        if (err.message && /traversal|symlink escape|outside workspace/i.test(err.message)) {
          rejectedEscapeAttempt = true;
        }
      }
    }

    const outsideAfter = snapshotOutsideWorkspace(this.workspaceRoot);
    const outsideChanges = changedSnapshotKeys(outsideBefore, outsideAfter);
    escapedJail = this.tools.detectWorkspaceEscape() || outsideChanges.length > 0;
    return {
      success,
      plan,
      escapedJail,
      outsideSnapshot: { beforeEntries: outsideBefore.count, afterEntries: outsideAfter.count, changed: outsideChanges },
      rejectedEscapeAttempt,
      unconfirmedDestructive,
      audit: this.tools.auditLedger,
      stdout
    };
  }

  async runCodingLoop(taskSpec, userTests) {
    // 1. Synthesize candidate from task examples
    const { synthesize } = await import('../synthesis/synthesize.mjs');
    const synthRes = synthesize({
      training: taskSpec.training,
      development: taskSpec.development
    });

    if (!synthRes.found) {
      return { success: false, reason: synthRes.reason };
    }

    // 2. Run user's independent tests in sandbox (§9)
    const passedTests = [];
    let allPassed = true;

    for (const t of userTests) {
      const code = `
        ${synthRes.source.replace(/^export\s+function\s+solution/, 'function solution')}
        return solution(...args);
      `;
      const sandRes = await runInWorkerSandbox(code, t.input, { timeoutMs: 1000 });
      if (sandRes.status === 'ok' && JSON.stringify(sandRes.result) === JSON.stringify(t.output)) {
        passedTests.push(t);
      } else {
        allPassed = false;
      }
    }

    return {
      success: allPassed,
      source: synthRes.source,
      passedTestsCount: passedTests.length,
      totalTestsCount: userTests.length,
      audit: this.tools.auditLedger,
      stdout
    };
  }
}
