/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synora Agent Planner — deterministic task planning.
 *
 * Takes a natural language task and breaks it into a deterministic sequence
 * of steps. Each step has: operation, input type, expected output type.
 * The same task always produces the same plan (deterministic, auditable).
 *
 * This is NOT a neural planner — it uses symbolic pattern matching on the
 * task description to identify the required operations.
 */
import { parseNLToCode } from '../nl2code/grammar.mjs';
import { detectQuestionType } from '../knowledge/answer-extractor.mjs';

/**
 * Plan a task into deterministic steps.
 *
 * @param {string} task — natural language task description
 * @param {object} [opts] — { lang?: 'en'|'ar', examples?: [] }
 * @returns {{ steps: Step[], deterministic: true }}
 *
 * @typedef {object} Step
 * @property {string} id — step identifier
 * @property {string} operation — what to do (e.g. 'synthesize', 'query', 'compute')
 * @property {string} description — human-readable description
 * @property {object} params — parameters for the step
 */
export function planTask(task, opts = {}) {
  const lang = opts.lang || (/[\u0600-\u06FF]/.test(task) ? 'ar' : 'en');
  const steps = [];

  // Step 1: Parse the task to identify the operation
  const nlResult = parseNLToCode(task, { lang });
  const qType = detectQuestionType(task);

  if (nlResult.status === 'ok' && nlResult.ast) {
    // Programming task — single synthesis step (verification happens in the brain)
    steps.push({
      id: 'step-1',
      operation: 'synthesize',
      description: lang === 'ar' ? `تركيب برنامج: ${task}` : `Synthesize program: ${task}`,
      params: {
        ast: nlResult.ast,
        source: nlResult.source,
        taskType: 'programming'
      }
    });
  } else if (qType !== 'value' && qType !== 'attribute') {
    // Knowledge query — single QA step
    steps.push({
      id: 'step-1',
      operation: 'query',
      description: lang === 'ar' ? `البحث عن إجابة: ${task}` : `Answer question: ${task}`,
      params: {
        question: task,
        questionType: qType,
        taskType: 'knowledge'
      }
    });
  } else {
    // Unsupported task — abstain honestly
    steps.push({
      id: 'step-1',
      operation: 'abstain',
      description: lang === 'ar' ? `نوع المهمة غير مدعوم: ${task}` : `Unsupported task type: ${task}`,
      params: {
        reason: nlResult.reason || 'unknown_task_type',
        taskType: 'unsupported'
      }
    });
  }

  return { steps, deterministic: true, lang, taskType: steps[0]?.params?.taskType || 'unknown' };
}
