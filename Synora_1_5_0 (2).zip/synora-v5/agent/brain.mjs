/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synora Agent Brain — the orchestrator for the Agent SDK.
 *
 * Flow:
 *   1. planTask(task) → deterministic steps
 *   2. For each step:
 *      a. synthesize → generate + execute code
 *      b. query → answer from knowledge store
 *      c. abstain → honest refusal
 *   3. verifyStep → check result
 *   4. Report with provenance
 *
 * The brain NEVER hallucinates:
 * - If synthesis fails → reports "could not solve"
 * - If verification fails → reports "solution failed verification"
 * - If knowledge is missing → apologizes + offers to search
 *
 * Usage:
 *   import { AgentBrain } from './brain.mjs';
 *   const brain = new AgentBrain({ store, synthesizer });
 *   const result = await brain.execute('sum of [1,2,3,4]', { testCases: [...] });
 */
import { planTask } from './planner.mjs';
import { verifyStep } from './verifier.mjs';
import { synthesize } from '../synthesis/synthesize.mjs';
import { evalAst } from '../synthesis/dsl.mjs';
import { executeAST } from '../nl2code/sanity-checks.mjs';
import { FailureMemory } from '../synthesis/failure-memory.mjs';
import { isIdentityQuestion, generateIdentityResponse } from '../identity.mjs';

export class AgentBrain {
  /**
   * @param {object} opts
   * @param {object} [opts.store] — KnowledgeStore instance
   * @param {object} [opts.failureMemory] — FailureMemory instance
   * @param {object} [opts.synthesizerOptions] — default synthesis options
   */
  constructor(opts = {}) {
    this.store = opts.store || null;
    this.failureMemory = opts.failureMemory || new FailureMemory();
    this.synthOptions = opts.synthesizerOptions || {
      maxSize: 8,
      maxExpressions: 400000,
      deterministicBudget: true,
      safetyTimeoutMs: 30000
    };
  }

  /**
   * Execute a task. This is the main entry point.
   *
   * @param {string} task — natural language task
   * @param {object} [context] — { training?, development?, testCases?, lang? }
   * @returns {Promise<AgentResult>}
   *
   * @typedef {object} AgentResult
   * @property {boolean} success — did the task complete?
   * @property {string} status — 'solved' | 'verified' | 'not_found' | 'abstained' | 'error'
   * @property {any} [output] — the result value (if solved)
   * @property {string} [source] — provenance (code or knowledge source)
   * @property {object} [plan] — the steps that were planned
   * @property {object[]} [stepResults] — results per step
   * @property {string} [reason] — failure reason (if not success)
   * @property {string} [message] — natural language response
   */
  async execute(task, context = {}) {
    // Identity check — answer identity questions directly
    if (isIdentityQuestion(task)) {
      const lang = /[؀-ۿ]/.test(task) ? 'ar' : 'en';
      return { success: true, status: 'solved', output: generateIdentityResponse(task), message: generateIdentityResponse(task), plan: { steps: [{ id: 'identity', operation: 'respond' }], deterministic: true, lang, taskType: 'identity' }, stepResults: [], timestamp: new Date().toISOString(), agentVersion: 'synora-agent/1.5' };
    }
    const lang = context.lang || (/[\u0600-\u06FF]/.test(task) ? 'ar' : 'en');

    // Step 1: Plan
    const plan = planTask(task, { lang });
    const stepResults = [];

    // Step 2: Execute each step
    for (const step of plan.steps) {
      const stepResult = await this._executeStep(step, context);
      stepResults.push({ ...stepResult, stepId: step.id });

      // Step 3: Verify
      const verification = verifyStep(step, stepResult, context);
      stepResults[stepResults.length - 1].verification = verification;

      if (!verification.verified && step.operation !== 'abstain') {
        // Verification failed — record failure and stop
        this.failureMemory.record({
          training: context.training || [],
          development: context.development || [],
          result: { reason: `verification_failed: ${verification.reason}` },
          operation: step.params?.taskType
        });
        return this._finish(false, 'not_found', {
          plan,
          stepResults,
          reason: verification.reason,
          message: lang === 'ar'
            ? `تعذّر التحقق من النتيجة: ${verification.reason}`
            : `Verification failed: ${verification.reason}`
        });
      }
    }

    // All steps passed — check if any step actually produced a result
    const lastResult = stepResults[stepResults.length - 1];
    const allAnswered = stepResults.every(sr => sr.answered || sr.stepId === undefined);
    const success = allAnswered && plan.steps[0]?.operation !== 'abstain' && lastResult?.answered !== false;
    const status = success ? 'solved' : 'abstained';
    const output = lastResult?.output || lastResult?.answer;
    const source = lastResult?.source || lastResult?.span?.sourceId;

    let message = '';
    if (success) {
      const answerStr = typeof output === 'object' ? JSON.stringify(output) : String(output);
      message = lang === 'ar'
        ? `الإجابة: ${answerStr}`
        : `The answer is: ${answerStr}`;
    } else {
      message = lang === 'ar'
        ? 'أعتذر، لم أتمكن من حل هذه المهمة. هل تريد أن أبحث عنها؟'
        : 'I apologize, I could not solve this task. Would you like me to search for it?';
    }

    return this._finish(success, status, {
      output,
      source,
      plan,
      stepResults,
      message
    });
  }

  async _executeStep(step, context) {
    switch (step.operation) {
      case 'synthesize':
        return this._executeSynthesize(step, context);
      case 'query':
        return this._executeQuery(step, context);
      case 'abstain':
        return { answered: false, reason: step.params.reason };
      default:
        return { answered: false, reason: 'unknown_operation' };
    }
  }

  _executeSynthesize(step, context) {
    // If we have training examples, use the synthesizer
    if (context.training?.length >= 3) {
      const result = synthesize({
        training: context.training,
        development: context.development || [],
        ...this.synthOptions
      });

      if (result.found && result.ast) {
        // Execute on the provided input (or a default sample)
        const input = context.input || (context.testCases?.[0]?.input);
        let output = null;
        if (input) {
          try { output = evalAst(result.ast, input); } catch (_) {}
        }
        return {
          answered: true,
          ast: result.ast,
          source: result.source,
          output,
          explored: result.explored
        };
      }
      // Record failure
      this.failureMemory.record({
        training: context.training,
        development: context.development || [],
        result,
        operation: 'synthesize'
      });
      return { answered: false, reason: result.reason || 'synthesis_failed' };
    }

    // No training examples — use the NL parser's AST directly
    if (step.params?.ast) {
      const input = context.input || (context.testCases?.[0]?.input) || [[9,8,7,6,5,4,3,2,1]];
      let output = null;
      try { output = executeAST(step.params.ast, input); } catch (_) {}
      return {
        answered: true,
        ast: step.params.ast,
        source: step.params.source,
        output
      };
    }

    return { answered: false, reason: 'no_ast_and_no_training' };
  }

  _executeQuery(step, context) {
    if (!this.store) {
      return { answered: false, reason: 'no_knowledge_store' };
    }
    const result = this.store.answerQuestion(step.params.question);
    return {
      answered: result.status === 'answered',
      answer: result.answer,
      span: result.span,
      source: result.span?.sourceId,
      reason: result.reason
    };
  }

  _finish(success, status, extra) {
    return {
      success,
      status,
      ...extra,
      timestamp: new Date().toISOString(),
      agentVersion: 'synora-agent/1.0'
    };
  }
}
