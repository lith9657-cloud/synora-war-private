/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { TaintedValue } from './taint.mjs';

function sha256(str) {
  return crypto.createHash('sha256').update(str).digest('hex');
}

function fdRealPath(fd, fallbackPath) {
  const procPath = `/proc/self/fd/${fd}`;
  try { if (fs.existsSync(procPath)) return fs.realpathSync(procPath); } catch {}
  return fs.realpathSync(fallbackPath);
}

export class SafeToolRegistry {
  constructor(workspaceRoot) {
    this.workspaceRoot = path.resolve(workspaceRoot);
    this.backupDir = path.join(this.workspaceRoot, '.synora-backups');
    if (fs.existsSync(this.backupDir)) {
      const backupReal = fs.realpathSync(this.backupDir);
      if (backupReal !== this.workspaceRoot && !backupReal.startsWith(this.workspaceRoot + path.sep)) {
        throw new Error(`Backup directory symlink escape denied: ${backupReal}`);
      }
    }
    fs.mkdirSync(this.backupDir, { recursive: true });
    const backupReal = fs.realpathSync(this.backupDir);
    if (backupReal !== this.workspaceRoot && !backupReal.startsWith(this.workspaceRoot + path.sep)) {
      throw new Error(`Backup directory escaped workspace: ${backupReal}`);
    }
    this.auditLedger = [];
    this.allowedShellCommands = new Set(['echo']);
  }

  resolvePath(relPath) {
    if (TaintedValue.isTainted(relPath)) {
      throw new Error('Security Error: Tainted value cannot be used as a file path');
    }
    const cleanRel = String(relPath || '').replace(/\\/g, '/');
    if (cleanRel.normalize('NFC') !== cleanRel) throw new Error('Non-canonical Unicode path denied');
    const resolved = path.resolve(this.workspaceRoot, cleanRel);
    // Path traversal guard
    if (resolved !== this.workspaceRoot && !resolved.startsWith(this.workspaceRoot + path.sep)) {
      throw new Error(`Path traversal denied: ${relPath} escapes workspace ${this.workspaceRoot}`);
    }
    // Resolve every existing ancestor, including symlinked parent directories.
    // Checking only the leaf misses writes through a symlinked directory.
    let cursor = resolved;
    while (cursor !== this.workspaceRoot && cursor.startsWith(this.workspaceRoot + path.sep)) {
      if (fs.existsSync(cursor)) {
        const stat = fs.lstatSync(cursor);
        if (stat.isFile() && stat.nlink > 1) throw new Error(`Hard-linked file denied: ${cursor}`);
        const real = fs.realpathSync(cursor);
        if (real !== this.workspaceRoot && !real.startsWith(this.workspaceRoot + path.sep)) {
          throw new Error(`Symlink escape denied: ${cursor} points outside workspace to ${real}`);
        }
      }
      const parent = path.dirname(cursor);
      if (fs.existsSync(parent) && fs.statSync(parent).isDirectory()) {
        const leaf = path.basename(cursor);
        const folded = leaf.normalize('NFC').toLocaleLowerCase();
        const collision = fs.readdirSync(parent).find(name => name !== leaf && name.normalize('NFC').toLocaleLowerCase() === folded);
        if (collision) throw new Error(`Case/Unicode path collision denied: ${leaf} conflicts with ${collision}`);
      }
      cursor = parent;
    }
    const rootReal = fs.realpathSync(this.workspaceRoot);
    if (rootReal !== this.workspaceRoot) this.workspaceRoot = rootReal;
    return resolved;
  }

  logAction(action, details) {
    const prevHash = this.auditLedger.length > 0 ? this.auditLedger[this.auditLedger.length - 1].hash : '0'.repeat(64);
    const ts = Date.now();
    const canon = `${this.auditLedger.length}|${prevHash}|${ts}|${action}|${JSON.stringify(details)}`;
    const hash = sha256(canon);
    const entry = { index: this.auditLedger.length, prevHash, timestamp: ts, action, details, hash };
    this.auditLedger.push(entry);
    return entry;
  }

  backupFile(targetPath) {
    if (!fs.existsSync(targetPath)) return null;
    const content = fs.readFileSync(targetPath);
    const hash = sha256(content);
    const backupTarget = path.join(this.backupDir, hash);
    if (!fs.existsSync(backupTarget)) {
      fs.writeFileSync(backupTarget, content);
    }
    return hash;
  }

  restoreFile(targetPath, backupHash) {
    if (typeof backupHash !== 'string' || !/^[a-f0-9]{64}$/.test(backupHash)) throw new Error('Invalid backup hash');
    const target = path.isAbsolute(targetPath) ? path.relative(this.workspaceRoot, targetPath) : targetPath;
    const safeTarget = this.resolvePath(target);
    const backupTarget = path.join(this.backupDir, backupHash);
    const backupReal = fs.realpathSync(this.backupDir);
    if (backupReal !== this.workspaceRoot && !backupReal.startsWith(this.workspaceRoot + path.sep)) throw new Error('Backup directory escaped workspace');
    if (!fs.existsSync(backupTarget)) throw new Error(`Backup not found for hash: ${backupHash}`);
    fs.mkdirSync(path.dirname(safeTarget), { recursive: true });
    fs.copyFileSync(backupTarget, safeTarget);
    this.logAction('fs.restore', { path: target, backupHash });
  }

  detectWorkspaceEscape() {
    for (const entry of this.auditLedger) {
      const rel = entry.details?.path;
      if (typeof rel !== 'string') continue;
      const resolved = path.resolve(this.workspaceRoot, rel);
      if (resolved !== this.workspaceRoot && !resolved.startsWith(this.workspaceRoot + path.sep)) return true;
      if (!fs.existsSync(resolved)) continue;
      const real = fs.realpathSync(resolved);
      if (real !== this.workspaceRoot && !real.startsWith(this.workspaceRoot + path.sep)) return true;
    }
    return false;
  }

  readFile(relPath) {
    const p = this.resolvePath(relPath);
    if (!fs.existsSync(p)) throw new Error(`File not found: ${relPath}`);
    const fd = fs.openSync(p, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
    let content;
    try {
      const openedPath = fdRealPath(fd, p);
      if (openedPath !== this.workspaceRoot && !openedPath.startsWith(this.workspaceRoot + path.sep)) throw new Error(`Symlink race denied after open: ${openedPath}`);
      const stat = fs.fstatSync(fd);
      if (stat.nlink > 1) throw new Error(`Hard-linked file denied: ${relPath}`);
      if (stat.size > 2 * 1024 * 1024) throw new Error('Output size limit exceeded (>2MB)');
      content = fs.readFileSync(fd, 'utf-8');
    } finally { fs.closeSync(fd); }
    this.logAction('fs.read', { path: relPath, size: content.length });
    return TaintedValue.wrap(content, `file:${relPath}`);
  }

  writeFile(relPath, content, options = {}) {
    const p = this.resolvePath(relPath);
    const isOverwrite = fs.existsSync(p);

    if (options.dryRun) {
      this.logAction('fs.write:dryRun', { path: relPath, isOverwrite });
      return { status: 'dry_run_recorded', path: relPath };
    }

    if (isOverwrite && !options.confirmToken) {
      this.logAction('fs.write:blocked', { path: relPath, reason: 'overwrite_unconfirmed' });
      return { status: 'unconfirmed', reason: 'Overwrite requires explicit confirmToken' };
    }

    let backupHash = null;
    if (isOverwrite) {
      backupHash = this.backupFile(p);
    }

    fs.mkdirSync(path.dirname(p), { recursive: true });
    const parentReal = fs.realpathSync(path.dirname(p));
    if (parentReal !== this.workspaceRoot && !parentReal.startsWith(this.workspaceRoot + path.sep)) throw new Error(`Parent symlink escape denied: ${parentReal}`);
    const rawContent = TaintedValue.unwrap(content);
    const flags = fs.constants.O_WRONLY | (isOverwrite ? 0 : (fs.constants.O_CREAT | fs.constants.O_EXCL)) | (fs.constants.O_NOFOLLOW || 0);
    const fd = fs.openSync(p, flags, 0o600);
    try {
      const openedPath = fdRealPath(fd, p);
      if (openedPath !== this.workspaceRoot && !openedPath.startsWith(this.workspaceRoot + path.sep)) throw new Error(`Symlink race denied after open: ${openedPath}`);
      const stat = fs.fstatSync(fd);
      if (stat.nlink > 1) throw new Error(`Hard-linked file denied after open: ${relPath}`);
      fs.ftruncateSync(fd, 0);
      fs.writeFileSync(fd, rawContent, 'utf-8');
      fs.fsyncSync(fd);
    } catch (err) {
      if (!isOverwrite) { try { fs.unlinkSync(p); } catch {} }
      throw err;
    } finally { fs.closeSync(fd); }
    this.logAction('fs.write', { path: relPath, backupHash });
    return { status: 'written', path: relPath, backupHash };
  }

  deleteFile(relPath, options = {}) {
    const p = this.resolvePath(relPath);
    if (!fs.existsSync(p)) return { status: 'not_found' };

    if (options.dryRun || !options.confirmToken) {
      this.logAction('fs.delete:dryRun', { path: relPath });
      return { status: 'dry_run_recorded', path: relPath, requiresConfirmation: true };
    }

    const backupHash = this.backupFile(p);
    fs.unlinkSync(p);
    this.logAction('fs.delete', { path: relPath, backupHash });
    return { status: 'deleted', path: relPath, backupHash };
  }

  list(relPath = '.') {
    const p = this.resolvePath(relPath);
    const entries = fs.readdirSync(p);
    this.logAction('fs.list', { path: relPath, count: entries.length });
    return entries;
  }

  runShell(cmd, args = [], options = {}) {
    if (!this.allowedShellCommands.has(cmd)) {
      throw new Error(`Shell command not in allowlist: ${cmd}`);
    }
    if (!Array.isArray(args)) {
      throw new Error('Shell arguments must be provided as an array (no shell interpolation)');
    }
    for (const a of args) {
      if (TaintedValue.isTainted(a)) {
        throw new Error('Security Error: Tainted value cannot be passed as shell argument');
      }
    }

    return new Promise((resolve, reject) => {
      const child = spawn(cmd, args, {
        cwd: this.workspaceRoot,
        shell: false, // Strict: no shell execution to prevent injection
        timeout: options.timeoutMs || 5000
      });

      let stdout = '';
      let stderr = '';
      child.stdout.on('data', d => { stdout += d; });
      child.stderr.on('data', d => { stderr += d; });

      child.on('close', code => {
        this.logAction('shell.run', { cmd, args, exitCode: code });
        resolve({
          exitCode: code,
          stdout: TaintedValue.wrap(stdout, 'stdout'),
          stderr: TaintedValue.wrap(stderr, 'stderr')
        });
      });

      child.on('error', err => {
        reject(err);
      });
    });
  }
}
