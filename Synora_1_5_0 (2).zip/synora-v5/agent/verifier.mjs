/**
 * @license SPDX-License-Identifier: Apache-2.0
 *
 * Synora Agent Verifier — verifies that a step's output matches expectations.
 *
 * For programming tasks: executes the synthesized code in the sandbox and
 * checks the output against test cases.
 * For knowledge tasks: checks that the answer has a valid span + provenance.
 *
 * The verifier is the LAST line of defense against hallucination: if the
 * output doesn't pass verification, the agent reports failure honestly.
 */
import { evalAst, deepEqual } from '../synthesis/dsl.mjs';

/**
 * Verify a synthesis step result.
 *
 * @param {object} step — the step that was executed
 * @param {object} result — the execution result
 * @param {object} context — { testCases?: [{input, output}], input?: any }
 * @returns {{ verified: boolean, passes: number, total: number, reason?: string }}
 */
export function verifyStep(step, result, context = {}) {
  if (step.operation === 'synthesize') {
    // Programming task: execute the AST on test cases
    if (!result.ast && !step.params?.ast) {
      return { verified: false, passes: 0, total: 0, reason: 'no_ast' };
    }
    const ast = result.ast || step.params.ast;
    const testCases = context.testCases || [];
    if (!testCases.length) {
      // No test cases — can't verify, but don't reject either
      return { verified: true, passes: 0, total: 0, reason: 'no_tests' };
    }
    let passes = 0;
    let failReason = null;
    for (const { input, output } of testCases) {
      try {
        const actual = evalAst(ast, input);
        if (deepEqual(actual, output)) {
          passes++;
        } else {
          failReason = `expected ${JSON.stringify(output)} got ${JSON.stringify(actual)}`;
          break;
        }
      } catch (err) {
        failReason = `execution error: ${err.message}`;
        break;
      }
    }
    return {
      verified: passes === testCases.length,
      passes,
      total: testCases.length,
      reason: failReason
    };
  }

  if (step.operation === 'query') {
    // Knowledge task: check answer has provenance
    if (!result.answered) {
      return { verified: false, passes: 0, total: 1, reason: result.reason || 'not_answered' };
    }
    // Answer must have a span (provenance)
    if (!result.span) {
      return { verified: false, passes: 0, total: 1, reason: 'no_provenance' };
    }
    return { verified: true, passes: 1, total: 1 };
  }

  if (step.operation === 'abstain') {
    // Abstention is always "verified" — it's an honest refusal
    return { verified: true, passes: 0, total: 0, reason: 'abstained' };
  }

  return { verified: false, passes: 0, total: 0, reason: 'unknown_operation' };
}
