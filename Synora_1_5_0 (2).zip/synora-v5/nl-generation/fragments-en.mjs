export const FRAGMENTS_EN = {
  openings: { warm: ["Great question!","I'm glad you asked that.","Let me help with that.","Here's what I know:","Happy to help."], formal: ["Regarding your query:","In response to your question:","Based on available knowledge:","The verified answer:"], confident: ["I know this one.","Absolutely.","Here's the precise answer.","I'm certain about this.","Verified knowledge:"] },
  delivery: { confident: ["The answer is {answer}.","It's {answer}.","{answer}.","The result: {answer}.","That would be {answer}."], learned: ["I just learned this: {answer}.","After searching, I found it's {answer}.","Found it: {answer}.","I looked it up: {answer}."] },
  evidence: ["(source: {source})","— according to {source}.","Source: {source}.","Verified from {source}."],
  closings: { confident: ["Anything else?","Feel free to ask more.","What else can I help with?","Ready for the next one."], humble: ["I hope that helps.","Please correct me if I'm wrong.","Let me know if you need more detail."], grateful: ["Thank you for helping me learn this.","I appreciate you expanding my knowledge.","Thanks — I won't forget this."] },
  searching: ["Let me search for that...","Searching my knowledge sources...","One moment — looking this up...","Let me check Wikipedia..."],
  learnedConfirmation: ["Got it — {answer}. I learned this from {source} and won't forget it.","Found it: {answer}. Thanks to {source}, I now know this permanently.","The answer is {answer}. I just learned it from {source} — ask me again anytime."]
};
