import { FRAGMENTS_EN } from './fragments-en.mjs';
import { FRAGMENTS_AR } from './fragments-ar.mjs';
function seededPick(seed, arr) { if (!arr?.length) return ''; let h=0; for(let i=0;i<seed.length;i++) h=((h<<5)-h+seed.charCodeAt(i))|0; return arr[Math.abs(h)%arr.length]; }
export function composeAnswer({answer,question,lang='en',persona={},source,justLearned=false}) {
  const F=lang==='ar'?FRAGMENTS_AR:FRAGMENTS_EN;
  const p={tone:'warm',...persona};
  const seed=question+'|'+p.tone;
  const opening=seededPick(seed+'o',F.openings[p.tone]||F.openings.warm);
  const pool=justLearned?F.delivery.learned:F.delivery.confident;
  const delivery=seededPick(seed+'d',pool).replace('{answer}',answer);
  const evidence=source?' '+seededPick(seed+'e',F.evidence).replace('{source}',source):'';
  const closing=seededPick(seed+'c',F.closings.confident);
  return [opening,delivery,evidence,closing].filter(s=>s&&s.trim()).join(' ').replace(/\s+/g,' ').replace(/\s+([.,؛؟!?])/g,'$1').trim();
}
export function composeSearching({question,lang='en'}) { const F=lang==='ar'?FRAGMENTS_AR:FRAGMENTS_EN; return seededPick(question+'s',F.searching); }
export function composeLearned({answer,question,lang='en',source}) { const F=lang==='ar'?FRAGMENTS_AR:FRAGMENTS_EN; const seed=question+'l'; return seededPick(seed,F.learnedConfirmation).replace('{answer}',answer).replace('{source}',source||'Wikipedia'); }
