import vm from 'node:vm';
import { parseRequest } from '../dialogue/index.mjs';

const templates = Object.freeze({
  'code.sum': {
    id: 'sum-array-v1', language: 'javascript',
    source: String.raw`export function solution(values) {
  if (!Array.isArray(values) || !values.every(Number.isFinite)) throw new TypeError("values must be an array of finite numbers");
  const total = values.reduce((sum, value) => sum + value, 0);
  if (!Number.isFinite(total)) throw new RangeError("sum overflowed finite numeric range");
  return total;
}`,
    tests: [{ input: [[1, 2, 3]], expected: 6 }, { input: [[]], expected: 0 }, { input: [[-2, 5]], expected: 3 }, { input: [[1, 'bad']], expectedError: 'TypeError' }, { input: [[1e308, 1e308]], expectedError: 'RangeError' }]
  },
  'code.max': {
    id: 'max-array-v1', language: 'javascript',
    source: String.raw`export function solution(values) {
  if (!Array.isArray(values) || values.length === 0 || !values.every(Number.isFinite)) throw new TypeError("values must be a non-empty array of finite numbers");
  return values.reduce((best, value) => value > best ? value : best, values[0]);
}`,
    tests: [{ input: [[1, 2, 3]], expected: 3 }, { input: [[-8, -2, -5]], expected: -2 }, { input: [[7]], expected: 7 }, { input: [[]], expectedError: 'TypeError' }, { input: [[1, Infinity]], expectedError: 'TypeError' }]
  },
  'code.factorial': {
    id: 'factorial-v1', language: 'javascript',
    source: String.raw`export function solution(n) {
  if (!Number.isSafeInteger(n) || n < 0 || n > 170) throw new RangeError("n must be a safe integer from 0 to 170");
  let result = 1;
  for (let i = 2; i <= n; i++) result *= i;
  return result;
}`,
    tests: [{ input: [0], expected: 1 }, { input: [1], expected: 1 }, { input: [5], expected: 120 }, { input: [7], expected: 5040 }, { input: [-1], expectedError: 'RangeError' }, { input: [171], expectedError: 'RangeError' }]
  },
  'code.reverse': {
    id: 'reverse-array-v1', language: 'javascript',
    source: String.raw`export function solution(values) {
  if (!Array.isArray(values) || !values.every(Number.isFinite)) throw new TypeError("values must be an array of finite numbers");
  return [...values].reverse();
}`,
    tests: [{ input: [[1, 2, 3]], expected: [3, 2, 1] }, { input: [[]], expected: [] }, { input: [[-2, 5]], expected: [5, -2] }, { input: [[1, 'bad']], expectedError: 'TypeError' }]
  },
  'code.sort': {
    id: 'sort-array-ascending-v1', language: 'javascript',
    source: String.raw`export function solution(values) {
  if (!Array.isArray(values) || !values.every(Number.isFinite)) throw new TypeError("values must be an array of finite numbers");
  return [...values].sort((left, right) => left - right);
}`,
    tests: [{ input: [[3, 1, 2]], expected: [1, 2, 3] }, { input: [[]], expected: [] }, { input: [[-2, 5, -1]], expected: [-2, -1, 5] }, { input: [[1, 'bad']], expectedError: 'TypeError' }]
  }
});

function sameExpected(actual, expected) {
  if (Object.is(actual, expected)) return true;
  return Array.isArray(actual) && Array.isArray(expected) && actual.length === expected.length && actual.every((value, index) => Object.is(value, expected[index]));
}

function evaluateTrustedTemplate(template, input) {
  // Only source strings defined in this module are evaluated. Arbitrary user source is never executed.
  const executable = template.source.replace(/^export\s+function\s+solution/, 'function solution') + '\nsolution';
  const context = vm.createContext(Object.create(null), { codeGeneration: { strings: false, wasm: false } });
  const fn = new vm.Script(executable, { filename: `${template.id}.trusted-template.js` }).runInContext(context, { timeout: 50 });
  return fn(...input);
}

export function generateSolution(requestOrText) {
  const request = typeof requestOrText === 'string' ? parseRequest(requestOrText) : requestOrText;
  const template = templates[request.intent];
  if (!template) return { ok: false, status: 'unsupported', reason: 'no-verified-template-for-intent', request };
  const results = [];
  for (const test of template.tests) {
    try {
      const actual = evaluateTrustedTemplate(template, test.input);
      results.push({ passed: !test.expectedError && sameExpected(actual, test.expected), input: test.input, expected: test.expectedError ? { throws: test.expectedError } : test.expected, actual });
    } catch (error) {
      results.push({ passed: Boolean(test.expectedError && error.name === test.expectedError), input: test.input, expected: test.expectedError ? { throws: test.expectedError } : test.expected, error: { name: error.name, message: String(error.message ?? error) } });
    }
  }
  const passed = results.filter(r => r.passed).length;
  return {
    ok: passed === results.length, status: passed === results.length ? 'tests-passed' : 'tests-failed',
    generated: { templateId: template.id, language: template.language, source: template.source, origin: 'verified-internal-template', arbitraryUserCodeExecuted: false },
    verification: { independence: 'template-self-tests-only; does not prove the template matches the user request', syntax: 'source-template-reviewed; export syntax removed only for internal execution', testsPassed: passed, testsTotal: results.length, cases: results },
    limits: ['Only the listed internal templates are generated.', 'The test harness evaluates trusted internal templates in a restricted vm context; this is not a security boundary for hostile JavaScript.', 'No arbitrary user-supplied source is executed.']
  };
}

export function listSolutionTemplates() {
  return Object.entries(templates).map(([intent, t]) => ({ intent, id: t.id, language: t.language, testCount: t.tests.length }));
}
