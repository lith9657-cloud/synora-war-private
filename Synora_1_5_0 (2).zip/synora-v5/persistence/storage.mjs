/** @license SPDX-License-Identifier: Apache-2.0 */
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
import { EventLedger } from './event-ledger.mjs';

export class JsonStorageAdapter {
  constructor(baseDir) {
    this.baseDir = baseDir;
    fs.mkdirSync(baseDir, { recursive: true });
    this.ledger = new EventLedger(path.join(baseDir, 'events.jsonl'));
  }
  #target(collection, id) {
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(collection) || !/^[a-zA-Z0-9_.-]{1,128}$/.test(id) || id === '.' || id === '..') throw new TypeError('invalid storage key');
    return path.join(this.baseDir, collection, `${id}.json`);
  }
  async set(collection, id, data) {
    const target = this.#target(collection, id);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const tmp = `${target}.${process.pid}.${Date.now()}.tmp`;
    const fd = fs.openSync(tmp, 'wx', 0o600);
    try { fs.writeFileSync(fd, JSON.stringify(data)); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    fs.renameSync(tmp, target);
    this.ledger.append({ action: 'set', collection, id, data });
    return true;
  }
  async get(collection, id) {
    const target = this.#target(collection, id);
    if (!fs.existsSync(target)) return null;
    return JSON.parse(fs.readFileSync(target, 'utf8'));
  }
  async delete(collection, id) {
    const target = this.#target(collection, id);
    if (!fs.existsSync(target)) return false;
    fs.unlinkSync(target);
    this.ledger.append({ action: 'delete', collection, id });
    return true;
  }
  async list(collection) {
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(collection)) throw new TypeError('invalid collection');
    const dir = path.join(this.baseDir, collection);
    return fs.existsSync(dir) ? fs.readdirSync(dir).filter(f => f.endsWith('.json')).map(f => f.slice(0, -5)).sort() : [];
  }
  backup(destPath) { this.ledger.backup(destPath); }
  restore(srcPath) { this.ledger.restore(srcPath); }
}

export class SqliteStorageAdapter {
  constructor(dbPath) {
    this.dbPath = dbPath || ':memory:';
    this.fallback = null;
    try {
      const { DatabaseSync } = requireNodeSqlite();
      if (this.dbPath !== ':memory:') fs.mkdirSync(path.dirname(path.resolve(this.dbPath)), { recursive: true });
      this.db = new DatabaseSync(this.dbPath);
      this.db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; CREATE TABLE IF NOT EXISTS synora_schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP); CREATE TABLE IF NOT EXISTS synora_kv (collection TEXT NOT NULL, id TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY(collection,id)); INSERT OR IGNORE INTO synora_schema_migrations(version) VALUES(1);');
    } catch (err) {
      if (err?.code !== 'ERR_UNKNOWN_BUILTIN_MODULE' && !/Cannot find module|not supported/i.test(err?.message || '')) throw err;
      const fallbackDir = this.dbPath === ':memory:' ? fs.mkdtempSync(path.join(process.cwd(), '.synora-sqlite-fallback-')) : `${this.dbPath}.json-fallback`;
      this.fallback = new JsonStorageAdapter(fallbackDir);
      this.fallbackReason = 'node:sqlite unavailable; persistent JSON fallback';
    }
  }
  async set(collection, id, data) {
    if (this.fallback) return this.fallback.set(collection, id, data);
    this.db.prepare('INSERT INTO synora_kv(collection,id,value) VALUES(?,?,?) ON CONFLICT(collection,id) DO UPDATE SET value=excluded.value').run(collection, id, JSON.stringify(data));
    return true;
  }
  async get(collection, id) {
    if (this.fallback) return this.fallback.get(collection, id);
    const row = this.db.prepare('SELECT value FROM synora_kv WHERE collection=? AND id=?').get(collection, id);
    return row ? JSON.parse(row.value) : null;
  }
  async delete(collection, id) {
    if (this.fallback) return this.fallback.delete(collection, id);
    return this.db.prepare('DELETE FROM synora_kv WHERE collection=? AND id=?').run(collection, id).changes > 0;
  }
  async list(collection) {
    if (this.fallback) return this.fallback.list(collection);
    return this.db.prepare('SELECT id FROM synora_kv WHERE collection=? ORDER BY id').all(collection).map(r => r.id);
  }
  close() { this.db?.close(); }
}

function requireNodeSqlite() {
  // node:sqlite is synchronously loaded by createRequire to keep the adapter's construction synchronous.
  return require('node:sqlite');
}

export class PostgresStorageAdapter {
  constructor(options = {}) {
    if (!options || typeof options.query !== 'function') throw new TypeError('Postgres adapter requires an injected pg-compatible client with query(sql, params)');
    this.client = options;
    this.ready = (async () => { await this.client.query('CREATE TABLE IF NOT EXISTS synora_schema_migrations (version INTEGER PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP)'); await this.client.query('CREATE TABLE IF NOT EXISTS synora_kv (collection TEXT NOT NULL, id TEXT NOT NULL, value JSONB NOT NULL, PRIMARY KEY(collection,id))'); await this.client.query('INSERT INTO synora_schema_migrations(version) VALUES(1) ON CONFLICT(version) DO NOTHING'); })();
  }
  async set(collection, id, data) {
    await this.ready;
    await this.client.query('INSERT INTO synora_kv(collection,id,value) VALUES($1,$2,$3::jsonb) ON CONFLICT(collection,id) DO UPDATE SET value=EXCLUDED.value', [collection, id, JSON.stringify(data)]);
    return true;
  }
  async get(collection, id) {
    await this.ready;
    const r = await this.client.query('SELECT value FROM synora_kv WHERE collection=$1 AND id=$2', [collection, id]);
    return r.rows?.[0]?.value ?? null;
  }
  async delete(collection, id) {
    await this.ready;
    const r = await this.client.query('DELETE FROM synora_kv WHERE collection=$1 AND id=$2', [collection, id]);
    return (r.rowCount || 0) > 0;
  }
  async list(collection) {
    await this.ready;
    const r = await this.client.query('SELECT id FROM synora_kv WHERE collection=$1 ORDER BY id', [collection]);
    return (r.rows || []).map(x => x.id);
  }
  async close() { if (typeof this.client.end === 'function') await this.client.end(); }
}

export function createStorage(type = 'json', location = '') {
  switch (type) {
    case 'sqlite': return new SqliteStorageAdapter(location || ':memory:');
    case 'postgres': return new PostgresStorageAdapter(location);
    case 'json':
    default: return new JsonStorageAdapter(location || path.join(process.cwd(), 'data'));
  }
}
