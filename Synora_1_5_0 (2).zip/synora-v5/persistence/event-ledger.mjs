/** @license SPDX-License-Identifier: Apache-2.0 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const ZERO_HASH = '0'.repeat(64);
const WAIT_CELL = new Int32Array(new SharedArrayBuffer(4));
const sha256 = str => crypto.createHash('sha256').update(str).digest('hex');

export class EventLedger {
  constructor(filePath, options = {}) {
    this.filePath = filePath;
    this.lockPath = `${filePath}.lock`;
    this.lockTimeoutMs = options.lockTimeoutMs ?? 8000;
    this.events = [];
    this.load();
  }

  load() {
    if (!fs.existsSync(this.filePath)) { this.events = []; return; }
    const raw = fs.readFileSync(this.filePath, 'utf8');
    const lines = raw.split('\n');
    const hasFinalNewline = raw.endsWith('\n');
    const parsed = [];
    let expectedPrev = ZERO_HASH;
    let validBytes = 0;
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (!line) { if (i < lines.length - 1) validBytes++; continue; }
      let ev;
      try { ev = JSON.parse(line); }
      catch {
        // Only a malformed, unterminated final record is treated as a crash-torn append.
        if (i === lines.length - 1 && !hasFinalNewline) fs.truncateSync(this.filePath, validBytes);
        break;
      }
      if (ev.prevHash !== expectedPrev) break; // hash-chain mismatch is corruption, never auto-heal it
      const canon = `${ev.index}|${ev.prevHash}|${ev.timestamp}|${JSON.stringify(ev.payload)}`;
      if (sha256(canon) !== ev.hash || ev.index !== parsed.length) break;
      parsed.push(ev);
      expectedPrev = ev.hash;
      validBytes += Buffer.byteLength(line) + 1;
    }
    this.events = parsed;
  }

  #acquireLock() {
    const deadline = Date.now() + this.lockTimeoutMs;
    while (Date.now() < deadline) {
      try {
        const fd = fs.openSync(this.lockPath, 'wx', 0o600);
        fs.writeFileSync(fd, String(process.pid));
        fs.fsyncSync(fd);
        return fd;
      } catch (err) {
        if (err.code !== 'EEXIST') throw err;
        try {
          const pid = Number(fs.readFileSync(this.lockPath, 'utf8'));
          if (Number.isInteger(pid) && pid > 0) {
            try { process.kill(pid, 0); }
            catch (probe) { if (probe.code === 'ESRCH') fs.unlinkSync(this.lockPath); }
          } else if (Date.now() - fs.statSync(this.lockPath).mtimeMs > 2000) fs.unlinkSync(this.lockPath);
        } catch (probe) { if (probe.code === 'ENOENT') continue; }
        Atomics.wait(WAIT_CELL, 0, 0, 10);
      }
    }
    throw new Error(`Timed out acquiring event ledger lock: ${this.lockPath}`);
  }

  append(payload) {
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    const lockFd = this.#acquireLock();
    try {
      // Re-read while holding the process lock so independent writers extend one chain.
      this.load();
      const index = this.events.length;
      const prevHash = index ? this.events[index - 1].hash : ZERO_HASH;
      const timestamp = Date.now();
      const canon = `${index}|${prevHash}|${timestamp}|${JSON.stringify(payload)}`;
      const event = { index, prevHash, timestamp, payload, hash: sha256(canon) };
      const fd = fs.openSync(this.filePath, 'a', 0o600);
      try { fs.writeSync(fd, JSON.stringify(event) + '\n'); fs.fsyncSync(fd); }
      finally { fs.closeSync(fd); }
      this.events.push(event);
      return event;
    } finally {
      fs.closeSync(lockFd);
      try { fs.unlinkSync(this.lockPath); } catch {}
    }
  }

  verify() {
    let prev = ZERO_HASH;
    for (let i = 0; i < this.events.length; i++) {
      const ev = this.events[i];
      if (ev.index !== i || ev.prevHash !== prev) return false;
      if (sha256(`${ev.index}|${ev.prevHash}|${ev.timestamp}|${JSON.stringify(ev.payload)}`) !== ev.hash) return false;
      prev = ev.hash;
    }
    return true;
  }

  backup(destPath) {
    fs.mkdirSync(path.dirname(destPath), { recursive: true });
    if (!fs.existsSync(this.filePath)) fs.writeFileSync(destPath, '', { mode: 0o600 });
    else fs.copyFileSync(this.filePath, destPath);
    const fd = fs.openSync(destPath, 'r'); try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  }

  restore(srcPath) {
    if (!fs.existsSync(srcPath)) throw new Error(`Backup file not found: ${srcPath}`);
    const candidate = new EventLedger(srcPath);
    if (!candidate.verify()) throw new Error('Backup ledger failed integrity verification');
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    fs.copyFileSync(srcPath, this.filePath);
    this.load();
  }
}
