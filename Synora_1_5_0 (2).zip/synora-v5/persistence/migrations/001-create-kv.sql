-- Migration 001: common key/value storage contract
CREATE TABLE IF NOT EXISTS synora_kv (
  collection TEXT NOT NULL,
  id TEXT NOT NULL,
  value TEXT NOT NULL,
  PRIMARY KEY (collection, id)
);
