import { spawn, spawnSync } from 'node:child_process';
import process from 'node:process';
const PERMISSION_FLAG = (() => {
  for (const flag of ['--permission', '--experimental-permission']) {
    try { const res = spawnSync(process.execPath, [flag, '-e', 'process.exit(0)'], { stdio: 'ignore' }); if (res.status === 0) return flag; } catch (_) {}
  }
  return null;
})();
export function runInWorkerSandbox(code, args = [], options = {}) {
  const timeoutMs = options.timeoutMs || 1000;
  const memoryCapMb = options.memoryCapMb || 64;
  return new Promise((resolve) => {
    const runnerScript = `const fs=undefined;const child_process=undefined;const net=undefined;const http=undefined;const https=undefined;const vm=require('node:vm');Object.freeze(Object.prototype);Object.freeze(Function.prototype);Object.freeze(Array.prototype);let buffer='';process.stdin.on('data',chunk=>{buffer+=chunk;});process.stdin.on('end',async()=>{try{const req=JSON.parse(buffer);const sandbox=Object.create(null);sandbox.argsJSON=JSON.stringify(req.args);const context=vm.createContext(sandbox,{codeGeneration:{strings:false,wasm:false}});// Freeze prototypes INSIDE the VM context too
const ctxObj=context.Object;const ctxFn=context.Function;const ctxArr=context.Array;if(ctxObj)Object.freeze(ctxObj.prototype);if(ctxFn)Object.freeze(ctxFn.prototype);if(ctxArr)Object.freeze(ctxArr.prototype);const wrapped='(async function(){const args=JSON.parse(argsJSON);\\n'+req.code+'\\n})';const fn=new vm.Script(wrapped,{filename:'synora-user-code',importModuleDynamically:()=>Promise.reject(new Error('Dynamic imports are disabled'))}).runInContext(context,{timeout:${timeoutMs}});const result=await fn();process.stdout.write(JSON.stringify({status:'ok',result}));process.exit(0);}catch(err){process.stdout.write(JSON.stringify({status:'error',error:err.message||String(err)}));process.exit(0);}});`;
    const workerArgs = [`--max-old-space-size=${memoryCapMb}`];
    if (PERMISSION_FLAG) workerArgs.push(PERMISSION_FLAG);
    workerArgs.push('--disable-proto=throw', '-e', runnerScript);
    const child = spawn(process.execPath, workerArgs, { stdio: ['pipe', 'pipe', 'pipe'], env: { NODE_ENV: 'production' } });
    let stdout='';let stderr='';let killed=false;
    const timer=setTimeout(()=>{killed=true;child.kill('SIGKILL');resolve({status:'timeout',error:'Execution timed out'});},timeoutMs);
    child.stdout.on('data',chunk=>{stdout+=chunk;});
    child.stderr.on('data',chunk=>{stderr+=chunk;});
    child.on('close',(code,signal)=>{clearTimeout(timer);if(killed)return;if(signal==='SIGKILL'||signal==='SIGTERM'){resolve({status:'killed',error:`killed:${signal}`});return;}if(code!==0&&!stdout){resolve({status:'crash',error:stderr||`exit ${code}`});return;}try{resolve(JSON.parse(stdout));}catch{resolve({status:'error',error:stderr||'parse error'});}});
    child.stdin.write(JSON.stringify({code,args}));
    child.stdin.end();
  });
}
