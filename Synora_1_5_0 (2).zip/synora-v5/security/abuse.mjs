/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import crypto from 'node:crypto';

export class AbuseProtection {
  constructor(options = {}) {
    this.rateLimitWindowMs = options.rateLimitWindowMs || 60_000;
    this.maxRequestsPerWindow = options.maxRequestsPerWindow || 60;
    this.maxDailyQuota = options.maxDailyQuota || 1000;
    this.maxPayloadBytes = options.maxPayloadBytes || 64 * 1024; // 64 KB cap
    this.clientHits = new Map(); // clientId -> [timestamps]
    this.dailyUsage = new Map(); // clientId:day -> count
    this.anonymousBlockedTools = new Set(['shell.run', 'fs.write', 'fs.delete', 'fs.move']);
  }

  checkRateLimit(clientId) {
    const now = Date.now();
    const hits = (this.clientHits.get(clientId) || []).filter(ts => now - ts < this.rateLimitWindowMs);
    if (hits.length >= this.maxRequestsPerWindow) {
      return { allowed: false, reason: 'rate_limit_exceeded' };
    }
    hits.push(now);
    this.clientHits.set(clientId, hits);

    // Check daily quota
    const today = new Date().toISOString().slice(0, 10);
    const dayKey = `${clientId}:${today}`;
    const usage = (this.dailyUsage.get(dayKey) || 0) + 1;
    if (usage > this.maxDailyQuota) {
      return { allowed: false, reason: 'daily_quota_exceeded' };
    }
    this.dailyUsage.set(dayKey, usage);

    return { allowed: true };
  }

  checkPayloadSize(payloadString) {
    const bytes = Buffer.byteLength(payloadString || '', 'utf-8');
    if (bytes > this.maxPayloadBytes) {
      return { allowed: false, reason: 'payload_too_large', bytes, cap: this.maxPayloadBytes };
    }
    return { allowed: true, bytes };
  }

  isToolAllowed(toolName, isAnonymous = true) {
    if (isAnonymous && this.anonymousBlockedTools.has(toolName)) {
      return { allowed: false, reason: 'anonymous_tool_forbidden' };
    }
    return { allowed: true };
  }

  generateProofOfWork(difficulty = 3) {
    const challenge = crypto.randomBytes(16).toString('hex');
    return { challenge, difficulty };
  }

  verifyProofOfWork(challenge, nonce, difficulty = 3) {
    const hash = crypto.createHash('sha256').update(`${challenge}:${nonce}`).digest('hex');
    const prefix = '0'.repeat(difficulty);
    return hash.startsWith(prefix);
  }
}
